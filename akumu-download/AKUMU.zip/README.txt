AKUMU — 1986 RECEPTION

Extract this ZIP and open index.html in a current desktop browser. Choose PLAY, NORMAL or DEMO, sign the guestbook, then CHECK IN. All game assets are embedded.

Developer shortcuts appear only at index.html?debug (or /games/akumu/?debug on a server). ROOM 2 / TEST and ROOM 3 / TEST retain their existing destinations.

To host inside another application, serve index.html as text/html at a static subdirectory such as /games/akumu/. No server backend, CDN, paid API, account or secret key is needed. WebGL2 and browser audio support are required. For an iframe, allow pointer-lock, scripts and same-origin access as needed by the host sandbox. A direct browser tab is simplest.

App file previews can block JavaScript or WebGL. On iPad, host it as a webpage and open the URL in Safari. Physical iPad testing and hardware FPS were not measured; see REPORT.md for the actual desktop/touch checks and limitations.

Keep the bundled Three.js MIT license with distributed copies.
