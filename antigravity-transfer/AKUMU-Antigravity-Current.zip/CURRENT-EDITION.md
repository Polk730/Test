# Current development project edition

This smaller ZIP contains the complete current editable source and runtime assets, tests and fixtures, feature reports, available original uploads, user skill, and latest playable HTML. Open akumu/ in Antigravity; run npm ci and npm run dev.

It omits historical builds/backups, generated dist/, Atlas duplicate exports and QA screenshots to keep the transfer small. Those are in AKUMU-Antigravity-Complete.zip. The accompanying handoff document describes that larger archive; history/, integration/ and screenshot folders are absent in this edition. No current game content was removed. Build dist/ with npm run build.
