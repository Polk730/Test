# AKUMU v2.0 — Performance report

Final HTML SHA256: `85b7db1d18aaaf58406c43e46f35df8f5f19a49e3b75702f7132ccf5f6181ba4`. Original backup SHA256: `423d59e50b1211c7ba2ec48ad5d80d0fd7032358bf4ab22074763e34f8ceb121`.

Environment: Linux headless Chromium, ANGLE SwiftShader software Vulkan, viewport 1000×700, DPR 0.5, actual render 500×350 in every compared view. These are software-renderer diagnostics, not Mac M3, school-PC GPU or iPad results. Baseline and final use 8-second warmup and nominal 12-second RAF sampling. Short samples and severe stalls prevent a reliable statistical 1% low or a general FPS verdict.

## Rendering resources

| View | Draw calls before → v2 | Triangles | Texture objects | Geometry objects |
|---|---:|---:|---:|---:|
| bedroom / main | 110 → 79 | 27,924 → 27,924 | 31 → 32 | 181 → 150 |
| storage / main | 71 → 71 | 13,312 → 13,312 | 67 → 62 | 240 → 209 |
| observation / main | 52 → 52 | 6,030 → 6,388 | 59 → 61 | 232 → 211 |
| observation / live | 67 → 67 | 7,128 → 7,746 | 62 → 64 | 239 → 218 |

The bedroom submits 31 fewer draws (28.2%) with the same triangle count. Static bed/equipment batching preserves targets and bounds. Storage reuses fewer texture/geometry objects. New cassette detail adds a small number of triangles; original CCTV resolution/update cap remain unchanged. Object counts are not GPU allocation bytes. Exact GPU memory is UNVERIFIED.

## Measured frame-time diagnostics — not a hardware performance pass

| View | Samples before → v2 | Mean FPS | Mean frame ms | Observed p99 ms |
|---|---:|---:|---:|---:|
| bedroom / main | 40 → 2 | 3.328 → 0.083 | 300.470 → 12053.900 | 699.900 → 17382.600 |
| storage / main | 16 → 39 | 1.249 → 3.132 | 800.931 → 319.256 | 1433.300 → 783.300 |
| observation / main | 81 → 87 | 6.744 → 7.236 | 148.283 → 138.198 | 266.700 → 266.500 |
| observation / live | 60 → 61 | 4.981 → 5.060 | 200.770 → 197.636 | 316.600 → 333.200 |

The final bedroom sample contains only two frames and very large stalls: its FPS estimate is UNVERIFIED for steady-state use. It is retained above rather than concealed. Storage and Observation samples are larger, but the test environment varied strongly across runs. No universal FPS improvement, reliable 1% low, or hardware 60 FPS desktop / 30 FPS mobile result is claimed. CPU submission timings are not GPU timings. Isolated GPU/shader compilation time is UNVERIFIED.

## Startup and texture generation

| Fixture | Ready time before | Final ready time |
|---|---:|---:|
| bedroom | 29.139s | 19.829s |
| storage | 26.233s | 125.835s |
| observation | 23.063s | 25.775s |

Ready time measures navigation to the debug-ready flag, including JavaScript, surface generation and some initial compilation; it is not an isolated first-frame GPU measurement. The final storage launch was much slower in this run. Startup and frame pacing remain a performance limitation in this software environment; a supported hardware-GPU benchmark is needed before calling the overall performance target met.

A separate same-browser CPU fixture compared all 13 recipes and all 40,894,464 color/normal/packed-map bytes: exactly equal. The direct lattice-index optimization measured 2.053s → 1.547s (24.6% less generation time) in that fixture. This is a component measurement, not a promise of that percentage off game load time or higher FPS.

CCTV remains 512×320, capped at the original 10 Hz. Measured CPU submission time: 12.244 → 12.013 ms. No content, camera or scripted activation timing changed.

## Decisions based on measurements

- Rejected scene-wide reflections: they flattened lighting and added cost. Only a small original generated probe remains on bare-metal materials.
- Rejected the compressed byte-atlas experiment; it showed no dependable benefit and was removed.
- Removed low-value per-material AO sampling and reflections on rough coated metal. Existing local contact occlusion and physical shadow casters remain.
- Shared 13 texture recipes rather than creating equivalent room-specific maps; reused packed roughness/metal channels.
- Eliminated per-sample function creation and repeated wrapping operations in the texture generator, with complete byte-equality verification.
- No bloom, fullscreen SSAO, extra compositor or particle pass was added. HIGH/MEDIUM/LOW affect graphics resolution only; gameplay, audio and CCTV clocks are unchanged.

Raw data and actual test logs are in `qa-v2/`. Hardware performance targets, physical mobile performance, exact GPU memory and a representative long-run 1% low remain **UNVERIFIED**.
