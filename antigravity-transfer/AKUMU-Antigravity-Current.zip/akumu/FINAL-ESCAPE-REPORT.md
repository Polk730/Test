# AKUMU — final Room 2 puzzle and escape update

## 1. Files changed
- `src/storage-envelope.js`: add a separately textured letter reverse and flip operation; keep original front text, envelope address and location.
- `src/computer-stage.js`, `src/computer-interface.js`, `index.html`: unlock a read-only Stage 4 message after Stage 3 and add the inspection FLIP button.
- `src/storage-escape.js` (new): Stage 3-only box opening, separate wrench collection and elevation/tool/placement checks for the vent.
- `src/storage-computer.js`: hollow opened-box geometry, simple folded lid, visible wrench and independent cavity target. Reuse the existing movement, glow and stacking implementation. A constant pickup hit volume preserves reach when the visible body becomes hollow, while the separate cavity target selects the wrench first when aiming inside.
- `src/storage-room.js`: register a target on the existing grille.
- `src/main.js`: route flip/open/pickup/wrench/vent actions through existing controls; hide the old completion-time text for the requested Room 2 ending.
- `src/style.css`: match FLIP to the existing envelope button.
- Tests/package scripts, README, validation/report files and regenerated HTML/downloads.

No Room 1 puzzle, recording, event, architecture, lighting, aisle label, inventory ID, movement or stacking-runtime file was changed. Stages 1–3 retain their puzzles/answers and rewards; only Stage 4 progression metadata is extended.

## 2. Letter flipping
Opening the same envelope enables FLIP in the existing inspection toolbar. FLIP switches between front and reverse, resetting inspection rotation to the selected side; drag/zoom remain available. The exact existing front text and original first-read narrator trigger remain. The reverse reads HE IS LISTENING on aged paper. Closing returns to gameplay; subsequent inspections can flip again. No progression requirement gates the reverse.

## 3. Stage 4
Stage 3 immediately makes Stage 4 available. It contains only AKUMU SYSTEM — STAGE 04, FINAL MESSAGE, Think inside the box., END OF MESSAGE and the normal menu/exit controls. There is no new puzzle, input, voice or completion requirement. Players can open boxes before ever reading it.

## 4. Box opening and carrying
Before Stage 3, previously unlocked boxes carry as before and cannot open. After Stage 3, one E/left-click/touch INTERACT opens a closed box and returns immediately, without picking it up. A later interaction on its wooden body carries the opened box. The same three existing boxes retain glows, outlines, supports, placement checks, step surfaces and stacking collision. Supporting bases cannot move until boxes above are lifted. Boxes 2/3 are empty.

## 5. Wrench collection
Box 1 reveals its one reserved wrench. An independent, generous target inside its cavity collects only the wrench; wooden walls remain the box's carry target. Collection requires Stage 3, opened Box 1 and no box being carried. The tool enters the existing player tool state (`puzzle.state.wrench = 'carried'`), disappears from the box and is never included in drop logic. No spare wrench or extra finding puzzle was added.

## 6. Ventilation escape
The existing high grille receives an interaction target. Eligibility requires completed Stage 3, the collected wrench, all three designated boxes placed on floor/stack, feet at least 1.08 m above the floor and proximity to the vent. Thus floor-level activation and no-wrench activation fail. The existing marked arrangement—Box 1 as first step, Box 3 atop Box 2—supports walking up with unchanged keyboard/joystick controls. One interaction opens the existing hinged grille; a second confirms escape. No alternative platform, ladder, code or tool was added.

## 7. Ending
Escape uses the existing fade-to-black route without narrator audio. Only TO BE CONTINUED... appears at the center; the prior elapsed-time ending text is suppressed for Room 2. No credits, extra scene, replay, anvil or glitch character was added.

## 8. Tests and review
All 44 unit checks and both final builds passed. The full desktop/touch browser route verified letter opening/flipping/reinspection and original voice trigger, exact front-text preservation, Stage 1–4 progression, opening without pickup, open-box carry/restack, separate wrench pickup, real stair climbing, no-wrench/floor rejection, grille opening and the exact black-screen ending. The final-geometry desktop/touch fixture additionally verified three wrench aim angles, actual left-click/touch collection, opened Box 1 pickup/drop without losing the tool, and climbing/escaping with lids folded clear. Screenshots of the letter, hint, final wrench view, reached grille and ending were inspected. No uncaught page errors. The unchanged full Room 1 playthrough and all optional voice/scare suites were not rerun. See the latest final-escape entry in VALIDATION.md for visual corrections and test-fixture details. Physical iPad/Safari and school-computer GPU performance require device testing; Chromium touch emulation does not establish those results.

## 9. Remaining problems
No known blocking problem remained in the executed checks. Physical-device compatibility/performance remains unverified; no new ending/story mechanics are implemented beyond the requested fade and text.
