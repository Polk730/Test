# AKUMU — Stage 2 assistance

## 1. Files modified
- New `src/stage-two-assistance.js`: one 300-second deadline, persistent availability, cancellation and one-shot announcement state.
- New `src/assets/attention-assistance.mp3`: exact supplied recording, copied byte-for-byte.
- `src/computer-stage.js`: start assistance on successful Stage 1 completion; finish/cancel pending assistance on successful Stage 2 completion. Existing answer validation and rewards remain unchanged.
- `src/main.js`: prepare the recording through the existing loader, update assistance independently of the PC view and request playback only in visible, unpaused Room 2 gameplay/inspection/computer states.
- `src/audio.js`: use the existing voice/caption channel for the supplied announcement.
- `src/computer-interface.js`, `index.html`: Stage 2-only HELP, exact assistance screen and BACK TO PUZZLE.
- `tests/stage-two-assistance.test.js`, `tests/stage-two-assistance.mjs`, `package.json`, README/VALIDATION/this report and regenerated downloads.

No room geometry, aisle/shelf/item IDs, letter, narrator recording, existing scare, box, wrench, grille, ending or control implementation was modified. Stage 3's hint remains “The letter...”.

## 2. Timer
Successful Stage 1 submission immediately starts a monotonic-clock deadline of exactly 300 seconds. The computer does not own or reset the clock: exploration, closing/reopening the PC and HELP navigation do not restart it. Pausing/backgrounding also does not reset the deadline; audio waits for visible, unpaused gameplay and a running audio context. No countdown is displayed.

Solving Stage 2 before expiry permanently cancels assistance, leaving HELP hidden. A late solve cancels any still-pending announcement while retaining already-activated HELP. An announcement already started is allowed to finish normally, with no replay. Production duration is always 300; browser checks inject a simulated clock rather than changing this constant.

## 3. MP3 loading and playback
The original 104,205-byte Attention Assistance.mp3 is embedded through the same inline-asset/build and OfflineAudioContext decoding path as existing recordings. Its source copy was verified byte-for-byte. Playback uses the existing voice bus at the default rate of 1; no replacement speech, pitch shift or time stretching is used. The existing shared-speech guard queues assistance behind other speech/cooldown. Only successful playback claims the one-shot flag. Reopening PC/HELP never requests another recording.

## 4. Captions
The existing subtitle element and audio-clock caption timings display exactly:

(PC) Attention. Assistance is now available. Please check the computer.

The caption begins with actual scheduled playback and ends at the decoded recording duration. No second caption layer is added. A failed/deferred playback request creates no assistance caption.

## 5. HELP
Before expiry, HELP is hidden. Once activated, it remains accessible on Stage 2 across PC reopen and late completion. Its green CRT screen uses the exact seven requested instructions and BACK TO PUZZLE. It contains no missing-item identity, answer, item ID or singled-out shelf. The return button preserves the typed answer and puzzle state. Other stages never display HELP.

## 6. Tests
All 48 unit checks, both final builds and all three browser scenarios passed. Desktop/touch late-assistance scenarios verified the 300-second boundary while exploring, no restart, queued speech, actual MP3 decoding/playback at normal rate, exact caption timing/removal, one-shot state, exact HELP text/no answer disclosure, BACK/input preservation, persistence and unchanged Box 2/Stage 3 rewards. The separate early-completion scenario verified permanent suppression of audio/caption/HELP at simulated 299.999 seconds, including after advancing beyond the deadline. The original asset copy was verified byte-for-byte. The HELP screenshot was reviewed. No uncaught page errors. Full results and clock-fixture details are recorded in the latest assistance entry in VALIDATION.md. No physical iPad/Safari or hardware performance claim follows from Chromium touch emulation. The unchanged full Room 1/vent escape and optional narrator/scare browser suites were not rerun for this scoped update.

## 7. Remaining limitations
Audio still depends on browser permission and an available running audio context. If playback is temporarily unavailable, HELP can activate while the announcement waits; no false caption is displayed. Existing speech is allowed to finish before the announcement starts. No additional puzzles, hints, objects, countdowns, dialogue or horror events were added.
