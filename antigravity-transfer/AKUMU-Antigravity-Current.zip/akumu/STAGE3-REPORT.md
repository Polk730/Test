# AKUMU — Stage 3 password recovery

## 1. Files changed
- `src/computer-stage.js`: fixed 13-letter tile pool and selection state, Stage 3 validation/completion, Stage 2→3 gating and permanent Box 3 access. Stage 1 generation/validation and Stage 2 answer validation are unchanged.
- `src/computer-interface.js`: clickable/touchable tiles, grouped answer slots, Backspace/Clear/Enter, results and existing screen/glow refresh callbacks.
- `index.html`, `src/style.css`: Stage 3 section within the existing green CRT interface, responsive tile pool and word slots. No physical computer or room changes.
- `tests/password-recovery.test.js`, `tests/password-recovery.mjs`: new state and browser regressions.
- `tests/inventory-stage-two.test.js`, `tests/inventory-stage-two.mjs`: update only Stage 3's expected availability after Stage 2.
- `tests/embedded-start.mjs`: additionally complete Stage 3 using touch in the restricted iframe.
- `package.json`: add Stage 3 checks/scripts. README, this report and VALIDATION updated; standalone/production builds and downloadable copies regenerated.

## 2. Implementation and progression
Stage 3 becomes selectable only after Stage 2. The existing terminal shows AKUMU SYSTEM — STAGE 03, PASSWORD RECOVERY, the exact hint “The message...” and one mixed pool. No letter, narrator recording, inventory label, room geometry, light, movement routine, horror event, transition or ending was edited. Stage 4 stays locked.

## 3. All 13 letters verified
Fixed order: N S E I L H E T S G I I N. Frequencies: H=1, E=2, I=3, S=2, L=1, T=1, N=2, G=1. Both state tests and actual browser tile checks verify the pool. No solution is supplied as a hint or preview.

## 4. Password input
Each tile has an independent index, so selecting one I/E/S/N leaves its duplicates available. Selected tiles become inactive. Answer slots form exactly 2 + 2 + 9 characters, separated by automatic visual word gaps; players never type spaces. BACKSPACE releases the last tile, CLEAR restores all tiles, ENTER requires all 13 selections. Incorrect input shows INVALID PASSWORD and allows unlimited retries. Only HEISLISTENING succeeds, displaying ACCESS GRANTED / STAGE 03 COMPLETE. Partial input and completion persist across closing/reopening in the current run; no new cross-session save system was added.

## 5. Box 3 and stacking
Completion uses the existing generic reward refresh to give Box 3 the same green glow, through-wall outline and carry permission. Boxes 1 and 2 remain unlocked permanently. The existing stacking implementation was reused without modification: supported bases cannot be moved until their top boxes are lifted, and all unlocked boxes can be repositioned/restacked. Box 1 stays closed and its hidden reserved wrench cannot be collected or used.

## 6. Stages 1 and 2
Their original random cipher/numeric validation and fixed 38C inventory validation remain intact. New browser checks solve both through the existing UI, including wrong-answer rejection, before Stage 3. Original Stage 1 sequence is retained. Only the intended progression metadata changes: Stage 2 now makes Stage 3 available.

## 7. Executed checks
All 42 unit checks, both standalone/production builds, the complete Stage 3 desktop/touch-emulated browser regression and the restricted-iframe touch regression passed. Browser checks solved the earlier stages, exercised all tile controls and wrong/correct answers, verified partial/completed persistence and performed actual three-box carry/stack/unstack/restack. Empty/completed CRT, stack and 390px portrait screenshots were reviewed. No uncaught page errors; embedded checks also reported no blocked-form errors. Full results are recorded in the latest Stage 3 entry in VALIDATION.md. Physical iPad/Safari and school-computer GPU performance are not implied by Chromium touch emulation. The unchanged full Room 1 playthrough and all optional voice-event browser suites were not rerun for this update.

## 8. Intentionally unfinished
Stage 4 stays locked and has no puzzle. Box 1 opening, collecting/using the wrench and a new ventilation escape are unimplemented. The existing ending is unchanged. No new narrator line, scare, penalty, timer, decoration or unrelated mechanic was added.
