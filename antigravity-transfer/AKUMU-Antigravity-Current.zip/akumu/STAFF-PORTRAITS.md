# Staff-corner portraits

Both PNGs from the uploaded ZIP are now wall-mounted above the Laundry Room coffee counter. The first supplied portrait is on the left and the added second portrait is on the right. Original image files are preserved byte-for-byte, without repainting or cropping the artwork.

Each has a recessed picture surface, raised solid mouldings using its original border pixels, visible wooden frame sides, rear spacers, a hanging wire/nail and soft contact shadow. Frames reuse the room materials and static batching. No lights, interactions, puzzles or dialogue were added.

Changed runtime files: new `src/staff-portraits.js`, two PNGs in `src/assets/`, `src/laundry-room.js` and a readiness await in `src/main.js`. Both images decode during NORMAL startup loading, before GPU texture/shader preparation. They remain embedded in the standalone HTML.

Verification performed: both builds passed; browser check decoded the exact dimensions (1100×1430 and 1194×1317), confirmed two decorative frames/no new targets, exercised the grille/drop into Laundry and captured front/angled/resized views with no page errors. Front and angled screenshots were visually inspected. Compiled program count stayed 148→148 on entry in this check. Two existing Laundry state/collision tests passed; preservation audit passed for 78 protected existing files and 29 unrelated main functions. Both source PNGs were compared against the ZIP contents and match exactly. No physical iPad or hardware FPS test was performed for this change.
