import {build} from 'vite';
import {Script} from 'node:vm';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
const result=await build({
 configFile:false,
 build:{write:false,minify:true,cssCodeSplit:false,lib:{entry:'src/main.js',name:'AKUMU',formats:['iife']},rollupOptions:{output:{inlineDynamicImports:true}}},
});
const outputs=(Array.isArray(result)?result:[result]).flatMap(r=>r.output);
const js=outputs.filter(o=>o.type==='chunk').map(o=>o.code).join('\n');
const css=outputs.filter(o=>o.type==='asset'&&o.fileName.endsWith('.css')).map(o=>o.source).join('\n');
let html=await readFile('index.html','utf8');
const license=await readFile('node_modules/three/LICENSE','utf8');
html=html.replace('<html',`<!-- Bundled Three.js license:\n${license}\n-->\n<html`);
html=html.replace(/<script type="module" src="\/src\/main.js"><\/script>/,'');
html=html.replace('</head>',()=>`<style>${css}</style></head>`);
html=html.replace('</body>',()=>`<script>${js.replace(/<\/script/gi,'<\\/script')}</script></body>`);
// Parse the final embedded script too: replacement metacharacters must never corrupt it.
new Script(html.slice(html.indexOf('<script>')+8,html.lastIndexOf('</script>')),{filename:'AKUMU.html'});
await mkdir('standalone',{recursive:true});
await writeFile('standalone/AKUMU.html',html);
console.log('Created standalone/AKUMU.html — open directly in a desktop browser.');
