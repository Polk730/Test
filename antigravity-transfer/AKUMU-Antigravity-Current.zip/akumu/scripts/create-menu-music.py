"""Original eight-bar spooky lo-fi loop: no external samples."""
import numpy as np
import wave
from pathlib import Path
sr=22050; beat=60/72; length=32*beat;n=round(sr*length)
rng=np.random.default_rng(207);mix=np.zeros((n,2))
def add(t,d,f,amp,pan=0,kind='keys'):
 count=round(sr*d);x=np.arange(count)/sr
 if kind=='keys':
  phase=2*np.pi*f*x+.004*np.sin(2*np.pi*3.6*x)
  v=(np.sin(phase)+.22*np.sin(phase*2)+.09*np.sin(phase*3))*np.exp(-x/1.8)*(1-np.exp(-x*65))
 elif kind=='kick':v=np.sin(2*np.pi*(43*x+40*(1-np.exp(-x*20))/20))*np.exp(-x*15)
 else:v=rng.normal(0,1,count);v=np.convolve(v,np.ones(5)/5,mode='same')*np.exp(-x*30)*(1-np.exp(-x*200))
 v*=amp*np.minimum(1,(d-x)*30);st=round(t*sr)
 for ch,g in enumerate([np.sqrt((1-pan)/2),np.sqrt((1+pan)/2)]):np.add.at(mix[:,ch],(st+np.arange(count))%n,v*g)
def hz(m):return 440*2**((m-69)/12)
for bar,chord in enumerate([[45,52,55,59,62],[45,52,55,59,62],[41,48,52,57,59],[41,48,52,57,59],[38,45,48,52,55],[38,45,48,52,55],[40,47,53,56,59],[40,47,53,56,59]]):
 for k,m in enumerate(chord):add(bar*4*beat+k*.035,4.5,hz(m),.065 if k else .095,(k-2)*.2)
 for b in [0,2.5]:add((bar*4+b)*beat,.45,0,.12,kind='kick')
 for b in [1,3]:add((bar*4+b)*beat+.018,.23,0,.038,.15,kind='noise')
 for b in [.5,1.5,2.5,3.5]:add((bar*4+b)*beat,.10,0,.012,-.25,kind='noise')
for b,m in [(2,76),(7,71),(10.5,74),(15,69),(18,72),(23,67),(26,68),(30,71)]:add(b*beat,2.8,hz(m),.028,.3)
# Quiet continuous tape bed and periodic wow; delays wrap seamlessly around the loop.
for ch in range(2):
 mix[:,ch]+=np.convolve(rng.normal(0,1,n),np.ones(9)/9,mode='same')*.0015
 mix[:,ch]+=np.roll(mix[:,ch],round(sr*beat*.75))*.16
mix*=.88+.025*np.sin(2*np.pi*np.arange(n)/n*4)[:,None]
mix=np.tanh(mix*1.2);mix*=.65/max(.65,np.max(np.abs(mix)))
p=Path('/tmp/akumu-menu-music.wav')
with wave.open(str(p),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype('<i2').tobytes())
print(p)
