"""Original 5x7 bitmap lettering for the name prompt, embedded locally."""
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
from pathlib import Path
patterns={
'A':'01110 10001 10001 11111 10001 10001 10001','B':'11110 10001 10001 11110 10001 10001 11110','C':'01111 10000 10000 10000 10000 10000 01111','D':'11110 10001 10001 10001 10001 10001 11110','E':'11111 10000 10000 11110 10000 10000 11111','F':'11111 10000 10000 11110 10000 10000 10000','G':'01111 10000 10000 10111 10001 10001 01111','H':'10001 10001 10001 11111 10001 10001 10001','I':'11111 00100 00100 00100 00100 00100 11111','J':'00111 00010 00010 00010 10010 10010 01100','K':'10001 10010 10100 11000 10100 10010 10001','L':'10000 10000 10000 10000 10000 10000 11111','M':'10001 11011 10101 10101 10001 10001 10001','N':'10001 11001 10101 10011 10001 10001 10001','O':'01110 10001 10001 10001 10001 10001 01110','P':'11110 10001 10001 11110 10000 10000 10000','Q':'01110 10001 10001 10001 10101 10010 01101','R':'11110 10001 10001 11110 10100 10010 10001','S':'01111 10000 10000 01110 00001 00001 11110','T':'11111 00100 00100 00100 00100 00100 00100','U':'10001 10001 10001 10001 10001 10001 01110','V':'10001 10001 10001 10001 10001 01010 00100','W':'10001 10001 10001 10101 10101 10101 01010','X':'10001 10001 01010 00100 01010 10001 10001','Y':'10001 10001 01010 00100 00100 00100 00100','Z':'11111 00001 00010 00100 01000 10000 11111',
'0':'01110 10001 10011 10101 11001 10001 01110','1':'00100 01100 00100 00100 00100 00100 01110','2':'01110 10001 00001 00010 00100 01000 11111','3':'11110 00001 00001 01110 00001 00001 11110','4':'00010 00110 01010 10010 11111 00010 00010','5':'11111 10000 10000 11110 00001 00001 11110','6':'01110 10000 10000 11110 10001 10001 01110','7':'11111 00001 00010 00100 01000 01000 01000','8':'01110 10001 10001 01110 10001 10001 01110','9':'01110 10001 10001 01111 00001 00001 01110',
'?':'01110 10001 00001 00010 00100 00000 00100','/':'00001 00001 00010 00100 01000 10000 10000',"'":'00100 00100 00000 00000 00000 00000 00000','-':'00000 00000 00000 11111 00000 00000 00000','.':'00000 00000 00000 00000 00000 00100 00100',' ':'00000 00000 00000 00000 00000 00000 00000'}
fb=FontBuilder(1000,isTTF=True);names=['.notdef']+[f'g{ord(c)}' for c in patterns];fb.setupGlyphOrder(names)
glyphs={};metrics={}
for c,pattern in patterns.items():
 pen=TTGlyphPen(None)
 for y,row in enumerate(pattern.split()):
  for x,value in enumerate(row):
   if value=='1':
    left=x*100+50;bottom=(6-y)*100;pen.moveTo((left,bottom));pen.lineTo((left,bottom+100));pen.lineTo((left+100,bottom+100));pen.lineTo((left+100,bottom));pen.closePath()
 name=f'g{ord(c)}';glyphs[name]=pen.glyph();metrics[name]=(600,50)
glyphs['.notdef']=glyphs['g63'];metrics['.notdef']=(600,50)
fb.setupGlyf(glyphs);fb.setupHorizontalMetrics(metrics);fb.setupHorizontalHeader(ascent=850,descent=-150)
cmap={ord(c):f'g{ord(c)}' for c in patterns}
for c in 'abcdefghijklmnopqrstuvwxyz':cmap[ord(c)]=f'g{ord(c.upper())}'
fb.setupCharacterMap(cmap);fb.setupNameTable({'familyName':'AKUMU Pixel','styleName':'Regular','uniqueFontIdentifier':'AKUMU Pixel Original','fullName':'AKUMU Pixel','psName':'AkumuPixel'});fb.setupOS2(sTypoAscender=850,sTypoDescender=-150,usWinAscent=850,usWinDescent=150);fb.setupPost();fb.setupMaxp();fb.font.flavor='woff';fb.save('src/assets/akumu-pixel.woff')
print('Created original AKUMU Pixel font')
