# AKUMU — WELCOME BACK event

The baseline was the last delivered AKUMU-Room2.html; it matched the existing standalone build byte-for-byte before edits.

## Change
Only a successful Stage 2 submission invokes the recognition display. Original Stage 2 validation, completion, Box 2 refresh and Stage 3 availability execute first. The UI then briefly flickers its existing monochrome screen and shows:

STAGE 02 COMPLETE  
ACCESS GRANTED

USER RECOGNIZED  
WELCOME BACK, [actual player name].

The name comes from the existing playerName variable and is inserted as text, without another input. The message stays for 4 seconds, followed by a 180 ms ending flicker and the normal stage menu. The small distortion uses the existing noise/SFX path; no asset or dependency was added. The flicker affects only terminal content, with a one-pixel shift and modest opacity variation.

## Narrator silence and safety
During the event the existing voice bus is muted, new narrator playback requests are refused, and narrator captions return an empty string. Existing speech already in progress is also inaudible. The prior voice level is restored when the display ends or the PC closes. No voice line, subtitle, joke or explanation is added.

A per-playthrough UI flag and the existing one-time successful-submission guard prevent replay. Closing with EXIT COMPUTER or Escape clears both event timers, restores narration and consumes the event. Reopening immediately exposes the normal unlocked menu. No puzzle/reward depends on waiting for the display.

## Files
Runtime changes: src/computer-interface.js, src/audio.js, src/main.js, index.html and src/style.css. The existing puzzle/state/assistance, geometry, inventory IDs, box/wrench/vent, lighting and movement implementations were not edited. Stage 3 still uses HE IS LISTENING and “The letter...”; Stage 4 still says Think inside the box.

Tests/docs: new tests/recognition.test.js and tests/welcome-back.mjs, package scripts, existing PC-route browser expectations adapted to await the new display, README and validation/report. Standalone/website/source downloads regenerated.

## Validation
All 50 unit checks and both final builds passed. Desktop/portrait-touch event checks verified actual names, four-second timing, narrator silence, immediate rewards, one-shot behavior, safe early close and Stage 3/4 progression. The existing complete desktop Room 2 escape regression also passed through the letter, all PC stages, box opening/carry/stacking, wrench collection, climbing, grille and ending. Both event screenshots were reviewed; no uncaught page errors. Detailed executed results and limitations are in the latest WELCOME BACK entry in VALIDATION.md. Desktop and touch emulation are not physical iPad/Safari or hardware loudspeaker tests. No 15-minute playtime benchmark is claimed; existing gameplay pacing and balance were not retuned.
