# Working coffee machine

Optional Laundry Room activity, with no puzzle, exit condition or narrator dialogue.

## Controls

- E / left-click (touch: INTERACT) picks up either cup.
- Aim at the machine and interact with an empty cup to place it under the spout and brew. Brewing takes about 1.8 seconds. A full cup can then be picked up separately.
- Interacting with the machine without a cup under it spills coffee onto the counter. The spill disappears five active gameplay seconds after pouring starts.
- Hold a filled cup, look away from the machine and interact to drink (touch button becomes DRINK). This gives 3x normal Laundry walking speed for five active gameplay seconds, then returns to normal. Buffs refresh rather than stack; empty cups give no bonus.
- G / DROP puts the held cup down: onto its counter spot when nearby, otherwise onto a clear floor spot ahead. Cups remain reusable.

The original glass coffee pot now sits beside the machine so it does not overlap the cup/dispenser. Added a spout, pouring/overflow visuals, rising cup contents, a brief sip animation and quiet brewing/cup sounds using the existing audio buses. Cups remain body-free held objects; there is no new inventory interface or control key. The existing movement collision system remains active at boosted speed. Timers pause with gameplay. Both wall portraits stay unchanged.

Runtime files: `src/coffee-state.js`, `src/coffee-play.js`, `src/laundry-room.js`, `src/main.js`. Added `tests/coffee.test.js`, `tests/coffee-browser.mjs` and `npm run test:coffee`. Existing portrait/Laundry browser expectations were updated from zero to three room targets for the machine and two cups. The preservation audit allows the explicit coffee-aware touch-button label in syncUI.

## Verification performed

- Standalone and web builds passed.
- 60 existing unit tests, 3 new coffee-state tests and 2 Laundry state/collision tests passed.
- Desktop and emulated-touch browser checks passed: no-cup spilling/expiry; pickup, placement, brewing, collection, drinking; 3x boost and expiry; putting the cup down; and independent use of the second cup. Desktop left-click drinking and boosted keyboard movement were exercised. No page errors were reported.
- Spill and filled-cup screenshots were visually inspected.
- Preservation audit: 78 protected existing source/assets files and 28 unrelated main functions remain byte-identical. Room 1, Storage puzzles, DEMO logic and existing dialogue assets were not changed.
- Physical iPad testing, a full unassisted playthrough and hardware FPS measurement were not performed for this update.
