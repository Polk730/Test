# AKUMU — Stage 2 inventory puzzle

## Changed files

New runtime files:
- `src/storage-inventory.js`: consistent item IDs, framed-bay identifiers and the fixed Stage 2 inventory manifest.
- `src/inventory-labels.js`: worn aisle signs, shelf labels and inspectable inventory sheet.
- `src/inventory-props.js`: recognizable radios, lamp and suitcases for the three counted shelf units, batched by material.

Modified runtime/UI files:
- `src/computer-stage.js`: Stage 2 availability, fixed normalized answer validation, persistent completion and permanent box-unlock queries. Stage 1's sequence generation and numeric validation are unchanged.
- `src/computer-interface.js`, `index.html`, `src/style.css`: simple Stage 2 CRT screen and sandbox-compatible answer entry. Stages 3–4 stay disabled.
- `src/storage-room.js`: typed stock records, clear only the three puzzle units, install labels/items/sheet and register existing computer/crates with consistent IDs.
- `src/storage-computer.js`: use the same glow/outline style for each permanently unlocked crate, with isolated materials so Box 3 remains unlit.
- `src/main.js`: route the new sheet and shelf groups through the existing inspection system.
- `src/box-stacking.js`: detach a lifted box from its former support immediately, allowing reliable lifting/restacking without a stale support reference.

Tests/docs/builds: new Stage 2 unit/browser and sign-preview checks, updated Stage 1 expectations/embedded-viewer test, package scripts, README/validation reports and regenerated downloads. No Room 1 geometry, puzzle, recording, transition or ending implementation was changed.

## Aisle and shelf labels

AISLE 1–6 use worn, ceiling-hung storage plaques at the front and middle entrances, readable from both directions. Existing aisle widths, racks, cross-passages, walls and lights remain in place.

Each framed bay between vertical supports is one shelf unit, with one identifier for all its horizontal levels. There are 24 units. A single physical unit uses the same letter on both faces; letters are globally unique (A–X), which also makes every identifier unique within its aisle. The three rear bays bordering aisle 3 are A, B and C. Other bays receive D–X. Labels sit on frame edges above the stored items and are not floating object numbers.

## Item IDs and physical counts

Recognizable storage types use one consistent inventory mapping:

| Type | ID |
|---|---:|
| Radio | 14 |
| Table lamp | 27 |
| Suitcase | 38 |
| Carton | 42 |
| Folded linen | 51 |
| Covered item | 63 |
| Picture frame | 72 |
| Sealed crate | 84 |
| Computer | 91 |

Existing props receive typed inventory records; no decorative filler was added to populate this list. The only new counted objects are those required for the puzzle. The three bays are cleared of other contents so counts are unambiguous:

- A: exactly two radios.
- B: exactly one table lamp.
- C: exactly two suitcases.

They occupy the rear shelf bank on the left while walking down aisle 3 toward the far wall. Their centers are z=6.775, 7.825 and 8.875, beside x=4.35. The radios have speaker grilles, knobs, handles and antennas; the suitcases have handles, straps and clasps. Wide shelf inspection targets reuse the existing rotate/zoom viewer, letting players count without pixel-perfect aiming. These inspections do not reveal the numerical answer.

## Inventory sheet

One dusty STORAGE INVENTORY sheet is on the front wall below the existing LINEN & FURNISHINGS sign, at x=4.6, y=1.4, z=2.171. It is near the computer and accessible from the entry apron without a puzzle. E/left-click or touch INTERACT opens the existing inspection view. The original Stage 1 translation page and the story envelope remain where they were.

## Stage 2 and permanent rewards

Completing Stage 1 makes Stage 2 selectable. Its CRT interface lists expected stock in aisle 3: A has two radios, B one table lamp, C three suitcases. Actual C has only two; the sheet supplies suitcase ID 38. The fixed answer is 38C, accepting lowercase and surrounding whitespace. Other input displays only INCORRECT CODE, with no punishment, timer or answer reveal. Correct input displays CORRECT — STAGE 2 COMPLETE. Completion survives closing/reopening.

Stage 1 permanently unlocks Box 1. Stage 2 permanently adds Box 2. Both retain the same green glow, through-wall outline and carry/drop permission. Prior rewards never relock. Only one item can be carried at a time; top boxes must be lifted before their supporting bases move. Both unlocked boxes can be repositioned and restacked to correct mistakes. Box 3 stays locked. Box 1 remains sealed, with the reserved wrench hidden, untargetable and unusable.

## Validation

See the latest Stage 2 section in `VALIDATION.md` for executed results. New checks cover all aisle/shelf identifiers, consistent mandatory IDs, exact rendered-stock records, reference inspection, Stage 1→2 gating, accepted/rejected answers, persistent completion, two-box glow/carry/stack/recovery and locked future content. Screenshots were inspected for clear item counts and readable signs/sheet.

No physical iPad/Safari or school-computer GPU measurement is implied by Chromium touch emulation and software WebGL. New shelf props are batched by material, labels use shared atlases, and no new light or post-processing effect is introduced. Vite retains its nonblocking large-bundle advisory.

## Intentionally unfinished

Stages 3 and 4 have no puzzles and remain locked. Box 3 remains locked. No crate-opening method, accessible wrench, new grille interaction, escape trigger, narrator line, horror event, enemy or additional puzzle was added. The full three-box staircase still depends on a future Box 3 reward. The existing grille/ending behavior is preserved.
