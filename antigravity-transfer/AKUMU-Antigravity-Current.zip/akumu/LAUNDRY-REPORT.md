# AKUMU — Laundry continuation

## Scope

NORMAL mode now continues from the existing opened Room 2 vent into a manually traversed industrial duct and then Room 3, The Laundry Room. The wrench in Box 1, all PC stages, box interactions and vent-opening requirements remain unchanged. The original NORMAL ending implementation remains available, and the DEMO route and ending are unchanged.

The duct has one 90-degree right turn, approximately 12.5 metres of travel, low automatic crawling height, reduced movement speed, solid boundaries, quiet airflow/metal foley and one subtle sound behind the approach to the elbow. E, left-click and the existing touch interaction open the exit grille. A short controlled transition lowers the player to a clear landing and restores standing movement. No body parts, new controls or puzzles were added.

The 12 x 10 x 3.2 metre laundry has four front-loading washers, three dryers, carts, baskets, towels, storage shelves, a folding table, plumbing/conduits and a staff corner separated by a partition with an open passage. The staff area contains a vintage coffee machine, two ceramic cups, a counter, chair and cabinets. Cold finite fluorescent lighting contrasts with a warm staff light. Static geometry is batched, materials reuse the existing PBR library, and only one new light casts shadows. The future metal exit remains closed, with no unlocking interaction or ending.

## Files

- `src/main.js`: lazy initialization, NORMAL vent destination, new area movement/target selection and camera/audio updates. Existing rooms keep their control and puzzle branches.
- `src/laundry-layout.js`: duct/room dimensions, collision layout and one-shot entry/drop state.
- `src/laundry-room.js`: environment models, materials, lighting and exit grille.
- `src/laundry-audio.js`: quiet environmental audio through existing buses.
- `package.json`: dedicated Laundry test commands.
- `tests/laundry.test.js`, `tests/laundry-preservation.mjs`, `tests/laundry-flow.mjs`, `tests/laundry-touch.mjs`: collision/state, preservation and browser checks.
- Generated `standalone/AKUMU.html` and `dist/`: playable exports.

A pre-change standalone game and source manifest are saved in `/workspace/AKUMU-Laundry-Backup/`.

## Running

Open the supplied standalone HTML in a desktop browser, or host it as `index.html` on a static server. All required runtime code and assets are embedded; no API keys, paid services or external asset downloads are required. For Atlas, serve the page under `/games/akumu/`; allow the game's inline scripts/styles and embedded media in its CSP, and permit scripts and Pointer Lock if embedding in a sandboxed iframe. Audio starts through the existing user gesture flow.

Development: `npm ci`, then `npm run dev`. Build the standalone file using `npm run build:html`; build the web distribution using `npm run build`.

## Intentional limits

There are no Room 3 puzzles, machine/coffee interactions, monsters, narrator additions, music, Room 4 or new ending. The Laundry exit stays closed for future development. No claim is made of a guaranteed frame rate on every device. Automated browser testing uses software WebGL; physical iPad and real GPU performance/subjective audio balance still require human playtesting.

## Verification performed

- `npm run build:html` and `npm run build`: passed. Vite retains its advisory warning about large bundled chunks.
- `npm test`: 60 existing tests passed, 0 failed.
- `node tests/laundry.test.js`: 2 new tests passed: elbow traversal/solid bounds and one-shot, pause-safe camera state transitions/valid standing landing.
- `node tests/laundry-preservation.mjs`: 80 existing source/assets files outside `main.js`/`style.css` and 29 unrelated main function bodies are byte-identical to the pre-change backup.
- `node tests/laundry-flow.mjs --desktop-only`: passed. The browser solved existing Stages 1–3 and checked Stage 4; exercised separate box opening, carrying/restacking, actual stair climbing, the no-wrench/floor-level guards, separate wrench collection, original vent opening, manual crawling along both duct legs, grille interaction and safe Laundry landing. Fixture camera aiming uses the existing debug tools; this is automated testing, not an unassisted human playthrough.
- `node tests/laundry-touch.mjs`: passed on emulated touch: joystick crawling, grille interaction, landing, standing movement, washer/exit-door collision and staff passage. This fixture initializes the completed vent to isolate the continuation; it does not claim a full mobile Room 2 puzzle playthrough.
- `node tests/prototype.mjs`: full Room 1 puzzle/physical transition into Room 2 passed with no page or console errors.
- `node tests/demo-invitation.mjs`: desktop and emulated-touch checks passed for live-camera silence, delayed post-black invitation, once-only playback, button gating, fresh NORMAL name/start flow and retained old ending implementation.
- Final standalone HTML touch check passed after the environmental audio adjustment. Main-room, duct, washer and staff/coffee-machine screenshots were inspected. No physical iPad or hardware FPS benchmark was performed.

## ROOM 3 / TEST shortcut

Added beside ROOM 2 / TEST in the top-right menu. It reuses name entry and starts directly at the duct entrance in NORMAL mode with crawling controls ready. Only this explicit test shortcut bypasses the original puzzles. Changes: `index.html`, `src/style.css`, `src/main.js`; targeted checks in `tests/room-three-shortcut.mjs`. Both builds succeeded. Desktop and emulated-touch checks passed for adjacent buttons, narrow-screen fit, name entry, exact duct-entry spawn and playable state; desktop keyboard movement was also checked. The preservation audit was updated to allow these explicitly requested menu/startup changes.

## Visual bug fixes

Reviewed eight player-camera views of the shaft bend, grille, exit door, ceiling, shelves, staff corner and machines before/after correction. Fixed the unsupported inner shaft brace and floor trim in the elbow, detached straight-wall braces, overlapping duct floor/ceiling panels, door-leaf/frame fit and hinge attachments, grille/floor clipping and over-rotation, duplicate/disconnected pipes and floating wall/ceiling attachments, cart-wheel/floor contact, and small cup/carafe/towel support gaps. Fluorescent housings/bulbs no longer cast oversized self-shadows; static batching now preserves shadow flags. Duct seam lights sit on the visible ceiling face.

Runtime edits for this pass are limited to `src/laundry-room.js`; `tests/laundry-visual.mjs` provides the inspection fixture. Puzzles, controls, collision layout, mode routing, dialogue and original rooms were not modified.

Checks actually run for this pass: both production builds passed; two Laundry collision/state tests passed; preservation audit passed (80 protected original files and 29 unrelated main functions); browser inspection captured eight final views and verified grille interaction/drop and room navigation. Final bend, door, ceiling, grille and staff images were visually reviewed. The complete 62-test/full-room regression above describes the earlier Laundry implementation, not a rerun for this visual-only pass. Physical iPad and hardware FPS checks remain unperformed.

## Startup loading update

The requested startup flow now includes a preparation screen after name entry. See STARTUP-LOADING.md for implementation files, tests, measurements and limits. The current preservation audit covers 78 protected files and 29 unrelated main functions, excluding the explicitly added startup/preparation APIs.
