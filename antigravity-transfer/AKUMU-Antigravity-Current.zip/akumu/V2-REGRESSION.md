# AKUMU v2.0 — Regression report

Delivered HTML SHA256: `85b7db1d18aaaf58406c43e46f35df8f5f19a49e3b75702f7132ccf5f6181ba4`.

## Passed

- All 60 model/unit checks and both standalone/production builds.
- Preservation audit: 67 existing non-visual files and 65 protected function bodies byte-identical, including the original random generator and photograph.
- UI/model review on desktop and touch emulation: NORMAL/DEMO/BACK/name/empty-name validation, keyboard focus, touch target size, reduced motion and portrait/landscape resize.
- Full texture equality: 13 recipes, 40,894,464 bytes, identical after the final CPU-only load optimization.
- Final optimized HTML launched again in an offline context, including original bedroom captures, Observation entry and VHS display, with no external asset request.

## Browser suites

| Group | Program | Result |
|---|---|---|
| core | prototype.mjs | PASS |
| core | storage-escape.mjs | PASS |
| core | observation-room.mjs | PASS |
| core | demo-invitation.mjs | PASS |
| core | inspect-escape.mjs | PASS |
| events | key-blackout.mjs | PASS |
| events | unusual-clock.mjs | PASS |
| events | photo-voice.mjs | PASS |
| events | closet-damage.mjs | PASS |
| events | spider-scare.mjs | PASS |
| events | bed-voice.mjs | PASS |
| events | wrong-code-voice.mjs | PASS |
| events | drawer-repeat-voice.mjs | PASS |
| events | stage-two-assistance.mjs | PASS |
| events | pc-startup.mjs | PASS |
| events | pc-beacon.mjs | PASS |
| ui | menu-sprites.mjs | PASS |
| ui | name-filter.mjs | PASS |
| ui | embedded-start.mjs | PASS |
| ui | chrome-input.mjs | PASS |
| ui | touch.mjs | PASS |
| ui | observation-sfx.mjs | PASS |
| ui | welcome-back.mjs | PASS |
| ui | standalone-demo.mjs | PASS |
| ui | storage-lighting.mjs | PASS |
| ui | v2-context.mjs | PASS |

The 26 queued suites include complete NORMAL bedroom → storage progression, all original PC stages/HELP/welcome event, box opening versus pickup and stable stairs, separate wrench collection, vent escape, all DEMO VHS/archive/live-feed/exit flows, fresh NORMAL name entry from PLAY FULL VERSION, return-to-title/reset, and Escape inspection recapture. They also cover the existing clock/photo/bed/drawer/closet/spider events, PC startup/spatial pips, embedded start with restricted forms/pointer lock, mouse rejection fallback, touch gestures, all six aisles from front/rear, and advertised WebGL-loss reload recovery. Test durations are automated fixture durations, not human escape-completion measurements.

## Scope of the final changes

Core progression suites passed after the model/material/UI changes and before the final removal of low-value shader sampling. Subsequent event/UI suites exercised that lighter shader build. The final change after those suites was solely a private texture-generation optimization: every resulting texture byte was proven identical, protected gameplay functions stayed unchanged, and the actual final HTML was built and offline-smoke-tested again. No game logic was modified to make tests pass.

## Failed attempts investigated and resolved

- The old bedroom test exceeded its 30-second page-load budget on the software GPU: navigation waits were made explicit and longer in the fixture.
- Several browser calls arrived after the short Found key presentation ended: the fixture now records that temporary state atomically when shown.
- Old tablet fixtures skipped the already-existing NORMAL/DEMO menu: they were corrected to choose NORMAL.
- The old touch fixture waited for a drawer target without explicitly re-aiming after lock inspection: it now checks unpaused play and centers its test view as the desktop fixture does.
- Native-resolution subsecond flicker sampling failed because a frame jumped from age 0 to approximately 0.534s. The unchanged exact waveform and separately controlled rendered intermediate lighting were checked; actual dark frames, recovery, key-text ordering and one-shot behavior passed.
- Reflections/atlas/AO candidates that added low-value cost were rejected or reduced. The discarded byte atlas is not shipped.

## UNVERIFIED / limitations

- Physical iPad/Safari, Android Chrome, desktop Google Chrome/Firefox/Edge and hardware GPU performance were not directly tested; only Linux Chromium was available. Touch emulation is not physical iPad testing.
- Visible real-time half-second flicker on this slow native-resolution software renderer is UNVERIFIED; the model timing and controlled light response passed, with no production duration change.
- Direct file:// testing was blocked by this managed Chromium policy. The packaged document passed via an intercepted request in an offline context without a server or external assets.
- WebGL context loss shows the original reload guidance. The restore event and fresh-reload recovery into NORMAL storage passed; seamless continuation is not an existing supported behavior.
- No manual human 15-minute pacing playtest, hardware-speaker listening, exact GPU-memory allocation measurement, reliable 1% low or hardware 60/30 FPS result.
- No reproduced softlock in the covered paths; exhaustive testing of every possible box placement is UNVERIFIED.
- The original pending final DEMO/Observation narrator recordings remain pending. Existing caption placeholders/audio-ready hooks are preserved; no substitute narration was generated.
- Crowbar interactions are N/A: the existing game uses the wrench, and no crowbar mechanic was invented.

No unresolved reproducible gameplay regression was found in the covered scenarios. Performance limitations are documented separately; this is not a universal platform certification.
