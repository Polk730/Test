# AKUMU — Rooms 1–3

A browser first-person psychological horror escape-room game by Oliver & Vihaan. PLAY now offers NORMAL (the existing storage route) and DEMO (The Observation Room), both through the original bedroom. The existing Room 207 bedroom puzzle now leads into an explorable abandoned hotel storage room. Room 2 includes the Stage 1 computer cipher, Stage 2 missing-inventory puzzle and Stage 3 password recovery. Stage 4 now gives the final box hint; after Stage 3, open Box 1 for the wrench and use the existing three-box stairs to escape through the high vent.

## Play the single HTML file

`standalone/AKUMU.html` contains the game, Three.js, styles, generated surfaces and audio in one offline file. On a desktop, download and open it in a current browser. No dependencies or server are needed for that edition. In-app viewers and iPad Files previews can restrict JavaScript/WebGL; if they do, serve the file as a webpage and open it in Safari. Desktop play uses FPS mouse capture. Esc releases it and pauses; click the pause screen to resume. Touch play never requests capture.

After PLAY, choose NORMAL or DEMO, sign the reception guestbook and select CHECK IN. The existing preload runs before the original eight-second waking sequence. Touch controls appear automatically on touch-capable devices. Landscape is recommended on iPad.

## Controls

Desktop: WASD or arrow keys to move, mouse to look, E to interact, G to drop the carried hammer, Esc to pause or exit inspection. Mouse capture is requested after CHECK IN, a click to resume, the CLOSE button in inspection, or a left-click in the room to retry. Esc never captures or automatically recaptures it. If capture is blocked by Chrome, WASD still works: hold either left or right mouse button and drag to look. Clicking the room restores keyboard focus, and left-click also retries capture. The game suppresses the browser context menu. Touchscreen laptops can use desktop mouse input; actual touch switches to touch controls. In inspection, drag to rotate, scroll to zoom and Esc/CLOSE to leave. In lock inspection, click each physical number wheel to advance it.

Touch: left joystick to move, swipe the scene to look, generic INTERACT button to interact with the object you face. In inspection, drag to rotate, pinch or use + / − to zoom, CLOSE to leave. Tap individual lock wheels to turn them. DROP appears only while physically carrying the hammer. Top-right button pauses; tap the pause screen to resume.

A small fixed center dot shows where you aim during gameplay. It disappears in menus, pause, inspection and the ending. There are no object labels, outlines, glowing targets or floating prompts. The physical notes teach the controls. The generic iPad interaction button stays available without revealing target names or proximity.

## Develop and build

Install Node.js 22.12+ (Node 24 LTS recommended), open a terminal in `akumu`:

```sh
npm ci
npm run dev
```

Open the address printed by Vite. `npm run build` produces the standard web build under `dist`; `npm run preview` serves it. `npm run build:html` produces the standalone edition and checks the final embedded JavaScript syntax.

## Room 207 and puzzle

Three handwritten-style logbook notes belong to a previous prisoner. Turn over the second note in inspection to discover the combination. An aged four-wheel mechanical lock secures the drawer. Solving it releases the latch but leaves the drawer shut: exit inspection, then open it manually. Pick up the hammer inside, carry the real object to the window, and remove the barricade. The planks and hammer remain on the floor. The larger brass key hangs centrally between the barricade and the closed window on a small frame hook. It becomes accessible after the planks fall. Pick it up to see a brief large 3D key presentation with “Found key”; gameplay then resumes and the bedroom door can be unlocked. No inventory is added.

`src/config.js` is the single configuration location for the clearly marked temporary four-digit combination and hotel room number. The same combination is rendered on the note back and validated by the lock. It never changes randomly.

Puzzle state explicitly tracks read notes; locked/unlocked/open drawer; wheel digits; available/carried/dropped hammer; intact/removing/removed barricade; hidden/available/collected key; locked/opening/open door; and controlled sequence state. Hammer drops are restricted to recoverable clear floor locations. Window collision remains solid after removing planks. The bedroom door now opens into Room 2; the ending is reserved for future ventilation-shaft completion.

## Lighting and surfaces

A shaded tungsten ceiling lamp casts downward light with inverse-square falloff and rare, smoothly shaped electrical faults. A separate cold source outside the window casts plank shadows. Very weak local spill and bounced light keep important objects readable. Two shadow-casting spotlights use 1024² depth maps and soft PCF filtering; shadow depth maps refresh for moving objects, while brightness changes naturally alter the light/shadow contrast. No six-face point-light shadow map, bloom or expensive fullscreen AO pass is used.

Procedural contact-occlusion patches ground furniture and wall edges. Original cached surface sets separate sRGB base color from linear roughness and normal maps. Plaster coordinates align across structural wall segments. Worn wood, distressed paint, oxidized metal, stained fabric and rounded furniture edges add detail. Sparse dust, restrained distance haze and a barely visible forest support the atmosphere. Web Audio produces quiet wind, localized lamp hum, rare creaks, wheel/latch clicks, wood impacts and the final fade. The existing title menu has automatic spooky lo-fi music after browser audio permission; gameplay uses environmental audio.

## Verification

```sh
npm test
npm run build
npm run build:html
npm run test:browser
npm run test:touch
npm run test:storage
```

The browser tests use Chromium at `/usr/bin/chromium`, or a Playwright-installed Chromium if absent. The full puzzle, touch and Room 2 browser tests self-host the built standalone HTML on a temporary local port. Older focused tests expect `http://127.0.0.1:4175/AKUMU.html?debug`; `AKUMU_URL` can override the location. Screenshots and outputs go to ignored `test-results/`. Explicit `?debug` exposes test hooks; ordinary play does not. Tests position the camera for repeatable coverage but use actual E presses, wheel clicks/taps, drag, pinch and drop controls; the full puzzle regression does not skip puzzle steps. Room 2-focused and touch-transition checks explicitly grant the key after their respective baseline checks to isolate the new transition.

See `VALIDATION.md` for executed results and remaining limits. Physical iPad, Safari and ordinary school-computer frame-rate measurements are not implied by cloud Chromium tests.

## Assets and limits

All model geometry, surface maps, notes, photograph and environmental SFX are original procedural work. The opening MC voice is the user-supplied MP3, embedded unchanged. Three.js is MIT-licensed; its notice is embedded in the standalone file. The title menu now embeds the supplied pixel-art JPEG from `src/assets/title-menu.jpg`. The original image remains intact, with CSS lantern/moon lighting, cloud drift, twinkling stars, a gently animated PLAY face, a small low-resolution particle layer. The full illustration fits landscape and portrait screens against a blurred backdrop. Reduced-motion preferences disable decorative movement. There is still only one PLAY button and the original creator credit. Menu effects stop at PLAY; the covered 3D scene renders once to warm up, then waits until gameplay. The asset is inlined in both web and standalone builds, so no separate image file is needed at runtime.

This is a procedural indie prototype, not a commercial photogrammetry asset pack. Contact AO is a local baked-style approximation. The plank-removal and hammer-drop sequence uses controlled collision-aware motion rather than a general rigid-body solver. Desktop and touch controls share one puzzle implementation. WebGL 2 is required.

`npm run test:menu` checks embedded artwork, a single accessible PLAY button, animation and reduced-motion behavior, idle 3D rendering, keyboard FPS startup/Esc release and portrait/landscape touch startup.

The lantern flame now uses eight separate SVG picture frames at approximately 9 fps, fixed inside the glass. It is not an animation of the entire lantern or painting. Birds use four wing-pose pictures and occasional short flights, masked behind the window mullions. The first flight occurs after about six active menu seconds, followed by irregular 16–35 second gaps. A second, smaller bird sometimes follows. Reduced motion freezes the flame and hides birds; PLAY stops menu frame updates. `npm run test:menu:sprites` checks frame changes, fixed geometry, masked flights and gameplay handoff.

## Stronger foley mix

Action sounds now use original precomputed PCM foley with four cached variations: wooden footsteps, handle rattles, drawer friction, mechanical detents, latch releases, tool handling, hammer impacts, bouncing boards, key jingles and hinge creaks. Separate SFX/ambience buses, a short stereo room response and compression provide louder foreground effects with controlled overlap. The existing title menu has automatic spooky lo-fi music after browser audio permission; gameplay uses environmental audio. `src/audio-synthesis.js` exposes per-effect levels. `npm run test:audio` renders a mixed preview, checks peak headroom and fade-out, compares a footstep against the previous signal chain and exercises actual in-game door/footstep and pause/resume triggers. The generated WAV is under `test-results/sfx-preview.wav`.

## Recorded wake-up dialogue

The supplied `src/assets/wakeup-voice.mp3` is embedded in both builds and decoded silently while the title menu is displayed. It plays once after PLAY, at its original speed/pitch, centered as the protagonist’s voice. The yawn accompanies the ceiling view; the question coincides with the start of the rise. Subtitle and camera use the same AudioContext clock as the recording, so suspending audio does not make the visuals run ahead. Ambience dips briefly under the voice and restores before player control.

`src/opening.js` centralizes timing: recording offset 1.50 s, speech within the recording about 1.01–2.58 s, a short subtitle hold, and standing/control at 8 s. The supplied clip is about 2.93 s long. `npm run test:voice` records actual caption/camera/audio-clock samples, checks pause/resume alignment and the gameplay handoff. If audio is unavailable, the cinematic has a bounded silent fallback rather than hanging on black.


### Locked-door narrator
The supplied narrator MP3 is embedded unchanged and predecoded on the menu. Trying the exit without the key plays the recording and the caption “(Narrator) Did you think escaping would be that easy?” using the audio clock. Repeated clicks cannot overlap or restart the voice; a two-second cooldown follows playback. The keyed-door interaction opens normally. Run `npm run test:door-voice` to verify.


### Hammer attempt at the exit
Interacting with the locked exit while carrying the hammer plays an impact and the supplied, unchanged hammer-door recording, with “(Narrator) Creative. Unfortunately, the door disagrees.” The 4.049-second MP3 is embedded and predecoded, and the caption uses its playback clock. Both door lines share overlap protection and a two-second cooldown. Ordinary handle attempts retain their previous recording, and the key still opens the exit.


### Fourth bed inspection
The bed is now an inspectable object using the existing desktop/touch inspection controls. Opening the inspection increments a session counter. The first inspection is silent; the second queues the supplied bed narrator recording once per session. The caption “(Narrator) You just woke up. Already tired?” follows the recording clock, including in the inspection view. Shared narrator cooldown prevents overlap with door lines; a pending bed line waits for an available slot. The unchanged 3.396-second MP3 is embedded for offline playback. Run `npm run test:bed-voice`.


### Wrong drawer combination narrator
The supplied 3.709-second MP3 is embedded unchanged and predecoded with the other voice assets. After a wheel changes, leaving a wrong combination settled for two active seconds while examining the lock triggers “(Narrator) Four numbers. Apparently, that's asking a lot.” once per session. Untouched default digits and intermediate wheel turns do not immediately trigger dialogue. Entering the correct code cancels the opportunity and unlocks normally. Shared narrator cooldown prevents overlapping recordings. Run `npm run test:wrong-code-voice`.


### Fitted exit door and menu music
The door slab now fits the existing jamb with 5 mm head clearance, 5 mm side clearances and a 15 mm floor clearance. The handle sits opposite the hinge. Added an original eight-bar 72 BPM spooky lo-fi track (soft minor chords, sparse melody, muted percussion and tape noise) generated by `scripts/create-menu-music.py` and embedded as MP3. Title-menu music automatically attempts playback with no music button; browsers blocking autoplay start it after the first menu tap or key press. It pauses while hidden and stops on PLAY, preserving quiet gameplay and narration. Run `npm run test:door-menu`.


### Seventh empty-hand cabinet interaction
Aim at the intact boarded cupboard and interact without carrying the hammer. Seven deliberate interactions trigger the supplied voice once per game, with “(▓▒░▓▒) Can't a guy have his peace?” Hammer strikes retain swing and impact sounds but do not count toward the voice trigger. Rapid empty-hand duplicate input is ignored for half a second. Pending cupboard dialogue waits while the hammer is carried and shares the narrator overlap protection. Breaking the closet disables its target and interactions permanently and cancels pending peace dialogue. Run `npm run test:cabinet-voice`.


### Hammer swing animation
Held hammer strikes now use a 0.64-second camera-local animation with a raised wind-up, forward/downward contact at 0.26 seconds, and smooth recovery. A quiet swish accompanies the swing; impact SFX and cabinet hit counts/door dialogue/window removal begin at contact. Repeated input cannot restart the swing, and dropping is blocked during recovery. The active game clock freezes the animation on pause. Use E / touch INTERACT on a strike target, or left-click with the mouse captured. Left-click or E with no target swings freely without a false impact sound. Run `npm run test:hammer-swing`.


### Left-click interactions
Left-click now uses the same aimed interaction as E for all objects. While pointer-locked, it activates on mouse-down; without capture it activates on a short click (under 7 px movement), preserving drag-to-look. Opening an inspection does not reuse that click to turn a lock wheel. E and touch INTERACT remain available. Updated HUD, pause instructions and notes. Run `npm run test:left-click`.


### Crayon day tallies
The wall beside the bed is covered in 195 uneven groups of five day-count marks (four vertical strokes crossed by a diagonal fifth). A deterministic canvas texture adds irregular broken wax strokes and plaster grain, drawn as one rough, shadow-receiving wall decal. Marks inherit room lighting; furniture and the original note remain in front. The decal does not block aiming interactions. Run `npm run test:tally-wall`.


### Name entry, personal wall message and escape timer
PLAY opens a keyboard/touch-friendly name form, with a Back action. A trimmed nonempty name (up to 24 characters) is drawn as literal canvas text; it is not stored or sent anywhere. WAKE UP submits the name and starts the existing recorded wake-up animation. A blood-red message addresses the player by name on the cupboard-side wall near the door, separate from the tally wall and behind the waking camera. The overlay does not block note interactions.

A small bottom-right MM:SS timer starts when control is handed to the player. It measures real elapsed play time, including inspections and scripted actions, excluding pauses and time in a hidden tab. Physics frame-time clamping does not slow the timer. Completing the future Room 2 exit fixes the result; the TO BE CONTINUED screen displays “Escaped in MM:SS”. Run `npm run test:name-timer`. Browser tests now fill the name form before starting.


### Escape narrator
The supplied 5.068-second recording is embedded unchanged. Unlocking the exit interrupts any previous narrator line, preserves voice volume and schedules the escape recording after 0.75 seconds. Subtitles use the audio clock: “(Narrator) One door down.” then “(Narrator) How many more until you remember?” The voice performance supplies the menacing delivery. This existing recording now accompanies the bedroom-door transition without ending the game or freezing the timer. TO BE CONTINUED and the fixed total escape time are reserved for future vent completion. Tab visibility pauses/resumes ending audio. Run `npm run test:escape-voice`.


### Repeated drawer-opening voice
The third successful drawer opening queues the supplied unchanged 4.284-second recording once per game, with “(Narrator) Maybe it'll magically refill. Keep trying.” Locked attempts and closing actions do not count. Shared narrator scheduling prevents overlap. Escape narration interrupts a current line and blocks any queued in-room line for the rest of the ending. Run `npm run test:drawer-repeat-voice`.


### Pixel-styled name prompt
Name-entry artwork now matches the purple pixel menu: original embedded 5×7 bitmap lettering, stepped panel corners, inset pixel borders, square input and beveled pixel buttons. The font is generated by `scripts/create-pixel-font.py`; no network font dependency. Lowercase Latin letters use uppercase pixel shapes visually; the stored input retains exact case and spaces, with a monospace fallback for other characters. Responsive layout preserves native keyboard/touch input. Run `npm run test:pixel-name`.


### Dripping message and rear twig snaps
The personal message is now drawn with original single-stroke handwritten letter paths, variable stroke weight, uneven alignment, wet red highlights and gravity drips with hanging beads. A restrained pigment-only emissive contribution preserves readability during lamp dips without adding lights or brightening the wall. The original name spelling remains in message data; handwriting is visually uppercase.

A newly synthesized twig snap occasionally plays 1.25–1.9 m behind the player, with small lateral variation. A Web Audio HRTF panner and camera-aligned listener supply directional placement. First eligibility is at 18–30 active seconds; subsequent gaps are 16–34 seconds. Sounds only trigger during active gameplay, wait for narrator cooldown, and are disabled in inspections, scripted busy moments and the ending. No jump scare or added character. Run `npm run test:blood-rear-sound`.


### First hammer hit: closet spider scare
The first hammer contact with the boarded closet triggers a one-time giant spider lunge, a loud synthesized crack/rumble/hiss sting, 35 ms lunge, short scrambling motion and retreat (1.26 real active seconds). Eight articulated legs, bristles, eyes and fangs are rendered in a temporary camera overlay. Gameplay input is briefly locked and then restored. Room narration is interrupted/suppressed during the scare.

Afterward, the supplied unchanged 8.516-second recording plays with two audio-clock subtitle cues: “(Narrator) Imagine getting jumpscared by a closet.” and “(Narrator) That's property damage. You owe me about 200 francs.” The empty-hand peace dialogue remains separate. Scare sound uses its own louder channel and dedicated limiter, separate from the ordinary room SFX compressor. The sting combines a saturated sustained crash/screech with a deep impact. No strobing. Run `npm run test:spider-scare`.


### Local name filter
Common English/German profanity and racist slurs are screened locally before gameplay starts. Checks normalize common Unicode lookalikes, leetspeak, separators and repeated letters. Exact-word matching protects innocent names such as Scunthorpe, Hancock and Fuchs; selected unambiguous abusive fragments are also blocked. An accessible pixel-style error asks for another name without echoing rejected text. This is a small offline list/heuristic filter, not exhaustive semantic moderation of every language or possible evasion. Run `npm run test:name-filter`. First closet hammer contact now triggers the one-time scare. User-facing download uses a neutral filename.


### Uploaded scare SFX
The user-supplied scare MP3 is embedded unchanged and predecoded on the title screen. It replaces the synthesized sting when available, starts with the spider lunge through the dedicated scare channel, and plays once at original speed. Its first four seconds play at original speed, with a short fade at the cut; the closet narrator recording follows completion. Gameplay control returns after the visual retreat. Existing room voice queues wait while the SFX plays; escaping cancels it and takes priority. The synthesized sting remains a decode-failure fallback.


### Closet destruction
The first hammer contact now shatters the front panel and all three barricade planks at the same instant as the spider scare. Replaced the old solid cupboard box with a hollow carcass. Thirty jagged panel/plank fragments scatter and settle on the floor; the shell, dark interior and wreckage remain afterward. Debris updates only during active simulation and stops once settled. Breakage is idempotent; it does not respawn fragments or replay the scare. Original furniture collision footprint is retained. Uploaded scare SFX and property-damage recording remain unchanged. Run `npm run test:closet-damage`.


### Name filter spelling expansion
Added targeted spelling families to block the reported single-G racial-slur bypass, repeated/missing consonants, common phonetic variants and additional English/German abusive words. Existing Unicode, separator and leetspeak normalization still applies. Regression tests cover the reported bypass and preserve ordinary names such as Nigel, Ginger, Cassidy and Fuchs. The filter remains a local heuristic rather than exhaustive moderation of every language.


### Note controls and hidden-code location
Note 3 now reads “E / LMC to inspect,” explains left mouse click, and teaches drag rotation, scroll zoom and touch pinch/drag controls. The hidden code is on the back of Note 2, selected by `CODE_NOTE_INDEX` in `src/logbooks.js`; Note 3 has a plain back and no code hint on its front.


### Key pickup blackout
After the hidden-key pickup text finishes, a half-second irregular flicker precedes a single two-second outage on the active real-play clock, followed by a 180 ms smooth recovery. Ceiling spotlight, local spill, bounce and bulb emission switch off; ambient fill drops and faint moonlight remains. Electrical buzz follows lamp power. Key pickup feedback now overlays the room rather than clearing to a bright inspection backdrop, so the blackout is visible. The key presentation lasts 2.3 real active seconds. Pausing/backgrounding freezes the sequence, and collecting cannot retrigger the outage. Run `npm run test:key-blackout`.


### The unusual wall clock
An aged round clock hangs on the wall above the first note. Quiet spatial tick/tock audio starts after waking, mutes immediately whenever any visible portion of the clock is on screen, and resumes looking away. An occluding object prevents gaze detection. The clock has no interaction target or prompt. Three separate on-screen appearances trigger the supplied unchanged 2.769-second recording once, with “(Narrator) Watching it won't give you more time.” A short gaze dwell and look-away rearm avoid counting jitter or a single long stare as multiple looks. Shared narrator queuing prevents overlapping voices. The hands and attention state use their own clock; the escape timer continues normally. Pause/background/scare/end states mute the clock appropriately; quiet ticking continues offscreen during ordinary item inspection. Run `npm run test:unusual-clock`.


### Clock viewport detection, key-text sequence and fixture repair
Clock silence now uses frustum/screen coverage plus occlusion checks, including partial edge visibility, rather than the center aiming ray. Narrator visit counting follows separate visible episodes. After “Found key” disappears, a half-second sequence of irregular lamp dips plays immediately, followed by two seconds fully off and 180 ms recovery. No triggered blackout begins during the pickup text. Normal lamp faults now recur at irregular 5–16-second intervals; rear twig snaps at 16–34 seconds, still respecting narration/scare/pause restrictions. The ceiling stem now joins a physical socket, which overlaps the bulb base with no gap.


### Five-second photograph narration
Inspecting the framed photograph for five continuous active seconds plays the supplied unchanged 4.049-second recording once per game. Caption: “(Narrator) Funny. Last time you recognized everyone.” The wait resets on closing the photograph; notes and other inspected objects do not count. Timing uses the active real-play clock, and the trigger waits for shared narration availability while the photo remains open. Once started, ordinary close/resume behaviour and escape-priority audio apply. Run `npm run test:photo-voice`.


## Room 2: storage-room foundation

Room 1 geometry, puzzle content, recordings, menu, waking sequence and lighting are retained. Shared control/physics routing now accepts the active room, and the original door and frame are shared objects. Reverse-side matching details are installed only when that door unlocks. A held hammer remains usable and droppable in storage.

Walk through the existing unlocked door to enter an approximately 11 × 9 × 3.8 m windowless storage room. The same door closes once the player clears the threshold (z ≥ 2.72), slams, then emits a separate metallic lock sound scheduled on the audio clock half a second later. Room 1 is hidden after the slam; collision prevents returning. Name and running timer persist. No new narrator lines or scripted Room 2 scares are introduced.

Five banks of 3.2 m shelving form six aisles with widths 0.95–1.4 m, two cross-passages and a clear entrance apron. Aged wood and rusty steel shelving hold a medium mixture of cartons, suitcases, folded linen, lamps, covered belongings and framed pictures. Decorative clutter remains inside shelf collision footprints. The floor is level cracked concrete; grey-beige damaged plaster exposes sparse faded brick patches beneath an old plaster ceiling.

`src/storage-layout.js` owns dimensions, aisle/rack placement, collision boxes and vent location. `src/storage-materials.js` creates cached original base-color, normal and roughness maps. `src/storage-room.js` builds and batches static meshes by material. `STORAGE_LIGHTING` provides easily revised steady illumination: two 1024² spotlight shadow maps plus two inexpensive local fills. Storage shadows are cached during the two-room doorway view and refreshed for movement after entry; the closed door lets the bedroom stop rendering.

The high metal vent and grille are physically present near the opposite corner. Future integration exposes `storage.vent.openWithTool({kind:'wrench'})`, `setExitHandler(callback)` and `confirmEscape()`. A screwdriver is rejected. These are development hooks, **not player-facing mechanics**: the reserved wrench is inaccessible. Box step-up is implemented, but completing the staircase still requires locked Boxes 2 and 3; no vent prompt is implemented. Normal play includes the Stage 1 terminal and stable box placement; the vent remains unescapable. Final fade/TO BE CONTINUED/timer completion is wired to future vent exit, verified through the developer hook only.

Owner decisions still needed for future work: opening Box 1, accessing the reserved wrench, how to reach/enter the vent, final lighting preferences and any Room 2 story/scare events. No approval is needed to explore this environmental foundation. See `ROOM2-REPORT.md` for the files changed, checks and limits.


### Direct Room 2 test start
The menu's **ROOM 2 / TEST** button asks for your name, then starts directly inside storage with the entrance already locked and the timer starting at zero. It skips the bedroom puzzle and wake-up/transition narration. Normal PLAY still runs the original Room 1 start. Backing out of the name form and choosing PLAY resets the testing choice. Run `node tests/storage-start.mjs` to check desktop/touch direct entry and the normal-start fallback.


### Room 2 envelope
An aged envelope rests on a deeper shelf in the third aisle, beyond the first cross-passage and screened from the entrance by shelving. E/left-click or touch INTERACT inspects the envelope, addressed From/To the entered player name in uneven blood-red handwriting with small drips. OPEN ENVELOPE reveals a rotatable, zoomable letter with uneven hand-drawn blood strokes, sparse drips and finger smears. Closing restores the world envelope; reopening returns to the letter without requiring another opening. Its four sentences are held in `STORAGE_LETTER_TEXT` and wrapped for the physical paper without changing their wording. Run `npm run test:envelope`. No Room 1 content or new narrator line is added.


### First letter narrator
Opening the Room 2 letter for the first time queues the supplied unchanged 6.922-second recording. Merely inspecting the sealed envelope is silent. Shared narrator scheduling waits for other dialogue; playback is marked once only after the recording successfully starts. Closing and rereading cannot restart it. Two AudioContext-timed captions read “(Narrator) Found something interesting?” and “(Narrator) How about we forget about that and concentrate on escaping, shall we?” Captions sit above the paper during letter inspection, while normal Room 1 subtitle placement remains unchanged. Run `npm run test:letter-voice`.


### Fragile closet appearance
The Room 1 closet front now uses thin separated wooden slats, chipped ends, pale exposed fibres, branching stress cracks and visibly split retaining boards with exposed nail heads. Existing room lighting provides the contrast; no glowing marker or new prompt is added. The extra front detail is batched by material. The first-hammer-hit scare, 30-fragment breakage, collision footprint and disabled interactions after destruction remain unchanged.


### Sturdier window barricade
Window boards are thicker, more evenly aligned and darker, with broad metal washers and a heavier diagonal brace. Gaps still admit moonlight. They contrast with the chipped closet front; the existing hammer-removal sequence, key reveal and collection remain the same. Run `npm run test:window-barricade`.


### Updated repeat-interaction thresholds
The bed narrator now triggers on the second inspection, once per game. The intact closet's empty-hand peace line now queues on the seventh accepted interaction, retaining the existing short debounce and unreadable-speaker caption. Hammer hits do not count toward this line; first hammer contact still triggers the separate scare/destruction, and the broken closet stays inactive.


## Room 2 computer — Stages 1 and 2
An aged beige CRT computer and keyboard occupy one existing shelf bay in aisle 2, in the front section (x=3.81, z=4.72). Only the contents/backing of that bay were cleared to fit the computer; shelf positions and the room layout are unchanged. Interact with E/left-click or touch INTERACT, choose POWER ON, then STAGE 1. EXIT COMPUTER or Esc returns to first-person controls.

A physical LETTER / NUMBER key is attached to the left-facing side of a rear shelf beside aisle 4 (x=7.285, z=8.75). Inspect it with the existing rotation/zoom controls. It gives A=1 through I=9. The terminal generates four letters once per run; translate them in order into four digits. Wrong answers leave the stage incomplete. Closing/reopening or powering on again does not regenerate the sequence. Stage 1 completion persists during the run. Completing Stage 1 makes Stage 2 available; Stage 3 requires Stage 2 completion; Stage 4 becomes a read-only hint after Stage 3.

Exactly three designated closed puzzle crates, numbered BOX 1–3, sit among normal shelf packages in separate bays. Only a glowing crate can be picked up. Stage 1 enables Box 1; Stage 2 permanently adds Box 2. Stage 3 permanently adds Box 3. Previously unlocked crates stay unlocked. E/left-click or touch INTERACT lifts the glowing crate into the player's view. Walk to carry it, then use G or touch DROP to set it on clear floor (empty-target E/left-click also sets it down). Drop the hammer first: only one object can be carried. The old placement menu and vent-side floor pads are removed. Drops check walls, racks, player clearance and room bounds; blocked placement keeps the crate in hand. Floor crates remain stable and can be picked up again. Room 2 now supports walking up placed box steps; no jumping control is added.

Only Box 1 gains a restrained emissive glow after solving Stage 1. It stays sealed. Its reserved wrench is enclosed, hidden, untargetable and unusable. Moving/stacking does not open any crate or unlock a stage. The existing future vent developer hook now names the wrench as its reserved tool, reflecting the updated specification; no normal player interaction invokes it. The existing ending remains separate and unchanged.

Runtime modules: `computer-stage.js`, `box-stacking.js`, `storage-computer.js`, `computer-interface.js`. Run `npm test`, `npm run test:computer`, and see `COMPUTER-STAGE1-REPORT.md` for validation and remaining limits.


### Embedded viewer startup and shelf visibility
WAKE UP and computer answer submission handle button activation and Enter directly, preventing native form navigation. This supports embedded viewers without `allow-forms`, while preserving name validation/filtering and the existing mouse-capture fallback. Tests reproduce the original blocked submission inside a restricted iframe and verify click, touch, Enter, normal waking, Room 2 test entry and terminal submission. This is browser sandbox emulation, not a test inside the actual ChatGPT app.

Room 2's indirect illumination and neutral ground bounce are brighter, with two additional low-power unshadowed shelf fills activated only after entry. All shelf rows remain under the existing two shadow-casting ceiling lights. Room 1 lighting settings are unchanged. Run `npm run test:storage-lighting` for front/rear screenshots in all six aisles.


### Room 2 walking speed
Room 2 movement is 1.35 m/s (about 29% faster) for keyboard and touch. Room 1 stays at 1.05 m/s. Acceleration, collisions and the translation clue location remain unchanged.


### Glowing-box locator and vent floor guides
After Stage 1, Box 1 also shows a green outline through shelves/walls while resting in the world. The outline follows its dropped position and hides while carried. It grants visibility only: normal range, collision and glowing-only pickup checks remain. Stages 2 and 3 permanently add Box 2’s and Box 3’s outlines. Worn floor guides beneath the vent show Box 1 as the first step, followed by Box 3 stacked on Box 2 as the higher step. These are visual guides, not teleport pads or new unlock/escape triggers.


### Box staircase beneath the shaft
The first floor guide is Box 1 at (10.35, 9.8). The next guide at (10.35, 10.45) reads “2 + 3 / 3 ON TOP OF 2,” forming a two-level staircase toward the high grille. Room 2 movement steps onto supported crate tops up to 0.58 m higher and settles safely back onto lower surfaces/the floor. No extra jump button is needed; keyboard and joystick movement use the same behavior. Room 1 movement is unchanged. Box 1 is movable after Stage 1 and Box 2 after Stage 2; Box 3 becomes movable after Stage 3, allowing the full staircase to be assembled. The vent requires the wrench and an elevated player on the three-box stairs to open and escape.


## Stage 2 — missing inventory
After Stage 1, select Stage 2 on the same computer. It expects Aisle 3 Shelf A: 2 radios, Shelf B: 1 table lamp and Shelf C: 3 suitcases. The three rear bays on the left side of aisle 3 are labeled A, B and C; actual stock is 2 radios, 1 lamp and 2 suitcases. E/left-click/touch INTERACT can inspect the complete stock group using existing rotate/zoom controls, without changing or collecting the items.

The dusty STORAGE INVENTORY reference sheet hangs on the front wall below LINEN & FURNISHINGS (4.6, 1.4, 2.171). It lists RADIO 14, TABLE LAMP 27, SUITCASE 38 and consistent IDs for existing cartons, linen, covered belongings, pictures, sealed crates and the computer. No item IDs float over objects. Enter the missing item ID followed by the shelf letter: **38C**. Only case and surrounding whitespace are normalized. Incorrect input displays INCORRECT CODE; correct input displays CORRECT — STAGE 2 COMPLETE. No timeout, punishment, answer reveal or narrator line is added.

All six aisles have worn numerical signs. Every framed shelf bay has one identifier for its entire set of levels; labels are readable on both faces. There are 24 globally unique letters A–X, so identifiers are also unique within each aisle. Shared units retain the same letter when viewed from the neighboring aisle. Shelf geometry and paths are unchanged. Only the three required puzzle units were cleared/replaced to make counts unambiguous.

After completion, Boxes 1 and 2 both stay glowing, outlined and movable. Stage 3 becomes available and unlocks Box 3 on completion. Stage 3 also enables opening all boxes, collecting Box 1’s wrench and reaching the vent; Stage 4 offers the final hint. Lift a top box before moving its supporting base; lifted support links are detached immediately, allowing reliable restacking/recovery. Run `npm run test:stage2`. See `STAGE2-REPORT.md` for files and actual validation results.


## Stage 3 — password recovery
After Stage 2, select Stage 3 on the same terminal. It shows the fixed mixed pool `N S E I L H E T S G I I N` and only the hint “The letter...” referring to the existing Room 2 letter. Click/tap each tile to fill the 2 + 2 + 9 answer slots. The UI inserts word gaps automatically; duplicate letters are independent tiles. BACKSPACE restores the last tile, CLEAR restores all tiles and ENTER stays disabled until 13 tiles are selected. Wrong answers display INVALID PASSWORD with free retries. The solution is HE IS LISTENING; it is not supplied as a hint in the game.

Correct submission displays ACCESS GRANTED / STAGE 03 COMPLETE and permanently adds Box 3's existing green glow, outline and carry permission. Boxes 1 and 2 remain unlocked. Partial input and completion survive closing/reopening during the current run. Stage 4 now unlocks as the final read-only hint, and all boxes become openable immediately after Stage 3. The final update adds the wrench/grille escape described below. Run `npm run test:stage3`; see `STAGE3-REPORT.md` for changed files and executed checks.


## Final Room 2 escape
The existing story letter has a FLIP button after opening; its front text and first-read voice are unchanged. Its back reads HE IS LISTENING, available immediately. Stage 4 becomes available after Stage 3 and displays only FINAL MESSAGE / Think inside the box. / END OF MESSAGE. Reading Stage 4 is optional.

Before Stage 3, unlocked boxes carry normally and cannot open. After Stage 3, E/left-click/touch INTERACT on a closed box opens it without pickup; interacting with the open body picks it up. Boxes 2/3 are empty. Aim into Box 1's cavity to collect the separate wrench target; aiming at its wooden body still carries the box. The wrench enters the existing tool state and cannot be dropped or lost. All boxes retain glow, movement, solid step surfaces and stable stacking.

Use the existing floor guides: Box 1 first, then Box 3 on Box 2. Climb with normal keyboard/joystick movement. The vent is inactive from the floor or without the wrench. At the top, interact once to swing the grille open and again to escape. Room 2 fades to black and displays only TO BE CONTINUED... (no timer, narration or extra ending text). Run `npm run test:escape-room2`; see `FINAL-ESCAPE-REPORT.md` for scoped changes and actual checks.


## Stage 2 assistance
Completing Stage 1 starts one hidden 300-second monotonic timer. It continues while exploring or closing/reopening the PC. Solving Stage 2 early cancels the timer and keeps HELP hidden. If still unsolved at expiry, Stage 2 gains HELP and the supplied Attention Assistance.mp3 plays once, queued behind existing speech. The existing subtitles show the exact `(PC)` caption only during playback. HELP contains the seven procedural instructions and BACK TO PUZZLE, without the answer or missing-item identity. Typed input survives HELP/BACK. Already-activated HELP remains available after a late solve, but no pending announcement can start afterward.

The deadline continues through pause/backgrounding, with playback deferred until the game is visible, unpaused and audio is running. Production duration is fixed at 300 seconds; browser tests use a simulated clock. Run `npm run test:assistance`; see `STAGE2-ASSISTANCE-REPORT.md` for files and actual validation.


## Room 2 PC startup cue
Entering Room 2 starts a one-time two-second delay, including the direct testing start. The supplied startup MP3 then plays at normal speed on the existing SFX bus, independently of the doorway narration. A small (PC Startup) sound caption lasts only for the recording. Pause/backgrounding defers a pending start until gameplay resumes; PC power/menu interactions never replay it. No PC power state, puzzle or Stage 2 assistance behavior changes. Run `npm run test:pc-startup`.


## Positional PC beeps
After the Room 2 startup chime, the monitor emits one quiet 0.11-second pip every 3.2 seconds until the first PC interaction. A world-space HRTF panner follows the existing camera listener and distance falloff, so the sound shifts sides as you walk/turn. Opening the computer through E/left-click/touch permanently stops the cue, even if it was not yet running; closing or revisiting never restarts it. Other inspections do not consume the cue. No new controls, captions or puzzle changes are added. Run `npm run test:pc-beeps`.


## Stage 2 WELCOME BACK event
The first successful Stage 2 answer unlocks Box 2 and Stage 3 immediately, then briefly flickers the existing CRT and displays STAGE 02 COMPLETE / ACCESS GRANTED / USER RECOGNIZED / WELCOME BACK, followed by the existing player name. It lasts four seconds plus a short ending flicker before returning to the stage menu. Narration and narrator subtitles are suppressed only during this event; a quiet existing electronic noise effect accompanies the initial flicker. Closing the PC cancels the display safely, restores narration and never replays it. Wrong answers, opening Stage 2 and later PC visits do not trigger it. No puzzle, hint, movement or escape behavior was retuned. Run `npm run test:welcome-back`; see WELCOME-BACK-REPORT.md and VALIDATION.md.


## NORMAL and DEMO modes
PLAY → NORMAL or DEMO → existing name entry. Both begin with the unchanged bedroom. NORMAL leads to the existing storage room; DEMO leads to a separate 7×6 m Observation Room. The old ROOM 2 / TEST button remains a normal-storage shortcut. RETURN TO TITLE on pause reloads a fresh game, and the DEMO ending also provides a return button.

In the office, physically carry one VHS tape at a time with E/left-click/touch INTERACT, G/DROP to put it down, use the single deck to insert/eject/replay and arrange the three recordings chronologically in 01–03. VERIFY rejects an incorrect order without resetting. The correct archive starts a real corner-camera live view with no player model and unlocks the metal exit. Walk through to finish. Four one-shot environmental events and the existing material/audio/control systems are used; the three new narrator lines currently use captions only, pending supplied recordings. There is no inventory panel, player body, sprint, gameplay music, mirror figure or extra puzzle.

Run `npm run test:demo` for the desktop/touch DEMO route, `npm run test:browser` for the NORMAL bedroom regression and `npm run test:escape-room2 -- --desktop-only` for the normal storage escape. See DEMO-REPORT.md for runtime files, live-camera details and test limitations. The approximate 5/10-minute pacing targets are not forced timers or a measured playtest guarantee.


## DEMO ending invitation
After the black TO BE CONTINUED... screen, the invitation waits three seconds. PLAY FULL VERSION appears after it and starts a fresh NORMAL name-entry flow. Pending the user's final narrator MP3, the invitation is a ten-second caption-only placeholder. The existing voice system is prepared to use the recording's actual duration when provided; live-camera narration remains suppressed.

## DEMO Observation Room sound and exit feedback
The DEMO room now has positional CRT hum and VCR transport noise, distinct cassette load/eject/slot sounds, quiet occasional metal creaks, an archive error tone, and spatial exit latch/hinge sounds. Room tone fades away during the final live-camera sequence; narrator silence remains enforced. Restoring the archive changes the persistent sign above the door to EXIT UNLOCKED and turns its small status light green, with a soft local spill. A nearby door prompt gives E / LEFT CLICK or touch INTERACT instructions. Puzzle order, door-opening rules, and NORMAL rooms are unchanged.


## AKUMU v2.0 visual release
See V2-REPORT.md for the visual-only overhaul and launch instructions, V2-PERFORMANCE.md for measured limitations and V2-REGRESSION.md for real test coverage. The continuous beveled wrench is visual-only inside the original reserved-wrench group. Existing NORMAL/DEMO mechanics remain. Use the standalone HTML or the website archive; no runtime external assets are needed.

## Laundry basement expansion

The Laundry Room includes one hidden washer passage, a short automatic chute and an explorable basement with walkable return stairs. No new puzzle is present. See `BASEMENT-REPORT.md` for files, verification and limitations. Run `npm run test:basement` for the basement state and desktop/touch browser checks.

## 1986 reception presentation

The main menu is a real-time 3D reception with quiet ambience and no music. PLAY retains NORMAL/DEMO selection; name entry uses the existing validation and personalization through an accessible input on a physical guestbook page. Loading uses the existing real progress with a hotel-document visual style. The in-world Room 2 terminal keeps its own interface.

ROOM 2 / TEST and ROOM 3 / TEST appear only with `?debug`, for example `AKUMU.html?debug` or `/games/akumu/?debug`. Their destinations are unchanged. `npm run test:reception` runs current presentation/flow/preservation checks. The older menu and pixel-name npm command aliases now point to these current checks. See `RECEPTION-REPORT.md` for exact validation and limitations.
