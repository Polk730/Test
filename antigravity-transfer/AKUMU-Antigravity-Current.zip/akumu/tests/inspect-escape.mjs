import {chromium} from '@playwright/test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {createServer} from 'node:http';
const html=await readFile('standalone/AKUMU.html'),server=createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(html);});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try{const p=await browser.newPage({viewport:{width:1000,height:700},deviceScaleFactor:.5}),errors=[];p.setDefaultTimeout(180000);p.on('pageerror',e=>errors.push(e.message));await p.goto(`http://127.0.0.1:${server.address().port}/?debug`);await p.waitForFunction(()=>window.__AKUMU__);await p.click('#play');await p.click('#mode-normal');await p.fill('#player-name','Alex');await p.click('#name-form button[type=submit]');await p.waitForFunction(()=>window.__AKUMU__.state==='playing');if(await p.locator('#pause').isVisible())await p.click('#pause');
for(let i=0;i<2;i++){
 await p.evaluate(()=>window.__AKUMU__.setView(-.63,.95,Math.PI,-.21));await p.waitForFunction(()=>window.__AKUMU__.focused?.kind==='note');await p.keyboard.press('e');await p.waitForFunction(()=>window.__AKUMU__.state==='inspecting');await p.waitForFunction(()=>document.pointerLockElement===null);
 await p.keyboard.press('Escape');await p.waitForFunction(()=>window.__AKUMU__.state==='playing'&&!window.__AKUMU__.paused&&document.pointerLockElement===document.getElementById('world'));
 assert.equal(await p.locator('#pause').isVisible(),false);assert.equal(await p.locator('#inspection').isVisible(),false);
 const before=await p.evaluate(()=>window.__AKUMU__.camera.rotation.y);await p.mouse.move(500,350);await p.mouse.move(570,350);await p.waitForFunction(before=>Math.abs(window.__AKUMU__.camera.rotation.y-before)>.01,before);
 console.log('Escape closes inspection and restores real mouse capture/look without pausing, cycle',i+1);
}
await p.keyboard.press('Escape');await p.waitForFunction(()=>window.__AKUMU__.paused);assert.equal(await p.evaluate(()=>document.pointerLockElement),null);assert.deepEqual(errors,[]);console.log('A separate Escape during gameplay still pauses/releases the mouse normally.');
}finally{await browser.close();server.close();}
