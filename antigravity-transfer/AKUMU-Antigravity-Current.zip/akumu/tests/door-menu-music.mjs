import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.addInitScript(()=>{const Native=window.Audio;window.Audio=function(...args){const a=new Native(...args);if(args[0]?.startsWith('data:audio')){window.__menuAudio=a;window.__musicAttempts=0;const play=a.play.bind(a);a.play=()=>{window.__musicAttempts++;return play();};}return a;};});
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});
 await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:60000});
 assert.equal(await page.locator('.menu-music').count(),0);
 assert.ok(await page.evaluate(()=>window.__musicAttempts>=1));
 await page.locator('#menu').click({position:{x:20,y:100}});
 await page.waitForFunction(()=>window.__menuAudio&&!window.__menuAudio.paused);
 assert.equal(await page.evaluate(()=>window.__menuAudio.loop),true);
 await page.screenshot({path:'test-results/music-menu.png'});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 assert.equal(await page.evaluate(()=>window.__menuAudio.paused),true);
 assert.deepEqual(errors,[]);console.log('Automatic music attempt, gesture fallback, no toggle, looping and stop on PLAY passed.');
}finally{await browser.close();server.close();}
