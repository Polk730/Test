import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');for(const rejectedName of ['niger','n1g3r','n i g e r']){await page.fill('#player-name',rejectedName);await page.click('#name-form button[type=submit]');assert.equal(await page.evaluate(()=>window.__AKUMU__.state),'menu');assert.equal(await page.locator('#name-error').textContent(),'Please choose a different name.');}
 assert.equal(await page.evaluate(()=>window.__AKUMU__.state),'menu');assert.equal(await page.locator('#name-entry').isVisible(),true);assert.equal(await page.locator('#name-error').textContent(),'Please choose a different name.');assert.equal(await page.locator('#player-name').getAttribute('aria-invalid'),'true');
 await page.fill('#player-name','Maya Rose');assert.equal(await page.locator('#name-error').textContent(),'');
 await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='opening');assert.equal(await page.locator('#name-entry').isVisible(),false);
 assert.equal(await page.evaluate(()=>window.__AKUMU__.room.bloodMessage.mesh.userData.message),"Maya Rose, you don't remember me, but I remember you..");
 assert.deepEqual(errors,[]);console.log('Rejected obfuscated profanity stays on form with accessible error; editing clears it; valid name starts the game and personalizes the wall.');
}finally{await browser.close();server.close();}
