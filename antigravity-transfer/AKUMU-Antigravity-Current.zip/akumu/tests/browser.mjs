// Backwards-compatible entry point for the current V1 browser playthrough.
import './prototype.mjs';
