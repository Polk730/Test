import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const errors=[],url=process.env.AKUMU_URL||'http://127.0.0.1:4175/AKUMU.html?debug';
const observe=p=>p.on('pageerror',e=>errors.push(e.message));
try{
 const context=await browser.newContext({viewport:{width:1000,height:700}});
 await context.addInitScript(()=>{Object.defineProperty(navigator,'maxTouchPoints',{get:()=>5});window.__captureCalls=0;HTMLCanvasElement.prototype.requestPointerLock=()=>{window.__captureCalls++;return Promise.reject(new Error('Browser permission denied'));};});
 const page=await context.newPage();observe(page);await page.goto(url,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:60000});await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 assert.equal(await page.evaluate(()=>window.__AKUMU__.touchMode),false);assert.equal(await page.evaluate(()=>document.activeElement.id),'world');assert.equal(await page.evaluate(()=>window.__AKUMU__.paused),false);assert.equal(await page.locator('#input-notice').isVisible(),true);
 await page.evaluate(()=>window.__AKUMU__.setView(0,0));await page.keyboard.down('w');await page.waitForFunction(()=>window.__AKUMU__.camera.position.z<-.12,null,{timeout:30000});await page.keyboard.up('w');console.log('Denied capture: touchscreen laptop still gets desktop mode, keyboard focus and WASD movement');
 await page.evaluate(()=>{window.__contextPrevented=false;document.addEventListener('contextmenu',e=>window.__contextPrevented=e.defaultPrevented);});
 await page.mouse.click(500,350,{button:'right'});await page.waitForFunction(()=>window.__contextPrevented);assert.equal(await page.evaluate(()=>window.__AKUMU__.paused),false);
 let yaw=await page.evaluate(()=>window.__AKUMU__.camera.rotation.y);await page.mouse.move(500,350);await page.mouse.down({button:'right'});await page.mouse.move(600,370,{steps:5});await page.mouse.up({button:'right'});await page.waitForFunction(y=>Math.abs(window.__AKUMU__.camera.rotation.y-y)>.05,yaw);
 yaw=await page.evaluate(()=>window.__AKUMU__.camera.rotation.y);await page.mouse.down({button:'left'});await page.mouse.move(680,380,{steps:5});await page.mouse.up({button:'left'});await page.waitForFunction(y=>Math.abs(window.__AKUMU__.camera.rotation.y-y)>.05,yaw);
 console.log('Right-click menu prevented; both right-drag and left-drag look work without Pointer Lock');
 await page.keyboard.down('w');await page.keyboard.press('Escape');await page.waitForFunction(()=>window.__AKUMU__.paused);await page.click('#pause');assert.equal(await page.evaluate(()=>window.__AKUMU__.paused),false);assert.equal(await page.evaluate(()=>document.activeElement.id),'world');
 await page.evaluate(()=>window.__AKUMU__.setView(0,0));await page.keyboard.down('w');await page.waitForFunction(()=>window.__AKUMU__.camera.position.z<-.12);await page.keyboard.up('w');console.log('Pause/resume remains playable after capture rejection');await context.close();
 const touch=await browser.newContext({viewport:{width:1024,height:768},hasTouch:true,isMobile:true});const tablet=await touch.newPage();observe(tablet);await tablet.goto(url,{waitUntil:'domcontentloaded',timeout:120000});await tablet.tap('#play');await tablet.tap('#mode-normal');await tablet.fill('#player-name','Alex');await tablet.tap('#name-form button[type=submit]');await tablet.waitForFunction(()=>window.__AKUMU__?.state==='playing',null,{timeout:60000});assert.equal(await tablet.locator('#touch-controls').isVisible(),true);
 const b=await tablet.locator('#joystick').boundingBox(),cdp=await touch.newCDPSession(tablet),x=b.x+b.width/2,y=b.y+b.height/2;
 const initial=await tablet.evaluate(()=>window.__AKUMU__.camera.position.z);await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{id:1,x,y}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{id:1,x,y:y-35}]});await tablet.waitForFunction(z=>window.__AKUMU__.camera.position.z<z-.10,initial,{timeout:30000});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});console.log('Touch joystick remains functional with dynamic input-mode detection');
 assert.deepEqual(errors,[]);console.log('Chrome input regression passed without page errors');await touch.close();
}finally{await browser.close();}
