import {build} from 'vite';
import {chromium} from '@playwright/test';
import {existsSync} from 'node:fs';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
await mkdir('test-results',{recursive:true});
const result=await build({configFile:false,build:{write:false,minify:true,lib:{entry:'src/audio.js',name:'AKUMUAudio',formats:['iife']},rollupOptions:{output:{inlineDynamicImports:true}}}});
const code=result[0].output.find(o=>o.type==='chunk').code;
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox']});
const html=await readFile('standalone/AKUMU.html');const server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const page=await browser.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.setContent('<button id="start">Start audio</button>');await page.addScriptTag({content:code});
 const report=await page.evaluate(async()=>{
  function stats(data){let peak=0,sum=0;for(const s of data){peak=Math.max(peak,Math.abs(s));sum+=s*s;}return {peak,rms:Math.sqrt(sum/data.length)};}
  const rate=48000,context=new OfflineAudioContext(2,rate*12.5,rate),audio=new AKUMUAudio.Ambience();audio.setup(context);
  const effects=['footstep','door','drawer','wheel','unlock','pickup','impact','fall','key','doorCreak','ambientCreak'];effects.forEach((name,i)=>audio.play(name,(i%3-1)*.3,.3+i*.9));
  for(let i=0;i<6;i++)audio.play('fall',(i-3)*.08,7.0+i*.075);
  const suspension=context.suspend(11);const rendering=context.startRendering();await suspension;audio.fadeOut(.45);await context.resume();const buffer=await rendering;
  const left=buffer.getChannelData(0),right=buffer.getChannelData(1),all=stats(left),fade=stats(left.subarray(rate*12));
  const pcm=[];for(let i=0;i<buffer.length;i++){pcm.push(Math.max(-32767,Math.min(32767,Math.round(left[i]*32767))));pcm.push(Math.max(-32767,Math.min(32767,Math.round(right[i]*32767))));}
  const single=new OfflineAudioContext(1,rate*.7,rate),foley=new AKUMUAudio.Ambience();foley.setup(single);foley.ambience.gain.value=0;foley.footstep();const foot=stats((await single.startRendering()).getChannelData(0));
  const old=new OfflineAudioContext(1,rate*.7,rate),master=old.createGain();master.gain.value=.45;master.connect(old.destination);const noise=old.createBuffer(1,rate*5,rate);let n=0;const nd=noise.getChannelData(0);for(let i=0;i<nd.length;i++){n=(n+(Math.random()*2-1)*.018)/1.018;nd[i]=n*3.3;}
  const source=old.createBufferSource(),filter=old.createBiquadFilter(),gain=old.createGain();source.buffer=noise;filter.type='lowpass';filter.frequency.value=420;gain.gain.setValueAtTime(.001,0);gain.gain.linearRampToValueAtTime(.2,.012);gain.gain.exponentialRampToValueAtTime(.001,.13);source.connect(filter).connect(gain).connect(master);source.start();source.stop(.16);
  const tone=old.createOscillator(),tg=old.createGain();tone.frequency.setValueAtTime(80,0);tone.frequency.exponentialRampToValueAtTime(56,.12);tg.gain.setValueAtTime(.001,0);tg.gain.linearRampToValueAtTime(.025,.025);tg.gain.exponentialRampToValueAtTime(.001,.12);tone.connect(tg).connect(master);tone.start();tone.stop(.14);const baseline=stats((await old.startRendering()).getChannelData(0));
  return {all,fade,foot,baseline,footstepGainDb:20*Math.log10(foot.rms/baseline.rms),samples:pcm,rate};
 });
 assert.ok(report.all.peak<.99&&report.all.peak>.1);assert.ok(report.fade.peak<.00001);assert.ok(report.footstepGainDb>8);assert.deepEqual(errors,[]);
 const data=Buffer.alloc(report.samples.length*2);report.samples.forEach((v,i)=>data.writeInt16LE(v,i*2));const header=Buffer.alloc(44);header.write('RIFF',0);header.writeUInt32LE(36+data.length,4);header.write('WAVEfmt ',8);header.writeUInt32LE(16,16);header.writeUInt16LE(1,20);header.writeUInt16LE(2,22);header.writeUInt32LE(report.rate,24);header.writeUInt32LE(report.rate*4,28);header.writeUInt16LE(4,32);header.writeUInt16LE(16,34);header.write('data',36);header.writeUInt32LE(data.length,40);await writeFile('test-results/sfx-preview.wav',Buffer.concat([header,data]));
 delete report.samples;console.log('Offline audio mix:',JSON.stringify(report));
 await page.evaluate(()=>{window.testAudio=new AKUMUAudio.Ambience();document.getElementById('start').addEventListener('click',()=>window.testAudio.start());});await page.click('#start');await page.waitForFunction(()=>window.testAudio.ctx?.state==='running');
 await page.evaluate(async()=>{const a=window.testAudio;a.footstep();a.wheel();a.unlock();a.impact();a.key();await a.pause();});assert.equal(await page.evaluate(()=>window.testAudio.ctx.state),'suspended');await page.evaluate(()=>window.testAudio.resume());await page.waitForFunction(()=>window.testAudio.ctx.state==='running');
 console.log('User-gesture playback, action methods, pause/resume, headroom and ending fade passed');
 await page.evaluate(()=>window.testAudio.ctx.close());
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__?.audio,null,{timeout:60000});await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing'&&window.__AKUMU__.audio.ctx?.state==='running',null,{timeout:60000});
 if(await page.locator('#pause').isVisible())await page.click('#pause');
 await page.evaluate(()=>window.__AKUMU__.setView(1.4,.8,Math.PI,0));await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='door');await page.keyboard.press('e');await page.waitForFunction(()=>[...window.__AKUMU__.audio.buffers.keys()].some(k=>k.startsWith('door:')));
 await page.evaluate(()=>window.__AKUMU__.setView(0,0));await page.keyboard.down('w');await page.waitForFunction(()=>[...window.__AKUMU__.audio.buffers.keys()].some(k=>k.startsWith('footstep:')),null,{timeout:30000});await page.keyboard.up('w');await page.keyboard.press('Escape');await page.waitForFunction(()=>window.__AKUMU__.audio.ctx.state==='suspended');await page.click('#pause');await page.waitForFunction(()=>window.__AKUMU__.audio.ctx.state==='running');assert.deepEqual(errors,[]);console.log('Standalone game: PLAY audio, real door/footstep triggers and Esc/resume passed');
}catch(e){console.log('Audio errors:',errors);throw e;}finally{await browser.close();server.close();}
