import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createServer} from 'node:http';
const html=await readFile('standalone/AKUMU.html');const server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try{
 for(const touch of (process.env.AKUMU_NORMAL_ONLY?[]:[false,true])){
 const page=await browser.newPage({viewport:{width:800,height:600},deviceScaleFactor:.5,hasTouch:touch,isMobile:touch});const press=selector=>touch?page.tap(selector):page.click(selector);const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:120000});
 // Going back and choosing PLAY must clear the testing choice.
 await press('#test-room-two');await press('#name-back');await press('#play');await press('#mode-normal');await press('#name-back');await press('#test-room-two');await page.fill('#player-name','Alex');await press('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:120000});
 const state=await page.evaluate(()=>{const g=window.__AKUMU__;return {room:g.currentRoom,name:g.playerName,phase:g.progression.phase,door:g.puzzle.state.door,z:g.camera.position.z,paused:g.paused,seconds:g.runSeconds,openingVoice:g.openingUsesAudio};});
 assert.equal(state.room,2);assert.equal(state.name,'Alex');assert.equal(state.phase,'locked');assert.equal(state.door,'locked-behind');assert.equal(state.z,3);assert.equal(state.paused,false);assert.equal(state.openingVoice,false);assert.ok(state.seconds<10);assert.equal(await page.locator('#escape-time').isVisible(),false);
 if(touch)assert.equal(await page.locator('#touch-controls').isVisible(),true);
 else{await page.keyboard.down('w');await page.waitForFunction(()=>window.__AKUMU__.camera.position.z>3.15,null,{timeout:60000});await page.keyboard.up('w');}
 assert.deepEqual(errors,[]);console.log(touch?'Touch direct Room 2 start passed':'Desktop direct Room 2 start and movement passed');await page.close();
 }
 const normal=await browser.newPage({viewport:{width:800,height:600},deviceScaleFactor:.5});await normal.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await normal.waitForFunction(()=>window.__AKUMU__,null,{timeout:120000});await normal.click('#test-room-two');await normal.click('#name-back');await normal.click('#play');await normal.click('#mode-normal');await normal.fill('#player-name','Alex');await normal.click('#name-form button[type=submit]');await normal.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:120000});assert.equal(await normal.evaluate(()=>window.__AKUMU__.currentRoom),1);assert.equal(await normal.evaluate(()=>window.__AKUMU__.progression.phase),'bedroom-locked');console.log('Normal PLAY still starts in Room 1 after cancelling testing choice');await normal.close();
}finally{await browser.close();server.close();}
