import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__?.audio?.escapeVoiceBuffer,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 const duration=await page.evaluate(()=>window.__AKUMU__.audio.escapeVoiceBuffer.duration);assert.ok(duration>5&&duration<5.2);
 await page.evaluate(()=>{const g=window.__AKUMU__;g.puzzle.interact({kind:'door'});window.__escapeFrames=[];const record=()=>{const a=g.audio;if(g.state==='ending'&&a.escapeVoice)window.__escapeFrames.push({time:a.escapeTime(),caption:document.getElementById('ending-caption').textContent,master:a.master.gain.value});if(document.getElementById('escape-time').hidden)requestAnimationFrame(record);};requestAnimationFrame(record);g.finishGame(true);});
 await page.waitForFunction(()=>window.__AKUMU__.audio.escapeVoice,null,{timeout:20000});
 await page.waitForFunction(()=>document.getElementById('ending-caption').textContent.includes('One door down'),null,{timeout:15000});
 assert.equal(await page.locator('#escape-time').isVisible(),false);
 const stopped=await page.evaluate(async()=>{const a=window.__AKUMU__.audio;await a.pause();return a.escapeTime();});await page.waitForTimeout(200);assert.ok(Math.abs(await page.evaluate(()=>window.__AKUMU__.audio.escapeTime())-stopped)<.04);await page.evaluate(()=>window.__AKUMU__.audio.resume());
 await page.waitForFunction(()=>!document.getElementById('escape-time').hidden,null,{timeout:25000});
 const result=await page.evaluate(()=>({frames:window.__escapeFrames,ended:window.__AKUMU__.audio.escapeVoice.ended,oldEnded:window.__AKUMU__.audio.doorVoice.ended}));
 assert.ok(result.frames.some(f=>f.caption.includes('One door down.')));const question=result.frames.filter(f=>f.caption.includes('How many more until you remember?'));assert.ok(question.length>0);assert.ok(question.every(f=>f.master>.8));assert.equal(result.ended,true);assert.equal(result.oldEnded,true);
 assert.equal(await page.locator('#ending-caption').textContent(),'');assert.equal(await page.locator('#opening-caption').textContent(),'TO BE CONTINUED...');assert.match(await page.locator('#escape-time').textContent(),/^Escaped in/);
 await page.screenshot({path:'test-results/escape-narrator-ending.png'});assert.deepEqual(errors,[]);console.log('Embedded escape recording, both narrator cues, audio-clock pause alignment, interruption of prior dialogue, preserved voice volume, final title and escape time passed. Duration:',duration);
}finally{await browser.close();server.close();}
