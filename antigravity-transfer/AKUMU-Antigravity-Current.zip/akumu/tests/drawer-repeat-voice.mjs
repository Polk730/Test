import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700},deviceScaleFactor:.5}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__?.audio?.drawerRepeatVoiceBuffer,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 await page.evaluate(()=>{const p=window.__AKUMU__.puzzle;p.interact({kind:'drawer'});});assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.drawerOpens),0);
 await page.evaluate(()=>{const p=window.__AKUMU__.puzzle;[1,9,8,6].forEach((digit,i)=>{for(let n=0;n<digit;n++)p.turnWheel(i);});});await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.drawer==='unlocked');
 for(let n=1;n<=3;n++){
  await page.evaluate(()=>window.__AKUMU__.puzzle.interact({kind:'drawer'}));assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.drawerOpens),n);
  if(n<3){assert.equal(await page.evaluate(()=>!!window.__AKUMU__.audio.doorVoice),false);await page.evaluate(()=>window.__AKUMU__.puzzle.interact({kind:'drawer'}));}
 }
 await page.waitForFunction(()=>document.getElementById('opening-caption').textContent==="(Narrator) Maybe it'll magically refill. Keep trying.",null,{timeout:15000});
 const at=await page.evaluate(()=>window.__AKUMU__.audio.doorVoice.startAt);
 await page.evaluate(()=>{const p=window.__AKUMU__.puzzle;p.interact({kind:'drawer'});p.interact({kind:'drawer'});});assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.doorVoice.startAt),at);
 await page.evaluate(()=>{const g=window.__AKUMU__;g.finishGame(true);});await page.waitForFunction(()=>window.__AKUMU__.audio.escapeVoice);
 assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.drawerRepeatVoice()),false);
 await page.waitForFunction(()=>document.getElementById('ending-caption').textContent.includes('How many more'),null,{timeout:15000});
 await page.waitForFunction(()=>!document.getElementById('escape-time').hidden,null,{timeout:20000});assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.escapeVoice.ended),true);assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.doorVoice.ended),true);
 assert.deepEqual(errors,[]);console.log('Locked drawer does not count, first two openings silent, third triggers voice/caption once, fourth does not restart, escape interrupts and blocks queued lines, ending voice/time preserved.');
}finally{await browser.close();server.close();}
