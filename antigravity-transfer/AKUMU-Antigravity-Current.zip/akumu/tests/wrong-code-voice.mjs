import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700},deviceScaleFactor:.5}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});
 await page.waitForFunction(()=>window.__AKUMU__?.audio?.wrongCodeVoiceBuffer,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 await page.evaluate(()=>{const g=window.__AKUMU__;g.puzzle.interact({kind:'lock'});});
 await page.waitForTimeout(2200);assert.equal(await page.evaluate(()=>!!window.__AKUMU__.audio.doorVoice),false);
 await page.evaluate(()=>window.__AKUMU__.puzzle.turnWheel(3));
 await page.waitForTimeout(500);assert.equal(await page.evaluate(()=>!!window.__AKUMU__.audio.doorVoice),false);
 await page.waitForFunction(()=>document.getElementById('opening-caption').textContent==="(Narrator) Four numbers. Apparently, that's asking a lot.",null,{timeout:20000});
 const first=await page.evaluate(()=>({at:window.__AKUMU__.audio.doorVoice.startAt,drawer:window.__AKUMU__.puzzle.state.drawer,duration:window.__AKUMU__.audio.wrongCodeVoiceBuffer.duration}));assert.equal(first.drawer,'locked');assert.ok(first.duration>3.6&&first.duration<3.8);
 await page.screenshot({path:'test-results/wrong-code-narrator.png'});
 await page.waitForFunction(()=>window.__AKUMU__.audio.doorVoice.ended,null,{timeout:15000});
 await page.waitForFunction(()=>document.getElementById('opening-caption').textContent==='');
 await page.evaluate(()=>{const p=window.__AKUMU__.puzzle;for(let i=0;i<4;i++){const digit=[1,9,8,6][i];while(p.state.digits[i]!==digit)p.turnWheel(i);}});
 await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.drawer==='unlocked');
 assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.doorVoice.startAt),first.at);
 assert.deepEqual(errors,[]);console.log('Untouched lock silent; intermediate wheel click silent; settled wrong code triggers recorded line and synced caption; caption clears and correct code unlocks without repeating.');
}finally{await browser.close();server.close();}
