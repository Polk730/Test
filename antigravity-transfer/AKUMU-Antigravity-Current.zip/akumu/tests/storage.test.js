import {test} from 'node:test';
import assert from 'node:assert/strict';
import {storageLayout,STORAGE_BOUNDS,STORAGE_ENTRY} from '../src/storage-layout.js';
import {RoomProgression} from '../src/room-progression.js';
import {move,collides,ROOM,PLAYER_RADIUS} from '../src/physics.js';
test('six aisles and both cross-passages are connected at player clearance',()=>{
 const l=storageLayout(),step=.10,minX=l.bounds.minX+PLAYER_RADIUS,minZ=l.bounds.minZ+PLAYER_RADIUS,nx=Math.floor((l.bounds.maxX-PLAYER_RADIUS-minX)/step)+1,nz=Math.floor((l.bounds.maxZ-PLAYER_RADIUS-minZ)/step)+1;
 const cell=(x,z)=>[Math.round((x-minX)/step),Math.round((z-minZ)/step)],id=(x,z)=>z*nx+x,valid=(x,z)=>x>=0&&x<nx&&z>=0&&z<nz&&!collides(minX+x*step,minZ+z*step,l.boxes);
 const first=cell(STORAGE_ENTRY.x,STORAGE_ENTRY.z),queue=[first],visited=new Set([id(...first)]);for(let i=0;i<queue.length;i++){const [x,z]=queue[i];for(const [dx,dz]of [[1,0],[-1,0],[0,1],[0,-1]]){const a=x+dx,b=z+dz,key=id(a,b);if(valid(a,b)&&!visited.has(key)){visited.add(key);queue.push([a,b]);}}}
 assert.equal(l.aisles.length,6);for(const a of l.aisles){assert.ok(a.width>=.9&&a.width<=1.6);for(const z of [4.2,7.2,10.2])assert.ok(visited.has(id(...cell(a.centerX,z))),`aisle ${a.index}, z ${z}`);}
 for(const c of l.crossPassages)for(const a of l.aisles)assert.ok(visited.has(id(...cell(a.centerX,(c.minZ+c.maxZ)/2))));
 assert.ok(visited.has(id(...cell(10.6,10.3))));
});
test('storage shelves cannot be crossed by large frame movements; original bedroom bounds remain default',()=>{
 const l=storageLayout(),a=l.aisles[0];const p=move({x:a.centerX,z:4.2},10,0,l.boxes,STORAGE_BOUNDS);assert.ok(p.x<l.racks[0].minX-PLAYER_RADIUS+.001);assert.equal(collides(p.x,p.z,l.boxes),false);
 const old=move({x:0,z:0},20,20,[]);assert.equal(old.x,ROOM.maxX-PLAYER_RADIUS);assert.equal(old.z,ROOM.maxZ-PLAYER_RADIUS);
});
test('door remains open while player is in doorway, then slams and locks once with a separate half-second delay',()=>{
 const p=new RoomProgression();assert.equal(p.unlock(),true);assert.deepEqual(p.update(.1,true,{x:1.4,z:2.4}),[]);assert.equal(p.phase,'open');assert.equal(p.committed,false);
 assert.deepEqual(p.update(.1,true,{x:1.4,z:2.72}),['entered']);assert.equal(p.committed,true);assert.equal(p.angle,1.22);
 assert.deepEqual(p.update(.20,true,{x:1.4,z:3}),[]);assert.ok(p.angle>0);assert.deepEqual(p.update(.07,true,{x:1.4,z:3}),['slam']);assert.equal(p.angle,0);
 assert.deepEqual(p.update(.49,true,{x:1.4,z:3}),[]);assert.deepEqual(p.update(.02,true,{x:1.4,z:3}),['lock']);assert.equal(p.phase,'locked');assert.deepEqual(p.update(20,true,{x:1.4,z:3}),[]);
});
