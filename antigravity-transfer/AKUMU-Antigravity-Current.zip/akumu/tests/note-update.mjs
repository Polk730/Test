import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 const maps=await page.evaluate(()=>{const notes=window.__AKUMU__.puzzle.notes;return {plain:notes[0].children[1].material.map.image===notes[2].children[1].material.map.image,secondDifferent:notes[1].children[1].material.map.image!==notes[2].children[1].material.map.image};});assert.equal(maps.plain,true);assert.equal(maps.secondDifferent,true);
 await page.evaluate(()=>{const g=window.__AKUMU__;g.puzzle.interact({kind:'note',index:2,object:g.puzzle.notes[2]});});await page.waitForFunction(()=>window.__AKUMU__.inspectionKind==='note');await page.screenshot({path:'test-results/note-3-controls.png'});
 await page.click('#close-inspect');await page.evaluate(()=>{const g=window.__AKUMU__;g.puzzle.interact({kind:'note',index:1,object:g.puzzle.notes[1]});g.inspected.rotation.y=Math.PI;});await page.waitForFunction(()=>document.querySelector('#inspection h2').textContent==='LOGBOOK 2');
 await page.screenshot({path:'test-results/note-2-hidden-code.png'});assert.deepEqual(errors,[]);console.log('Note 3 control instructions rendered; Note 1/3 plain backs share texture; only Note 2 has the code back; inspected its rendered reverse.');
}finally{await browser.close();server.close();}
