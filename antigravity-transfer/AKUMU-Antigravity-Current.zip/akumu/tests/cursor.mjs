import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700}}),errors=[];
page.on('pageerror',e=>errors.push(e.message));
await page.addInitScript(()=>{window.__captureRequests=0;const original=HTMLCanvasElement.prototype.requestPointerLock;HTMLCanvasElement.prototype.requestPointerLock=function(...args){window.__captureRequests++;return original.apply(this,args);};});
const captured=()=>page.waitForFunction(()=>document.pointerLockElement?.id==='world',null,{timeout:30000});
const released=()=>page.waitForFunction(()=>document.pointerLockElement===null);
try{
 await page.goto(process.env.AKUMU_URL||'http://127.0.0.1:4175/AKUMU.html?debug',{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:60000});await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});await captured();assert.equal(await page.locator('#crosshair').isVisible(),true);const dot=await page.locator('#crosshair').boundingBox();assert.equal(dot.width,4);assert.equal(dot.height,4);assert.ok(Math.abs(dot.x+dot.width/2-500)<.5&&Math.abs(dot.y+dot.height/2-350)<.5);
 const yaw=await page.evaluate(()=>window.__AKUMU__.camera.rotation.y);await page.mouse.move(640,350,{steps:4});await page.waitForFunction(y=>Math.abs(window.__AKUMU__.camera.rotation.y-y)>.01,yaw);
 await page.mouse.click(500,350,{button:'right'});await captured();assert.equal(await page.evaluate(()=>window.__AKUMU__.paused),false);
 const initialRequests=await page.evaluate(()=>window.__captureRequests);await page.keyboard.press('Escape');await released();await page.waitForFunction(()=>window.__AKUMU__.paused);assert.equal(await page.locator('#crosshair').isVisible(),false);await page.waitForTimeout(250);assert.equal(await page.evaluate(()=>window.__captureRequests),initialRequests);
 await page.keyboard.press('Escape');await released();assert.equal(await page.evaluate(()=>window.__AKUMU__.paused),true);
 await page.click('#pause');await captured();console.log('PLAY captures for FPS look; Escape releases and stays released; explicit Resume captures again');
 async function inspectNote(){await page.evaluate(()=>window.__AKUMU__.setView(1.4,.68,-Math.PI/2,-.20));await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='note'&&window.__AKUMU__.focused.index===2);await page.keyboard.press('e');await page.waitForFunction(()=>window.__AKUMU__.inspectionKind==='note');assert.equal(await page.locator('#crosshair').isVisible(),false);await released();}
 await inspectNote();const beforeEsc=await page.evaluate(()=>window.__captureRequests);await page.keyboard.press('Escape');await page.waitForFunction(()=>window.__AKUMU__.state==='playing'&&window.__AKUMU__.paused);await released();assert.equal(await page.evaluate(()=>window.__captureRequests),beforeEsc);
 await page.click('#pause');await captured();await inspectNote();await page.click('#close-inspect');await page.waitForFunction(()=>window.__AKUMU__.state==='playing');await captured();
 await page.keyboard.press('Escape');await released();console.log('Inspection is free-cursor; Escape exits without recapture; clicking CLOSE deliberately resumes FPS capture');assert.deepEqual(errors,[]);console.log('FPS cursor regression passed without page errors');
}finally{await browser.close();}
