import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');await page.evaluate(()=>document.fonts.ready);
 assert.equal(await page.evaluate(()=>document.fonts.check('20px "AKUMU Pixel"')),true);
 assert.ok((await page.locator('#name-title').evaluate(el=>getComputedStyle(el).fontFamily)).includes('AKUMU Pixel'));
 await page.fill('#player-name','Maya Rose');assert.equal(await page.inputValue('#player-name'),'Maya Rose');
 await page.screenshot({path:'test-results/pixel-name-desktop.png'});
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:'test-results/pixel-name-phone.png'});
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
 const bounds=await page.locator('#name-form').boundingBox();assert.ok(bounds.x>=0&&bounds.x+bounds.width<=390);
 await page.click('#name-back');assert.equal(await page.locator('#name-entry').isVisible(),false);assert.equal(await page.evaluate(()=>window.__AKUMU__.state),'menu');
 assert.deepEqual(errors,[]);console.log('Embedded pixel font loaded, desktop/mobile form fits, name input preserves case and spaces, Back works; no page errors.');
}finally{await browser.close();server.close();}
