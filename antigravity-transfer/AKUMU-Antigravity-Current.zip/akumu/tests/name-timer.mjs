import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');assert.equal(await page.locator('#name-entry').isVisible(),true);assert.equal(await page.evaluate(()=>window.__AKUMU__.state),'menu');
 await page.fill('#player-name','Maya Rose');await page.screenshot({path:'test-results/name-prompt.png'});await page.press('#player-name','Enter');
 await page.waitForFunction(()=>window.__AKUMU__.state==='opening');assert.equal(await page.locator('#run-timer').isVisible(),false);
 await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 assert.equal(await page.evaluate(()=>window.__AKUMU__.room.bloodMessage.mesh.userData.message),"Maya Rose, you don't remember me, but I remember you..");
 await page.evaluate(()=>window.__AKUMU__.setView(.3,1,-Math.PI/2,.2));await page.waitForTimeout(500);await page.screenshot({path:'test-results/personal-blood-message.png'});
 assert.equal(await page.locator('#run-timer').isVisible(),true);
 await page.keyboard.press('Escape');await page.waitForFunction(()=>window.__AKUMU__.paused);
 const paused=await page.locator('#run-timer').textContent();await page.waitForTimeout(1200);assert.equal(await page.locator('#run-timer').textContent(),paused);
 await page.click('#pause');await page.waitForFunction(()=>!window.__AKUMU__.paused);
 await page.evaluate(()=>{const g=window.__AKUMU__;g.finishGame(false);});
 await page.waitForFunction(()=>document.getElementById('escape-time').hidden===false,null,{timeout:120000});
 const final=await page.locator('#escape-time').textContent();assert.match(final,/^Escaped in \d{2}:\d{2}$/);await page.waitForTimeout(1100);assert.equal(await page.locator('#escape-time').textContent(),final);
 await page.screenshot({path:'test-results/escape-time-ending.png'});
 assert.deepEqual(errors,[]);console.log('Name prompt, spaces/Enter input, personalized wall, timer hidden during waking, pause freeze, and fixed ending escape time passed:',final);
}finally{await browser.close();server.close();}
