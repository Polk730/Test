import {test} from 'node:test';
import assert from 'node:assert/strict';
import {synthesizeEffect,EFFECT_DURATION,EFFECT_LEVEL} from '../src/audio-synthesis.js';
test('all foley samples remain finite, audible, centered and below full scale',()=>{for(const rate of [44100,48000])for(const name of Object.keys(EFFECT_DURATION)){const pcm=synthesizeEffect(name,rate);let peak=0,sum=0,power=0;for(const value of pcm){assert.ok(Number.isFinite(value));peak=Math.max(peak,Math.abs(value));sum+=value;power+=value*value;}assert.ok(peak>.70&&peak<.73,name);assert.ok(Math.abs(sum/pcm.length)<.00001,name);assert.ok(Math.sqrt(power/pcm.length)>.02,name);assert.ok(EFFECT_LEVEL[name]>0&&EFFECT_LEVEL[name]<1);}});
test('repeat variants change the sound without changing its length',()=>{const a=synthesizeEffect('footstep',48000,207),b=synthesizeEffect('footstep',48000,8126);assert.equal(a.length,b.length);assert.ok(a.some((s,i)=>Math.abs(s-b[i])>.01));});
test('main action effects remain stronger than distant ambient creaks',()=>{assert.ok(EFFECT_LEVEL.impact>EFFECT_LEVEL.footstep);assert.ok(EFFECT_LEVEL.key>EFFECT_LEVEL.ambientCreak*2);assert.ok(EFFECT_LEVEL.wheel>EFFECT_LEVEL.ambientCreak);});
