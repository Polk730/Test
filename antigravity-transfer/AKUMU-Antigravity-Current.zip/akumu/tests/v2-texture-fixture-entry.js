import {agedSurface as before,surfaceBuildStats as beforeStats} from './v2-fixtures/aged-before.js';
import {agedSurface as after,surfaceBuildStats as afterStats} from '../src/aged-surface.js';
const kinds=['wall','plaster','ceiling','concrete','wood','floor','cloth','metal','rust','cardboard','brick','paper','plastic'];
const original=kinds.map(kind=>before(kind)),updated=kinds.map(kind=>after(kind));let compared=0;
for(let i=0;i<kinds.length;i++)for(const channel of ['color','normal','roughness']){const a=original[i][channel].image.getContext('2d').getImageData(0,0,512,512).data,b=updated[i][channel].image.getContext('2d').getImageData(0,0,512,512).data;for(let j=0;j<a.length;j++){if(a[j]!==b[j])throw Error('Texture mismatch '+kinds[i]+'/'+channel+' at '+j);compared++;}}
window.__textureComparison={equal:true,recipes:kinds.length,comparedBytes:compared,beforeMs:beforeStats.totalMs,afterMs:afterStats.totalMs};
