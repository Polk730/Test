import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700},deviceScaleFactor:.65}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:120000});await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:120000});
 await page.evaluate(()=>window.__AKUMU__.setView(0,-.35,0,-.11));await page.screenshot({path:'test-results/window-sturdy-barricade.png'});
 await page.evaluate(()=>{const g=window.__AKUMU__;g.puzzle.state.hammer='carried';g.puzzle.hammer.visible=true;});await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='window');await page.keyboard.press('e');await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.barricade==='removed',null,{timeout:120000});await page.waitForFunction(()=>window.__AKUMU__.puzzle.hammer.userData.resting,null,{timeout:60000});
 assert.equal(await page.evaluate(()=>window.__AKUMU__.room.boards.length),6);assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.key),'available');assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.hammer),'dropped');await page.screenshot({path:'test-results/window-sturdy-removed.png'});
 await page.evaluate(()=>window.__AKUMU__.setView(0,-.55,0,-.105));await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='key');await page.keyboard.press('e');await page.waitForFunction(()=>window.__AKUMU__.state==='key-found');assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.key),'collected');assert.deepEqual(errors,[]);console.log('Sturdier window appearance, same hammer removal, all six fallen boards, resting hammer and key collection passed.');
}finally{await browser.close();server.close();}
