import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 await page.evaluate(()=>window.__AKUMU__.setView(.65,.20,Math.PI/2,-.02));await page.waitForTimeout(500);
 await page.screenshot({path:'test-results/crayon-tally-wall.png'});
 assert.equal(await page.evaluate(()=>window.__AKUMU__.room.tallyWall.visible),true);
 await page.evaluate(()=>window.__AKUMU__.setView(-1,1.24,Math.PI/2,-.12));await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='note');
 assert.deepEqual(errors,[]);console.log('Tally wall rendered from player view; wall note remains interactable; no page errors.');
}finally{await browser.close();server.close();}
