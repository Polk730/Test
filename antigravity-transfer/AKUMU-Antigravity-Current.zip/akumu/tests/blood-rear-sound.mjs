import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Maya Rose');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 await page.evaluate(()=>{const g=window.__AKUMU__;g.setView(.3,1,-Math.PI/2,.2);g.faults.sample=()=>.35;g.audio.nextRearSnap=0;});
 await page.waitForFunction(()=>window.__AKUMU__.audio.lastRearSnap);
 const sound=await page.evaluate(()=>({snap:window.__AKUMU__.audio.lastRearSnap,next:window.__AKUMU__.audio.nextRearSnap}));
 const delta=sound.snap.position.map((v,i)=>v-sound.snap.listener[i]);assert.ok(delta.reduce((sum,v,i)=>sum+v*sound.snap.forward[i],0)<-1);
 assert.ok(sound.next-sound.snap.time>=16&&sound.next-sound.snap.time<34);
 await page.screenshot({path:'test-results/dripping-blood-low-light.png'});
 await page.evaluate(()=>{const g=window.__AKUMU__;g.puzzle.interact({kind:'bed'});g.audio.nextRearSnap=0;});
 await page.waitForTimeout(300);assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.lastRearSnap.time),sound.snap.time);
 assert.equal(await page.evaluate(()=>window.__AKUMU__.room.bloodMessage.mesh.material.emissiveIntensity),.32);
 assert.deepEqual(errors,[]);console.log('Blood message rendered under a 35% lamp fault; HRTF twig snap is behind current facing direction; irregular 16–34 second gap; no rear sounds during inspection.');
}finally{await browser.close();server.close();}
