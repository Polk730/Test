import {test} from 'node:test';
import assert from 'node:assert/strict';
import {move,collides,ROOM,PLAYER_RADIUS} from '../src/physics.js';
const bed={minX:-2.34,maxX:-.98,minZ:-1.42,maxZ:.88};
test('walls and window boundary remain solid even for large movements',()=>{for(const [dx,dz]of [[99,0],[-99,0],[0,99],[0,-99]]){const p=move({x:0,z:0},dx,dz,[]);assert.ok(p.x>=ROOM.minX+PLAYER_RADIUS&&p.x<=ROOM.maxX-PLAYER_RADIUS);assert.ok(p.z>=ROOM.minZ+PLAYER_RADIUS&&p.z<=ROOM.maxZ-PLAYER_RADIUS);}});
test('bed cannot be crossed, including during a long frame',()=>{const p=move({x:0,z:0},-4,0,[bed]);assert.ok(p.x>=bed.maxX+PLAYER_RADIUS-.001);assert.equal(collides(p.x,p.z,[bed]),false);});
test('diagonal wall contact slides rather than blocking both axes',()=>{const p=move({x:-.75,z:0},-.5,.5,[bed]);assert.ok(p.x>=bed.maxX+PLAYER_RADIUS-.001);assert.ok(p.z>.4);});
test('open drawer blocks passage but closed drawer footprint does not',()=>{const drawer={minX:-.83,maxX:-.31,minZ:-1.22,maxZ:-.86};assert.equal(collides(-.57,-1,[drawer]),true);assert.equal(collides(-.57,-1,[]),false);});

test('intact window planks stop the camera before the wood; the closed window boundary survives removal',()=>{const window={minX:-1.19,maxX:1.19,minZ:-1.90,maxZ:-1.71};const intact=move({x:0,z:-1.3},0,-2,[window]);assert.ok(intact.z>=-1.52-.001);const removed=move({x:0,z:-1.3},0,-2,[]);assert.equal(removed.z,ROOM.minZ+PLAYER_RADIUS);});
