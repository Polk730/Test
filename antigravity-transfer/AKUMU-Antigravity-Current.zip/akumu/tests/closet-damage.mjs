import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700},deviceScaleFactor:.5}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 assert.equal(await page.evaluate(()=>window.__AKUMU__.room.closetDamage.broken),false);
 await page.evaluate(()=>window.__AKUMU__.setView(.2,-.65,-Math.PI/2,-.34));await page.screenshot({path:'test-results/closet-fragile-front.png'});
 await page.evaluate(()=>{const g=window.__AKUMU__;g.puzzle.state.hammer='carried';g.room.cupboard.parent.attach(g.puzzle.hammer);g.puzzle.hammer.visible=true;g.setView(1.1,-.65,-Math.PI/2,0);});await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='barricade');
 await page.evaluate(()=>window.__AKUMU__.interact());await page.waitForFunction(()=>window.__AKUMU__.room.closetDamage.broken,null,{timeout:30000});
 assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.cabinetScarePlayed),true);
 assert.equal(await page.evaluate(()=>window.__AKUMU__.room.closetDamage.intact.visible),false);
 await page.waitForFunction(()=>!window.__AKUMU__.busy,null,{timeout:30000});
 const result=await page.evaluate(()=>{const g=window.__AKUMU__,d=g.room.closetDamage;for(let i=0;i<60;i++)d.update(.05);g.renderer.shadowMap.needsUpdate=true;g.setView(-.1,-.65,-Math.PI/2,-.32);return {count:d.shards.length,landed:d.shards.every(s=>s.landed),floor:d.shards.every(s=>s.mesh.position.y<.06),repeat:d.breakApart(),rubble:d.rubble.visible};});
 assert.equal(result.count,30);assert.equal(result.landed,true);assert.equal(result.floor,true);assert.equal(result.repeat,false);assert.equal(result.rubble,true);
 await page.waitForTimeout(250);await page.screenshot({path:'test-results/broken-closet.png'});
 assert.equal(await page.evaluate(()=>window.__AKUMU__.room.closetDamage.intact.visible),false);
 await page.waitForFunction(()=>!window.__AKUMU__.puzzle.swinging,null,{timeout:30000});
 const blocked=await page.evaluate(()=>{const g=window.__AKUMU__,p=g.puzzle,t=g.room.targets.find(t=>t.kind==='barricade'),touches=p.state.cabinetTouches,hits=p.state.cabinetHits;p.state.hammer='dropped';p.interact(t);p.state.hammer='carried';p.interact(t);return {enabled:t.enabled(),unchanged:p.state.cabinetTouches===touches&&p.state.cabinetHits===hits,swing:p.swinging};});
 assert.equal(blocked.enabled,false);assert.equal(blocked.unchanged,true);assert.equal(blocked.swing,false);
 assert.deepEqual(errors,[]);console.log('First-contact shatter and spider trigger, hidden intact front, 30 persistent floor fragments, hollow carcass idempotent break, and blocked empty-hand/hammer interactions after destruction passed.');
}finally{await browser.close();server.close();}
