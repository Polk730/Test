import {test} from 'node:test';
import assert from 'node:assert/strict';
import {LOGBOOK_TEXTS,CODE_NOTE_INDEX} from '../src/logbooks.js';
import {PROTOTYPE_CODE} from '../src/config.js';
test('Note 3 front teaches interaction without revealing or hinting at hidden content',()=>{const front=LOGBOOK_TEXTS[2].join('\n');assert.ok(front.includes('E / LMC to inspect'));assert.match(front,/Drag to rotate items/);assert.match(front,/Scroll to zoom in \/ out/);assert.doesNotMatch(front,/code|secret|combination|back|turn/i);assert.ok(!front.includes(PROTOTYPE_CODE));});
test('movement note includes the fallback for blocked mouse capture',()=>assert.ok(LOGBOOK_TEXTS[1].some(line=>line.includes('hold + drag'))));

test('hidden combination is assigned to Note 2 only and never printed on note fronts',()=>{assert.equal(CODE_NOTE_INDEX,1);for(const lines of LOGBOOK_TEXTS)assert.ok(!lines.join(' ').includes(PROTOTYPE_CODE));});
