import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700},deviceScaleFactor:.5}),errors=[];page.on('pageerror',e=>errors.push(e.message));
async function openPhoto(){await page.evaluate(()=>{const g=window.__AKUMU__,p=g.room.photo.position,x=-.4,z=-.7,dx=p.x-x,dz=p.z-z;g.setView(x,z,Math.atan2(-dx,-dz),Math.atan2(p.y-1.65,Math.hypot(dx,dz)));});await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='photo');await page.keyboard.press('e');await page.waitForFunction(()=>window.__AKUMU__.inspectionKind==='photo');}
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__?.audio?.photoVoiceBuffer,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 await openPhoto();await page.waitForFunction(()=>window.__AKUMU__.photoInspectSeconds>1.2);assert.equal(await page.evaluate(()=>window.__AKUMU__.photoVoicePlayed),false);await page.click('#close-inspect');assert.equal(await page.evaluate(()=>window.__AKUMU__.photoInspectSeconds),0);
 await openPhoto();const enteredAt=await page.evaluate(()=>window.__AKUMU__.audio.ctx.currentTime);await page.evaluate(()=>{window.__photoCaptions=[];new MutationObserver(()=>window.__photoCaptions.push(document.getElementById('opening-caption').textContent)).observe(document.getElementById('opening-caption'),{childList:true,subtree:true,characterData:true});});
 await page.waitForFunction(()=>window.__AKUMU__.photoVoicePlayed,null,{timeout:20000});
 const result=await page.evaluate(()=>({at:window.__AKUMU__.audio.doorVoice.startAt,dwell:window.__AKUMU__.photoInspectSeconds}));assert.ok(result.dwell>=5);assert.ok(result.at-enteredAt>=4.5);
 await page.waitForFunction(()=>window.__AKUMU__.audio.doorVoice.ended,null,{timeout:15000});assert.ok((await page.evaluate(()=>window.__photoCaptions)).includes('(Narrator) Funny. Last time you recognized everyone.'));
 await page.click('#close-inspect');await openPhoto();await page.waitForFunction(()=>window.__AKUMU__.photoInspectSeconds>5.2,null,{timeout:20000});assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.doorVoice.startAt),result.at);
 assert.deepEqual(errors,[]);console.log('Actual photo inspection: short visit silent/reset; five continuous seconds trigger uploaded voice and exact (Narrator) caption; later inspection cannot repeat it.');
}finally{await browser.close();server.close();}
