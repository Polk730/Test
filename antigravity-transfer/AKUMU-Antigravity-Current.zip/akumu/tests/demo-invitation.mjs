import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {readFile,mkdir} from 'node:fs/promises';
import {createServer} from 'node:http';
const html=await readFile('standalone/AKUMU.html');
const server=createServer((q,r)=>{r.setHeader('Content-Type','text/html');r.end(html);});
await new Promise(r=>server.listen(0,'127.0.0.1',r));await mkdir('test-results',{recursive:true});
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try{
 for(const touch of (process.argv.includes('--touch-only')?[true]:[false,true])){
  const page=await browser.newPage({viewport:{width:1000,height:720},deviceScaleFactor:.5,hasTouch:touch,isMobile:touch});page.setDefaultTimeout(180000);
  const errors=[];page.on('pageerror',e=>errors.push(e.message));const press=q=>touch?page.tap(q):page.click(q);
  await page.goto(`http://127.0.0.1:${server.address().port}/?debug`);await page.waitForFunction(()=>window.__AKUMU__);
  await press('#play');await press('#mode-demo');await page.fill('#player-name','Maya');await press('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing');if(await page.locator('#pause').isVisible())await press('#pause');
  await page.evaluate(()=>{const g=window.__AKUMU__;g.puzzle.state.door='open';g.beginRoomTwoPassage();});await page.waitForFunction(()=>window.__AKUMU__.progression.portalOpen);
  await page.evaluate(()=>window.__AKUMU__.setView(1.4,2.45,Math.PI,0));
  // The existing doorway trigger remains the entry route; keyboard events also drive the touch fixture.
  await page.keyboard.down('w');await page.waitForFunction(()=>window.__AKUMU__.currentRoom===3);await page.keyboard.up('w');
  await page.evaluate(touch=>{const g=window.__AKUMU__,m=g.observation.model;m.solved=true;m.events.live=true;m.solvedAt=m.time;g.audio.setRecognitionSilence(true);window.invitationStarts=0;
   if(touch){g.audio.demoInvitationBuffer=g.audio.ctx.createBuffer(1,Math.floor(g.audio.ctx.sampleRate*.8),g.audio.ctx.sampleRate);const play=g.audio.playNarrator.bind(g.audio);g.audio.playNarrator=(buffer,...args)=>{if(buffer===g.audio.demoInvitationBuffer)window.invitationStarts++;return play(buffer,...args);};}
  },touch);
  await page.waitForFunction(()=>window.__AKUMU__.observation.liveFrames>0);
  assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.photoVoice()),false);assert.equal(await page.evaluate(()=>window.__AKUMU__.demoInvitation.started),false);
  await page.evaluate(()=>window.__AKUMU__.finishGame(false));await page.waitForFunction(()=>document.getElementById('opening-caption').textContent==='TO BE CONTINUED...');
  assert.equal(await page.locator('#play-full-version').isVisible(),false);assert.equal(await page.evaluate(()=>window.__AKUMU__.demoInvitation.started),false);
  await page.waitForFunction(()=>window.__AKUMU__.demoInvitation.started);
  assert.equal(await page.evaluate(()=>document.getElementById('ending-caption').textContent),"(Narrator) Oh, you thought that was the end? That was only the beginning. Play the full version... if you dare.");
  assert.ok(await page.evaluate(()=>window.__AKUMU__.demoInvitation.startedAt-window.__AKUMU__.demoInvitation.titleAt>=3));
  assert.equal(await page.evaluate(()=>document.getElementById('veil').style.opacity),'1');
  await page.evaluate(()=>window.__AKUMU__.finishGame(false));
  await page.waitForFunction(()=>window.__AKUMU__.demoInvitation.complete);
  assert.equal(await page.locator('#play-full-version').isVisible(),true);assert.equal(await page.locator('#opening-caption').textContent(),'TO BE CONTINUED...');
  if(touch){assert.equal(await page.evaluate(()=>window.invitationStarts),1);assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.ambience.gain.value),0);assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.sfx.gain.value),0);}
  await page.screenshot({path:`test-results/invitation-${touch?'touch-audio-hook':'desktop-caption'}.png`});
  console.log('Invitation complete; activating NORMAL handoff',touch);await press('#play-full-version');await page.waitForFunction(()=>window.__AKUMU__?.gameMode==='normal'&&!document.getElementById('name-entry').hidden);
  console.log('Fresh NORMAL name entry visible',touch);assert.equal(await page.locator('#player-name').inputValue(),'');assert.equal(await page.evaluate(()=>window.__AKUMU__.observation),null);
  await page.fill('#player-name','Alex');await press('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing');
  console.log('NORMAL Room 1 started',touch);assert.equal(await page.evaluate(()=>window.__AKUMU__.currentRoom),1);assert.equal(await page.evaluate(()=>window.__AKUMU__.gameMode),'normal');
  // Verify the original NORMAL ending never starts this invitation.
  await page.evaluate(()=>window.__AKUMU__.finishGame(false));await page.waitForFunction(()=>document.getElementById('opening-caption').textContent==='TO BE CONTINUED...');
  await page.waitForTimeout(3400);assert.equal(await page.evaluate(()=>window.__AKUMU__.demoInvitation.started),false);assert.equal(await page.locator('#play-full-version').isVisible(),false);
  assert.deepEqual(errors,[]);console.log(`${touch?'Touch/audio-hook':'Desktop/caption fallback'}: live silence, post-black delay, once-only invitation, completion gating, fresh NORMAL name/start and unchanged NORMAL ending passed`);await page.close();
 }
}finally{await browser.close();server.close();}
