import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {mkdir,readFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {PROTOTYPE_CODE} from '../src/config.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700},deviceScaleFactor:.5}),errors=[];
page.on('pageerror',e=>{errors.push(e.message);console.log('PAGE ERROR',e.message);});page.on('console',m=>{if(m.type()==='error'){errors.push(m.text());console.log('CONSOLE ERROR',m.text());}});
const view=async(x,z,yaw=0,pitch=0)=>page.evaluate(v=>window.__AKUMU__.setView(...v),[x,z,yaw,pitch]);
const focused=kind=>page.waitForFunction(k=>window.__AKUMU__.focused?.kind===k,kind,{timeout:180000});
const close=async()=>{await page.click('#close-inspect');await page.waitForFunction(()=>window.__AKUMU__.state==='playing');if(await page.locator('#pause').isVisible())await page.click('#pause');};
try{
 await page.goto(process.env.AKUMU_URL||`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:180000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:180000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:180000});if(await page.locator('#pause').isVisible())await page.click('#pause');
 assert.equal(await page.locator('#crosshair').isVisible(),true);assert.equal(await page.locator('#prompt').isVisible(),false);
 await view(1.25,1.15,.9,-.10);await page.screenshot({path:'test-results/v1-room-overview.png'});console.log('Representative room render',await page.evaluate(()=>({calls:window.__AKUMU__.renderer.info.render.calls,triangles:window.__AKUMU__.renderer.info.render.triangles,textures:window.__AKUMU__.renderer.info.memory.textures})));
 await view(.7,.5,.55,.72);await page.screenshot({path:'test-results/v1-lamp.png'});
 await view(-.2,-.2,Math.PI,-.03);await page.screenshot({path:'test-results/v1-door-wall.png'});
 await view(1.4,.8,Math.PI);await focused('door');await page.keyboard.press('e');assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.door),'locked');
 await view(-.34,-.42,0,-.92);await focused('drawer');await page.keyboard.press('e');assert.equal(await page.evaluate(()=>window.__AKUMU__.room.targets.find(t=>t.kind==='drawer').open),false);
 console.log('Center aiming dot, no labels, locked door and locked drawer gates passed');
 for(const [i,pose]of [[0,[-.63,.95,Math.PI,-.21]],[1,[-1.50,1.24,Math.PI/2,-.17]],[2,[1.40,.68,-Math.PI/2,-.20]]]){
  await view(...pose);await page.waitForFunction(i=>window.__AKUMU__.focused?.kind==='note'&&window.__AKUMU__.focused.index===i,i,{timeout:180000});await page.keyboard.press('e');await page.waitForFunction(()=>window.__AKUMU__.state==='inspecting');
  await page.screenshot({path:`test-results/v1-note-${i+1}-front.png`});
  if(i===1){await page.mouse.move(340,350);await page.mouse.down();await page.mouse.move(690,350,{steps:12});await page.mouse.up();await page.waitForFunction(()=>Math.abs(window.__AKUMU__.inspected.rotation.y)>3);await page.screenshot({path:'test-results/v1-note-2-back.png'});}
  await close();
 }
 assert.deepEqual(await page.evaluate(()=>window.__AKUMU__.puzzle.state.notes),[true,true,true]);console.log('All three notes inspected, second note physically turned over');
 await view(-.57,-.45,0,-1.01);await focused('lock');await page.keyboard.press('e');await page.waitForFunction(()=>window.__AKUMU__.inspectionKind==='lock');await page.waitForTimeout(300);
 async function clickWheel(index){const before=await page.evaluate(i=>window.__AKUMU__.puzzle.state.digits[i],index);const p=await page.evaluate(i=>window.__AKUMU__.wheelScreen(i),index);await page.mouse.click(p.x,p.y);await page.waitForFunction(({i,b})=>window.__AKUMU__.puzzle.state.digits[i]!==b,{i:index,b:before},{timeout:30000});}
 for(let n=0;n<10;n++)await clickWheel(0);assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.digits[0]),0);
 for(let i=0;i<4;i++)for(let n=0;n<Number(PROTOTYPE_CODE[i]);n++)await clickWheel(i);
 await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.drawer==='unlocked');assert.equal(await page.evaluate(()=>window.__AKUMU__.room.targets.find(t=>t.kind==='drawer').open),false);
 await page.screenshot({path:'test-results/v1-lock-solved.png'});await close();console.log('Individual mechanical wheels wrap, code unlocks but does not open drawer');
 await view(-.57,-.45,0,-1.01);await focused('drawer');await page.keyboard.press('e');await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.drawer==='open'&&window.__AKUMU__.room.drawer.position.z>.30);
 await view(-.57,-.55,0,-1.13);await focused('hammer');await page.keyboard.press('e');await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.hammer==='carried');
 await page.keyboard.press('g');await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.hammer==='dropped'&&window.__AKUMU__.puzzle.hammer.position.y<.08,null,{timeout:180000});
 await page.evaluate(()=>{const g=window.__AKUMU__,p=g.puzzle.hammer.position,c=g.camera.position;g.setView(c.x,c.z,Math.atan2(c.x-p.x,c.z-p.z),Math.atan2(p.y-c.y,Math.hypot(p.x-c.x,p.z-c.z)));});
 await focused('hammer');await page.keyboard.press('e');await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.hammer==='carried');console.log('Hammer pickup, safe physical drop and pickup again passed');
 assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.key),'hidden');
 await view(0,-.35,0,-.11);await focused('window');await page.keyboard.press('e');await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.barricade==='removed',null,{timeout:120000});
 assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.hammer),'dropped');assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.key),'available');
 await page.waitForFunction(()=>window.__AKUMU__.puzzle.hammer.userData.resting,null,{timeout:180000});await page.screenshot({path:'test-results/v1-window-cleared.png'});assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.hammer.visible&&window.__AKUMU__.puzzle.hammer.parent===window.__AKUMU__.getSpace().root),true);await view(.9,.75,.35,-.85);await page.screenshot({path:'test-results/v1-fallen-planks.png'});
 await view(0,-.55,0,-.105);await focused('key');await page.evaluate(()=>{const notice=document.getElementById('key-found');new MutationObserver(()=>{if(!notice.hidden&&!window.__foundKeyAudit){const label=notice.querySelector('h2');window.__foundKeyAudit={shown:!notice.hidden,text:label.textContent,opacity:getComputedStyle(label).opacity,modelVisible:window.__AKUMU__.keyFoundModel?.visible};}}).observe(notice,{attributes:true,attributeFilter:['hidden']});});await page.keyboard.press('e');await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.key==='collected'&&window.__foundKeyAudit);assert.deepEqual(await page.evaluate(()=>window.__foundKeyAudit),{shown:true,text:'Found key',opacity:'1',modelVisible:true});if(await page.evaluate(()=>window.__AKUMU__.state==='key-found'))await page.screenshot({path:'test-results/v1-found-key.png'});await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:180000});
 console.log('Controlled plank fall, persistent hammer, hidden-key reveal and collection passed');
 await view(1.4,1.4,Math.PI);await focused('door');await page.keyboard.press('e');await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.door==='open',null,{timeout:180000});assert.equal(await page.evaluate(()=>window.__AKUMU__.state),'playing');
 await page.keyboard.down('w');await page.waitForFunction(()=>window.__AKUMU__.currentRoom===2,null,{timeout:180000});await page.keyboard.up('w');await page.waitForFunction(()=>window.__AKUMU__.progression.phase==='locked',null,{timeout:30000});
 assert.equal(await page.evaluate(()=>window.__AKUMU__.playerName),'Alex');assert.equal(await page.evaluate(()=>window.__AKUMU__.state),'playing');assert.equal(await page.locator('#escape-time').isVisible(),false);await page.screenshot({path:'test-results/v2-entered-storage.png'});
 console.log('Room 1 full puzzle and physical entry into Room 2 passed; no early ending');assert.deepEqual(errors,[]);console.log('Complete puzzle: no console or page errors');
 console.log(await page.evaluate(()=>({calls:window.__AKUMU__.renderer.info.render.calls,triangles:window.__AKUMU__.renderer.info.render.triangles,textures:window.__AKUMU__.renderer.info.memory.textures,shadowLights:2})));
}catch(e){console.log('FAILURE STATE',await page.evaluate(()=>({state:window.__AKUMU__?.state,focus:window.__AKUMU__?.focused?.kind,puzzle:window.__AKUMU__?.puzzle?.state})));await page.screenshot({path:'test-results/v1-failure.png'}).catch(()=>{});throw e;}finally{await browser.close();server.close();}
