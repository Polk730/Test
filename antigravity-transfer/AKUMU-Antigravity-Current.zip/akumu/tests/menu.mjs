import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {mkdir} from 'node:fs/promises';
await mkdir('test-results',{recursive:true});
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const errors=[];const url=process.env.AKUMU_URL||'http://127.0.0.1:4175/AKUMU.html?debug';
function observe(page){page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});}
async function ready(page){await page.goto(url,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__&&document.querySelector('.title-image').complete&&document.querySelector('.title-image').naturalWidth===1280,null,{timeout:120000});}
try{
 const page=await browser.newPage({viewport:{width:1280,height:721}});observe(page);await ready(page);await page.waitForTimeout(1700);
 assert.equal(await page.locator('#menu button').count(),1);assert.ok(await page.locator('.title-image').evaluate(img=>img.src.startsWith('data:image/jpeg;')));
 assert.ok(await page.locator('#menu').evaluate(m=>m.getAnimations({subtree:true}).filter(a=>a.playState==='running').length>=6));
 const before=await page.evaluate(()=>window.__AKUMU__.renderer.info.render.frame);await page.waitForTimeout(300);assert.equal(await page.evaluate(()=>window.__AKUMU__.renderer.info.render.frame),before);
 await page.screenshot({path:'test-results/title-animated-desktop.png'});
 await page.keyboard.press('Tab');assert.equal(await page.evaluate(()=>document.activeElement.id),'play');
 await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(150);assert.equal(await page.locator('.play-face').evaluate(e=>getComputedStyle(e).animationName),'none');
 assert.equal(await page.locator('#menu').evaluate(m=>m.getAnimations({subtree:true}).filter(a=>a.playState==='running').length),0);
 console.log('Embedded artwork, one PLAY button, keyboard focus, animations and reduced-motion support passed');
 await page.keyboard.press('Enter');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});assert.equal(await page.locator('#menu').isVisible(),false);await page.waitForFunction(()=>document.pointerLockElement?.id==='world');await page.keyboard.press('Escape');await page.waitForFunction(()=>document.pointerLockElement===null&&window.__AKUMU__.paused);
 console.log('Keyboard PLAY hands off to FPS gameplay; Escape still releases the mouse');await page.close();
 const context=await browser.newContext({viewport:{width:768,height:1024},hasTouch:true,isMobile:true,deviceScaleFactor:1});const tablet=await context.newPage();observe(tablet);await ready(tablet);await tablet.waitForTimeout(1700);
 const rect=await tablet.locator('#play').boundingBox();assert.ok(rect.width>=44&&rect.height>=44);assert.ok(rect.x>=0&&rect.x+rect.width<=768&&rect.y>=0&&rect.y+rect.height<=1024);await tablet.screenshot({path:'test-results/title-ipad-portrait.png'});
 await tablet.setViewportSize({width:1024,height:768});await tablet.waitForTimeout(150);await tablet.screenshot({path:'test-results/title-ipad-landscape.png'});await tablet.tap('#play');await tablet.fill('#player-name','Alex');await tablet.tap('#name-form button[type=submit]');await tablet.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});assert.equal(await tablet.locator('#touch-controls').isVisible(),true);assert.equal(await tablet.evaluate(()=>document.pointerLockElement),null);
 console.log('Portrait/landscape iPad layout, touch PLAY and touch gameplay handoff passed');assert.deepEqual(errors,[]);console.log('Menu update: no console or page errors');await context.close();
}finally{await browser.close();}
