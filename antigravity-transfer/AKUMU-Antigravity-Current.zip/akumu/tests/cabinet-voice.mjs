import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700},deviceScaleFactor:.5}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__?.audio?.cabinetVoiceBuffer,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 await page.evaluate(()=>window.__AKUMU__.setView(1.1,-.65,-Math.PI/2,0));await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='barricade');
 await page.evaluate(()=>{window.__AKUMU__.puzzle.state.cabinetScarePlayed=true;});
 // Two deliberate hammer hits do not trigger the line or count as empty-hand touches.
 for(let i=0;i<2;i++){
  await page.evaluate(()=>{const g=window.__AKUMU__;g.puzzle.state.hammer='carried';g.puzzle.hammer.visible=true;g.interact();});
  await page.waitForFunction(()=>!window.__AKUMU__.puzzle.swinging);
 }
 assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.cabinetHits),2);
 assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.cabinetTouches),0);
 assert.equal(await page.evaluate(()=>!!window.__AKUMU__.audio.doorVoice),false);
 const atTouch=await page.evaluate(()=>{const g=window.__AKUMU__;g.puzzle.state.hammer='dropped';g.interact();g.interact();return g.elapsed;});
 assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.cabinetTouches),1);
 assert.equal(await page.evaluate(()=>!!window.__AKUMU__.audio.doorVoice),false);
 let previous=atTouch;for(let count=2;count<=7;count++){await page.waitForFunction(t=>window.__AKUMU__.elapsed>t+.6,previous,{timeout:60000});await page.evaluate(()=>window.__AKUMU__.interact());assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.cabinetTouches),count);if(count<7)assert.equal(await page.evaluate(()=>!!window.__AKUMU__.audio.doorVoice),false);previous=await page.evaluate(()=>window.__AKUMU__.elapsed);}
 await page.waitForFunction(()=>document.getElementById('opening-caption').textContent==="(▓▒░▓▒) Can't a guy have his peace?",null,{timeout:15000});
 assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.cabinetTouches),7);
 const at=await page.evaluate(()=>window.__AKUMU__.audio.doorVoice.startAt);
 await page.waitForFunction(()=>window.__AKUMU__.audio.doorVoice.ended,null,{timeout:15000});
 await page.evaluate(()=>window.__AKUMU__.interact());assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.doorVoice.startAt),at);
 assert.deepEqual(errors,[]);console.log('Two hammer hits stay silent; seventh deliberate empty-hand interaction triggers cabinet voice once; rapid duplicates ignored; unreadable-speaker caption preserved.');
}finally{await browser.close();server.close();}
