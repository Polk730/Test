import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700},deviceScaleFactor:.5}),errors=[];page.on('pageerror',e=>errors.push(e.message));
async function aimClock(){await page.evaluate(()=>{const g=window.__AKUMU__,p=g.room.wallClock.face.getWorldPosition(g.camera.position.clone()),x=-.65,z=.8,dx=p.x-x,dz=p.z-z;g.setView(x,z,Math.atan2(-dx,-dz),Math.atan2(p.y-1.65,Math.hypot(dx,dz)));});}
async function away(){await page.evaluate(()=>window.__AKUMU__.setView(-.65,.8,0,0));await page.waitForFunction(()=>window.__AKUMU__.clockAttention.armed&&window.__AKUMU__.audio.clockTickEnabled);}
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__?.audio?.clockVoiceBuffer,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 await page.evaluate(()=>{window.__clockCaptions=[];new MutationObserver(()=>window.__clockCaptions.push(document.getElementById('opening-caption').textContent)).observe(document.getElementById('opening-caption'),{childList:true,subtree:true,characterData:true});});
 await away();assert.equal(await page.evaluate(()=>window.__AKUMU__.room.targets.some(t=>t.kind==='clock'||t.object===window.__AKUMU__.room.wallClock.root)),false);
 await aimClock();await page.waitForFunction(()=>window.__AKUMU__.clockAttention.looks===1);assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.clockTickEnabled),false);assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.clockTickGain.gain.value),0);
 const times=await page.evaluate(()=>({escape:window.__AKUMU__.runSeconds,clock:window.__AKUMU__.clockAttention.seconds}));await page.waitForTimeout(650);
 const later=await page.evaluate(()=>({escape:window.__AKUMU__.runSeconds,clock:window.__AKUMU__.clockAttention.seconds,looks:window.__AKUMU__.clockAttention.looks}));assert.ok(later.escape>times.escape+.2);assert.equal(later.clock,times.clock);assert.equal(later.looks,1);
 await page.screenshot({path:'test-results/unusual-wall-clock.png'});
 // The face is now partly beyond the screen edge, nowhere near the crosshair.
 await page.evaluate(()=>{const g=window.__AKUMU__,p=g.room.wallClock.face.getWorldPosition(g.camera.position.clone()),dx=p.x+.65,dz=p.z-.8;g.setView(-.65,.8,Math.atan2(-dx,-dz)+.82,Math.atan2(p.y-1.65,Math.hypot(dx,dz)));});
 await page.waitForTimeout(200);assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.clockTickEnabled),false);assert.equal(await page.evaluate(()=>window.__AKUMU__.clockAttention.looks),1);
 assert.ok(await page.evaluate(()=>Math.abs(window.__AKUMU__.room.wallClock.face.getWorldPosition(window.__AKUMU__.camera.position.clone()).project(window.__AKUMU__.camera).x)>1));
 await page.screenshot({path:'test-results/clock-edge-visible.png'});

 await away();assert.ok(await page.evaluate(()=>window.__AKUMU__.audio.clockTickGain.gain.value)>.1);
 await aimClock();await page.waitForFunction(()=>window.__AKUMU__.clockAttention.looks===2);assert.equal(await page.evaluate(()=>window.__AKUMU__.clockAttention.narrated),false);
 await away();await aimClock();await page.waitForFunction(()=>window.__AKUMU__.clockAttention.narrated,null,{timeout:15000});await page.waitForFunction(()=>window.__AKUMU__.audio.doorVoice.ended,null,{timeout:15000});
 assert.ok((await page.evaluate(()=>window.__clockCaptions)).includes("(Narrator) Watching it won't give you more time."));const at=await page.evaluate(()=>window.__AKUMU__.audio.doorVoice.startAt);
 await away();await aimClock();await page.waitForFunction(()=>window.__AKUMU__.clockAttention.looks===4);assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.doorVoice.startAt),at);assert.equal(await page.evaluate(()=>window.__AKUMU__.clockAttention.narratorPending),false);
 assert.deepEqual(errors,[]);console.log('Quiet clock resumes away and mutes anywhere in view including partial screen-edge visibility; no interaction target; sustained stare counts once; third separate look plays recorded narrator caption once; escape timer keeps running independently.');
}finally{await browser.close();server.close();}
