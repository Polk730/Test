import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700},deviceScaleFactor:.5}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});
 await page.waitForFunction(()=>window.__AKUMU__?.audio?.bedVoiceBuffer,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 await page.evaluate(()=>window.__AKUMU__.setView(-.65,.6,.85,-.65));
 await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='bed');
 for(let i=1;i<=2;i++){
  await page.evaluate(()=>window.__AKUMU__.interact());
  await page.waitForFunction(()=>window.__AKUMU__.state==='inspecting');
  const r=await page.evaluate(()=>({count:window.__AKUMU__.puzzle.state.bedInspections,voice:!!window.__AKUMU__.audio.doorVoice}));
  assert.equal(r.count,i);if(i<2)assert.equal(r.voice,false);
  if(i<2){await page.evaluate(()=>window.__AKUMU__.exitInspection(true));await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='bed');}
 }
 await page.waitForFunction(()=>document.getElementById('opening-caption').textContent==='(Narrator) You just woke up. Already tired?');
 await page.screenshot({path:'test-results/bed-narrator.png'});
 const at=await page.evaluate(()=>window.__AKUMU__.audio.doorVoice.startAt);
 await page.waitForFunction(()=>window.__AKUMU__.audio.doorVoice.ended,null,{timeout:15000});
 await page.waitForFunction(()=>document.getElementById('opening-caption').textContent==='');
 await page.evaluate(()=>window.__AKUMU__.exitInspection(true));await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='bed');
 await page.evaluate(()=>window.__AKUMU__.interact());assert.equal(await page.evaluate(()=>window.__AKUMU__.audio.doorVoice.startAt),at);
 assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.bedInspections),3);
 assert.deepEqual(errors,[]);console.log('Actual aimed bed interaction: first visit silent, second plays recording with caption during inspection, caption clears and third does not repeat.');
}finally{await browser.close();server.close();}
