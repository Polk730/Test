import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1100,height:760},deviceScaleFactor:.65}),errors=[];page.on('pageerror',e=>{errors.push(e.message);console.log('PAGE ERROR',e.message);});
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:120000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Maya Rose');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:120000});
 await page.evaluate(()=>{const g=window.__AKUMU__;window.__entryDoor=g.room.door;window.__doorSounds=[];const play=g.audio.play.bind(g.audio);g.audio.play=(name,...args)=>{if(['doorSlam','doorLock'].includes(name))window.__doorSounds.push({name,time:g.audio.ctx.currentTime+(args[1]||0),z:g.camera.position.z});return play(name,...args);};g.puzzle.state.key='collected';g.setView(1.4,1.4,Math.PI,0);});await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='door');await page.keyboard.press('e');console.log('Exit requested',await page.evaluate(()=>({phase:window.__AKUMU__.progression.phase,door:window.__AKUMU__.puzzle.state.door,paused:window.__AKUMU__.paused,time:window.__AKUMU__.elapsed})));
 await page.waitForFunction(()=>window.__AKUMU__.progression.portalOpen,null,{timeout:120000});assert.equal(await page.evaluate(()=>window.__AKUMU__.state),'playing');assert.equal(await page.locator('#escape-time').isVisible(),false);
 await page.keyboard.down('w');await page.waitForFunction(()=>window.__AKUMU__.camera.position.z>2.35,null,{timeout:120000});await page.keyboard.up('w');
 // At the threshold the player is not yet fully clear, so the door must remain open.
 await page.evaluate(()=>window.__AKUMU__.setView(1.4,2.4,Math.PI,0));assert.equal(await page.evaluate(()=>window.__AKUMU__.currentRoom),1);assert.equal(await page.evaluate(()=>window.__doorSounds.length),0);
 await page.keyboard.down('w');await page.waitForFunction(()=>window.__AKUMU__.currentRoom===2,null,{timeout:120000});await page.keyboard.up('w');await page.waitForFunction(()=>window.__AKUMU__.progression.phase==='locked',null,{timeout:30000});
 const transition=await page.evaluate(()=>({name:window.__AKUMU__.playerName,sameDoor:window.__entryDoor===window.__AKUMU__.room.door,angle:window.__AKUMU__.room.door.rotation.y,sounds:window.__doorSounds,room:window.__AKUMU__.currentRoom,aisles:window.__AKUMU__.storage.layout.aisles.length}));
 assert.equal(transition.name,'Maya Rose');assert.equal(transition.sameDoor,true);assert.equal(transition.angle,0);assert.equal(transition.aisles,6);assert.deepEqual(transition.sounds.map(e=>e.name),['doorSlam','doorLock']);assert.ok(transition.sounds[0].z>=2.72);assert.ok(transition.sounds[1].time-transition.sounds[0].time>=.49);assert.ok(transition.sounds[1].time-transition.sounds[0].time<.65);
 await page.evaluate(()=>window.__AKUMU__.setView(1.4,2.95,0,0));await page.keyboard.down('w');await page.waitForTimeout(1100);await page.keyboard.up('w');assert.ok(await page.evaluate(()=>window.__AKUMU__.camera.position.z)>2.25);
 await page.screenshot({path:'test-results/storage-same-door.png'});
 const poses=[[1.38,3.0,Math.PI,-.08],[5.05,5.7,-Math.PI/2,-.02],[8.7,6.55,Math.PI,-.04],[10.55,10.1,Math.PI,.65]];
 for(let i=0;i<poses.length;i++){await page.evaluate(p=>window.__AKUMU__.setView(...p),poses[i]);await page.waitForTimeout(120);await page.screenshot({path:`test-results/storage-view-${i+1}.png`});}
 // Inspect every actual aisle, then the high vent apron; unit tests flood-fill all routes.
 for(const aisle of await page.evaluate(()=>window.__AKUMU__.storage.layout.aisles)){await page.evaluate(x=>window.__AKUMU__.setView(x,7.4,Math.PI,0),aisle.centerX);assert.equal(await page.evaluate(()=>window.__AKUMU__.currentRoom),2);}
 const metrics=await page.evaluate(()=>({drawCalls:window.__AKUMU__.renderer.info.render.calls,triangles:window.__AKUMU__.renderer.info.render.triangles,textures:window.__AKUMU__.renderer.info.memory.textures,staticBatches:window.__AKUMU__.storage.staticDrawCalls}));
 assert.ok(metrics.drawCalls<100);assert.equal(await page.evaluate(()=>window.__AKUMU__.storage.vent.requiredTool),'wrench');assert.equal(await page.evaluate(()=>window.__AKUMU__.storage.vent.openWithTool({kind:'screwdriver'})),false);assert.equal(await page.evaluate(()=>window.__AKUMU__.storage.vent.confirmEscape()),false);assert.equal(await page.evaluate(()=>window.__AKUMU__.state),'playing');
 // Developer-only integration: future wrench access and climbing are deliberately absent.
 await page.evaluate(()=>{window.__AKUMU__.storage.vent.openWithTool({kind:'wrench'});window.__AKUMU__.storage.vent.confirmEscape();});await page.waitForFunction(()=>document.getElementById('opening-caption').textContent==='TO BE CONTINUED...',null,{timeout:20000});
 assert.deepEqual(errors,[]);console.log('Physical shared-door crossing, safe slam/lock delay, name preservation, blocked return, six aisles, high vent and future-only ending hook passed',metrics);await writeFile('test-results/storage-metrics.json',JSON.stringify({transition,metrics},null,2));
}catch(e){console.log('STORAGE DIAGNOSTIC',await page.evaluate(()=>{const g=window.__AKUMU__;return {state:g.state,room:g.currentRoom,phase:g.progression.phase,door:g.puzzle.state.door,paused:g.paused,busy:g.busy,time:g.elapsed,position:g.camera.position.toArray(),calls:g.renderer.info.render.calls,triangles:g.renderer.info.render.triangles};}));throw e;}finally{await browser.close();server.close();}
