import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {mkdir,readFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {PROTOTYPE_CODE} from '../src/config.js';
await mkdir('test-results',{recursive:true});
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const url=process.env.AKUMU_URL||`http://127.0.0.1:${server.address().port}/?debug`,errors=[];
function watch(page){page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});}
try{
 const context=await browser.newContext({viewport:{width:1024,height:768},deviceScaleFactor:1,hasTouch:true,isMobile:true});
 await context.addInitScript(()=>{Object.defineProperty(HTMLCanvasElement.prototype,'requestPointerLock',{value:undefined,configurable:true});});
 const page=await context.newPage();watch(page);await page.goto(url,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__?.state==='menu',null,{timeout:120000});await page.tap('#play');await page.tap('#mode-normal');await page.fill('#player-name','Alex');await page.tap('#name-form button[type=submit]');
 await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:120000});
 assert.equal(await page.evaluate(()=>window.__AKUMU__.touchMode),true);assert.equal(await page.locator('#pause').isVisible(),false);assert.equal(await page.locator('#touch-controls').isVisible(),true);
 assert.equal(await page.locator('#prompt').isVisible(),false);assert.equal(await page.locator('#crosshair').isVisible(),true);assert.equal(await page.locator('#touch-interact').textContent(),'INTERACT');
 console.log('Touch PLAY without Pointer Lock and no target indicators passed');
 const cdp=await context.newCDPSession(page),box=await page.locator('#joystick').boundingBox(),x=box.x+box.width/2,y=box.y+box.height/2;
 const send=(type,points)=>cdp.send('Input.dispatchTouchEvent',{type,touchPoints:points.map(([id,x,y])=>({id,x,y,radiusX:8,radiusY:8,force:1}))});
 const initial=await page.evaluate(()=>({x:window.__AKUMU__.camera.position.x,z:window.__AKUMU__.camera.position.z,rotation:window.__AKUMU__.camera.rotation.y}));
 await send('touchStart',[[1,x,y]]);await send('touchMove',[[1,x,y-40]]);await send('touchStart',[[1,x,y-40],[2,760,340]]);await send('touchMove',[[1,x,y-40],[2,825,355]]);
 await page.waitForFunction(p=>Math.hypot(window.__AKUMU__.camera.position.x-p.x,window.__AKUMU__.camera.position.z-p.z)>.12,initial,{timeout:120000});
 await page.waitForFunction(r=>Math.abs(window.__AKUMU__.camera.rotation.y-r)>.05,initial.rotation,{timeout:120000});await send('touchEnd',[]);await page.waitForFunction(()=>window.__AKUMU__.touchInput.axis.y===0);
 console.log('Simultaneous joystick movement and swipe look passed');
 await page.tap('#touch-pause');assert.equal(await page.locator('#pause').isVisible(),true);await page.tap('#pause');assert.equal(await page.evaluate(()=>window.__AKUMU__.paused),false);
 await page.evaluate(()=>window.__AKUMU__.setView(1.4,.68,-Math.PI/2,-.20));await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='note'&&window.__AKUMU__.focused.index===2);await page.tap('#touch-interact');await page.waitForFunction(()=>window.__AKUMU__.state==='inspecting');
 const rotation=await page.evaluate(()=>window.__AKUMU__.inspected.rotation.y);await send('touchStart',[[3,480,380]]);await send('touchMove',[[3,520,395]]);await send('touchEnd',[]);await page.waitForFunction(r=>window.__AKUMU__.inspected.rotation.y!==r,rotation);
 let zoom=await page.evaluate(()=>window.__AKUMU__.inspectDistance);await page.tap('#zoom-in');await page.waitForFunction(z=>window.__AKUMU__.inspectDistance<z,zoom);
 zoom=await page.evaluate(()=>window.__AKUMU__.inspectDistance);await send('touchStart',[[3,440,380],[4,540,380]]);await send('touchMove',[[3,420,380],[4,560,380]]);await send('touchEnd',[]);await page.waitForFunction(z=>window.__AKUMU__.inspectDistance<z,zoom);await page.tap('#close-inspect');
 await page.waitForFunction(()=>window.__AKUMU__.state==='playing');assert.equal(await page.locator('#pause').isVisible(),false);
 console.log('Touch note rotation, pinch, zoom buttons, pause and resume passed');
 await page.evaluate(()=>window.__AKUMU__.setView(-.57,-.45,0,-1.01));await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='lock');await page.tap('#touch-interact');await page.waitForFunction(()=>window.__AKUMU__.inspectionKind==='lock');
 for(let i=0;i<4;i++)for(let n=0;n<Number(PROTOTYPE_CODE[i]);n++){const previous=await page.evaluate(i=>window.__AKUMU__.puzzle.state.digits[i],i),p=await page.evaluate(i=>window.__AKUMU__.wheelScreen(i),i);await page.touchscreen.tap(p.x,p.y);await page.waitForFunction(({i,b})=>window.__AKUMU__.puzzle.state.digits[i]!==b,{i,b:previous});}
 await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.drawer==='unlocked');assert.equal(await page.evaluate(()=>window.__AKUMU__.room.targets.find(t=>t.kind==='drawer').open),false);await page.tap('#close-inspect');
 await page.waitForFunction(()=>window.__AKUMU__.state==='playing');console.log('Post-inspection pose',await page.evaluate(()=>{const g=window.__AKUMU__;return {paused:g.paused,pos:g.camera.position.toArray(),rotation:g.camera.rotation.toArray(),focused:g.focused?.kind};}));assert.equal(await page.evaluate(()=>window.__AKUMU__.paused),false);await page.evaluate(()=>window.__AKUMU__.setView(-.57,-.45,0,Math.atan2(.56-1.65,.707)));await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='drawer');await page.tap('#touch-interact');await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.drawer==='open');
 await page.evaluate(()=>window.__AKUMU__.setView(-.57,-.55,0,-1.13));await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='hammer');await page.tap('#touch-interact');await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.hammer==='carried');await page.tap('#touch-drop');await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.hammer==='dropped');
 console.log('Touch physical wheel clicks, separate drawer opening, hammer pickup and DROP passed');
 await page.evaluate(()=>window.__AKUMU__.setView(1.25,1.15,.9,-.10));await page.screenshot({path:'test-results/v1-ipad-landscape.png'});await page.setViewportSize({width:768,height:1024});assert.equal(await page.locator('#touch-interact').isVisible(),true);await page.screenshot({path:'test-results/v1-ipad-portrait.png'});// Isolate the new transition after the existing touch puzzle checks above.
 await page.setViewportSize({width:1024,height:768});await page.evaluate(()=>{const g=window.__AKUMU__;g.puzzle.state.key='collected';g.setView(1.4,1.4,Math.PI,0);});await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='door');await page.tap('#touch-interact');await page.waitForFunction(()=>window.__AKUMU__.progression.portalOpen,null,{timeout:120000});
 const jb=await page.locator('#joystick').boundingBox(),jx=jb.x+jb.width/2,jy=jb.y+jb.height/2;
 await send('touchStart',[[1,jx,jy]]);await send('touchMove',[[1,jx,jy-40]]);await page.waitForFunction(()=>window.__AKUMU__.currentRoom===2,null,{timeout:120000});await send('touchEnd',[]);await page.waitForFunction(()=>window.__AKUMU__.progression.phase==='locked',null,{timeout:30000});
 assert.equal(await page.evaluate(()=>window.__AKUMU__.playerName),'Alex');assert.equal(await page.locator('#touch-interact').isVisible(),true);
 await page.evaluate(()=>window.__AKUMU__.setView(5.05,5.7,-Math.PI/2,0));const look=await page.evaluate(()=>window.__AKUMU__.camera.rotation.y);await send('touchStart',[[2,760,340]]);await send('touchMove',[[2,810,350]]);await send('touchEnd',[]);await page.waitForFunction(r=>Math.abs(window.__AKUMU__.camera.rotation.y-r)>.05,look);
 await page.tap('#touch-pause');assert.equal(await page.locator('#pause').isVisible(),true);await page.tap('#pause');await page.screenshot({path:'test-results/storage-ipad-landscape.png'});await page.setViewportSize({width:768,height:1024});await page.screenshot({path:'test-results/storage-ipad-portrait.png'});
 console.log('Touch Room 2 door interaction, joystick entry, locked return state, swipe look and pause passed');await context.close();
 const desktop=await browser.newContext({viewport:{width:900,height:650}});await desktop.addInitScript(()=>{HTMLCanvasElement.prototype.requestPointerLock=()=>Promise.reject(new Error('Pointer lock denied'));});
 const dp=await desktop.newPage();watch(dp);await dp.goto(url,{waitUntil:'domcontentloaded',timeout:120000});await dp.click('#play');await dp.click('#mode-normal');await dp.fill('#player-name','Alex');await dp.click('#name-form button[type=submit]');await dp.waitForFunction(()=>window.__AKUMU__?.state==='playing',null,{timeout:120000});assert.equal(await dp.locator('#pause').isVisible(),false);assert.equal(await dp.evaluate(()=>window.__AKUMU__.dragLook),true);
 await dp.evaluate(()=>window.__AKUMU__.setView(0,0));await dp.keyboard.down('w');await dp.waitForFunction(()=>window.__AKUMU__.camera.position.z<-.1,null,{timeout:120000});await dp.keyboard.up('w');
 const before=await dp.evaluate(()=>window.__AKUMU__.camera.rotation.y);await dp.mouse.move(450,330);await dp.mouse.down();await dp.mouse.move(510,350,{steps:3});await dp.mouse.up();await dp.waitForFunction(r=>Math.abs(window.__AKUMU__.camera.rotation.y-r)>.01,before);
 console.log('Desktop mouse-capture rejection fallback passed');assert.deepEqual(errors,[]);console.log('No touch or fallback console/page errors');await desktop.close();
}catch(e){console.error('Browser errors:',errors);throw e;}finally{await browser.close();server.close();}
