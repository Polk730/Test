import test from 'node:test';import assert from 'node:assert/strict';
import {ComputerStageOne,LETTER_NUMBER_KEY} from '../src/computer-stage.js';
import {StableBoxStack,BOX_HOMES,STACK_BOX_SIZE} from '../src/box-stacking.js';
import {storageLayout} from '../src/storage-layout.js';import {collides} from '../src/physics.js';
test('Stage 1 has a complete unambiguous key, persistent sequence, strict numeric validation and only Stage 2 becomes available',()=>{
 for(let run=0;run<200;run++){const p=new ComputerStageOne();assert.match(p.sequence,/^[A-I]{4}$/);assert.equal(p.answer,[...p.sequence].map(c=>LETTER_NUMBER_KEY[c]).join(''));assert.equal(p.submit(p.answer),false);p.powerOn();const sequence=p.sequence;for(const wrong of ['ABCD','123','12345','1e3','-123','0000',p.answer==='1111'?'2222':'1111']){assert.equal(p.submit(wrong),false);assert.equal(p.completed,false);}p.powerOn();assert.equal(p.sequence,sequence);assert.equal(p.submit(p.answer),true);assert.deepEqual(p.stages,['COMPLETED','AVAILABLE','LOCKED','LOCKED']);assert.equal(p.submit(p.answer),false);assert.equal(p.completed,true);}
});
test('shelf crates are immovable until glowing, and only the current reward can be carried and safely set down',()=>{
 const p=new ComputerStageOne(()=>0),s=new StableBoxStack(id=>id===1&&p.completed),layout=storageLayout();
 assert.equal(s.boxes.length,3);assert.deepEqual(s.colliders,[]);const initial=JSON.stringify(s.boxes);for(const id of [1,2,3])assert.equal(s.pickup(id),false);assert.equal(JSON.stringify(s.boxes),initial);
 p.powerOn();p.submit(p.answer);assert.equal(s.pickup(2),false);assert.equal(s.pickup(3),false);assert.equal(s.pickup(1),true);assert.equal(s.pickup(2),false);
 assert.equal(s.dropAt(-20,3,layout.boxes,layout.bounds),false);assert.equal(s.heldId,1);assert.equal(s.dropAt(2.3,7.825,layout.boxes,layout.bounds),false);assert.equal(s.heldId,1);
 assert.equal(s.dropNear({x:5,z:5.7},Math.PI,layout.boxes,layout.bounds),true);assert.equal(s.heldId,null);assert.equal(s.get(1).placement,'floor');assert.equal(s.colliders.length,1);assert.ok(Math.abs(s.position(1).y-STACK_BOX_SIZE/2-.015)<1e-9);
 for(const id of [2,3]){assert.deepEqual(s.position(id),{x:BOX_HOMES[id-1].x,y:BOX_HOMES[id-1].y,z:BOX_HOMES[id-1].z});assert.equal(s.pickup(id),false);}assert.equal(s.pickup(1),true);assert.equal(s.dropAt(5,5.7,layout.boxes,layout.bounds,{x:5,z:5.7}),false);assert.equal(s.heldId,1);assert.equal(s.dropNear({x:1.4,z:7.825},-Math.PI/2,layout.boxes,layout.bounds),true);
});
test('controlled placement remains supported and recoverable without falling, overlap, or dropping through shelving',()=>{
 // Geometry coverage for later rewards; production only grants Box 1 after Stage 1.
 const s=new StableBoxStack(()=>true),layout=storageLayout(),player={x:9.7,z:9.8};
 for(const id of [1,2,3]){assert.equal(s.pickup(id),true);assert.equal(s.dropAt(11.15,9.8,layout.boxes,layout.bounds,player),true);}assert.equal(s.get(2).support,1);assert.equal(s.get(3).support,2);assert.equal(s.pickup(1),false);assert.equal(s.pickup(2),false);assert.ok(Math.abs(s.position(3).y-s.position(1).y-STACK_BOX_SIZE*2)<1e-8);
 assert.equal(s.pickup(3),true);assert.equal(s.dropNear({x:5,z:5.7},0,layout.boxes,layout.bounds),true);assert.equal(s.pickup(2),true);assert.equal(s.dropNear({x:8.7,z:5.7},0,layout.boxes,layout.bounds),true);
 for(let i=0;i<200;i++){assert.equal(s.pickup(1),true);assert.equal(s.dropNear({x:1.38,z:5.7},i%2?0:Math.PI,layout.boxes,layout.bounds),true);for(const b of s.boxes){assert.ok(Number.isFinite(b.x)&&Number.isFinite(b.y)&&Number.isFinite(b.z));assert.ok(b.y>=STACK_BOX_SIZE/2);assert.ok(b.x>layout.bounds.minX&&b.x<layout.bounds.maxX);}}
});
