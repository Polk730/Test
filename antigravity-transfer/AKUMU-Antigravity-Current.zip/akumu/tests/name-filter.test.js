import {test} from 'node:test';
import assert from 'node:assert/strict';
import {validatePlayerName} from '../src/name-filter.js';
test('accepts normal names, accents, punctuation and safe embedded letter sequences',()=>{for(const name of ['Maya Rose','Oliver','Vihaan','Scunthorpe','Hancock','Cassidy','Fuchs','José','Zoë','李明',"O'Connor",'Anne-Marie','Nigel','Ginger','Niagara'])assert.equal(validatePlayerName(name).ok,true,name);assert.equal(validatePlayerName('  Maya   Rose  ').name,'Maya Rose');});
test('rejects profanity, racist slurs and simple disguises',()=>{for(const name of ['fuck','f u c k','f.u.c.k','fuuuck','f4gg0t','n1gger','nіgger','niggga','n i g g e r','ＦＵＣＫ','sh!t','Scheiße','Heil Hitler','white power','Arschloch'])assert.equal(validatePlayerName(name).ok,false,name);});
test('rejects empty, overlong and markup-like names without echoing rejected input',()=>{for(const name of ['  ','A'.repeat(25),'<img src=x>']){const result=validatePlayerName(name);assert.equal(result.ok,false);assert.ok(result.error);}});

test('rejects single-consonant slur variants and expanded spelling evasions',()=>{for(const name of ['niger','NIGER','niga','nigah','niggar','niggerr','n1g3r','n i g e r','n.i.g.e.r','n\u200biger','nіgеr','AlexNiger','neger','fuk','phuck','fvck','shlt'])assert.equal(validatePlayerName(name).ok,false,name);});
