import {test} from 'node:test';
import assert from 'node:assert/strict';
import {LampFaults,KeyBlackout} from '../src/atmosphere.js';
import {PROTOTYPE_CODE} from '../src/config.js';
test('lamp faults stay bounded and leave irregular long gaps',()=>{const lamp=new LampFaults(),starts=[];let previous=-100;for(let frame=0;frame<60*300;frame++){const time=frame/60,value=lamp.sample(time);assert.ok(value>.25&&value<1.02);if(lamp.start!==previous){starts.push(lamp.start);previous=lamp.start;}}assert.ok(starts.length>=15&&starts.length<65);for(let i=1;i<starts.length;i++)assert.ok(starts[i]-starts[i-1]>=5);assert.ok(new Set(starts.slice(1).map((x,i)=>Math.round(x-starts[i]))).size>2);});
test('lamp fault envelopes recover after brief dips',()=>{const lamp=new LampFaults();lamp.sample(3.6);const middle=lamp.sample(lamp.start+lamp.duration/2),after=lamp.sample(lamp.start+lamp.duration+.01);assert.ok(middle<.90);assert.ok(after>.98);});
test('prototype combination is a single fixed four-digit story configuration',()=>assert.match(PROTOTYPE_CODE,/^\d{4}$/));

test('key blackout flickers for half a second, stays off for two seconds, restores once',()=>{const b=new KeyBlackout();assert.equal(b.sample(5),1);assert.equal(b.trigger(10),true);assert.equal(b.sample(10),1);assert.ok(b.sample(10.055)<.4);assert.ok(b.sample(10.13)>.6);assert.ok(b.sample(10.22)<.25);for(const t of [10.5,11,12,12.499])assert.equal(b.sample(t),0);assert.ok(b.sample(12.59)>.4&&b.sample(12.59)<.6);assert.equal(b.sample(12.7),1);assert.equal(b.trigger(20),false);assert.equal(b.sample(20),1);});
