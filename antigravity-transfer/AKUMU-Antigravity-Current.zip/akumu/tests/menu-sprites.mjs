import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {mkdir} from 'node:fs/promises';
await mkdir('test-results',{recursive:true});
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1280,height:721}}),errors=[];
page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
try{
 await page.goto(process.env.AKUMU_URL||'http://127.0.0.1:4175/AKUMU.html?debug',{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__&&document.querySelector('.flame-frame').complete&&document.querySelector('.flame-frame').naturalWidth===64,null,{timeout:60000});await page.waitForTimeout(1700);
 const rect=await page.locator('.lantern-flame').boundingBox();const pictures=new Set();
 for(let i=0;i<12;i++){pictures.add(await page.locator('.flame-frame').getAttribute('src'));await page.waitForTimeout(120);}
 assert.ok(pictures.size>=4);const after=await page.locator('.lantern-flame').boundingBox();assert.deepEqual(after,rect);
 await page.mouse.move(1200,650);await page.waitForTimeout(850);assert.equal(await page.locator('.title-scene').evaluate(e=>getComputedStyle(e).transform),'none');
 await page.screenshot({path:'test-results/title-frame-flame.png'});await page.screenshot({path:'test-results/title-flame-detail.png',clip:{x:95,y:390,width:110,height:145}});
 console.log('Distinct flame images cycle inside a fixed lantern; whole artwork does not move');
 await page.waitForFunction(()=>[...document.querySelectorAll('.title-bird')].some(b=>!b.hidden&&parseFloat(b.style.left)>86.7&&parseFloat(b.style.left)<88.3),null,{timeout:30000});
 const bird=page.locator('.title-bird:not([hidden])').first();await page.waitForFunction(()=>[...document.querySelectorAll('.title-bird')].some(b=>!b.hidden&&b.complete&&b.naturalWidth===48));
 assert.ok(await page.locator('.window-birds').evaluate(e=>getComputedStyle(e).maskImage!=='none'||getComputedStyle(e).webkitMaskImage!=='none'));
 await page.screenshot({path:'test-results/title-window-bird.png'});await page.screenshot({path:'test-results/title-window-detail.png',clip:{x:970,y:50,width:270,height:380}});
 await page.waitForFunction(()=>[...document.querySelectorAll('.title-bird')].every(b=>b.hidden),null,{timeout:10000});console.log('Occasional wing-frame bird flight is masked to the glass panes and then disappears');
 await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(150);const still=await page.locator('.flame-frame').getAttribute('src');await page.waitForTimeout(300);assert.equal(await page.locator('.flame-frame').getAttribute('src'),still);assert.equal(await page.locator('.title-bird:not([hidden])').count(),0);
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});assert.equal(await page.locator('#menu').isVisible(),false);assert.equal(await page.locator('#crosshair').isVisible(),true);
 assert.deepEqual(errors,[]);console.log('Reduced motion and gameplay handoff passed without console/page errors');
}finally{await browser.close();}
