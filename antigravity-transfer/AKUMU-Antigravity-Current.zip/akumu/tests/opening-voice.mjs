import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__?.audio?.voiceBuffer,null,{timeout:60000});
 const duration=await page.evaluate(()=>window.__AKUMU__.audio.voiceBuffer.duration);assert.ok(duration>2.8&&duration<3.1);
 // Record actual per-frame caption/camera/audio-clock values, rather than sampling wall timers.
 await page.evaluate(()=>{window.__openingFrames=[];const record=()=>{const g=window.__AKUMU__;if(g.state==='opening'&&g.openingUsesAudio)window.__openingFrames.push({time:g.openingTime,caption:document.getElementById('opening-caption').textContent,height:g.camera.position.y,pitch:g.camera.rotation.x,ctx:g.audio.ctx.currentTime,voiceAt:g.audio.openingVoice?.startAt});if(g.state!=='playing')requestAnimationFrame(record);};requestAnimationFrame(record);});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.openingUsesAudio,null,{timeout:60000});
 await page.waitForFunction(()=>window.__AKUMU__.openingTime>.8);const frozen=await page.evaluate(async()=>{const g=window.__AKUMU__;await g.audio.pause();return g.openingTime;});await page.waitForTimeout(250);assert.ok(Math.abs(await page.evaluate(()=>window.__AKUMU__.openingTime)-frozen)<.035);await page.evaluate(()=>window.__AKUMU__.audio.resume());
 await page.waitForFunction(()=>document.getElementById('opening-caption').textContent==='Where am I?',null,{timeout:30000});await page.screenshot({path:'test-results/opening-spoken-line.png'});
 await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 const result=await page.evaluate(()=>({frames:window.__openingFrames,ended:window.__AKUMU__.audio.openingVoice.ended,height:window.__AKUMU__.camera.position.y,clock:window.__AKUMU__.openingTime}));
 const spoken=result.frames.filter(f=>f.caption==='Where am I?');assert.ok(spoken.length>0);assert.ok(spoken[0].time>=OPENING.voiceStart+OPENING.speechStart-.12);assert.ok(spoken[0].time<OPENING.voiceStart+OPENING.speechStart+.35);assert.ok(spoken.at(-1).time<=OPENING.voiceStart+OPENING.speechEnd+OPENING.captionTail+.2);
 assert.ok(result.frames.filter(f=>f.time>1.7&&f.time<2.05).every(f=>f.caption===''));assert.equal(result.ended,true);assert.equal(result.height,1.65);assert.ok(result.clock>=8&&result.clock<8.5);assert.equal(await page.locator('#opening-caption').textContent(),'');assert.deepEqual(errors,[]);
 console.log('Voice duration',duration,'caption first/last',spoken[0].time,spoken.at(-1).time,'standing',result.clock);console.log('Embedded MP3, audio-clock caption/camera alignment, pause/resume and gameplay handoff passed');
 await writeFile('test-results/opening-timing.json',JSON.stringify(result,null,2));
}finally{await browser.close();server.close();}
