import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {OPENING} from '../src/opening.js';
await mkdir('test-results',{recursive:true});
const html=await readFile('standalone/AKUMU.html'),server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end(html);});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined,headless:true,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1000,height:700}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(`http://127.0.0.1:${server.address().port}/?debug`,{waitUntil:'domcontentloaded',timeout:120000});await page.waitForFunction(()=>window.__AKUMU__,null,{timeout:60000});
 await page.click('#play');await page.click('#mode-normal');await page.fill('#player-name','Alex');await page.click('#name-form button[type=submit]');await page.waitForFunction(()=>window.__AKUMU__.state==='playing',null,{timeout:60000});
 await page.evaluate(()=>window.__AKUMU__.setView(-.65,.6,.85,-.65));await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='bed');
 await page.mouse.click(500,350);await page.waitForFunction(()=>window.__AKUMU__.state==='inspecting');
 assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.bedInspections),1);
 await page.click('#close-inspect');await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='bed');
 await page.keyboard.press('e');await page.waitForFunction(()=>window.__AKUMU__.state==='inspecting');
 assert.equal(await page.evaluate(()=>window.__AKUMU__.puzzle.state.bedInspections),2);
 await page.click('#close-inspect');await page.waitForFunction(()=>window.__AKUMU__.state==='playing');
 await page.evaluate(()=>window.__AKUMU__.setView(-.57,-.4,0,-.93));await page.waitForFunction(()=>window.__AKUMU__.focused?.kind==='lock');
 await page.mouse.click(500,350);await page.waitForFunction(()=>window.__AKUMU__.inspectionKind==='lock');
 assert.deepEqual(await page.evaluate(()=>window.__AKUMU__.puzzle.state.digits),[0,0,0,0]);
 const wheel=await page.evaluate(()=>window.__AKUMU__.wheelScreen(0));await page.mouse.click(wheel.x,wheel.y);
 await page.waitForFunction(()=>window.__AKUMU__.puzzle.state.digits[0]===1);
 assert.deepEqual(errors,[]);console.log('Left-click examines bed exactly once, E still works, left-click opens lock without unintended wheel turn, and wheel clicks still work.');
}finally{await browser.close();server.close();}
