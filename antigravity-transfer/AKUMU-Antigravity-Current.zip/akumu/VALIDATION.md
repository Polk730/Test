# AKUMU Prototype V1 — validation

Validated in the cloud environment with Node.js 24.22.1 and headless Chromium using software WebGL on 3 November 2026.

## Executed checks

- `npm test`: 8 tests passed. Five cover room boundaries, bed collision, sliding, the open drawer and intact/removed window barricade collision. Three cover bounded, brief and irregular lamp faults and the fixed four-digit configuration.
- `npm run build:html`: passed. The actual final embedded JavaScript is parsed before writing the standalone file. All game assets, styles and Three.js are embedded or generated locally.
- `npm run build`: passed. Vite gives a nonblocking size advisory for the 512 kB Three.js vendor chunk (about 130 kB gzip); there are no compilation failures.
- `npm run test:browser`: passed against the final standalone export. The playthrough inspected all three notes, physically rotated the third to reveal the back, clicked individual mechanical wheels including 9→0 wraparound, validated the shared combination, left the drawer shut after solving, exited inspection, opened it separately, picked up the hammer, dropped it, retrieved it, removed the barricade, observed the physical hammer still present in the scene, revealed/collected the key, unlocked/opened the door, and reached the fully black ending with TO BE CONTINUED.... Locked drawer and door gates and the absence of normal interaction indicators were also checked.
- `npm run test:touch`: passed. Touch emulation with Pointer Lock unavailable tested PLAY, simultaneous joystick movement and swipe look, pause/resume, note rotation, pinch/button zoom, physical lock-wheel taps, separate drawer opening, hammer pickup and the DROP button. A desktop context explicitly refused Pointer Lock and still supported keyboard movement and drag-to-look.
- Both browser suites reported zero console errors and zero uncaught page errors.

The browser suites place the camera at repeatable viewpoints but use real key presses, mouse clicks, touch taps, drags and pinches. They do not set puzzle progress to skip the combination, hammer, key or ending.

## Visual review and performance evidence

Reviewed screenshots of the room from eye height, ceiling fixture, door wall, all note fronts, the third note back, solved mechanical lock, cleared window, fallen boards and hammer, ending, and landscape/portrait touch layouts. The initial lighting trial left the upper walls too dark; it was corrected using restrained local spill, bounced light and a broader shaded cone. Blanket/mattress clipping and tiled plaster seams were also corrected. The normal-gameplay vignette was removed so scene lighting determines visibility.

The representative bed/window view in the final playthrough reported 69 render calls, 28,234 triangles and 29 allocated textures. The door/ending view reported 38 calls, 21,170 triangles and 33 textures after all inspection assets had been exercised. These are view-specific counts, not peak whole-scene or device frame-rate claims.

The scene uses two 1024×1024 shadow-casting spotlights. Weak local spill/bounce lights do not cast shadows. Static depth maps are retained; moving furniture, hammer, planks and door request updates. Cached 512² color/roughness/normal surface sets, shared digit atlases, static mesh batching and capped pixel ratio limit overhead. Contact occlusion uses local inexpensive patches rather than a fullscreen AO pass. No bloom, music or jump-scare effects were added.

## Limits

No physical iPad, Safari, Windows laptop or school-computer GPU benchmark was available. Touch results are Chromium emulation, not proof of every in-app viewer's permissions. Some attachment viewers block JavaScript or WebGL; that restriction requires opening a served webpage in a normal browser.

The environment is procedural, not a photogrammetry asset pack. Contact occlusion is approximate; the controlled plank and hammer motions are not a general rigid-body simulation. The original menu reference was visible in chat but unavailable as a project asset, so the existing CSS fallback remains. No additional room or inventory was added. Earlier 3D-print repository files remain unchanged.

## Free-mouse and Note 3 correction

Removed all automatic mouse capture. Desktop look now requires holding the left mouse button and dragging; ordinary cursor movement does not change the view. PLAY, returning from inspection and resuming never request Pointer Lock. Esc pauses/resumes gameplay or exits inspection. Note 2 teaches the revised look control. Note 3's front contains only its logbook title and the interaction instruction, with no mention of a code, its back or turning it over. The actual back-side puzzle content is retained.

`npm test` now passes 10 tests, including the no-hint content requirement. Both production and standalone builds pass. `node tests/cursor.mjs` instrumented the capture API and verified zero capture requests after PLAY, drag/release, pause/resume, Esc inspection exit, CLOSE inspection exit and subsequent keyboard movement. Ordinary mouse motion leaves the view still; holding and dragging changes it. No page errors occurred. The corrected Note 3 front screenshot was reviewed.

## FPS capture clarification

Restored normal desktop FPS mouse-look per the clarified control request. PLAY captures the mouse; Esc releases it and pauses without any automatic recapture. Clicking the pause screen or the inspection CLOSE button deliberately resumes capture. Esc from inspection leaves the mouse released and shows the pause screen. iPad still uses touch input; a blocked capture API still falls back to drag-to-look. Note 3's front remains free of code/back-side hints.

All 10 unit tests and both builds pass. The updated cursor browser test exercised real Pointer Lock: FPS mouse movement without holding a button, release and persistent pause on Esc, a second Esc remaining released, explicit Resume recapture, free-cursor inspection, Esc exit without recapture, and CLOSE recapture. No page errors occurred.

## Animated illustrated menu

The supplied 1280×721 JPEG is now a source asset and is embedded as a data URL in the standalone HTML. It is displayed intact, with separate lantern glow/flicker, moonlight/cloud movement, star glimmers, drifting pixel dust/embers, slight pointer parallax and a breathing/hover/press animation on the original illustrated PLAY face. There is one accessible PLAY button. Portrait layouts retain the full artwork against a blurred backdrop. Reduced-motion preferences disable decorative animations and particles. Menu effects stop on PLAY; the 3D scene renders once for warm-up while the menu is visible rather than continuously consuming GPU time.

`node tests/menu.mjs` passed: embedded image decode, one PLAY button, keyboard focus, active animations, reduced-motion opt-out, no repeated 3D rendering behind the menu, keyboard PLAY, actual desktop pointer capture and Esc release, portrait/landscape touch layout with a sufficiently large hit area, touch PLAY and gameplay controls. No console/page errors occurred. Desktop and portrait screenshots were reviewed. All 10 existing unit tests pass; production and standalone builds pass. The existing Three.js vendor size advisory remains nonblocking. Physical Safari/iPad testing is still not implied by Chromium emulation.

## Center aiming dot

Per the latest request, normal gameplay now shows a fixed 4 CSS-pixel off-white center dot with a subtle dark edge for contrast. The existing HUD state hides it during the title menu, opening, pause, object inspection, controlled sequences and ending. It has no pointer events and is hidden from assistive text output. Object labels and prompts stay hidden. The earlier attachment-preview investigation was canceled and no preview-loading change was applied.

The standalone build passed. The targeted browser regression verified the dot is visible during gameplay, exactly 4×4 pixels, and centered on the 1000×700 test viewport. It disappears while paused and in note inspection. FPS capture, Esc release and explicit resume still pass without page errors.

## Chrome focus, capture-denial and right-click correction

The game canvas now takes keyboard focus explicitly on PLAY, resume and mouse interaction. Touch-capable desktop machines are no longer assumed to be touch-only: initial coarse-pointer detection and the actual pointer type select mouse versus touch controls dynamically. The touch-input helper reads the current mode rather than a startup-only boolean.

Normal FPS capture remains supported and a left-click in the room can retry it. Rejected/unavailable capture is remembered so pause/resume does not keep triggering a failing permission request. During denied/pending capture, WASD remains independent of capture and either left or right mouse drag can look around. A fallback-only notice explains those controls. Context menus and right-button auxiliary clicks are prevented inside the game page. Movement-key repeats can restore held movement after focus/capture transitions, while repeated interaction actions stay suppressed.

`node tests/chrome-input.mjs` passed with Pointer Lock deliberately rejected and a simulated touch-capable laptop: desktop mode, focused canvas, actual WASD movement, prevented right-click context menu, both drag buttons, pause/resume with a held movement key, and mobile touch joystick movement. `node tests/cursor.mjs` also passed with real Chrome Pointer Lock, including a right-click during capture, FPS look, Esc release, explicit resume and inspection transitions. Both reported no page errors. The 10 unit tests and standalone build passed. These browser tests use the served standalone artifact; device/browser policy can still refuse capture, which the fallback is designed to handle.

## Center-window key and pickup presentation

The key now hangs from a small hook at the middle of the closed window, physically between the glass and the front barricade. It is larger (1.6×) and uses a brighter aged-brass surface. Its pickup target remains gated until the planks have been removed. The former side-wall crack placement is removed.

Collecting the key now enters a brief `key-found` presentation state: a large lit 3D copy and the exact text “Found key” appear, then gameplay resumes automatically. The collected-key state unlocks the subsequent door interaction. This introduces no inventory. Esc or focus loss during the presentation returns to the normal pause flow, retaining the collected key.

The complete browser playthrough passed on the final exported build: reveal at the center, pickup, visible 3D model, fully opaque Found key text, automatic return to gameplay, key-enabled door opening and ending. Both the centered world-key view and pickup screenshot were reviewed. No console/page errors occurred. All 10 unit tests and the standalone build pass; the production build is also checked.

## Picture-frame flame and occasional window birds

Eight separately authored pixel-art SVG pictures replace the prior flame-glow transform effect. Only the flame picture changes; its lantern remains fixed. Pointer-driven translation of the overall artwork has been removed. The existing soft light overlays remain stationary.

Four bird wing-pose SVG pictures support occasional short flights, with a rare smaller companion. A reference-aligned glass-pane mask prevents silhouettes painting over the mullions and stone frame. The first flight starts after roughly six active menu seconds; later flights have irregular 16–35 second gaps. No bird sound or music is added. Reduced motion freezes/hides these effects, and PLAY stops their updates.

`node tests/menu-sprites.mjs` passed on the final export. It observed at least four distinct flame image URLs while the lantern bounds stayed unchanged, verified the full artwork stays untransformed after mouse movement, observed a masked bird flight and its disappearance, checked reduced-motion behavior and PLAY handoff with the aim dot visible, and reported no console/page errors. Flame and window close-up screenshots were reviewed; an initial mask alignment issue was corrected. All 10 unit tests pass, along with standalone and production builds. Actual Safari/iPad behavior remains unverified by this Chromium test.

## Louder, layered SFX update

Replaced the previous simple action tones/noise puffs with deterministic layered PCM foley and four cached variants per effect. Actions now have distinct wood resonance, surface friction, spring/metal detents, latch rattles, key jingles and hinge stick-slip textures. Separate foreground/ambience buses, short stereo room reflections and a compressor improve perceived strength without globally blasting background sound. No music or external recordings were introduced.

All 13 unit tests pass, including finite samples at 44.1/48 kHz, bounded sample peaks, low DC, repeat variation and foreground/ambient level relationships. The browser audio test rendered a complete stereo mix with six overlapping board impacts. The final run measured a peak of 0.494 full-scale (about 6 dB headroom) and zero output after the ending fade. A representative new footstep was approximately 12.2 dB higher in RMS than a reconstruction of the prior footstep signal chain; exact values vary slightly with procedural variants/noise.

Actual AudioContext startup after a user gesture, action playback and suspend/resume passed. The exported standalone game also passed PLAY audio startup, a real locked-door interaction, movement-triggered footsteps, and Esc/pause/resume without page errors. The WAV preview contains the new mix, not the old comparison. This is signal/browser validation, not a claim of listening tests on physical speakers, headphones, iPad or Safari.


## Recorded wake-up voice

The supplied MP3 is embedded unchanged (mono, decoded duration 2.9257 seconds), predecoded on the menu and scheduled once after PLAY at opening time 1.50 seconds. The yawn accompanies the ceiling view; “Where am I?” appears at 2.51–4.26 seconds while the camera rises. Audio, subtitle and camera use the same AudioContext clock; ambience briefly ducks under the voice. Playback speed and pitch are unchanged.

Validation: all 15 unit tests, production build and standalone HTML build passed. Chromium integration verified the embedded voice source completed, subtitle timing (observed 2.529–4.210 seconds), audio pause/resume alignment, and standing/gameplay handoff at 8.354 seconds with no page errors. Inspected the spoken-line screenshot. Physical iPad/Safari playback was not tested.


## Locked-door narrator
All 15 unit tests and standalone build passed. Chromium verified embedded MP3 duration 3.23918 seconds, locked-door trigger, exact narrator subtitle, no overlapping restarts, audio pause alignment, caption clearing, cooldown replay, and normal door opening after key collection. No page errors.


## Hammer-door narrator
All 15 unit tests and standalone HTML build passed. Chromium verified both door voice triggers, hammer clip duration in the expected 3.9–4.2 second range, exact narrator captions and clearing, shared overlap/restart suppression even when switching hammer state, audio pause alignment, and keyed-door opening. No page errors. Uploaded recording embedded unchanged; no physical iPad playback test.


## Fourth bed inspection narration
All 15 unit tests, production build and final standalone build passed. Chromium tested actual aimed bed interaction: first three inspections silent, fourth plays the embedded recording with the exact narrator caption visible during inspection, caption clears, fifth does not replay. Inspected the bed screenshot and adjusted model size, centering and angle, then repeated the interaction test successfully. Existing two door narrator triggers, shared overlap protection, pause alignment and keyed-door opening also passed Chromium regression checks. No page errors.


## Wrong-code narrator
All 15 unit tests, production build and standalone build passed. Chromium verified the untouched lock remains silent, an intermediate wheel click does not immediately trigger dialogue, a wrong settled combination plays the uploaded recording and exact caption, the caption clears, and the correct combination subsequently unlocks without replaying the narrator. Screenshot inspected: subtitle is readable below the wheels. No page errors.


## Door alignment and title music
All 15 unit tests, production build and standalone build passed. Chromium checked music enable/mute/re-enable, slab top 2.215 m and horizontal bounds 0.9–1.9 m, actual aiming at the door, locked attempt and keyed opening with no page errors. Inspected rendered door and title screenshots. Music is original, locally synthesized and embedded; autoplay may require the title music button due to browser policy. Physical iPad playback and subjective listening quality were not tested.


## Second cabinet strike voice
All 15 unit tests, production and standalone builds passed. Chromium verified real aimed cupboard interaction: empty-hand interaction does not count; first hammer strike stays silent; a rapid duplicate is ignored; second deliberate strike plays the embedded recording with the unreadable-speaker caption; caption clears; third strike does not replay the voice. No page errors. Inspected screenshot: speaker label is obscured while the spoken text remains legible.


## Automatic title music, no toggle
Removed music toggle and its styling. Playback attempts immediately, retries on menu pointer/keyboard gestures, resumes on returning to the visible menu, and stops on PLAY. Standalone build and focused Chromium test passed: no toggle, initial play attempt, real gesture-unlocked playback, looping, and paused audio after PLAY. An initial expanded run passed all music checks but timed out on an unrelated door-opening assertion; the focused playback test then passed with no page errors.


## Hammer swing
All 15 unit tests and production/standalone builds passed. Chromium verified the wind-up/contact/recovery state, one impact at 0.26 seconds (within frame tolerance), duplicate-input suppression, second cabinet strike dialogue, and complete window barricade removal/key reveal. Initial 20-second window-physics wait timed out under software rendering; rerun with 60-second timeout passed with no page errors.


## Left-click interaction
Standalone build and Chromium interaction test passed: actual left-click examines the bed exactly once; E still works; left-click opens the lock without an unintended digit change; subsequent clicks on a wheel still turn it. Updated note-instruction assertion to match the new controls while retaining its no-hidden-content checks. No browser page errors.


## Crayon tally wall
Standalone build passed. Chromium rendered the wall from the player view and verified the original wall note remains targetable with no page errors. Inspected screenshot: dense groups of four vertical marks plus diagonal fifth cover the wall beside the bed, follow uneven room lighting, and sit behind furniture and note. One added draw call; no additional lights or shadow maps.


## Personal name and escape timer
All 15 unit tests and production/standalone builds passed. Chromium verified PLAY opens the form while the game remains on the menu, a name containing spaces submits with Enter, the wake-up runs with no timer shown, the exact personalized text is generated, the timer appears during play and freezes on pause, and the ending displays a fixed escape duration. After switching from physics-clamped elapsed time to real elapsed play time, reran the final export successfully (test escape result 00:03). Inspected name form, blood message and ending screenshots. No page errors. Existing browser start flows updated for the name form.


## Escape recording and repeated drawer narration
All 15 unit tests and production/standalone builds passed. Escape-specific Chromium test verified the 5.0678-second embedded clip, both timed narrator subtitle cues, audio-clock pause alignment, interruption of previous dialogue, preserved voice volume, final title and escape time. The repeated-drawer Chromium test verified locked attempts do not count; first two openings stay silent; third triggers the supplied recording/caption once; fourth does not restart it. Triggering escape then interrupts the drawer voice and blocks queued room lines while preserving the escape recording and ending time display. No page errors.


## Ending caption cleanup
Removed the performance direction [chuckling] from the ending subtitle. Recording and cue timings unchanged. Standalone build passed; exported HTML checked to contain the spoken line and no [chuckling] caption.


## Pixel name prompt
Standalone build passed. Chromium verified the embedded original pixel font loads, heading uses it, input retains actual case/spaces, responsive form stays within a 390-pixel viewport, and Back returns to menu. Desktop and phone screenshots inspected: purple stepped frame and pixel lettering match the menu. No page errors.


## Readable dripping blood message and rear twig snaps
All 15 unit tests (including finite/centered/headroom checks for the new twig PCM effect) and production/standalone builds passed. Chromium verified a snap originates behind the current facing direction via negative displacement/forward dot product, schedules the next at 35–75 active seconds, and does not trigger during inspection. Rendered and inspected the handwritten dripping message with lamp output held at 35%: text stays legible and the surrounding wall stays dark. No page errors. Subjective rear localization was not evaluated on physical headphones or speakers.


## Cabinet voice without hammer
Standalone build and focused Chromium test passed. Two hammer strikes retain their animations and hit counts but do not trigger the voice. Two empty-hand interactions trigger the recording once, with half-second duplicate filtering and the original unreadable-speaker subtitle. Pending voice waits if the player carries the hammer. Updated hammer regression expectations and README. No page errors.


## Closet spider jumpscare and aftermath recording
All 15 unit tests (including PCM headroom/finite checks for the new loud sting), production build and final standalone build passed. Chromium verified the first hammer contact is safe, the second starts the spider and temporary input lock, recovery restores control, both uploaded-recording subtitle cues appear, and a third hit does not replay the scare. Screenshot inspected and framing adjusted to reveal eyes/fangs, with a second successful browser run. Final mesh refinement tapers the fangs to points. Existing empty-hand peace dialogue remains a separate trigger. No page errors. The test temporarily holds the close-up pose for screenshot capture, then restores normal timing.


## First-hit trigger, neutral download, name filter and stronger scare
The first hammer contact now triggers the one-time scare; neutral user-facing export is AKUMU-Updated.html. Added local profanity/slur screening with Unicode/leet/separator normalization and accessible validation feedback. All 18 unit tests passed; the final saturated sting also passed audio finite/headroom tests. Name-filter Chromium test verified invalid input stays on the form, correction clears the error, and a valid name starts the opening and personalizes the wall.

Lunge arrival shortened from 150 ms to 35 ms. Replaced the short sting with a dense 1.2-second bass/crash/screech, routed through a separate 1.45-gain channel and dedicated limiter rather than the normal SFX compressor. New source PCM RMS is 0.361 at 48 kHz, with normalized peak 0.72. Production and final standalone builds passed. Final Chromium run verified first-hit scare, its louder audio bus, recovery, both narration cues and no repeat on the next hit. A strict Web Audio floating-point gain assertion was changed to a tolerance before the passing run. No page errors.


## Uploaded scare SFX
Embedded the uploaded MP3 unchanged (source/asset SHA-256 hashes match). It is predecoded and plays once with the first-hit spider at original speed, through the dedicated scare channel. Full approximately ten-second playback finishes before aftermath narration; escape interrupts it. Final standalone build passed. Chromium verified uploaded-buffer duration, completion before narrator source start, both aftermath caption cues, recovery and no repeat on a later hit. On the heavily throttled preview, short test deadlines initially expired despite diagnostics confirming sound completion and narration start; extended deadlines and subtitle-history observation passed with no page errors.


## Closet destruction synchronized with scare
All 18 unit tests and standalone build passed. Chromium verified the intact closet starts unbroken, first hammer contact simultaneously triggers damage and the spider flag, intact front disappears, thirty fragments settle and remain on the floor, a hollow carcass stays visible, and repeated break requests do not reset/duplicate debris. Inspected rendered wreckage screenshot. The test advances debris simulation to settling for the final screenshot; normal gameplay animates it during active frames. No page errors. Updated both neutral HTML export and website-upload ZIP.


## Expanded name filter and Note 2 code / Note 3 instructions
All 20 unit tests and standalone build passed. New filter regressions reject the reported single-G spelling, repeated/missing-letter variants, separated forms, Unicode lookalikes and leetspeak while preserving common innocent names. Chromium verified the reported spelling and variants stay on the name form with an error, then a valid replacement starts normally.

Note 3 now explains E / LMC inspection, left mouse click, drag rotation, scroll zoom and touch controls. The hidden code moved to Note 2 only via CODE_NOTE_INDEX. Chromium verified Note 1/3 share the plain back texture, Note 2 uses its own code texture, and rendered both the updated Note 3 front and Note 2 reverse. Inspected both screenshots: all instructions and the code are readable. No page errors. Neutral HTML and website ZIP updated.


## Disable destroyed closet interaction
The closet target becomes ineligible when broken; the interaction handler also rejects stale/direct targets. Breakage clears queued peace dialogue and its playback path checks intact state. Old room captions are suppressed while scare SFX is active. Standalone build passed. Chromium verified shatter persists, broken target is disabled, and neither empty-hand nor hammer interaction changes counters or starts a new swing. The test waits for the original strike recovery before checking new input. No page errors.


## Hidden-key blackout
All 21 unit tests and standalone build passed. The new timing test confirms two seconds fully off, smooth 180 ms recovery, and one-shot triggering. Chromium used an actual aimed key interaction and recorded lamp/spill/bounce/bulb power during the outage, confirmed key collection and cleanup of pickup feedback, and verified recovery plus no retrigger. The room remains rendered behind the key overlay. Inspected dark/restored screenshots from the same viewpoint: near-black room detail during outage and normal warm illumination afterward; faint moonlight remains. For screenshot comparison the already-completed blackout lighting was temporarily held in the test only. No page errors.


## Unusual wall clock
All 24 unit tests and standalone build passed, including new visit-count/debounce/inactive-state tests and audio PCM checks for the tick effect. Chromium verified actual gaze raycasts mute clock gain, look-away restores ticking, no clock interaction target exists, a sustained stare counts only once, the third separate look plays the uploaded recording and exact (Narrator) caption, and a fourth does not replay it. Escape timer progressed while the clock's own seconds remained frozen during gaze. Inspected the clock screenshot in normal room lighting. No page errors.


## Viewport clock, revised outage order, increased ambience and connected bulb
All 24 unit tests and final standalone build passed. Clock browser regression verified silence with the clock partially clipped at the screen edge while its center is outside the viewport, plus the original three-visit narrator behavior and independent escape timer. Key browser regression recorded pickup text visibility and outage power: no triggered outage while text remains, a half-second flicker after text dismissal, then two seconds fully off and restoration. Geometry checks confirmed stem-to-socket and socket-to-bulb overlap; inspected connected-fixture screenshot. Rear-sound browser check confirmed its updated irregular 16–34-second gap, behind-player origin and inspection suppression. Normal lamp fault intervals are now 5–16 seconds. No page errors.


## Photograph narration after five seconds
Standalone build and focused Chromium test passed. An actual aimed photograph inspection shorter than five seconds stays silent and closing resets the wait. A subsequent continuous five-second inspection starts the uploaded recording with the exact (Narrator) caption. The trigger uses active real time and does not replay on a later five-second visit. No page errors. Neutral HTML and website package updated.

## Room 2 storage foundation — latest validation

The older sections above are historical snapshots; this section describes the current two-room extension.

- `npm test`: all 27 tests passed, including all previous 24 tests plus storage flood-fill clearance for six aisles/two cross-passages, shelf collision with large moves, original bedroom movement defaults and the doorway/slam/lock state machine.
- `npm run build:html`: passed, including parsing the embedded JavaScript. `npm run build`: passed; Vite retains its nonblocking bundle-size advisory for Three.js and embedded assets.
- `node tests/prototype.mjs`: passed. The full Room 1 route used actual note inspection/rotation, number-wheel clicks (including wraparound), code 1986, separate drawer opening, hammer drop/retrieval, barricade removal and key pickup before opening the original door and physically walking into storage. Name persisted, the door locked behind the player and no early ending appeared. No console or page errors.
- `node tests/storage-room.mjs`: passed in headless Chromium. Actual E/W input opened the original door, crossed the threshold, entered storage and triggered one slam followed by a distinct lock. The threshold itself did not close the door. Final audio scheduling placed the metallic lock approximately 0.55 s after the slam on the AudioContext clock (configured delay 0.5 s), independently of graphics-frame scheduling. The original door object's identity and player name survived; the ending stayed hidden and return movement was blocked. The high vent rejects a screwdriver and cannot finish while closed. A developer-only crowbar/exit hook reached the future ending; this does not constitute a playable vent puzzle.
- `node tests/touch.mjs`: passed with iPad-like Chromium emulation and Pointer Lock unavailable. Existing joystick/swipe, pause, note rotation, pinch/buttons, physical number-wheel taps, drawer opening and hammer pickup/drop passed. Touch INTERACT opened the bedroom door; joystick movement entered Room 2, locking completed, name persisted, and storage swipe-look/pause worked. Landscape/portrait screenshots were captured. A separate desktop context refused mouse capture and retained WASD/drag look. No console or page errors.

Inspected player-view storage screenshots showing the entrance door, aisle/cross-passage lighting, tall shelving, far high grille and portrait touch UI. Walking routes remain readable between deep shelf shadows. Room 2 uses conservative provisional lighting rather than new scripted scares.

The final focused storage sample reported 20 render calls, 2,340 triangles, 58 allocated textures and 20 static storage batches. The full-puzzle storage entry view reported 20 calls, 6,890 triangles and 62 textures after all note/lock inspections. These counts are view-specific; they are not FPS measurements or proof of performance on a physical school computer. The open-door two-room view is more expensive, so storage shadows are cached during opening and the bedroom is hidden after the slam. A parallel software-rendering run timed out during door opening and an initial touch run timed out during page load; browser checks were rerun sequentially with longer timeouts. Reduced test pixel density is used by the full desktop/storage suites to keep software WebGL practical, without changing game rendering defaults.

Not verified on physical iPad/Safari or a school-computer GPU. Every prior optional Room 1 voice/scare browser suite was not rerun for this extension; those implementations and assets are preserved, with bedroom behavior gated to Room 1. Room 2 crowbar acquisition, reaching the vent and player-driven vent completion remain intentionally unimplemented. Future lighting/story/scare decisions remain with the project owners. See `ROOM2-REPORT.md` for all files and integration details.


## Direct Room 2 testing start
All 27 unit checks, standalone build and production build passed. `node tests/storage-start.mjs` passed desktop direct entry and movement, touch-tap direct entry with visible controls, preserved name, fresh timer and already-locked entrance without wake-up narration. Cancelling the testing name form and choosing normal PLAY still completed waking into Room 1. No direct-start page errors. These checks use Chromium emulation, not a physical iPad.


## Room 2 personalized envelope
Standalone and production builds passed. The final `node tests/storage-envelope.mjs` passed in desktop and touch-emulated Chromium: actual E/INTERACT aims at the shelf envelope, From/To preserve the entered name, OPEN ENVELOPE reveals the physical letter, the message matches the user's latest four sentences exactly, and closing/reopening retains readable letter state. No page errors. Reviewed the final bloody-handwriting screenshot for legibility and clipping. Room 1 was not redesigned; its blood-letter glyph table is merely exported for reuse.


## First letter narrator recording
Both builds passed. The uploaded MP3 is copied byte-for-byte unchanged (6.922 seconds decoded). `node tests/letter-voice.mjs` passed desktop and touch-emulated first reading: sealed envelope stays silent, uploaded buffer starts at playbackRate 1, both exact (Narrator) captions appear, another active narrator line delays playback, and closing/reopening cannot replay it. The final desktop rerun also verified and visually reviewed letter-only captions above the paper, preserving the last handwritten sentence. No page errors. Voice scheduling uses the existing AudioContext queue, ducking and pause/resume system. Physical device audio has not been tested.


## Fragile Room 1 closet front
At the user's explicit request, only the closet's intact visual front was revised: separated/chipped slats, exposed fibres, branching cracks and split retaining boards. Standalone and production builds passed. Final Chromium `tests/closet-damage.mjs` passed first-hammer-contact destruction and spider trigger, hidden intact front, all 30 persistent settled fragments, idempotent breakage and blocked interactions after destruction. Reviewed the final intact-front screenshot under the existing bedroom lighting. The detail is merged by material to avoid a draw call for each crack. No page errors; collision footprint, audio and trigger logic are unchanged.


## Four-second scare SFX and stronger window boards
Both builds passed. The spider browser regression passed with exactly four seconds of uploaded SFX playback, unchanged scare gain, recovery, following narrator captions and no repeat. Playback is trimmed rather than sped up and fades over its final 80 ms. The window browser regression passed actual hammer removal of the sturdier-looking barricade, six persistent fallen boards, a resting dropped hammer and collection of the revealed key. Reviewed the reinforced-window screenshot under unchanged room lighting. No page errors.


## Deeper blood-addressed envelope; bed/closet repetition thresholds
Both builds passed. Envelope regression passed desktop/touch inspection, opening and reopening at the deeper third-aisle shelf. Reviewed the new shelf view and envelope address: names use blood-red handwritten strokes/drips and remain readable. The shelf is beyond the first cross-passage and behind the entrance-facing shelf banks. Bed browser regression verified inspection one stays silent, inspection two plays the existing recording/caption, and inspection three does not replay it. Closet regression verified hammer hits do not count toward the peace line, empty-hand interactions one through six stay silent, interaction seven plays once, rapid duplicates retain the existing debounce and the unreadable-speaker caption remains correct. No page errors. Hammer scare/destruction guards and the four-second scare SFX are unchanged.


## Room 2 1980s computer — Stage 1 only
All 30 unit checks and both standalone/production builds passed. Three new unit checks cover 200 generated sequences with complete A–I key/strict numeric validation, Stage 1-only completion, supported three-box placement/reset, player overlap rejection and flood-fill reachability through all six aisles with the three floor crates.

`node tests/computer-stage.mjs` passed in desktop and touch-emulated Chromium. Actual E/INTERACT approached the physical computer and clue. Power-on exposed exactly four stages with 2–4 disabled. Incorrect input stayed incomplete; the correct translated digits completed Stage 1. Closing/reopening preserved sequence and completion. Only Box 1 gained its glow; its body remained closed, its reserved wrench hidden and no open action was available. The box UI stacked all three crates into one supported column, then reset them to floor positions. The vent stayed closed and no ending appeared. No page errors. The initial browser attempt used a camera angle aimed through the upper boxes while targeting the bottom one; the fixture was moved back to an unobstructed reachable angle and the complete checks passed. An initial layout clearance test caught the crates too far into aisle 6; their final safe positions sit against the right wall and the navigation test passes.

Existing `tests/prototype.mjs` passed the complete Room 1 note/code/drawer/hammer/window/key route and original physical doorway into locked Room 2, retaining the name and avoiding an early ending. Existing `tests/storage-envelope.mjs` passed desktop/touch envelope inspection, opening and rereading. Both reported no page errors (and the full prototype no console errors). All older optional voice/scare browser suites were not rerun for this update; their code/triggers/assets are unchanged.

Reviewed screenshots of the physical beige CRT/keyboard in its cleared shelf bay, physical key sheet, four-stage completed menu and Box 1's glow within the supported three-box stack. Only one bay's contents/backing were cleared; rack supports/positions, room architecture and lighting remain unchanged. No new light, narrator line, scare, later-stage puzzle, crate opening, usable wrench, climbing or vent escape interaction was added. Existing future vent developer-hook metadata now names the newly specified wrench; normal computer/box gameplay never calls the hook. Existing ending code/text remain unchanged.

Hardware performance and physical iPad/Safari were not tested. Browser checks use software Chromium and reduced test pixel density; game render defaults are unchanged. Vite retains nonblocking large-bundle advisories. See `COMPUTER-STAGE1-REPORT.md` for files, placements, behavior and deliberately unfinished mechanics.


## Embedded WAKE UP fix and readable Room 2 shelves
Reproduced the reported no-op WAKE UP behavior in an iframe permitting scripts but omitting allow-forms: Chrome blocked native submission and the name dialog remained visible. Added direct click/Enter handlers (preventing native submission) to name entry and computer answer entry. `tests/embedded-start.mjs` passed desktop click, touch and Enter in the same restricted iframe, retaining blank/profanity rejection, normal Room 1 wake-up, direct Room 2 start, keyboard movement with pointer lock denied and computer answers via Enter/button. No blocked-form errors or uncaught page errors remained. This was a simulated embedded browser environment, not a live ChatGPT app session.

Both builds passed. `tests/storage-lighting.mjs` captured front and rear rows in all six aisles. The first visual review found front-right/rear-left shelf pockets still too dark; final neutral shelf fills were repositioned there and ground/indirect bounce increased. Reviewed the final 12-view contact sheet and the previously darkest individual views. Shelf contents and walking routes are now more readable while wood, recesses and ceiling-light shadows retain depth. Existing ceiling-light power and two shadow casters remain unchanged; four low-cost unshadowed fills are active after Room 2 entry. Final representative view reported 50 draw calls; this is not a hardware FPS benchmark. Room 1 light settings, puzzle state and narrator logic are unchanged.


## Faster Room 2 walking
Room 2 keyboard/touch target speed is now 1.35 m/s, while Room 1 stays at 1.05 m/s. The five existing movement/collision tests and both builds passed. No new browser playthrough was run for this small speed adjustment. The translation clue remains at its original location (7.285, 1.4, 8.75).


## Glowing shelf crates with hammer-style carrying
At the user's request, the three designated crates now start in separate shelf bays, and the old box movement/reset interface is removed. Only Box 1 can be picked up, and only after Stage 1 makes it glow. Boxes 2 and 3 stay fixed. All 30 unit checks passed, including revised shelf/gating tests, repeated recoverable floor placement, rejection of walls/player overlap/out-of-bounds placement, a safe side placement when facing shelving and generic supported stacking geometry for future rewards. Production does not enable later boxes/stages.

Both builds passed. Updated `tests/computer-stage.mjs` passed on desktop and touch: initial shelf positions and no pre-solve pickup; physical computer/clue, incorrect/correct answer, persistent Stage 1 completion and locked later stages; glowing Box 1 pickup, visible camera-relative carrying, desktop walking while carrying, G/touch DROP to stable floor and re-pickup. Boxes 2 and 3 remain unchanged and cannot be picked up. Box 1 remains closed, wrench hidden, vent closed and no ending triggered. Reviewed the shelf and carried-box screenshots. No page errors.

The full existing `tests/prototype.mjs` passed again, including actual Room 1 hammer pickup/G-drop/recovery, note/code/drawer/window/key route and original doorway into Room 2. No page/console errors. Room 1 speed, Room 2's faster speed, embedded-start fix, lighting and translation-page location remain unchanged. Physical-device testing was not performed.


## Through-wall glowing-box outline and numbered vent floor guides
Both builds and final `tests/box-guides.mjs` passed. The outline is hidden before Stage 1; solving through the actual computer UI enables it only for Box 1. A screenshot from behind an intervening shelf panel confirms visible green edges through the obstruction. Normal pickup range, closed-box state and closed vent remain intact. Three transparent, worn BOX 1/2/3 markings are placed on the floor beneath the high shaft. They have ordinary depth testing, do not occlude interactions and add no colliders, unlocking or placement automation. Reviewed the final overview and closer floor view after orienting the numbers toward the approach. No page errors.


## Staircase guides and Room 2 crate step-up
Floor guides now form a route toward the shaft: Box 1 first, then Box 3 on Box 2 at the second footprint. Added Room 2-only `src/crate-walking.js` and integrated its supported step-up/fall state in `src/main.js`; Room 1 retains its original movement function and fixed eye height. Walking onto a placed crate raises the camera smoothly; stepping off or removing support returns it safely to floor height. Static wall/rack collision remains.

Both builds and all 33 unit checks passed. New unit tests validate the complete planned two-level staircase as a synthetic geometry fixture, reject climbing the higher column directly from the floor, verify safe descent/support removal and retain wall limits. This fixture does not unlock real later-stage crates. Desktop `tests/crate-steps.mjs` and touch `--touch` passed actual glowing Box 1 pickup, G/DROP at the first guide, W/joystick step-up and backward step-down. Boxes 2 and 3 remain unmovable; the vent stays closed and no ending triggers. `tests/box-guides.mjs` also passed the Stage 1 outline and revised shared 2+3 guide checks. Reviewed the unobstructed floor guide image and actual first-step screenshot. No page errors. The full staircase remains unavailable in normal play until future tasks unlock Boxes 2 and 3.


## Stage 2 inventory puzzle and permanent box rewards
Both standalone and production builds passed. All 37 unit checks passed, including fixed stock/IDs, 24 unique shelf-unit labels, Stage 2 answer normalization/gating, permanent Box 1/2 unlocks and lifting/restacking without stale supports.

`tests/inventory-stage-two.mjs` passed desktop and touch-emulated Chromium: physical reference and shelf inspection, exact A/B/C counts, Stage 1 completion, wrong Stage 2 answer rejection, correct 38C acceptance, persistent completion, both box glows, actual two-box carry/stack/lift/restack/reposition and locked Box 3/closed vent/hidden ending. Box 1 stayed closed and its wrench inaccessible. `tests/inventory-signs.mjs` passed; screenshots of all six aisle signs, shelf A, inspected radios/suitcases, reference sheet and completed terminal were reviewed.

Existing Stage 1 touch regression passed on retry with a 120-second action timeout after an earlier 30-second software-rendering timeout. The full existing Room 1 prototype route and desktop/touch envelope regressions passed. Embedded touch startup/name validation and Stage 1/2 answer entry passed in an iframe without allow-forms or pointer-lock permission. Physical iPad/Safari and school-computer GPU performance were not tested. See STAGE2-REPORT.md for placements, changed files and intentional limitations.


## Stage 3 password recovery
Both standalone and production builds passed; all 42 unit checks passed. Five new state/stacking checks verify exact letter order/frequencies, independent duplicate tiles, single-use selection, Backspace/Clear, incomplete/wrong/correct validation, Stage 2 gating, permanent three-box rewards and three-box stack/unstack/recovery. Existing Stage 1/2 validation tests remain passing. Vite retains its nonblocking large-bundle advisory.

The Stage 3 desktop browser regression passed actual UI completion of Stages 1 and 2 (including incorrect answers), Stage 3 locking/unlocking, the exact 13-tile pool, 2+2+9 answer groups, repeated-tile identity, disabled reuse/early Enter, Backspace/Clear, incorrect/correct password, partial-input and completion persistence, all three glows/outlines and actual three-box pickup/drop/stack/unstack/restack. Box 1 stayed closed, the reserved wrench hidden, Stage 4 disabled and the vent/ending inactive. Screenshots of the empty and completed CRT and the stack were inspected.

`tests/embedded-start.mjs --touch-only` passed name validation/startup, Stage 1/2 answer submissions and Stage 3 tile completion inside an iframe without allow-forms or pointer-lock permission. No blocked-form or uncaught page errors. This simulates restricted embedding; it is not a live ChatGPT-app or physical iPad/Safari test.

The unchanged full Room 1 playthrough and optional voice/scare browser suites were not rerun. No Room 1, envelope, room architecture/lighting, narrator, movement, transition, ending or stacking-runtime implementation was edited. See STAGE3-REPORT.md for the complete scoped report.

The complete `tests/password-recovery.mjs` run also passed in touch-emulated Chromium: all password controls/validation/persistence, prior stages and actual three-box pickup/drop/stack/unstack/restack. Reviewed the 390px portrait screenshot; word slots fit without horizontal overflow. Both desktop/touch runs reported no uncaught page errors. All three glows and permanent permissions remained active, with Stage 4 disabled, Box 1 sealed, wrench hidden and vent/ending inactive.


## Final Room 2 letter, boxes, wrench and ventilation escape
All 44 unit checks passed. The two new state checks cover Stage 3-only opening, independent wrench collection, no Stage 4 prerequisite, permanent earlier rewards and rejection of vent access without wrench/elevation/proximity/all three placed crates. Both final standalone and production builds passed; Vite retains its nonblocking bundle-size advisory.

The full desktop `tests/storage-escape.mjs` route passed actual letter inspection/front-text comparison, original voice trigger, flipping both ways and reopening; solving Stages 1/2/3 through the UI; closed-box movement before Stage 3; opening each box without pickup and before reading Stage 4; opened-box carry/restack; actual W/S stair climb without wrench followed by rejection; separate wrench collection without carrying the box; exact Stage 4 hint/no input; floor-level rejection even with the wrench; actual climb/open grille/confirm escape; and the exact fade-to-black ending without timer/narrator text. No uncaught page errors. Reviewed the letter reverse, CRT hint, reached vent and black-screen ending screenshots.

Visual review caught lids obscuring the tool, including a neighboring folded lid overlapping Box 1 in the stair arrangement. Final lids fold against each box's exterior side instead, without changing collision/support footprints. The tool has clearer metal shading and a generous separate cavity target; the wooden body remains the carry target. A targeted angle preview verified selection at three normal downward angles. Earlier exploratory runs timed out on the original narrow target; the precise camera test fixture also now waits for targeting after a teleport and lets movement inertia settle. One preview initially exceeded a 30-second click timeout during software rendering; its longer-timeout retry passed.

This update did not rerun the full unchanged Room 1 route or all optional voice/scare browser suites. The PC-stage UI route covers existing Stage 1/2/3 solutions; their strict wrong-answer/state checks also pass in the unit suite. No physical iPad/Safari or hardware GPU performance claim is made. See FINAL-ESCAPE-REPORT.md for scope and controls.

The full UI route also passed in touch-emulated Chromium, including the original letter voice trigger, Stage 1–4 route, opening without pickup, restacking, no-wrench/floor rejection, actual joystick climb and the exact ending. A further final-geometry fixture caught an opened-body targeting issue after collecting the tool: aiming through the empty cavity could put its bottom beyond the old interaction range. The final implementation preserves the original box pickup volume and uses a separate higher cavity target for the wrench, keeping opening/collection/carrying as distinct actions.

Final `tests/escape-geometry.mjs` passed desktop and touch-emulated Chromium against the exported geometry: wrench selection at three downward angles with the completed stair arrangement, separate left-click/touch tool collection, empty Boxes 2/3, actual opened Box 1 pickup/drop with the wrench retained, real keyboard/joystick stair climb, grille opening and final ending. No uncaught page errors. Reviewed the final unobscured wrench-in-box screenshot; lids no longer overlap the neighboring opening. An independent literal comparison also verified the original letter front exactly. The extra fixture uses model calls to prepare the already-tested stages/stack, then exercises actual pickup/drop/movement/vent controls; the full UI route separately solves the PC stages and constructs the stairs through interactions.


## Stage 3 hint wording
Changed the hint to “The letter...”, updated the existing browser expectation and rebuilt both HTML/production outputs successfully. Verified the generated HTML contains the new hint and no old hint. Gameplay browser suites were not rerun for this text-only change.


## Stage 2 five-minute assistance
Both standalone and production builds passed. All 48 unit checks passed, including four new checks for exactly 300 seconds, Stage 1-triggered/idempotent start, early cancellation, late cancellation of queued speech without revoking HELP, preservation of one-shot state and the exact caption/decoded-duration parameters. The supplied 104,205-byte MP3 was verified byte-for-byte against src/assets/attention-assistance.mp3. Production duration remains ASSISTANCE_DELAY=300; no shortened timer was shipped.

Desktop and touch-emulated Chromium late-assistance browser scenarios passed with a simulated clock at 299.999/300 seconds. The actual puzzle UI unlocked Stage 2, closed/reopened the PC without restarting the clock and activated help while exploring. An existing recording held the voice channel at expiry; the supplied decoded MP3 then played once at playbackRate=1 with a running audio context and positive voice gain. The exact (PC) caption was observed in the existing subtitle element and disappeared after playback; its audio-clock span matched the decoded buffer duration. The HELP screen matched all seven instructions and contained no solution/item identity/ID. BACK preserved typed input; HELP survived PC reopen and a late solve without replay. 38C still completed Stage 2, Box 2 still glowed and was movable, and Stage 3 remained available with its unchanged “The letter...” hint and no HELP button. No uncaught page errors. Reviewed the desktop HELP screenshot for readability and absence of answer disclosure.

Browser timing uses a test-injected clock rather than a five-minute wall-time wait or a modified production duration. Headless audio-source scheduling/decoding was verified; physical iPad/Safari, loudspeaker output and school-computer GPU performance were not tested. The unchanged full Room 1/Room 2 escape and optional narrator/scare browser suites were not rerun. See STAGE2-ASSISTANCE-REPORT.md for files and behavior.

The separate early-completion browser scenario also passed: solving at simulated 299.999 seconds permanently suppressed HELP, the announcement and its caption even after advancing to 900 seconds and reopening the PC. Box 2 and Stage 3 rewards remained intact. All three browser scenarios exited successfully.


## Delayed Room 2 startup chime
Both standalone/production builds and all existing 48 unit checks passed. The supplied startup MP3 was copied byte-for-byte to src/assets/pc-startup.mp3 and decoded through the existing asset loader. New tests/pc-startup.mjs passed desktop doorway entry and touch-emulated direct Room 2 start: no cue in Room 1, a minimum two-second entry delay, original decoded clip at playbackRate=1, small exact (PC Startup) caption during playback only, retained doorway narrator source, and no replay after completion or PC power/open/close. Observed software-rendered start delays were 2.70s and 3.44s (the two-second deadline is serviced by rendering frames). No uncaught page errors. Reviewed the final visible-room/caption screenshot.

The desktop fixture pre-unlocks the door and walks across the existing room-entry trigger; it does not replay all Room 1 puzzles. An initial incomplete fixture hid the storage root and was stopped/corrected before the final successful run. The direct touch test uses the existing testing entry normally. Physical iPad/Safari and loudspeaker playback were not tested. The sound uses the SFX bus and a small independent sound-caption label so it can coexist with the existing doorway narration and its subtitles; it does not change PC power/puzzles or the five-minute assistance system.


## Positional PC pip beacon
Added src/pc-beacon.js and integrated it through the existing SFX bus/listener in src/audio.js and src/main.js. A quiet 0.11-second monitor pip repeats every 3.2 seconds after the startup recording finishes. The first PC interface interaction stops and disconnects the loop permanently, including when the cue has not started yet. Letter/item inspections do not consume it. Existing startup recording/caption, narration, Stage 2 assistance and puzzle logic are unchanged.

Both final HTML/production builds passed; all 48 existing unit checks passed. tests/pc-beacon.mjs passed actual offline stereo rendering of the generated beep through the production HRTF panner: a left source produced channel energies [26.279, 2.408], and a right source reversed them. Desktop/touch-emulated Chromium verified the loop period, actual monitor world position/height, distance falloff configuration, camera listener movement, first E/touch PC interaction stopping/disconnecting the source, and no restart after PC close or later enabled updates. No uncaught page errors. Stereo samples were measured rather than physically auditioned; physical headphones/iPad/Safari were not tested. No unrelated full gameplay suite was rerun.


## Stage 2 WELCOME BACK recognition event
Confirmed the baseline standalone HTML matched the last delivered AKUMU-Room2.html byte-for-byte. Only the recognition UI, its scoped flicker and temporary narration-silence integration were added to the existing runtime. Both final HTML/production builds passed; all 50 unit checks passed, including two new checks for narrator audio/caption suppression, refusal of new narration during the event and exact/idempotent voice-volume restoration.

New tests/welcome-back.mjs passed desktop automatic return and 390px portrait touch close-mid-event scenarios. It verified no trigger on wrong answers/open/revisit; exact entered names; immediate Box 2 glow/carry and Stage 3 availability; an already-playing real narrator recording muted; no narrator subtitle/audio-gain leaks across event frames; new narration refused; one quiet distortion; approximately 4.18s display with end flicker; normal menu/audio restoration; no duplicate on reopen/re-submit; and successful original Stage 3/4 progression. The mobile scenario closed during the event, reopened, selected Stage 3 and retained partial input after waiting beyond the cancelled timer. Reviewed both recognition screenshots for font/colors/name/readability. The initial test used strict equality against 1.55 for an AudioParam represented as float32 (1.5499999523); the assertion was corrected to a floating-point tolerance, with no runtime change needed.

Existing tests/storage-escape.mjs --desktop-only also passed the complete Room 2 UI route: original envelope/front/voice/flip/reopen, Stages 1–4, Stage 2 recognition return, box opening distinct from pickup, open-box carry/restack, separate wrench collection, real stair climb, no-wrench/floor guards, vent opening and exact black-screen ending. No uncaught page errors in either browser suite. Existing PC route expectations were updated to wait for the new display; all optional browser suites, the five-minute assistance browser suite and the full unchanged Room 1 route were not rerun. Their models remain covered by the 50 passing checks and their runtime implementations were not edited.

Physical iPad/Safari and hardware loudspeaker performance were not tested. No new asset/dependency, puzzle, narrator line or pacing/balance retune was added; no 15-minute human playtime benchmark is claimed.


## NORMAL / DEMO and The Observation Room
Both final standalone/production builds passed. All 55 unit checks passed: 50 existing checks plus five new observation-state checks covering exactly three fixed tapes, one carried tape, seven-second viewing/replay, archive completeness/wrong/correct ordering, rearrangement, safe gravity/drop/recovery, four one-shot events, permanent solved state, final caption silence, exit-once and reset. Existing Room 1/puzzle and normal storage/PC-model runtime files remain byte-identical to the pre-DEMO baseline.

Final tests/observation-room.mjs passed on desktop and touch-emulated Chromium. PLAY → DEMO → existing name entry started the original Room 1; visual capture left the actual drawer, boards and hammer unchanged. The fixture pre-unlocks the already-tested bedroom door and crosses the real entry trigger with W/joystick. Each of three fixed tapes was picked up, dropped under gravity, recovered, inserted, played/viewed, ejected and placed; replay did not double-count a tape. The incorrect physical order displayed SEQUENCE INVALID without resetting the slots. Removing/rearranging tapes and correct verification permanently unlocked the exit. Four event signals occurred once, all new specified captions appeared, and final narration/captions were suppressed.

The final monitor's material samples an actual 512×320 room render target from a fixed upper-corner camera. GPU pixel hashes changed after removing a cassette from a slot and dropping it in the room; the live render counter advanced. Actual room lighting/props are shared with the view, and no player model/figure/silhouette exists. First-person held props and the monitor sampling plane are excluded only during the CCTV pass to avoid floating-player props/recursive framebuffer feedback. The physical exit was opened and crossed with W/joystick, then the existing black fade and TO BE CONTINUED... appeared. No normal-storage transition occurred. Desktop return-to-title/restart cleared the demo; a second DEMO began empty and a subsequent NORMAL began with no Observation Room/state. No page or WebGL console errors.

NORMAL tests/prototype.mjs passed the complete bedroom route: notes/second-note reverse, individual code wheels/1986, drawer/hammer pickup/drop/recovery, physical plank fall, hidden key and original physical storage-room entry. It reported the same representative 110 calls / 27,924 triangles / 31 textures as before. Existing tests/storage-escape.mjs --desktop-only passed the original normal letter/voice/flip, PC Stages 1–4 and recognition return, box opening versus pickup, carrying/restacking, separate wrench collection, real stair climb, no-wrench/floor guards, grille and exact ending. No page/console errors. Optional older voice/scare/assistance browser suites were not all rerun; their existing model checks pass. PLAY fixtures now explicitly choose NORMAL as required by the new mode picker. The normal ROOM 2 / TEST shortcut was exercised by the storage escape regression.

Reviewed actual bedroom stills (including a raised camera showing the hammer head), office overview, VHS playback, invalid feedback, live empty-room feed, pixel mode picker and ending screenshots. Initial office preview reported 23 main-view draw calls; this is not a hardware FPS benchmark. Preview corrections included cassette support heights, readable labels/left-to-right 01–03, the entrance header and placing VERIFY near the deck so middle-monitor feedback is in view. Dark inactive CRTs avoid repeated texture uploads; the 512×320 live pass is capped at 10 Hz. The voice mute now sets intrinsic gain as well as automation, handling idle Web Audio graphs; existing mute/restore tests and normal escape passed. A final offline display smoke also exercised the added subtle VHS tracking-band distortion.

Direct file:// launch testing was blocked by managed Chromium policy (ERR_BLOCKED_BY_ADMINISTRATOR). The fallback test loaded the built standalone document via an intercepted request in an offline context, with no server or external asset requests; mode/name/original bedroom, all three generated bedroom stills, actual Observation entry and animated VHS drawing passed. Both builds remain self-contained; no CDN/dependency or external video asset was added.

The three new narrator lines are intentionally caption-only until the supplied recordings arrive. Physical iPad/Safari, hardware speaker output/FPS and a human 5/10-minute pacing playtest were not run. Pacing remains a target, not a forced timer; verification is not gated by watching all recordings. All Room 1 and NORMAL puzzle difficulty/movement remain unchanged. See DEMO-REPORT.md for runtime files and launch/reset details.

## DEMO ending invitation update
The new isolated invitation controller has three passing unit checks for black/title-plus-three-second timing, exactly-once playback, real audio completion gating, suspended-audio retry and reset. All 58 unit checks and both standalone/production builds pass. The original room.js, puzzle.js, storage-room.js and computer-stage.js remain byte-identical to the pre-DEMO baseline; this update does not alter those systems.

The supplied final narrator recording is pending. The built HTML currently shows the requested (Narrator) invitation as a ten-second caption-only placeholder. The audio-ready path uses the existing narrator bus; its real buffer completion controls the CTA when supplied. A synthetic silent test buffer exercises routing only and is not shipped as a replacement voice.

Desktop and Chromium touch ending checks passed: live feed rejects narration; title is visible before the three-second delay; the invitation occurs once despite repeated ending calls; caption fallback and an actual short silent AudioBuffer both gate the button correctly. PLAY FULL VERSION reloads into empty NORMAL name entry and then starts original Room 1. Triggering the NORMAL ending does not show this invitation or button. No page errors were recorded. The silent buffer tests Web Audio completion, not the pending real narrator performance. Reviewed the black/title/CTA screenshot. Original complete bedroom/storage suites were not rerun for this ending-only update; their unchanged modules were compared with the baseline. Physical iPad/Safari and the unavailable final recording remain untested.

Final standalone touch rerun also passed after the bus-muting refinement, including explicit zero SFX/ambience gains during the audio-hook ending and the NORMAL name/start/ending regression.

## DEMO Observation Room SFX / exit clarity update
All 58 existing unit checks passed, including the audio suite which now checks finite, audible, centered samples and sub-full-scale peaks for the five new sounds at 44.1/48 kHz. Both HTML and production builds passed. Original Room 1, puzzle, storage Room 2 and PC puzzle modules were compared byte-for-byte to the saved baseline and are unchanged. The targeted observation-sfx.mjs browser fixture pre-unlocks the bedroom door, uses its real room-entry trigger, then exercises the archive model and real exit interaction. It does not constitute a full human audio/pacing test.

Desktop and Chromium touch checks passed for distinct spatial cassette/error/latch/hinge sounds, VCR motor while playing, equipment tone before the live feed, tone/motor fading to silence in the live feed, final narrator suppression, locked/unlocked signs, the green status light, and real E/touch door opening. Initial testing caught legacy panner parameter observation and the global hidden-HUD style; both were corrected with modern position parameters and a DEMO-only visible-prompt rule. Existing NORMAL audio samples and room/puzzle modules remain unchanged. Physical iPad/Safari and hardware speaker listening were not tested.

Final desktop and touch rerun passed with explicit prompt visibility assertions and the real door interactions. Reviewed the final desktop screenshot showing EXIT UNLOCKED, green status light and the visible E / LEFT CLICK opening instruction. All pre-existing synthesized sounds were additionally compared sample-for-sample at 44.1 kHz and remained identical.

## Escape closes inspection and resumes mouse look
Changed only the inspecting branch of the Escape handler to prevent default and use the existing close-and-recapture path. Both builds passed. tests/inspect-escape.mjs passed in Chromium with real pointer lock: twice opening a note, Escape returns to unpaused play with canvas capture and verified mouse-look rotation, without a pause overlay. A subsequent separate Escape in gameplay still pauses and releases capture. No page errors. Other browser/physical device testing was not performed for this change.


## AKUMU v2.0 overhaul
60 unit checks, both builds, the 26 queued browser suites, desktop/touch UI/model review, the full 40,894,464-byte texture equality comparison, and final optimized offline smoke passed in their documented scopes. 67 existing files and 65 protected functions remain byte-identical. See V2-REGRESSION.md for fixture changes and UNVERIFIED native flicker/platform conditions, and V2-PERFORMANCE.md for actual final diagnostics without a claimed universal FPS gain.
