# AKUMU — Room 2 implementation report

## Scope and Room 1 preservation

Extended the existing game. Room 1 artwork, furniture, lamp, lighting settings, notes, code 1986, key, closet scare, recordings, name filter, waking sequence, menu and input behavior were not redesigned. The progression change is the existing bedroom door opening into storage rather than ending the game. Shared scene grouping, collision-bound selection, active-room routing and hammer placement were adapted only to support that transition and exploration. The same door leaf and frame are retained as shared objects; matching reverse-side details appear when the exit unlocks.

## Implemented environment

- Approximately 11 × 9 × 3.8 m windowless abandoned hotel storage room.
- Level faded concrete with thin cracks, staining and roughness; damaged grey-beige plaster with localized faded brick exposure; aged plaster ceiling.
- Five banks of 3.2 m wood/steel shelving create six main aisles, varying from 0.95 to 1.4 m. Two cross-passages, a clear entrance apron and a widened far vent area connect the routes.
- Medium shelf clutter: cartons, suitcases, folded linen, old lamps, covered belongings and framed pictures. Contents remain inside shelf footprints.
- Steady neutral lighting with two shadow-casting spotlights and two small unshadowed local fills. No new Room 2 flicker/scare sequence, enemy, chase or dialogue.
- Existing movement, mouse/drag fallback, E/left-click interaction, touch controls, pause and hammer carrying/drop support extend to storage. Name and timer carry through.

## Transition and ending

The original key unlocks the original door. Players walk through it physically. The closing trigger waits until the camera center has cleared z=2.72 m, beyond the full doorway and player collision radius. The same leaf closes in 0.26 s, plays a heavy slam, then triggers a distinct metallic lock after a minimum 0.5 active seconds. The door stays locked and storage wall collision prevents return. The old bedroom is hidden after closure. Pausing freezes progression.

The existing approved “One door down…” recording accompanies the transition, without freezing the timer or ending play. No new narrator line was added. Final fade, TO BE CONTINUED and the combined escape time are reserved for future vent completion.

## Vent and deliberate placeholders

A high metal ventilation grille and shallow duct are physically built near the opposite corner. The modular API accepts a crowbar and rejects a screwdriver. An exit callback invokes the retained ending only after a future vent-opening/escape action.

**Room 2 is not yet a complete solvable escape puzzle.** There is no crowbar acquisition, reach/climb solution, player vent prompt or invented puzzle chain. Tests can call developer hooks to validate the future ending; these hooks are exposed only with `?debug` and are not normal gameplay. No unapproved trolley, crate or combination puzzle was added.

## Files changed for this extension

New runtime files:

- `src/storage-layout.js`: dimensions, six-aisle/rack layout, collision bounds, doorway passage and vent coordinates.
- `src/storage-materials.js`: cached procedural PBR storage surfaces.
- `src/storage-room.js`: architecture, shelving/clutter, material batching, lighting, matching door reverse and vent integration hooks.
- `src/room-progression.js`: threshold, one-way closure, slam and delayed lock state machine.

Modified runtime files:

- `src/main.js`: room roots, preserved shared door/frame, room-specific movement/interaction/audio and future ending routing.
- `src/physics.js`: optional active-room bounds; existing bedroom defaults retained.
- `src/room.js`: preserve the frame as a shareable object instead of merging it into static bedroom geometry.
- `src/puzzle.js`: route doorway completion into storage, retain hammer across active spaces and stop bedroom-only updates after entry.
- `src/audio.js`, `src/audio-synthesis.js`: separate slam/lock, concrete footsteps and reuse of the existing passage narration.

Verification/build documentation:

- New `tests/storage.test.js`, `tests/storage-room.mjs`.
- Updated `tests/prototype.mjs`, `tests/touch.mjs`, `tests/name-timer.mjs`, `tests/escape-voice.mjs`, `tests/drawer-repeat-voice.mjs`, `package.json`.
- Updated `README.md`, `VALIDATION.md`; this report.
- Regenerated standalone HTML, Vite build and user download packages.

## Verification

All 27 unit tests, both builds, the full Room 1 browser puzzle/entry regression and touch/fallback regression passed. See the latest Room 2 section of `VALIDATION.md` for detailed executed results. Unit tests verify connected walking clearance in all six aisles and both cross-passages, large-movement shelf collision, original bedroom movement defaults, safe doorway clearance and one-time slam/lock timing. Browser tests distinguish actual user input from deliberate developer-hook checks.

## Performance and limits

Static storage meshes are merged into 20 material/shadow batches. The final focused storage sample measured 20 render calls, 2,340 triangles and 58 allocated textures. The full-puzzle entry view measured 20 calls, 6,890 triangles and 62 textures after inspections. These are view-specific counts, not maximum scene cost or a device FPS guarantee. The open doorway temporarily exposes both rooms and their lights; storage shadow maps are cached during this interval. The bedroom stops rendering after closure. Procedural textures are cached and pixel ratio is capped.

Vite reports nonblocking large-chunk advisories because Three.js and embedded audio/art are bundled. Software WebGL in the cloud is slow, particularly during door animation, so browser tests allow longer timeouts and run sequentially. The metallic lock is scheduled on the AudioContext clock 0.5 s after the slam so graphics stalls do not stretch the sound gap; the logical lock state follows active progression. AudioContext suspension preserves pause behavior. No physical iPad/Safari or school-computer GPU benchmark was available.

## Decisions for future work

The environment foundation needs no further approval to use. Project-owner choices remain for crowbar acquisition, reaching/entering the vent, final Room 2 lighting and any future story/horror events. Those mechanics are intentionally unimplemented rather than silently invented.


## Direct testing entry
Added a small ROOM 2 / TEST menu button (`index.html`, `src/style.css`). `src/main.js` preserves name validation and normal PLAY while allowing a direct storage start without waking/transition voices. `RoomProgression.startInStorage()` initializes the already-locked entrance. The timer starts fresh and controls remain shared with normal gameplay. `tests/storage-start.mjs` covers desktop/touch test entry and normal PLAY after cancelling a test selection.


## Personalized envelope addition
Added `src/storage-envelope.js` and integrated the envelope with `src/storage-room.js`, Room 2 interaction in `src/main.js`, and the inspection open button in `index.html`/scoped `src/style.css`. The existing blood-stroke glyph table is exported from `src/blood-message.js` without altering Room 1 drawing. The envelope is addressed from/to the player's name and opens into the user's exact four-sentence warning in bloody handwriting. It is placed within a shelf footprint and adds no walking obstacle. `tests/storage-envelope.mjs` checks addressing, E/touch inspection, opening, exact message, close and reopen.


## First letter recording
Embedded the supplied `src/assets/letter-voice.mp3` unchanged. `src/audio.js` reuses the narrator queue and provides two audio-clock caption cues; `src/main.js` queues the line once on the first letter opening and only marks playback after a successful start. Added letter-only caption positioning in `src/style.css`, `tests/letter-voice.mjs` and its npm script. No Room 1 trigger, recording or caption placement is changed.


## Later authorized Room 1 closet visual update
The user subsequently requested a more breakable-looking closet. `src/closet-damage.js` now builds chipped slats, stress cracks and damaged retaining boards, batched by material. `tests/closet-damage.mjs` captures the revised front and verifies unchanged destruction/scare behavior. This is the only new bedroom appearance change in this update; the earlier Room 2 extension's preservation scope is otherwise retained.


## Four-second spider SFX
At the user's request, `src/audio.js` caps the uploaded spider SFX to its first four seconds at original playback speed and fades its last 80 ms to prevent a hard cutoff click. The original asset remains intact. Existing aftermath scheduling waits for the shortened playback and visual scare before starting the property-damage narration. `tests/spider-scare.mjs` now expects four seconds.


## Sturdier window barricade appearance
At the user's request, only the window-board construction in `src/room.js` was visually reinforced: thicker, more aligned timber, subdued surface damage, broad fasteners and a heavier diagonal brace. `tests/window-barricade.mjs` isolates actual hammer removal and key collection. The existing puzzle, collision boundary, number of boards and removal timing remain unchanged.


## Deeper envelope and revised repetition counts
`src/storage-envelope.js` moves the envelope onto a third-aisle shelf beyond the first cross-passage, screened from the entrance by shelving. Its From/To names now use uneven blood-red glyph strokes and sparse drips, retaining the exact name and letter text. Envelope and voice tests use the current object's location. `src/puzzle.js` changes only the existing bed threshold to two inspections and the intact empty-hand closet threshold to seven accepted interactions. Existing debounce, once-only flags, unreadable speaker, hammer scare and broken-closet guards are retained. Browser regressions were updated for the new thresholds.


## Stage 1 computer update
The later computer specification is implemented separately in `COMPUTER-STAGE1-REPORT.md`: shelf-mounted 1980s computer, one physical translation clue, Stage 1 only and exactly three safely stackable sealed crates. Box 1 glows after completion but cannot open; its reserved wrench remains inaccessible. Later stages and the vent escape remain unfinished. The new report supersedes earlier statements that Room 2 has no functional puzzle.
