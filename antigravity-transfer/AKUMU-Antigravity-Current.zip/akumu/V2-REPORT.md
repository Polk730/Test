# AKUMU v2 visual overhaul — audit and verification

## Source, backup and protected behavior
Authoritative input: /workspace/AKUMU-Play.html, byte-identical to standalone/AKUMU.html before editing. Untouched backup: /workspace/AKUMU-v1-Backup.html; SHA256 423d59e50b1211c7ba2ec48ad5d80d0fd7032358bf4ab22074763e34f8ceb121. Full original source backup: /workspace/AKUMU-v1-source-backup.zip. Original source hashes: /workspace/AKUMU-v2-baseline-hashes.json. The repository contains a Vite/Three.js 0.180 application, inline artwork/audio, generated surface maps and standalone builder scripts/build-html.mjs. No hosted assets are required.

Audit: main.js owns startup, name/mode routing, render loop, pointer lock and Escape inspection behavior; puzzle.js and the state modules own interaction/physics/story. room.js, storage-room.js, storage-computer.js and observation-room.js mix visual construction with protected transforms and state. Gameplay state modules, audio, menus' event handlers, text, targets and colliders are protected. There is no existing crowbar acquisition mechanic; the existing required tool is the wrench. Do not add a crowbar. Narrator audio still pending from the previous update remains pending; do not invent a replacement recording.

Safe changes: procedural texture maps/material response; visual-only wrench geometry within the original reserved-wrench group; additional equipment detail strictly inside its existing silhouette; rendering configuration and graphics-only adaptive resolution; CSS presentation. Existing green through-wall box indicators are gameplay affordances and must remain even though the style brief discourages gratuitous glow. Existing blackouts/flicker timings and readable shelf lighting must stay.

## Regression checklist established before edits
- Compare protected modules against original hashes; review construction diffs for unchanged transforms/targets/colliders and handlers.
- Existing 58 model/unit checks.
- NORMAL full bedroom/notes/lock/hammer/boards/key and real storage transition.
- NORMAL original PC stages, letter, welcome event, box opening/movement/stacking, separate wrench collection, real stair/vent ending (desktop and touch).
- DEMO all tapes/drop/play/reorder/verify/live camera/exit/restart; demo invitation/full-version name flow.
- Escape inspection recapture, name filtering, menu/back/focus and responsive/reduced motion.
- Representative narrator/scare/blackout/clock/assistance audio and visual triggers.
- Browser/console/shader errors, resizing and context restore where supported.
- Capture before/after screenshots and like-for-like performance telemetry. Hardware GPU timings, actual Safari/iPad/Firefox/Edge are UNVERIFIED unless a corresponding environment is available.

## Performance method
The profile samples requestAnimationFrame over twelve seconds after eight seconds of warmup in the final comparison (earlier exploratory runs used shorter windows), records mean/p99 frame time, calls/triangles/texture/geometry counts, launch-to-debug-ready time, and CCTV CPU submission time. Software-renderer measurements describe this test machine only. Texture/geometry counts are GPU resource counts, not allocated bytes; exact GPU memory is UNVERIFIED. The first warmup and launch time include compilation; no claim of isolated shader/GPU timing is made.

## Implemented graphics changes
- New shared, deterministic 512px surface library: plaster, ceiling, concrete, brick, wood, floorboards, fabric, steel, oxidized metal, cardboard, paper and aged plastic. Color, normal and packed roughness/metal maps remain internal assets; the spare occlusion channel is reserved without an extra runtime sample. No codes, notes or puzzle text were rewritten.
- Original open-jaw forged wrench mesh with a continuous beveled silhouette, hanging hole, recessed handle and manufacturing stamp. Only children of the existing hidden reserved-wrench group changed. Parent, spawn transform, hit target and collect/open logic are unchanged; no new held/drop mechanism was invented.
- Soft PCF shadows, the existing local contact occlusion and restrained bare-metal reflections. Existing light-source positions, scripted flicker/blackout schedules and narrator/SFX behavior remain. Storage ambient was tuned from 1.15 to 0.98 while retaining its two shadow sources and shelf fills; brighter material albedos preserve shelf readability.
- Rigid bed components and rigid equipment/cassette case pieces are grouped by material. Invisible hit meshes and changing CRT screens remain independent. Added restrained decorative cassette labels/screws and VCR buttons/vent detail inside existing equipment footprints. Observation wall/floor/ceiling texture UVs now use consistent physical scale.
- Existing menu artwork, flame pictures, bird pictures, music and event handlers stay. CSS polishes violet panels, focus/hover/press feedback, name entry, pause and end typography, readable CRT presentation and touch target sizes. Reduced motion disables decorative animation. Game controls are unchanged.
- HIGH/MEDIUM/LOW resolution scaling is graphics-only; no new gameplay-quality setting or gameplay timer was introduced. CCTV keeps its original camera, 512×320 target, 10 Hz cap and content.

## Assets and licenses
All new surfaces, equipment details, wrench geometry and the reflection artwork are authored procedurally in this project. No stock model, paid asset, paid service, external font dependency or runtime CDN was added. Three.js remains the existing MIT dependency; its license remains embedded by the standalone builder. The small reflection probe is generated locally from original canvas artwork; no external environment map or custom compressed atlas is required.

## Launch
Download AKUMU-v2.0.html and open it in a current desktop browser. The HTML is self-contained: artwork, audio, shaders and surface generation need no external asset server. The main menu still offers NORMAL and DEMO; ROOM 2 / TEST remains the original normal-storage shortcut.

Alternatively unzip AKUMU-v2-Website.zip and serve that folder (`python3 -m http.server 8000`), then open http://localhost:8000. On an iPad, use an actual Safari/Chrome web page; an app's attachment/source preview may show HTML code rather than run the game. Physical iPad/Safari support is not claimed as newly verified here. Development source uses the existing npm/Vite scripts: npm ci; npm run dev; npm test; npm run build:html.

## Limits retained from the original
The final DEMO invitation recording and three Observation Room narrator recordings have not been supplied. Their existing caption placeholders and timing are preserved, with the same audio-ready route. No synthesized substitute voice was added. There is no pre-existing separate crowbar puzzle, no player body, and no new mechanic was added to match speculative prompt examples. Human completion time and hardware-specific 60/30 FPS remain UNVERIFIED.


## Reviewable source
An isolated local Git review repository at /workspace/AKUMU-v2-review records the untouched original source as its baseline commit, with the overhaul staged for inspection. The user's main repository history was not rewritten. AKUMU-v2.patch contains the source changes; generated standalone output is delivered separately to keep the diff reviewable. The preservation audit checks 67 unchanged existing non-visual files and 65 protected function bodies, including the original random generator and photograph content.

## Validation method and harness corrections
The actual final gameplay has not been changed to make tests pass. The bedroom fixture's old 30-second page-load limit was increased for software rendering. Its temporary Found key view is sampled atomically when shown, rather than inspected through several delayed browser round trips after the existing 2.3-second display has ended. Both changes are in test code only. The failed compressed reflection-atlas experiment was removed from the shipped runtime; only the stable original procedural small-probe implementation remains.


## Final delivery and verification
The final CPU-only texture-generation optimization produces byte-identical textures and reduced generation time in its isolated fixture. Main progression, event and UI suites passed within the scopes documented in V2-REGRESSION.md. Full unit count is now 60. Existing gameplay, puzzle solutions, hints, interaction targets, item transforms, movement constants, audio files and progression were retained. The artwork remains the original illustrated menu.

See V2-PERFORMANCE.md for exact final diagnostics, including unfavorable samples and unverified hardware targets. Rendering resources improved; a general FPS improvement is not established. See V2-REGRESSION.md for test coverage, fixture corrections and explicit UNVERIFIED platforms/conditions. Source contains qa-v2/ raw evidence.

Deliverables: AKUMU-v2.0.html; AKUMU-v1-Backup.html; AKUMU-v1-source-backup.zip; AKUMU-v2-source.zip; AKUMU-v2-Website.zip; report/performance/regression Markdown; AKUMU-v2.patch. No publishing, remote commit or paid asset/service was used.
