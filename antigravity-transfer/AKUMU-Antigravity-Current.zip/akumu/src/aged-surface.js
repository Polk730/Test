import * as T from 'three';
// Original procedural PBR artwork. Packed R=occlusion, G=roughness, B=metallic.
const cache=new Map();
export const surfaceBuildStats={count:0,totalMs:0};
export function agedSurface(kind,seed=31){
 const key=kind;if(cache.has(key))return cache.get(key);const started=performance.now();seed=31; // Share the material library across rooms; local material tints retain variation.
 let state=(seed+17)>>>0;const rand=()=>{state=(1664525*state+1013904223)>>>0;return state/4294967296;};
 const size=512,grid=Float32Array.from({length:4096},rand),smooth=x=>x*x*(3-2*x);
 // Inputs are the fixed 0..511 texel grid; frequencies are 4, 8, 16 or 64.
 // Direct wrapped lattice indices avoid a closure and sixteen remainder operations per sample.
 const noise=(x,y,f)=>{x=x/size*f;y=y/size*f;const ix=Math.floor(x),iy=Math.floor(y),u=smooth(x-ix),v=smooth(y-iy),x1=ix+1===f?0:ix+1,y1=iy+1===f?0:iy+1,row=iy*64,next=y1*64,a=grid[row+ix]*(1-u)+grid[row+x1]*u,b=grid[next+ix]*(1-u)+grid[next+x1]*u;return a*(1-v)+b*v;};
 const palette={wall:[158,150,131],plaster:[165,157,139],ceiling:[135,131,118],concrete:[118,116,107],wood:[116,85,56],floor:[69,56,43],cloth:[139,133,115],metal:[133,132,122],rust:[111,103,86],cardboard:[148,125,91],brick:[133,82,60],paper:[190,175,139],plastic:[174,164,138]};
 const base=palette[kind]||palette.plaster,wood=kind==='wood'||kind==='floor',metal=kind==='metal'||kind==='rust',plaster=['wall','plaster','ceiling','concrete'].includes(kind);
 const canvas=document.createElement('canvas');canvas.width=canvas.height=size;const c=canvas.getContext('2d'),image=c.createImageData(size,size),height=new Float32Array(size*size),rough=new Float32Array(size*size),cavity=new Float32Array(size*size);
 for(let y=0;y<size;y++)for(let x=0;x<size;x++){
  const i=y*size+x,p=i*4,n=noise(x,y,4),m=noise(x,y,16),fine=rand()-.5,pores=noise(x,y,64);let shade=(n-.5)*17+(m-.5)*9+fine*6,h=pores*.07+fine*.025,r=.84,oc=1,oxidation=0;
  if(plaster){const damp=Math.max(0,.43-n)*35;shade-=damp;h+=Math.max(0,pores-.66)*.08;r=.82+m*.15;oc=1-Math.max(0,.4-pores)*.12;}
  if(wood){const bend=11*Math.sin(y/size*Math.PI*2)+7*Math.sin(y/size*Math.PI*6),grain=Math.sin((x+bend)*.35+noise(x,y,8)*7),fiber=Math.sin((x+bend)*1.9);shade+=(grain*.5+fiber*.18)*15;h=grain*.023+fiber*.005+fine*.012;r=.61+pores*.21;}
  if(metal){oxidation=Math.max(0,(n*.6+m*.4)-.57)*2.4;shade=(pores-.5)*9+fine*9;h=(pores-.5)*.045;r=.37+oxidation*.5+m*.16;}
  if(kind==='cloth'){const weave=(x%4===0||y%4===0);shade+=weave?-10:3;h+=weave?-.033:.02;r=.96;}
  if(kind==='cardboard'){shade+=Math.sin(x*Math.PI*.5)*1.4;r=.91+pores*.08;h+=Math.sin(x*Math.PI*.5)*.008;}
  if(kind==='plastic'){shade+=(m-.5)*6;r=.63+m*.2;h*=.3;}
  for(let k=0;k<3;k++)image.data[p+k]=base[k]+shade-(metal?oxidation*[15,36,45][k]:0);image.data[p+3]=255;height[i]=h;rough[i]=Math.min(.99,r);cavity[i]=oc;
 }
 c.putImageData(image,0,0);
 // Non-uniform, hairline damage; these marks never contain text or puzzle clues.
 if(plaster){for(let j=0;j<9;j++){let x=rand()*size,y=rand()*size;c.beginPath();c.moveTo(x,y);for(let k=0;k<9;k++){x+=(rand()-.54)*16;y+=5+rand()*13;c.lineTo(x,y);}c.strokeStyle='#332d2455';c.lineWidth=.45+rand()*.5;c.stroke();c.strokeStyle='#e0d4b530';c.lineWidth=.28;c.stroke();}
  if(kind!=='concrete')for(let j=0;j<22;j++){const x=rand()*size,y=rand()*size,r=2+rand()*9;c.fillStyle='#d7cdb015';c.beginPath();for(let k=0;k<9;k++){const a=k/9*Math.PI*2,rad=r*(.45+rand()*.5);c.lineTo(x+Math.cos(a)*rad,y+Math.sin(a)*rad*.6);}c.closePath();c.fill();}}
 if(wood){for(let j=0;j<3;j++){const x=rand()*size,y=rand()*size;for(let k=0;k<7;k++){c.strokeStyle='#21180e25';c.lineWidth=.6;c.beginPath();c.ellipse(x,y,2+k*1.8,9+k*7,.08,0,Math.PI*2);c.stroke();}}}
 if(metal||wood||kind==='plastic'){for(let j=0;j<100;j++){const x=rand()*size,y=rand()*size;c.strokeStyle=metal?'#e4dfca24':'#dec99f20';c.lineWidth=.35+rand()*.45;c.beginPath();c.moveTo(x,y);c.lineTo(x+(metal?8:2)+rand()*15,y+rand()*36);c.stroke();}}
 if(kind==='brick'){c.strokeStyle='#8c8470';c.lineWidth=7;for(let y=0;y<=size;y+=64){c.beginPath();c.moveTo(0,y);c.lineTo(size,y);c.stroke();for(let x=(y/64%2)*64;x<=size;x+=128){c.beginPath();c.moveTo(x,y);c.lineTo(x,y+64);c.stroke();}}}
 if(kind==='cardboard'){c.strokeStyle='#5e493422';c.lineWidth=1;for(let j=0;j<8;j++){const x=rand()*size,y=rand()*size;c.beginPath();c.moveTo(x,y);c.lineTo(x+35+rand()*90,y+20);c.stroke();}c.fillStyle='#cfb48722';c.fillRect(238,0,35,512);c.font='17px monospace';c.fillStyle='#3c342b';c.fillText('HOTEL / STORAGE',44,244);}
 const final=c.getImageData(0,0,size,size).data;
 for(let i=0;i<height.length;i++){const p=i*4,delta=(final[p]+final[p+1]+final[p+2]-image.data[p]-image.data[p+1]-image.data[p+2])/765;height[i]+=delta*.16;rough[i]=Math.min(.99,rough[i]+Math.max(0,-delta)*.3);}
 const normalCanvas=document.createElement('canvas'),packedCanvas=document.createElement('canvas');normalCanvas.width=normalCanvas.height=packedCanvas.width=packedCanvas.height=size;const nc=normalCanvas.getContext('2d'),pc=packedCanvas.getContext('2d'),ni=nc.createImageData(size,size),pi=pc.createImageData(size,size);
 for(let y=0;y<size;y++)for(let x=0;x<size;x++){const i=y*size+x,p=i*4,dx=(height[y*size+(x+1)%size]-height[y*size+(x+size-1)%size])*3,dy=(height[((y+1)%size)*size+x]-height[((y+size-1)%size)*size+x])*3,n=Math.hypot(dx,dy,1);ni.data.set([128-dx/n*127,128+dy/n*127,128+127/n,255],p);pi.data.set([cavity[i]*255,rough[i]*255,metal?Math.max(.15,1-(rough[i]-.35))*255:0,255],p);}
 nc.putImageData(ni,0,0);pc.putImageData(pi,0,0);
 const tex=(source,color=false)=>{const t=new T.CanvasTexture(source);t.wrapS=t.wrapT=T.RepeatWrapping;t.anisotropy=4;if(color)t.colorSpace=T.SRGBColorSpace;return t;};
 const maps={color:tex(canvas,true),normal:tex(normalCanvas),roughness:tex(packedCanvas)};cache.set(key,maps);surfaceBuildStats.count++;surfaceBuildStats.totalMs+=performance.now()-started;return maps;
}
