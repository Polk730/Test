import * as T from 'three';
import firstArtwork from './assets/staff-portrait-one.png?inline';
import secondArtwork from './assets/staff-portrait-two.png?inline';

// Exact uploaded artwork on recessed canvases, with actual raised frame mouldings.
// Decorative only: no prompts, item IDs, puzzle state or additional light sources.
export function createStaffPortraits(parent,{wood,metal,rust}){
 const root=new T.Group();root.name='staff-wall-pictures';parent.add(root);
 const boxGeometry=new T.BoxGeometry(1,1,1),frames=[],textures=[],loads=[];
 const shadowCanvas=document.createElement('canvas');shadowCanvas.width=shadowCanvas.height=256;
 const c=shadowCanvas.getContext('2d');c.shadowColor='rgba(0,0,0,.75)';c.shadowBlur=15;c.shadowOffsetY=5;c.fillStyle='#000';c.fillRect(22,18,212,220);
 const shadowMap=new T.CanvasTexture(shadowCanvas);shadowMap.colorSpace=T.SRGBColorSpace;
 const shadowMaterial=new T.MeshBasicMaterial({map:shadowMap,transparent:true,opacity:.48,depthWrite:false,toneMapped:false});
 function mesh(geometry,material,group){const o=new T.Mesh(geometry,material);o.castShadow=o.receiveShadow=true;group.add(o);return o;}
 function box(group,w,h,d,x,y,z,material){const o=mesh(boxGeometry,material,group);o.scale.set(w,h,d);o.position.set(x,y,z);return o;}
 function segment(group,a,b,r,material){const delta=new T.Vector3().subVectors(b,a),o=mesh(new T.CylinderGeometry(r,r,delta.length(),6),material,group);o.position.copy(a).add(b).multiplyScalar(.5);o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),delta.normalize());return o;}
 function face(group,w,h,x,y,z,material,rect=[0,0,1,1]){const geometry=new T.PlaneGeometry(w,h),uv=geometry.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,rect[0]+uv.getX(i)*rect[2],rect[1]+uv.getY(i)*rect[3]);const o=mesh(geometry,material,group);o.position.set(x,y,z);return o;}
 const entries=[{url:firstArtwork,width:1100,height:1430,x:26.22,angle:-.009},{url:secondArtwork,width:1194,height:1317,x:27.26,angle:.006}];
 for(const [i,entry]of entries.entries()){
  const image=new Image(),texture=new T.Texture(image);texture.colorSpace=T.SRGBColorSpace;texture.anisotropy=4;textures.push(texture);
  loads.push(new Promise((resolve,reject)=>{image.onload=()=>{texture.needsUpdate=true;resolve();};image.onerror=()=>reject(new Error('Unable to decode staff portrait '+(i+1)));image.src=entry.url;}));
  const w=.78,h=w*entry.height/entry.width,band=.045,frame=new T.Group();frame.name='staff-portrait-'+(i+1);frame.position.set(entry.x,2.67-h/2,12.08);frame.rotation.z=entry.angle;root.add(frame);
  const artwork=new T.MeshStandardMaterial({map:texture,roughness:.95,metalness:0,color:0xffffff});
  // Soft contact occlusion is inexpensive and works with the existing warm light.
  const shadow=face(frame,w+.13,h+.13,.008,-.014,.002,shadowMaterial);shadow.castShadow=shadow.receiveShadow=false;
  // Rear spacers touch the wall; the backing board sits 22 mm away from it.
  for(const x of [-w*.34,w*.34])box(frame,.035,.035,.022,x,-h*.35,.011,wood);
  box(frame,w,h,.036,0,0,.040,wood);
  face(frame,w,h,0,0,.061,artwork);
  // Reuse the original frame pixels for the front of the raised solid rails.
  // All five image planes share one texture/material, with UVs placed on the
  // original border; the picture itself is neither repainted nor cropped.
  for(const sign of [-1,1]){
   const y=sign*(h/2-band/2);box(frame,w,band,.052,0,y,.055,wood);
   face(frame,w,band,0,y,.0815,artwork,[0,sign<0?0:1-band/h,1,band/h]);
   const x=sign*(w/2-band/2);box(frame,band,h-2*band,.052,x,0,.055,wood);
   face(frame,band,h-2*band,x,0,.0815,artwork,[sign<0?0:1-band/w,band/h,band/w,1-2*band/h]);
   box(frame,w,.004,.008,0,sign*(h/2-.006),.083,rust);
   box(frame,.004,h-.012,.008,sign*(w/2-.006),0,.083,rust);
  }
  const nail=new T.Vector3(0,h/2+.12,.009);
  for(const sign of [-1,1])segment(frame,new T.Vector3(sign*w*.32,h/2-.025,.030),nail,.0017,metal);
  const head=mesh(new T.CylinderGeometry(.006,.006,.016,10),metal,frame);head.rotation.x=Math.PI/2;head.position.copy(nail);
  frames.push({root:frame,width:w,height:h,texture});
 }
 return {root,frames,textures,ready:Promise.all(loads)};
}
