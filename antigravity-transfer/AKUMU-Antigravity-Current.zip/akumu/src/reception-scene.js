import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {agedSurface} from './aged-surface.js';

// Presentation-only scene. Nothing is attached to a gameplay room or target list.
export function createReception(environment){
 const scene=new T.Scene();scene.background=new T.Color(0x090b0b);scene.fog=new T.FogExp2(0x111412,.022);
 const camera=new T.PerspectiveCamera(43,innerWidth/innerHeight,.025,45),root=new T.Group();scene.add(root);
 const unit=new T.BoxGeometry(1,1,1),materials=new Set(),textures=new Set();
 function worn(kind,color,roughness=.85,metalness=0){const a=agedSurface(kind),m=new T.MeshStandardMaterial({color,map:a.color,normalMap:a.normal,normalScale:new T.Vector2(.18,.18),roughnessMap:a.roughness,roughness,metalness});if(metalness>.4){m.envMap=environment;m.envMapIntensity=.32;}materials.add(m);return m;}
 const wood=worn('wood',0x66503a,.66),panel=worn('wood',0x342b22,.82),top=worn('wood',0x765740,.35),brass=worn('metal',0xa18b55,.43,.78),black=worn('plastic',0x242823,.72),cream=worn('plaster',0xc5bc9e),plaster=worn('plaster',0x777362),paper=worn('paper',0xf1dfb9,.98),green=worn('plastic',0x234d3b,.31,.12),rust=worn('rust',0x6d6657);
 function mesh(g,m,parent=root){const o=new T.Mesh(g,m);o.castShadow=o.receiveShadow=true;parent.add(o);return o;}
 function box(w,h,d,x,y,z,m=wood,parent=root){const o=mesh(unit,m,parent);o.scale.set(w,h,d);o.position.set(x,y,z);return o;}
 function cylinder(r,h,x,y,z,m=brass,parent=root,r2=r){const o=mesh(new T.CylinderGeometry(r2,r,h,20),m,parent);o.position.set(x,y,z);return o;}
 function tube(points,r,m,parent=root,segments=32){return mesh(new T.TubeGeometry(new T.CatmullRomCurve3(points.map(p=>new T.Vector3(...p))),segments,r,8,false),m,parent);}
 function torus(r,t,x,y,z,m,parent=root){const o=mesh(new T.TorusGeometry(r,t,8,32),m,parent);o.position.set(x,y,z);return o;}
 function canvasTexture(w,h,paint){const c=document.createElement('canvas');c.width=w;c.height=h;paint(c.getContext('2d'),w,h);const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;textures.add(t);return t;}
 let seed=1986;const random=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);
 const wallpaper=canvasTexture(512,512,(c,w,h)=>{c.fillStyle='#b6ad92';c.fillRect(0,0,w,h);for(let i=0;i<12000;i++){c.fillStyle=`rgba(56,50,34,${random()*.065})`;c.fillRect(random()*w,random()*h,1,1);}for(let x=24;x<w;x+=64){c.strokeStyle='#80795855';c.lineWidth=.7;c.beginPath();c.moveTo(x,0);c.lineTo(x,h);c.stroke();for(let y=24;y<h;y+=64){c.beginPath();c.ellipse(x,y,7,16,0,0,Math.PI*2);c.ellipse(x,y,12,5,0,0,Math.PI*2);c.stroke();}}for(let i=0;i<13;i++){const x=random()*w,y=random()*h,g=c.createRadialGradient(x,y,0,x,y,30+random()*75);g.addColorStop(0,'#635d4135');g.addColorStop(1,'#635d4100');c.fillStyle=g;c.fillRect(0,0,w,h);}c.strokeStyle='#4b493b55';c.beginPath();c.moveTo(422,0);c.lineTo(418,45);c.lineTo(430,61);c.lineTo(424,89);c.stroke();});wallpaper.wrapS=wallpaper.wrapT=T.RepeatWrapping;
 const wallMat=new T.MeshStandardMaterial({map:wallpaper,roughness:.98,bumpMap:wallpaper,bumpScale:.006});materials.add(wallMat);
 const carpet=canvasTexture(512,512,c=>{c.fillStyle='#48272b';c.fillRect(0,0,512,512);for(let i=0;i<27000;i++){c.fillStyle=random()>.5?'#a7775520':'#151b1429';c.fillRect(random()*512,random()*512,1+random()*2,1);}for(let y=64;y<512;y+=128)for(let x=64;x<512;x+=128){c.save();c.translate(x,y);c.rotate(Math.PI/4);c.strokeStyle='#92735765';c.lineWidth=2;c.strokeRect(-25,-25,50,50);c.strokeStyle='#1f262766';c.strokeRect(-34,-34,68,68);c.restore();c.strokeStyle='#ad89612c';c.beginPath();c.ellipse(x,y,9,20,0,0,Math.PI*2);c.stroke();}const g=c.createLinearGradient(0,0,512,512);g.addColorStop(0,'#a9956922');g.addColorStop(.55,'#00000000');g.addColorStop(1,'#060c1433');c.fillStyle=g;c.fillRect(0,0,512,512);});carpet.wrapS=carpet.wrapT=T.RepeatWrapping;carpet.repeat.set(5,8);
 const floorMat=new T.MeshStandardMaterial({map:carpet,roughness:1,normalMap:agedSurface('cloth').normal,normalScale:new T.Vector2(.12,.12)});materials.add(floorMat);
 function floor(w,d,x,z){const o=box(w,.12,d,x,-.06,z,floorMat);o.geometry=unit.clone();const p=o.geometry.attributes.position,n=o.geometry.attributes.normal,uv=o.geometry.attributes.uv;for(let i=0;i<uv.count;i++)if(n.getY(i)>.5)uv.setXY(i,(x+p.getX(i)*w+5)/10,(12-(z+p.getZ(i)*d))/18);return o;}
 // The room and hall meet at the rear wall face, with one carpet surface at the join.
 floor(10,15.37,0,4.315);box(10,.12,8.77,0,3.35,1.015,plaster);
 function corridorUV(o,length,height,z,y){const p=o.geometry.attributes.position,uv=o.geometry.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,(z+p.getZ(i)*length+12.3)/2,(y+p.getY(i)*height)/2);}
 function wall(w,x,z,side=false){const o=box(side?.14:w,3.3,side?w:.14,x,1.65,z,wallMat);o.geometry=unit.clone();const uv=o.geometry.attributes.uv;if(side&&(x===1.45||x===3.05))corridorUV(o,w,3.3,z,1.65);else for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*w/2,uv.getY(i)*1.65);box(side?.18:w,1.05,side?w:.18,x,.525,z,panel);box(side?.21:w,.045,side?w:.21,x,1.07,z,wood);box(side?.23:w,.12,side?w:.23,x,.06,z,panel);return o;}
 wall(6.45,-1.775,-3.3);wall(1.95,4.025,-3.3);wall(8.93,-5,1.235,true);wall(8.93,5,1.235,true);
 for(let x=-4.8;x<1.3;x+=.65){box(.026,.79,.025,x,.54,-3.193,wood);box(.54,.025,.025,x+.27,.89,-3.193,wood);}
 // A real recessed corridor. Doors and keys are deliberately static.
 floor(1.6,8.93,2.25,-7.835);box(1.75,.12,8.93,2.25,3.25,-7.835,plaster);wall(8.86,1.45,-7.8,true);wall(1.6,2.25,-12.3);
 box(1.6,.11,.14,2.25,3.245,-3.3,wallMat);
 // Real rough openings: neither wallpaper nor lower panelling runs behind the doors.
 let corridorEnd=-12.23;
 for(const z of [-10.9,-8.1,-5.1]){
  const start=z-.48,end=z+.48;
  wall(start-corridorEnd,3.05,(start+corridorEnd)/2,true);
  const header=box(.14,.9,.96,3.05,2.85,z,wallMat);header.geometry=unit.clone();corridorUV(header,.96,.9,z,2.85);
  // Jambs meet the header edge-to-edge; no coincident front faces at the corners.
  for(const zz of [-.4475,.4475])box(.14,2.34,.065,3.005,1.17,z+zz,wood);
  box(.14,.06,.96,3.005,2.37,z,wood);
  box(.04,2.31,.81,3.035,1.17,z,panel);
  cylinder(.022,.06,2.985,1.02,z+.24,brass).rotation.z=Math.PI/2;
  corridorEnd=end;
 }
 wall(-3.37-corridorEnd,3.05,(-3.37+corridorEnd)/2,true);
 // Clean, constructed walnut counter against the neglected shell.
 box(4.25,1.08,1.0,0,.54,.04,wood);box(4.32,.13,1.08,0,.075,.04,panel);
 for(const x of [-1.43,0,1.43]){box(1.25,.77,.025,x,.62,.552,panel);for(const dx of [-.64,.64])box(.042,.83,.04,x+dx,.62,.57,wood);for(const y of [.205,1.035])box(1.30,.04,.04,x,y,.57,wood);}
 const shape=new T.Shape();shape.moveTo(-2.16,-.54);shape.lineTo(2.16,-.54);shape.quadraticCurveTo(2.23,-.54,2.23,-.47);shape.lineTo(2.23,.55);shape.quadraticCurveTo(2.23,.62,2.16,.62);shape.lineTo(-2.16,.62);shape.quadraticCurveTo(-2.23,.62,-2.23,.55);shape.lineTo(-2.23,-.47);shape.quadraticCurveTo(-2.23,-.54,-2.16,-.54);
 const counter=mesh(new T.ExtrudeGeometry(shape,{depth:.055,bevelEnabled:true,bevelSize:.012,bevelThickness:.012,bevelSegments:3,steps:1}),top);counter.rotation.x=-Math.PI/2;counter.position.y=1.105;
 // Numbered brass key tags on a wooden rack, no interaction targets.
 box(2.45,1.08,.10,-1.35,2.0,-3.16,panel);for(const x of [-2.60,-.1])box(.05,1.18,.14,x,2,-3.10,wood);for(const y of [1.44,2.56])box(2.55,.045,.14,-1.35,y,-3.1,wood);
 for(let i=0;i<12;i++){const x=-2.35+(i%6)*.4,y=2.31-Math.floor(i/6)*.47;cylinder(.012,.06,x,y,-3.055,brass).rotation.x=Math.PI/2;torus(.025,.004,x,y-.045,-3.015,brass);box(.007,.082,.008,x,y-.105,-3.015,brass);box(.025,.009,.01,x+.009,y-.134,-3.015,brass);const tag=canvasTexture(64,96,c=>{c.fillStyle='#a79162';c.fillRect(0,0,64,96);c.fillStyle='#302d24';c.textAlign='center';c.font='20px Georgia';c.fillText(String(201+i),32,60);});const tm=new T.MeshStandardMaterial({map:tag,roughness:.8,metalness:.25});materials.add(tm);const t=mesh(new T.PlaneGeometry(.09,.12),tm);t.position.set(x+.055,y-.18,-3.009);}
 // Tarnished service bell, lathed dome and mechanical plunger.
 const bell=new T.Group();bell.name='reception-service-bell';bell.position.set(.05,1.18,.30);root.add(bell);
 const bp=[[0,0],[.087,0],[.09,.012],[.083,.024],[.079,.04],[.068,.072],[.047,.095],[.017,.105],[0,.105]].map(([r,y])=>new T.Vector2(r,y));mesh(new T.LatheGeometry(bp,40),brass,bell);cylinder(.008,.025,0,.116,0,brass,bell);cylinder(.024,.009,0,.132,0,brass,bell);torus(.084,.005,0,.018,0,panel,bell).rotation.x=Math.PI/2;
 // Banker's lamp: continuous curved stem, enamel shade and warm inner glass.
 const lamp=new T.Group();lamp.name='reception-desk-lamp';lamp.position.set(-.66,1.18,-.22);root.add(lamp);cylinder(.12,.025,0,.0125,0,brass,lamp);cylinder(.075,.025,0,.035,0,brass,lamp);
 tube([[0,.04,0],[0,.28,0],[0,.43,.04],[0,.47,.11]],.014,brass,lamp);
 const shade=mesh(new T.SphereGeometry(.19,32,16,0,Math.PI*2,0,Math.PI*.54),green,lamp);shade.scale.set(1.5,.8,.85);shade.position.set(0,.43,.14);const inner=new T.MeshStandardMaterial({color:0xe9dfb4,emissive:0xffd599,emissiveIntensity:.6,side:T.DoubleSide,roughness:.7});materials.add(inner);const diffuser=mesh(new T.CircleGeometry(.18,32),inner,lamp);diffuser.rotation.x=-Math.PI/2;diffuser.scale.set(1.5,.85,1);diffuser.position.set(0,.405,.14);diffuser.castShadow=false;
 const warm=new T.PointLight(0xffd59c,14,6,2);warm.position.set(-.66,1.56,-.08);warm.castShadow=true;warm.shadow.mapSize.set(512,512);warm.shadow.camera.near=.05;warm.shadow.camera.far=6;warm.shadow.bias=-.0003;warm.shadow.normalBias=.012;scene.add(warm);
 const ambient=new T.HemisphereLight(0xc4c2ac,0x24221e,.56);scene.add(ambient);
 const bounce=new T.PointLight(0xe6bf8e,2.4,3.5,2);bounce.position.set(0,1.13,.90);scene.add(bounce);
 box(1.0,.07,.19,2.25,3.13,-5.0,black);const coldMat=new T.MeshStandardMaterial({color:0xd4e1d3,emissive:0xb9d3bf,emissiveIntensity:.7,roughness:.6});materials.add(coldMat);box(.84,.025,.09,2.25,3.075,-5,coldMat).castShadow=false;const cold=new T.PointLight(0xc0d9c5,17,9,2);cold.position.set(2.25,2.98,-5);scene.add(cold);
 // Period rotary phone: shaped base, finger holes, curved receiver, coiled cord.
 const phone=new T.Group();phone.name='reception-rotary-telephone';phone.position.set(-1.55,1.18,.18);phone.rotation.y=.22;root.add(phone);
 const base=mesh(new T.CylinderGeometry(.19,.25,.085,5,1),black,phone);base.scale.set(1.12,1,.80);base.rotation.y=Math.PI/5;base.position.y=.0425;
 const dial=torus(.073,.011,0,.096,.045,brass,phone);dial.rotation.x=-Math.PI/2;for(let i=0;i<10;i++){const a=i*Math.PI*2/12+.3;const hole=cylinder(.010,.006,Math.sin(a)*.054,.099,.045+Math.cos(a)*.054,panel,phone);hole.rotation.x=.05;}
 const centre=cylinder(.031,.006,0,.10,.045,cream,phone);for(const x of [-.13,.13])box(.035,.10,.04,x,.12,-.06,black,phone);
 tube([[-.19,.16,-.05],[-.16,.21,-.06],[0,.235,-.06],[.16,.21,-.06],[.19,.16,-.05]],.032,black,phone);for(const x of [-.18,.18]){const e=mesh(new T.SphereGeometry(.057,20,12),black,phone);e.scale.set(1,.55,.9);e.position.set(x,.165,-.05);}
 const coil=[];for(let i=0;i<=200;i++){const t=i/200,a=t*Math.PI*2*25;coil.push([-.22-.10*t+.018*Math.cos(a),.13-.115*t,.0+.24*t+.018*Math.sin(a)]);}tube(coil,.0045,black,phone,200);
 // Open register. The left board folds over the right page at confirmation.
 const book=new T.Group();book.name='reception-guest-register';book.position.set(.99,1.18,.05);book.rotation.y=-.10;book.scale.setScalar(.75);root.add(book);
 const cover=worn('cloth',0x383d31,.92);/* The stationary back board belongs only below the right page block. */box(.56,.026,.75,.27,.014,0,cover,book);box(.52,.028,.70,.27,.04,0,paper,book);
 const hinge=new T.Group();hinge.position.y=.048;book.add(hinge);box(.54,.026,.74,-.27,-.022,0,cover,hinge);box(.52,.018,.70,-.27,-.004,0,paper,hinge);
 const arrivalTexture=canvasTexture(600,750,c=>{c.fillStyle='#e5d4af';c.fillRect(0,0,600,750);c.fillStyle='#75664e';c.font='19px monospace';c.fillText('ARRIVALS',45,58);c.font='12px monospace';c.fillText('DATE',45,98);c.fillText('GUEST',165,98);c.fillText('ROOM',475,98);c.strokeStyle='#7e6f4d66';c.lineWidth=1;for(let y=115;y<705;y+=44){c.beginPath();c.moveTo(35,y);c.lineTo(565,y);c.stroke();}for(const x of [35,140,455,565]){c.beginPath();c.moveTo(x,80);c.lineTo(x,704);c.stroke();}});
 const arrivalMat=new T.MeshStandardMaterial({map:arrivalTexture,roughness:1});materials.add(arrivalMat);const leftPage=mesh(new T.PlaneGeometry(.50,.68),arrivalMat,hinge);leftPage.rotation.x=-Math.PI/2;leftPage.position.set(-.27,.0055,0);
 const pageCanvas=document.createElement('canvas');pageCanvas.width=600;pageCanvas.height=750;const pageTexture=new T.CanvasTexture(pageCanvas);pageTexture.colorSpace=T.SRGBColorSpace;textures.add(pageTexture);const pageMat=new T.MeshStandardMaterial({map:pageTexture,roughness:1});materials.add(pageMat);
 const page=mesh(new T.PlaneGeometry(.50,.68),pageMat,book);page.rotation.x=-Math.PI/2;page.position.set(.27,.057,0);
 function writeName(name='',ink=null){const c=pageCanvas.getContext('2d');c.fillStyle='#e7d6b2';c.fillRect(0,0,600,750);let s=59;for(let i=0;i<18000;i++){s=(Math.imul(s,1664525)+1013904223)>>>0;c.fillStyle=s%2?'#694a2510':'#fff9d610';c.fillRect(s%600,Math.floor(s/600)%750,1,1);}c.strokeStyle='#69503935';c.lineWidth=1;c.strokeRect(24,24,552,702);c.beginPath();c.moveTo(48,374);c.lineTo(552,374);c.stroke();if(name){c.save();if(ink){c.beginPath();c.rect(ink.clip.x,ink.clip.y,ink.clip.width,ink.clip.height);c.clip();c.fillStyle=ink.color;c.font=ink.font;c.textBaseline='alphabetic';c.direction=ink.direction;if('letterSpacing' in c)c.letterSpacing=ink.letterSpacing;c.fillText(name,ink.x,ink.y);}else{c.fillStyle='#30271e';c.font='italic 43px Georgia';c.fillText(name,53,359,485);}c.restore();}pageTexture.needsUpdate=true;}writeName();
 // Fountain pen, barrel, grip, metal nib and restrained clip.
 const pen=new T.Group();pen.name='reception-fountain-pen';pen.position.set(1.56,1.19,.11);pen.rotation.z=Math.PI/2;pen.rotation.y=.4;root.add(pen);cylinder(.010,.20,0,.1,0,black,pen);cylinder(.012,.045,0,.035,0,brass,pen);mesh(new T.ConeGeometry(.011,.03,12),brass,pen).position.y=-.015;box(.004,.075,.006,0,.16,.013,brass,pen);
 // Batch only static meshes, preserving the book and bell for deliberate UI animations.
 root.updateMatrixWorld(true);const batches=new Map(),remove=[];root.traverse(o=>{if(!o.isMesh)return;for(let p=o;p;p=p.parent)if(p===book||p===bell)return;const key=o.material.uuid+':'+o.castShadow;const g=(o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone()).applyMatrix4(o.matrixWorld);if(!batches.has(key))batches.set(key,{m:o.material,shadow:o.castShadow,parts:[]});batches.get(key).parts.push(g);remove.push(o);});remove.forEach(o=>o.removeFromParent());for(const b of batches.values()){const o=mesh(mergeGeometries(b.parts),b.m);o.castShadow=b.shadow;b.parts.forEach(g=>g.dispose());}
 let power=1,time=0,nextFlicker=13.5,flickerUntil=0;
 function resize(){camera.aspect=innerWidth/innerHeight;camera.fov=camera.aspect<.75?52:43;const viewport=window.visualViewport,offset=viewport?innerHeight/2-(viewport.offsetTop+viewport.height/2):0;if(Math.abs(offset)>.5)camera.setViewOffset(innerWidth,innerHeight,0,offset,innerWidth,innerHeight);else camera.clearViewOffset();camera.updateProjectionMatrix();}
 function widePose(){const k=Math.max(1,.82/camera.aspect);return {eye:new T.Vector3(4.7,2.8+(k-1)*.7,6.9*k),look:new T.Vector3(0,1.18,-1.15)};}
 function pageCorners(){book.updateWorldMatrix(true,false);return [[.02,.057,-.34],[.52,.057,-.34],[.52,.057,.34],[.02,.057,.34]].map(a=>book.localToWorld(new T.Vector3(...a)));}
 function bookPose(){const look=book.localToWorld(new T.Vector3(.27,.06,0)),direction=new T.Vector3(0,.94,.34).normalize();let distance=1;camera.position.copy(look).addScaledVector(direction,distance);camera.lookAt(look);camera.updateMatrixWorld(true);const points=pageCorners().map(v=>v.project(camera)),pw=(Math.max(...points.map(v=>v.x))-Math.min(...points.map(v=>v.x)))*innerWidth/2,ph=(Math.max(...points.map(v=>v.y))-Math.min(...points.map(v=>v.y)))*innerHeight/2;const vh=window.visualViewport?.height||innerHeight;distance*=Math.max(pw/Math.min(innerWidth*.84,570),ph/Math.min(vh*.85,690));return {eye:look.clone().addScaledVector(direction,distance),look};}
 function update(dt,on=1){time+=dt;power=on;if(time>nextFlicker){flickerUntil=time+.16;nextFlicker=time+16+random()*19;}const f=time<flickerUntil?.65+.25*Math.sin(time*87):1;cold.intensity=17*f*on;coldMat.emissiveIntensity=.7*f*on;warm.intensity=14*on;bounce.intensity=2.4*on;inner.emissiveIntensity=.6*on;ambient.intensity=.56*on;}
 function dispose(){const geometries=new Set();scene.traverse(o=>{if(o.geometry)geometries.add(o.geometry);});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());textures.forEach(t=>t.dispose());warm.shadow.map?.dispose();root.clear();scene.clear();materials.clear();textures.clear();}
 resize();const pose=widePose();camera.position.copy(pose.eye);camera.lookAt(pose.look);
 return {scene,camera,root,book,hinge,bell,writeName,pageCorners,widePose,bookPose,resize,update,dispose,get time(){return time;}};
}
