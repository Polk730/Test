// Camera-local wind-up, forward strike and eased recovery, on the active game clock.
export const SWING_DURATION=.64;
export const SWING_CONTACT=.26;
const ease=t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};
export function hammerPose(time){
 const rest={offset:[.27,-.29,-.43],rotation:[-.18,.18,-.3]};
 const raised={offset:[.35,-.12,-.30],rotation:[.8,-.2,-.65]};
 const hit={offset:[.07,-.22,-.68],rotation:[-1.05,.35,.12]};
 let a,b,t;
 if(time<0||time>=SWING_DURATION)return rest;
 if(time<.15){a=rest;b=raised;t=ease(time/.15);}
 else if(time<SWING_CONTACT){a=raised;b=hit;t=ease((time-.15)/(SWING_CONTACT-.15));}
 else{a=hit;b=rest;t=ease((time-SWING_CONTACT)/(SWING_DURATION-SWING_CONTACT));}
 return {offset:a.offset.map((v,i)=>v+(b.offset[i]-v)*t),rotation:a.rotation.map((v,i)=>v+(b.rotation[i]-v)*t)};
}
