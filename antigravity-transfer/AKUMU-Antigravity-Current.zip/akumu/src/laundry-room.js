import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {createSecretWasher} from './secret-washer.js';
import {createCoffeePlay} from './coffee-play.js';
import {createStaffPortraits} from './staff-portraits.js';
import {agedSurface} from './aged-surface.js';
import {DUCT_FLOOR,DUCT_BOUNDS,DUCT_BOXES,LAUNDRY_FLOOR,LAUNDRY_BOUNDS,EXIT_GRILLE} from './laundry-layout.js';

export function createLaundryContinuation(scene){
 const duct=new T.Group(),laundry=new T.Group();duct.name='normal-ventilation';laundry.name='laundry-room';scene.add(duct,laundry);duct.visible=laundry.visible=false;laundry.position.y=LAUNDRY_FLOOR;
 let secretWasher=null;const boxes=[],machines=[],dryers=[],coffee=new T.Group(),cups=[];coffee.name='vintage-coffee-machine';
 const unit=new T.BoxGeometry(1,1,1),cylinders=new Map();
 function material(kind,color,roughness=.8,metalness=0){const maps=agedSurface(kind);return new T.MeshStandardMaterial({color,map:maps.color,normalMap:maps.normal,normalScale:new T.Vector2(.22,.22),roughnessMap:maps.roughness,roughness,metalness});}
 const metal=material('metal',0xc6c9bd,.61,.66),dark=material('metal',0x3a4140,.69,.55),rust=material('rust',0x7c6552,.92,.35),enamel=material('plastic',0xe0e7db,.65,.14),rubber=material('plastic',0x1c2424,.96),linen=material('cloth',0xfffbed,.95),wood=material('wood',0x9b8565,.88),concrete=material('concrete',0x666d68,.94),ceramic=new T.MeshStandardMaterial({color:0xd3d0bd,roughness:.39}),glass=new T.MeshStandardMaterial({color:0x1b343a,roughness:.19,metalness:.55}),water=new T.MeshStandardMaterial({color:0x2b3b38,roughness:.19,metalness:.22,transparent:true,opacity:.34});
 function mesh(g,m,parent= laundry){const o=new T.Mesh(g,m);o.castShadow=o.receiveShadow=true;parent.add(o);return o;}
 function box(w,h,d,x,y,z,m=metal,parent=laundry){const o=mesh(unit,m,parent);o.scale.set(w,h,d);o.position.set(x,y,z);return o;}
 function cylinder(r,h,x,y,z,m=metal,parent=laundry,r2=r){const key=[r,r2,h].join(':');if(!cylinders.has(key))cylinders.set(key,new T.CylinderGeometry(r2,r,h,24));const o=mesh(cylinders.get(key),m,parent);o.position.set(x,y,z);return o;}
 function ring(r,t,x,y,z,m,parent=laundry){const o=mesh(new T.TorusGeometry(r,t,8,40),m,parent);o.position.set(x,y,z);return o;}
 function collider(x,z,w,d){boxes.push({minX:x-w/2,maxX:x+w/2,minZ:z-d/2,maxZ:z+d/2});}
 function bolt(x,y,z,parent=laundry){return cylinder(.014,.012,x,y,z,dark,parent);}
 function tiles(){const c=document.createElement('canvas');c.width=c.height=512;const ctx=c.getContext('2d');ctx.fillStyle='#b3b9ae';ctx.fillRect(0,0,512,512);let seed=49;const rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);for(let y=0;y<512;y+=64)for(let x=0;x<512;x+=64){ctx.fillStyle=`rgb(${171+rand()*22},${178+rand()*20},${164+rand()*20})`;ctx.fillRect(x+2,y+2,60,60);if(rand()<.17){ctx.fillStyle='#515d4b25';ctx.fillRect(x+4,y+5,8+rand()*30,55);}}for(let i=0;i<60;i++){ctx.strokeStyle='#303b2820';ctx.beginPath();const x=rand()*512,y=rand()*512;ctx.moveTo(x,y);ctx.lineTo(x+rand()*6,y+rand()*50);ctx.stroke();}const tex=new T.CanvasTexture(c);tex.colorSpace=T.SRGBColorSpace;tex.wrapS=tex.wrapT=T.RepeatWrapping;return new T.MeshStandardMaterial({map:tex,bumpMap:tex,bumpScale:.009,color:0xd2d6ca,roughness:.86});}
 const tile=tiles();
 function wall(w,h,d,x,y,z,m=tile){const o=box(w,h,d,x,y,z,m);o.geometry=unit.clone();const uv=o.geometry.attributes.uv;for(let i=0;i<uv.count;i++){if(z===22.16){const p=o.geometry.attributes.position;uv.setXY(i,(28.95-(x+p.getX(i)*w))/2,(y+p.getY(i)*h)/2);}else uv.setXY(i,uv.getX(i)*Math.max(w,d)/2,uv.getY(i)*h/2);}return o;}
 // The 12 x 10 metre shell has an actual raised opening on its west wall.
 for(const [w,d,x,z]of [[5.15,10.10,19.325,17.03],[6.27,10.10,25.815,17.03],[.78,9.28,22.29,17.44]]){const floor=box(w,.16,d,x,-.08,z,concrete);floor.geometry=unit.clone();const p=floor.geometry.attributes.position,n=floor.geometry.attributes.normal,uv=floor.geometry.attributes.uv;for(let i=0;i<uv.count;i++)if(Math.abs(n.getY(i))>.5)uv.setXY(i,(p.getX(i)*w+x-16.75)/12.2,(22.08-(p.getZ(i)*d+z))/10.1);}box(12.2,.12,10.2,22.85,3.26,17.08,concrete);
 wall(12.2,3.2,.16,22.85,1.6,12);wall(10.33,3.2,.16,21.915,1.6,22.16);wall(.63,3.2,.16,28.635,1.6,22.16);wall(1.24,1.15,.16,27.70,2.625,22.16);wall(.16,3.2,10,28.93,1.6,17.08);
 wall(.16,3.2,4.48,16.77,1.6,14.32);wall(.16,3.2,4.48,16.77,1.6,19.84);wall(.16,1.8,1.04,16.77,.9,17.08);wall(.16,.48,1.04,16.77,2.96,17.08);
 // Open staff passage: 1.2 metres, with no new door or gameplay condition.
 wall(.14,3.2,2.3,24.85,1.6,13.23);wall(4.07,3.2,.14,26.885,1.6,15.58);wall(.14,.7,1.2,24.85,2.85,14.98);
 collider(24.85,13.23,.14,2.3);collider(26.885,15.58,4.07,.14);
 for(const x of [17.45,24.05,28.5]){cylinder(.043,3.05,x,1.525,12.26,rust);for(const y of [.4,1.8,2.8])box(.16,.055,.18,x,y,12.17,dark);}
 // Continuous pipe runs, with supports that actually meet the walls/ceiling.
 for(const z of [12.26,21.75]){const p=cylinder(.043,11.05,22.975,3.02,z,rust);p.rotation.z=Math.PI/2;for(const x of [19,22,25,28])cylinder(.009,.14,x,3.13,z,metal);}
 const returnPipe=cylinder(.043,9.49,28.5,3.02,17.005,rust);returnPipe.rotation.x=Math.PI/2;
 for(const z of [14.3,19.9]){const p=cylinder(.022,11.65,22.85,3.10,z,dark);p.rotation.z=Math.PI/2;for(const x of [18,23,28])cylinder(.008,.08,x,3.16,z,metal);}
 function appliance(x,z,dryer,index,angle){const g=new T.Group();g.position.set(x,0,z);g.rotation.y=angle;g.name=dryer?'industrial-dryer':'front-loading-washer';laundry.add(g);const h=dryer?1.6:1.12,w=dryer?1.04:.99,secret=!dryer&&index===3;
  if(secret){for(const xx of [-1,1])box(.055,h,.83,xx*(w/2-.0275),h/2,0,enamel,g);box(w,.10,.83,0,h-.05,0,enamel,g);box(w,.12,.83,0,.06,0,enamel,g);}else box(w,h,.83,0,h/2,0,enamel,g);box(w+.035,.045,.87,0,h+.015,0,metal,g);box(w-.04,.13,.06,0,h-.1,.446,dark,g);box(w-.07,.025,.025,0,.13,.435,rust,g);
  // Recessed drum, rubber seal, steel bezel and tinted glass are separate 3D layers.
  const cy=dryer?.79:.53,r=dryer?.36:.315;
  if(secret)secretWasher=createSecretWasher(g,{w,h,cy,r,enamel,metal,rubber,dark,glass});
  else{const recess=cylinder(r,.045,0,cy,.437,rubber,g);recess.rotation.x=Math.PI/2;ring(r,.031,0,cy,.47,metal,g);ring(r-.042,.018,0,cy,.482,rubber,g);const window=cylinder(r-.065,.018,0,cy,.482,glass,g);window.rotation.x=Math.PI/2;for(let k=0;k<3;k++){const a=k*Math.PI*2/3;box(.025,.14,.012,Math.sin(a)*r*.43,cy+Math.cos(a)*r*.43,.495,dark,g).rotation.z=-a;}box(.028,.18,.05,r-.02,cy,.51,dark,g);}
  if(!dryer)for(const y of [cy-.15,cy+.15])cylinder(.015,.085,-r-.03,y,.47,metal,g);
  box(.11,.035,.05,-w*.3,h-.105,.491,metal,g);
  for(let i=0;i<3;i++){const dial=cylinder(i===0?.038:.017,.025,.16+i*.092,h-.10,.492,i===0?metal:rubber,g);dial.rotation.x=Math.PI/2;}
  for(let i=0;i<6;i++)box(.045,.006,.008,-.18+i*.045,h-.10,.484,ceramic,g);
  for(const xx of [-w*.42,w*.42])for(const zz of [-.32,.32])cylinder(.035,.07,xx,.035,zz,rubber,g);
  if(index%2===0)box(.06,.018,.012,-w*.39,.21,.43,rust,g);
  collider(x,z,w+.08,.94);(dryer?dryers:machines).push(g);return g;
 }
 for(let i=0;i<4;i++)appliance(18.15+i*1.38,12.72,false,i,0);
 for(let i=0;i<3;i++)appliance(19.05+i*1.45,21.45,true,i,Math.PI);
 function towel(x,y,z,parent=laundry){for(let i=0;i<3;i++)box(.43,.055,.32,x+(i%2)*.009,y+i*.056,z,linen,parent);}
 towel(18.15,1.18,12.72);towel(20.91,1.18,12.72);
 // Metal shelving and clean linen contrast with damp tilework.
 for(const z of [19.5,20.6]){for(const x of [17.02,17.65])for(const zz of [z-.42,z+.42])box(.033,2.25,.033,x,1.125,zz,metal);for(const y of [.22,.9,1.58,2.2]){box(.7,.035,.9,17.34,y,z,metal);if(y<2)towel(17.34,y+.045,z);}collider(17.34,z,.72,.94);}
 function table(x,z,w,d,h,m=metal){box(w,.07,d,x,h,z,m);for(const xx of [-1,1])for(const zz of [-1,1])box(.055,h,.055,x+xx*(w/2-.08),h/2,z+zz*(d/2-.08),metal);collider(x,z,w,d);}
 table(23,18.6,2.2,1.05,.94);towel(22.45,1.0,18.6);towel(23.1,1.0,18.6);box(.26,.12,.18,23.68,1.04,18.55,wood);
 function basket(x,y,z,w=.65,d=.48,parent=laundry){box(w,.035,d,x,y,z,rubber,parent);for(let i=0;i<7;i++){const xx=x-w/2+i*w/6;for(const zz of [-1,1])box(.018,.4,.018,xx,y+.2,z+zz*d/2,metal,parent);}for(let i=0;i<5;i++){const zz=z-d/2+i*d/4;for(const xx of [-1,1])box(.018,.4,.018,x+xx*w/2,y+.2,zz,metal,parent);}for(const yy of [.11,.25,.4]){box(w,.018,.018,x,y+yy,z-d/2,metal,parent);box(w,.018,.018,x,y+yy,z+d/2,metal,parent);box(.018,.018,d,x-w/2,y+yy,z,metal,parent);box(.018,.018,d,x+w/2,y+yy,z,metal,parent);}}
 function cart(x,z){basket(x,.42,z,.9,.65);for(const xx of [-.36,.36])for(const zz of [-.25,.25]){box(.027,.33,.027,x+xx,.24,z+zz,metal);const wheel=cylinder(.075,.035,x+xx,.075,z+zz,rubber);wheel.rotation.x=Math.PI/2;}towel(x,.63,z);collider(x,z,.98,.73);}
 cart(20.1,15.25);cart(25.9,20.3);basket(23.6,.0175,20.7);collider(23.6,20.7,.65,.48);
 // Optional working brewer, independent of the room puzzles.
 table(27.1,12.72,2.4,.78,.98,wood);coffee.position.set(27.2,1.015,12.72);laundry.add(coffee);
 box(.30,.04,.26,0,.02,0,rubber,coffee);box(.29,.40,.065,0,.24,-.10,enamel,coffee);box(.31,.08,.27,0,.47,0,metal,coffee);box(.12,.19,.10,-.08,.31,.05,rubber,coffee);
 box(.08,.28,.10,.09,.28,-.025,glass,coffee);for(let i=0;i<5;i++)box(.025,.003,.003,.09,.20+i*.035,.028,ceramic,coffee);
 const carafe=new T.Group();carafe.position.set(.45,-.04,0);coffee.add(carafe);cylinder(.085,.16,0,.133,.035,glass,carafe,.065);cylinder(.085,.016,0,.048,.035,rubber,carafe);cylinder(.071,.025,0,.222,.035,rubber,carafe);const handle=ring(.06,.012,.11,.143,.04,rubber,carafe);handle.scale.set(.55,1,1);box(.06,.025,.05,.08,.395,.05,rust,coffee);
 function cup(x,z){const g=new T.Group();g.position.set(x,1.015,z);g.name='ceramic-cup';laundry.add(g);mesh(new T.LatheGeometry([new T.Vector2(.034,0),new T.Vector2(.045,.009),new T.Vector2(.047,.085),new T.Vector2(.039,.085),new T.Vector2(.035,.015),new T.Vector2(0,.015)],24),ceramic,g);ring(.026,.008,.065,.044,0,ceramic,g);cups.push(g);}
 cup(26.48,12.75);cup(26.68,12.65);
 const portraits=createStaffPortraits(laundry,{wood,metal,rust});
 const coffeePlay=createCoffeePlay(laundry,coffee,cups,boxes,LAUNDRY_BOUNDS);
 box(.82,1.65,.53,28.3,.825,13.65,wood);for(const y of [.5,1.15]){box(.77,.59,.035,28.3,y,13.94,enamel);box(.15,.022,.03,28.3,y+.1,13.97,dark);}collider(28.3,13.65,.86,.59);
 box(.46,.055,.46,26.45,.49,14.45,wood);box(.46,.6,.045,26.45,.78,14.66,wood);for(const x of [26.27,26.63])for(const z of [14.27,14.63])box(.035,.48,.035,x,.24,z,metal);collider(26.45,14.45,.5,.53);
 // Heavy future exit: closed slab and solid outer-wall collision, no interaction.
 const door=new T.Group();door.name='closed-future-exit';door.position.set(28.75,0,18);laundry.add(door);box(.022,2.34,1.28,.053,1.17,0,rubber,door);box(.08,2.30,1.22,0,1.165,0,dark,door);for(const z of [-.67,.67])box(.16,2.4,.08,0,1.2,z,metal,door);box(.16,.09,1.42,0,2.38,0,metal,door);for(const y of [.3,1.1,2]){cylinder(.025,.17,-.058,y,-.623,metal,door);box(.012,.12,.07,-.046,y,-.588,metal,door);box(.012,.12,.06,-.086,y,-.662,metal,door);}box(.065,.035,.22,-.07,1.02,.33,metal,door);box(.012,.68,.71,-.045,1.65,0,rust,door);collider(28.75,18,.16,1.4);
 for(const [x,z,s]of [[18.5,19,.55],[21,13.8,.35],[24.2,21,.5]]){const puddle=mesh(new T.CircleGeometry(s,24),water);puddle.rotation.x=-Math.PI/2;puddle.scale.y=.55;puddle.position.set(x,.008,z);puddle.castShadow=false;}
 // Fluorescents use four finite lights, one shadow map; staff area is warmer.
 const fixtures=[],ambient=new T.HemisphereLight(0xbecdc5,0x333b32,.58);laundry.add(ambient);
 for(const [i,[x,z]]of [[19.4,15],[23.1,15.8],[21.4,19.4],[26.6,13.7]].entries()){
  const housing=box(1.3,.10,.22,x,3.12,z,dark);housing.castShadow=false;for(const dx of [-.45,.45]){const mount=box(.012,.04,.06,x+dx,3.19,z,dark);mount.castShadow=false;}const glow=new T.MeshStandardMaterial({color:i===3?0xe8c581:0xd8e6d8,emissive:i===3?0xe4b459:0xc8ddcc,emissiveIntensity:1.1,roughness:.5});for(const dz of [-.065,.065]){const tube=cylinder(.025,1.16,x,3.05,z+dz,glow);tube.rotation.z=Math.PI/2;tube.castShadow=false;}
  const light=new T.PointLight(i===3?0xffd293:0xd8efdc,i===3?9:23,7,2);light.position.set(x,2.95,z);laundry.add(light);if(i===0){light.castShadow=true;light.shadow.mapSize.set(512,512);light.shadow.camera.near=.2;light.shadow.camera.far=8;light.shadow.bias=-.001;light.shadow.normalBias=.025;}fixtures.push({light,power:light.intensity,glow});
 }
 // Sheet metal duct: exactly one elbow. The laundry is visible through the exit.
 const dm=material('metal',0xb6c4bc,.68,.65),seam=material('rust',0x7e8477,.81,.5);
 function db(w,h,d,x,y,z,m=dm){return box(w,h,d,x,y,z,m,duct);}
 db(1.04,.07,6.52,10.35,DUCT_FLOOR-.035,14.34);db(1.04,.07,6.52,10.35,3.60,14.34);db(5.98,.07,1.04,13.86,DUCT_FLOOR-.035,17.08);db(5.98,.07,1.04,13.86,3.60,17.08);
 db(.06,.96,6.52,9.80,3.12,14.34);db(.06,.96,5.48,10.90,3.12,13.82);db(7.02,.96,.06,13.34,3.12,17.63);db(5.98,.96,.06,13.86,3.12,16.53);
 for(let z=11.65;z<17.3;z+=1.05){if(z<16.56)db(1.04,.014,.022,10.35,DUCT_FLOOR+.007,z,seam);for(const x of [9.835,10.865]){if(x>10&&z>16.56)continue;db(.018,.94,.035,x,3.12,z,seam);bolt(x,DUCT_FLOOR+.02,z,duct);}}
 for(let x=11.4;x<16.8;x+=1.05){db(.022,.014,1.04,x,DUCT_FLOOR+.007,17.08,seam);for(const z of [16.565,17.595]){db(.035,.94,.018,x,3.12,z,seam);bolt(x,DUCT_FLOOR+.02,z,duct);}}
 const da=new T.HemisphereLight(0x7e9d9c,0x333d38,.46);duct.add(da);
 for(const [x,z]of [[10.35,12.4],[10.35,16.9],[14.2,17.08]]){const l=new T.PointLight(0x9ebbb6,.95,3.5,2);l.position.set(x,3.38,z);duct.add(l);const strip=new T.MeshStandardMaterial({color:0x9cb9ae,emissive:0x91b3a8,emissiveIntensity:.7});db(.12,.006,.018,x,3.562,z,strip);}
 // Hinged exit grille, excluding its invisible hit volume from occlusion.
 const grille=new T.Group();grille.name='laundry-exit-grille';grille.position.set(EXIT_GRILLE.x,DUCT_FLOOR+.46,EXIT_GRILLE.z-.52);duct.add(grille);
 for(const z of [0,1.04])box(.035,.88,.045,0,0,z,metal,grille);for(const y of [-.4175,.4175])box(.035,.045,1.08,0,y,.52,metal,grille);for(let y=-.33;y<.4;y+=.09)box(.028,.035,1.0,0,y,.52,metal,grille);
 const hit=mesh(new T.BoxGeometry(.08,.88,1.04),new T.MeshBasicMaterial({visible:false}),duct);hit.position.copy(new T.Vector3(EXIT_GRILLE.x,DUCT_FLOOR+.46,EXIT_GRILLE.z));hit.userData.noOcclude=true;
 const target={root:hit,object:grille,kind:'laundry-grille'};
 // Batch static primitives by material. The sole moving grille stays separate.
 function batch(root,skip){root.updateMatrixWorld(true);const groups=new Map(),inverse=root.matrixWorld.clone().invert(),remove=[];root.traverse(o=>{if(!o.isMesh||skip(o)||o.material.transparent)return;const g=o.geometry.clone().applyMatrix4(new T.Matrix4().multiplyMatrices(inverse,o.matrixWorld));const key=o.material.uuid+':'+o.castShadow+':'+o.receiveShadow;if(!groups.has(key))groups.set(key,{material:o.material,cast:o.castShadow,receive:o.receiveShadow,parts:[]});groups.get(key).parts.push(g);remove.push(o);});for(const {material,cast,receive,parts}of groups.values()){const g=mergeGeometries(parts);if(g){const o=mesh(g,material,root);o.castShadow=cast;o.receiveShadow=receive;o.name='batched-laundry-detail';}for(const p of parts)p.dispose();}for(const o of remove)o.removeFromParent();}
 batch(laundry,o=>{for(let p=o;p;p=p.parent)if(p===coffee||cups.includes(p)||p===coffeePlay.effects||p===secretWasher?.door||p===secretWasher?.hit)return true;return false;});batch(duct,o=>{for(let p=o;p;p=p.parent)if(p===grille)return true;return o===hit;});
 const laundryOccluders=[];laundry.traverse(o=>{if(o.isMesh&&o.material.visible!==false&&!o.userData.noOcclude)laundryOccluders.push(o);});
 const occluders=[];duct.traverse(o=>{if(o.isMesh&&o.material.visible!==false)occluders.push(o);});
 return {wallMaterial:tile,duct:{root:duct,bounds:DUCT_BOUNDS,boxes:DUCT_BOXES,targets:[target],occluders},laundry:{root:laundry,bounds:LAUNDRY_BOUNDS,boxes,targets:[...coffeePlay.targets,secretWasher.target],occluders:laundryOccluders},machines,dryers,coffee,cups,portraits,coffeePlay,secretWasher,door,grille,fixtures,update(time,opening){grille.rotation.y=T.MathUtils.damp(grille.rotation.y,opening?-1.5:0,9,.05);for(const [i,f]of fixtures.entries()){const phase=(time+i*9.1)%23.7,dip=i<3&&phase>21.1&&phase<21.34?(Math.sin(time*73)>.1?.50:.85):1;f.light.intensity=f.power*dip;f.glow.emissiveIntensity=1.1*dip;}}};
}
