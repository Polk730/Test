import * as T from 'three';
import {BASEMENT_LANDING} from './basement-layout.js';
export const SLIDE_SECONDS=3.5;
const v=(x,y,z)=>new T.Vector3(x,y,z);
export const CHUTE_CURVE=new T.CatmullRomCurve3([v(22.29,1.37,12.83),v(22.29,.43,12.13),v(22.85,-.50,12.05),v(23.65,-.96,13.2),v(23.65,-.96,17),v(23.65,-.96,21.2),v(23.65,-.96,23.05)],false,'centripetal');
export class BasementJourney {
 constructor(){this.doorOpen=false;this.sliding=false;this.time=0;this.startYaw=0;this.startPitch=0;this.yaw=0;this.approach=null;}
 open(){if(this.doorOpen||this.sliding)return false;this.doorOpen=true;return true;}
 enter(position,yaw,pitch){if(!this.doorOpen||this.sliding)return false;this.sliding=true;this.time=0;this.startYaw=this.yaw=yaw;this.startPitch=pitch;this.approach=new T.CatmullRomCurve3([v(position.x,position.y,position.z),v(22.29,position.y,13.75),v(22.29,1.37,13.43),v(22.29,1.37,13.17),CHUTE_CURVE.getPoint(0)],false,'centripetal');return true;}
 update(dt){if(!this.sliding||!Number.isFinite(dt)||dt<=0)return null;this.time=Math.min(SLIDE_SECONDS,this.time+dt);let position,yaw,pitch;
 if(this.time<.9){const t=this.time/.9,s=t*t*(3-2*t);position=this.approach.getPointAt(s);const d=Math.atan2(Math.sin(-this.startYaw),Math.cos(-this.startYaw));yaw=this.startYaw+d*s;pitch=this.startPitch*(1-s);}
 else if(this.time<3.15){const t=(this.time-.9)/2.25;position=CHUTE_CURVE.getPointAt(t);const d=CHUTE_CURVE.getTangentAt(t);yaw=Math.atan2(-d.x,-d.z);pitch=T.MathUtils.clamp(Math.atan2(d.y,Math.hypot(d.x,d.z)),-.45,.2);}
 else{const t=(this.time-3.15)/.35,s=t*t*(3-2*t);position=CHUTE_CURVE.getPoint(1).lerp(v(BASEMENT_LANDING.x,BASEMENT_LANDING.y,BASEMENT_LANDING.z),s);yaw=-Math.PI;pitch=0;}
 const delta=Math.atan2(Math.sin(yaw-this.yaw),Math.cos(yaw-this.yaw));this.yaw+=delta*Math.min(1,dt*15);const done=this.time>=SLIDE_SECONDS;if(done){this.sliding=false;position=v(BASEMENT_LANDING.x,BASEMENT_LANDING.y,BASEMENT_LANDING.z);this.yaw=-Math.PI;pitch=0;}return {position,yaw:this.yaw,pitch,done};
 }
}
