import {agedSurface} from './aged-surface.js';
export function storageSurface(kind,seed=401){const s=agedSurface(kind,seed);return {map:s.color,normalMap:s.normal,roughnessMap:s.roughness};}
