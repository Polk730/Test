import * as T from 'three';
import {agedSurface} from './aged-surface.js';
// Visual replacement only. The reserved-wrench parent, hidden state and hit target remain original.
export function createWrenchVisual(){
 const group=new T.Group();group.name='forged-open-jaw-wrench';
 const maps=agedSurface('metal',1986),steel=new T.MeshStandardMaterial({map:maps.color,normalMap:maps.normal,normalScale:new T.Vector2(.16,.16),roughnessMap:maps.roughness,metalnessMap:maps.roughness,metalness:.88,roughness:.72,color:0xc6c8c1,envMapIntensity:1.1});
 const shape=new T.Shape();
 // A forged handle flowing into two open jaws. Coordinates are in the original X/Z footprint.
 shape.moveTo(-.020,-.126);shape.quadraticCurveTo(-.031,-.122,-.030,-.103);shape.lineTo(-.019,.063);shape.quadraticCurveTo(-.060,.077,-.055,.120);shape.quadraticCurveTo(-.051,.151,-.030,.158);shape.lineTo(-.027,.124);shape.lineTo(.006,.107);shape.lineTo(.030,.130);shape.lineTo(.027,.162);shape.quadraticCurveTo(.061,.146,.058,.112);shape.quadraticCurveTo(.055,.083,.021,.065);shape.lineTo(.030,-.103);shape.quadraticCurveTo(.031,-.124,.020,-.126);shape.quadraticCurveTo(0,-.134,-.020,-.126);
 const hole=new T.Path();hole.absellipse(0,-.108,.009,.009,0,Math.PI*2,true);shape.holes.push(hole);
 const body=new T.ExtrudeGeometry(shape,{depth:.012,bevelEnabled:true,bevelSize:.0024,bevelThickness:.0016,bevelSegments:2,steps:1,curveSegments:12});body.translate(0,0,-.006);body.rotateX(Math.PI/2);
 const mesh=new T.Mesh(body,steel);mesh.castShadow=mesh.receiveShadow=true;group.add(mesh);
 const inset=new T.Shape();inset.moveTo(-.008,-.083);inset.lineTo(-.008,.047);inset.quadraticCurveTo(0,.057,.008,.047);inset.lineTo(.008,-.083);inset.quadraticCurveTo(0,-.092,-.008,-.083);const insetGeo=new T.ShapeGeometry(inset,12);insetGeo.rotateX(Math.PI/2);insetGeo.translate(0,.008,0);const insetMaterial=steel.clone();insetMaterial.color.set(0x7d827c);insetMaterial.roughness=.85;insetMaterial.side=T.DoubleSide;group.add(new T.Mesh(insetGeo,insetMaterial));
 const c=document.createElement('canvas');c.width=256;c.height=64;const ctx=c.getContext('2d');ctx.clearRect(0,0,256,64);ctx.fillStyle='#343b35';ctx.font='bold 28px monospace';ctx.textAlign='center';ctx.fillText('DROP FORGED',128,27);ctx.font='18px monospace';ctx.fillText('CHROME VANADIUM',128,52);const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;const stamp=new T.Mesh(new T.PlaneGeometry(.015,.075),new T.MeshBasicMaterial({map:t,transparent:true,depthWrite:false,toneMapped:false}));stamp.rotation.x=-Math.PI/2;stamp.position.set(0,.0083,-.013);group.add(stamp);
 // Cross section stays within original .018 height; no collider or new interaction.
 return group;
}
