import * as T from 'three';
import {random} from './textures.js';
// Visual guides only: they do not move boxes, grant rewards, or unlock the vent.
export const BOX_FLOOR_MARKINGS=[{id:1,x:10.35,z:9.8},{id:2,x:10.35,z:10.45},{id:3,x:10.35,z:10.45,stackOn:2}];
export function createBoxFloorMarkings(root){
 const marks=[];for(const p of BOX_FLOOR_MARKINGS){if(p.stackOn){const base=marks.find(m=>m.id===p.stackOn);marks.push({...p,root:base.root});continue;}const c=document.createElement('canvas');c.width=c.height=512;const ctx=c.getContext('2d'),r=random(321+p.id);ctx.strokeStyle='#d4cbb3';ctx.lineWidth=9;ctx.lineCap='square';
  ctx.strokeRect(33,33,446,446);ctx.textAlign='center';ctx.fillStyle='#d4cbb3';ctx.font='bold 48px monospace';ctx.fillText(p.id===1?'FIRST STEP':'STACK HERE',256,135);ctx.font=`bold ${p.id===1?190:125}px monospace`;ctx.fillText(p.id===1?'1':'2 + 3',256,330);if(p.id===2){ctx.font='bold 32px monospace';ctx.fillText('3 ON TOP OF 2',256,405);}
  ctx.globalCompositeOperation='destination-out';for(let i=0;i<1600;i++){ctx.fillStyle=`rgba(0,0,0,${r()*.5})`;ctx.fillRect(r()*512,r()*512,1+r()*6,1+r()*3);}
  const map=new T.CanvasTexture(c);map.colorSpace=T.SRGBColorSpace;map.anisotropy=4;const material=new T.MeshStandardMaterial({map,transparent:true,opacity:.78,roughness:1,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});const mesh=new T.Mesh(new T.PlaneGeometry(.62,.62),material);mesh.name=`box-floor-mark-${p.id}`;mesh.rotation.set(-Math.PI/2,0,Math.PI);mesh.position.set(p.x,.013,p.z);mesh.receiveShadow=true;mesh.userData.noOcclude=true;root.add(mesh);marks.push({...p,root:mesh});}return marks;
}
