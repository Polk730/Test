import {move,PLAYER_RADIUS} from './physics.js';
import {LAUNDRY_FLOOR} from './laundry-layout.js';
export const BASEMENT_ROOM=6,BASEMENT_FLOOR=LAUNDRY_FLOOR-2.6,BASEMENT_CEILING=BASEMENT_FLOOR+2.2;
export const BASEMENT_BOUNDS={minX:23,maxX:29,minZ:22.08,maxZ:28.08,height:2.2};
export const STAIRS={minX:27.08,maxX:28.32,minZ:22.08,maxZ:25.98,steps:18};
export const BASEMENT_LANDING={x:23.65,y:BASEMENT_FLOOR+1.65,z:23.6};
export const BASEMENT_WALK_BOUNDS={minX:16.85,maxX:29,minZ:12.08,maxZ:28.08};
export function basementFloorAt(x,z){if(z<=STAIRS.minZ)return LAUNDRY_FLOOR;if(x>=STAIRS.minX&&x<=STAIRS.maxX&&z<STAIRS.maxZ){const index=Math.min(STAIRS.steps-1,Math.floor((z-STAIRS.minZ)/(STAIRS.maxZ-STAIRS.minZ)*STAIRS.steps));return LAUNDRY_FLOOR-(index+1)*(LAUNDRY_FLOOR-BASEMENT_FLOOR)/STAIRS.steps;}return BASEMENT_FLOOR;}
export const BASEMENT_BOUNDARIES=[
 {minX:16.65,maxX:16.85,minZ:11.88,maxZ:22.08},{minX:28.85,maxX:29.05,minZ:11.88,maxZ:22.08},
 {minX:16.65,maxX:29.05,minZ:11.88,maxZ:12.08},{minX:16.65,maxX:27.08,minZ:22.08,maxZ:22.24},{minX:28.32,maxX:29.05,minZ:22.08,maxZ:22.24},
 {minX:22.8,maxX:23,minZ:22.08,maxZ:28.28},{minX:29,maxX:29.2,minZ:22.08,maxZ:28.28},{minX:23,maxX:29,minZ:28.08,maxZ:28.28},
 {minX:23,maxX:27.08,minZ:21.92,maxZ:22.08},{minX:28.32,maxX:29,minZ:21.92,maxZ:22.08},
 {minX:27.02,maxX:27.23,minZ:22.08,maxZ:25.98},{minX:28.17,maxX:28.38,minZ:22.08,maxZ:25.98}
];
export const BASEMENT_DAMP=[{x:25.5,z:25.2,r:.4},{x:24.2,z:27.2,r:.34},{x:26.5,z:23.6,r:.25}];
export const basementWet=(x,z)=>BASEMENT_DAMP.some(p=>Math.hypot(x-p.x,z-p.z)<p.r);

// The return gate permits upward exit only. Clamp the swept crossing before collision substeps,
// so a fast diagonal move cannot enter from Laundry or leave the player embedded in a blocker.
export const STAIR_EXIT_Z=STAIRS.minZ-PLAYER_RADIUS;
export function walkBasement(position,dx,dz,boxes,bounds=BASEMENT_WALK_BOUNDS){
 if(dz>0&&position.z<=STAIR_EXIT_Z+1e-7&&position.z+dz>STAIR_EXIT_Z){
  const t=(STAIR_EXIT_Z-position.z)/dz,x=position.x+dx*t;
  if(x>STAIRS.minX-PLAYER_RADIUS&&x<STAIRS.maxX+PLAYER_RADIUS)dz=Math.max(0,STAIR_EXIT_Z-position.z);
 }
 return move(position,dx,dz,boxes,bounds);
}
