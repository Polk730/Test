import * as T from 'three';
import {random} from './textures.js';

// One inexpensive transparent decal: waxy, broken strokes, each group counts five days.
export function addTallyWall(scene){
 const canvas=document.createElement('canvas');canvas.width=2048;canvas.height=1280;
 const c=canvas.getContext('2d'),r=random(20753);
 function stroke(x1,y1,x2,y2){
  for(let pass=0;pass<3;pass++){
   c.strokeStyle=`rgba(72,31,27,${.27+r()*.17})`;c.lineWidth=2+r()*2;c.lineCap='round';
   const dx=(r()-.5)*3,dy=(r()-.5)*3;c.beginPath();c.moveTo(x1+dx,y1+dy);
   for(let i=1;i<=8;i++){const t=i/8;c.lineTo(x1+(x2-x1)*t+dx+(r()-.5)*3,y1+(y2-y1)*t+dy+(r()-.5)*3);}c.stroke();
  }
 }
 for(let row=0;row<13;row++)for(let col=0;col<15;col++){
  const x=38+col*132+(r()-.5)*12,y=34+row*95+(r()-.5)*15;
  const height=53+r()*16,slant=(r()-.5)*8;
  for(let n=0;n<4;n++){const sx=x+n*21+(r()-.5)*5;stroke(sx,y+(r()-.5)*6,sx+slant,y+height+(r()-.5)*5);}
  stroke(x-8,y+height-2,x+76,y+7);
 }
 // The wax skips on plaster grain; avoid clean vector-like lines and perfect repeats.
 const pixels=c.getImageData(0,0,canvas.width,canvas.height);
 for(let i=3;i<pixels.data.length;i+=4)if(pixels.data[i]){pixels.data[i]*=r()<.14?.12:.5+r()*.5;}
 c.putImageData(pixels,0,0);
 const map=new T.CanvasTexture(canvas);map.colorSpace=T.SRGBColorSpace;map.anisotropy=4;
 const material=new T.MeshStandardMaterial({map,transparent:true,depthWrite:false,roughness:1,metalness:0,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});
 const wall=new T.Mesh(new T.PlaneGeometry(3.88,2.44),material);wall.name='crayon-tally-wall';wall.position.set(-2.495,1.4,0);wall.rotation.y=Math.PI/2;wall.receiveShadow=true;wall.userData.noBatch=true;wall.userData.noOcclude=true;scene.add(wall);
 return wall;
}
