export const OBSERVATION_BOUNDS={minX:.6,maxX:7.6,minZ:2.08,maxZ:8.08,height:3.25};
export const TAPE_HOMES=Object.freeze([{x:1.6,y:.88,z:4.25},{x:6.93,y:1.09,z:4.6},{x:6.9,y:1.17,z:7.05}]);
// Physical locations deliberately do not encode the chronology: desk=discovery, shelf=after, cabinet=before.
export const TAPE_RECORDINGS=Object.freeze([1,2,0]);
export class ObservationArchive {
 constructor(){this.reset();}
 reset(){this.time=0;this.entered=false;this.held=null;this.player=null;this.slots=[null,null,null];this.tapes=TAPE_HOMES.map((p,id)=>({id,...p,place:'world',falling:false,velocity:0}));this.picked=new Set();this.viewed=new Set();this.events={monitors:false,recognition:false,dip:false,live:false};this.signals=[];this.queue=[];this.currentCaption=null;this.recognitionUntil=0;this.dipUntil=0;this.flickerUntil=0;this.playing=false;this.playAt=0;this.solvedAt=0;this.lastRecording=null;this.solved=false;this.doorOpen=false;this.ended=false;this.status='';this.statusUntil=0;}
 enter(){if(this.entered)return;this.entered=true;}
 captionLine(text,duration=3.6){if(!this.events.live)this.queue.push({text:'(Narrator) '+text,duration});}
 pickup(id){const t=this.tapes[id];if(this.held!==null||!t||t.place!=='world')return false;this.take(id);this.signals.push('pickup');return true;}
 take(id){const t=this.tapes[id];this.held=id;t.place='held';t.falling=false;this.picked.add(id);if(this.picked.size===2&&!this.events.recognition){this.events.recognition=true;this.recognitionUntil=this.time+2;this.flickerUntil=this.time+.25;this.signals.push('recognition');}}
 insertPlayer(){if(this.held===null||this.player!==null)return false;this.player=this.held;this.tapes[this.held].place='player';this.held=null;this.playing=true;this.playAt=this.time;this.lastRecording=this.player;this.signals.push('insert');return true;}
 ejectPlayer(){if(this.held!==null||this.player===null)return false;const id=this.player;this.player=null;this.playing=false;this.take(id);this.signals.push('eject');return true;}
 slot(index){if(index<0||index>2)return false;if(this.held!==null&&this.slots[index]===null){const id=this.held;this.slots[index]=id;this.tapes[id].place='slot';this.held=null;this.signals.push('slot');return true;}if(this.held===null&&this.slots[index]!==null){const id=this.slots[index];this.slots[index]=null;this.take(id);this.signals.push('eject');return true;}return false;}
 get canVerify(){return !this.solved&&this.slots.every(id=>id!==null);}
 verify(){if(!this.canVerify)return null;if(!this.slots.every((id,i)=>TAPE_RECORDINGS[id]===i)){this.status='SEQUENCE INVALID';this.statusUntil=this.time+3;this.signals.push('invalid');return false;}this.solved=true;this.solvedAt=this.time;this.events.live=true;this.status='ARCHIVE RESTORED';this.queue=[];this.currentCaption=null;this.signals.push('live');return true;}
 openDoor(){if(!this.solved)return false;if(!this.doorOpen){this.doorOpen=true;this.signals.push('door');}return true;}
 exit(position){if(this.ended||!this.doorOpen||position.z<8.24||position.x<5.85||position.x>6.85)return false;this.ended=true;return true;}
 drop(position,yaw,obstacles,bounds=OBSERVATION_BOUNDS){if(this.held===null)return false;const h=.17,clear=(x,z)=>x>bounds.minX+h&&x<bounds.maxX-h&&z>bounds.minZ+h&&z<Math.min(bounds.maxZ,8.08)-h&&!obstacles.some(o=>x>o.minX-h&&x<o.maxX+h&&z>o.minZ-h&&z<o.maxZ+h)&&!this.tapes.some(t=>t.id!==this.held&&t.place==='world'&&Math.hypot(x-t.x,z-t.z)<.28);
  for(const d of [.55,.8,.4])for(const a of [0,.55,-.55,1.1,-1.1,Math.PI/2,-Math.PI/2,Math.PI]){const x=position.x-Math.sin(yaw+a)*d,z=position.z-Math.cos(yaw+a)*d;if(!clear(x,z))continue;let blocked=false;for(let s=.05;s<=d;s+=.05){const px=position.x+(x-position.x)*s/d,pz=position.z+(z-position.z)*s/d;if(obstacles.some(o=>px>o.minX-.06&&px<o.maxX+.06&&pz>o.minZ-.06&&pz<o.maxZ+.06)){blocked=true;break;}}if(blocked)continue;Object.assign(this.tapes[this.held],{x,z,y:Math.max(.18,position.y-.3),velocity:0,place:'world',falling:true});this.held=null;return true;}return false;
 }
 update(seconds,physicsSeconds,canNarrate=true){if(!this.entered)return;this.time+=Math.max(0,seconds);if(!this.events.live&&!this.events.monitors&&this.time>=2.7){this.events.monitors=true;this.signals.push('startup');this.captionLine("Oh... this room. I was hoping we'd skip this one.",4.1);}
  if(this.playing&&this.time-this.playAt>=7){this.viewed.add(this.player);this.playing=false;if(this.viewed.size===3&&!this.events.dip&&!this.events.live){this.events.dip=true;this.dipUntil=this.time+1;this.flickerUntil=this.time+.3;this.signals.push('dip');this.captionLine("Don't worry. Those cameras haven't worked in years.",4);this.captionLine('...Apparently, I was wrong.',2.6);}}
  for(const t of this.tapes)if(t.falling){t.velocity-=9.8*physicsSeconds;t.y+=t.velocity*physicsSeconds;if(t.y<=.045){t.y=.045;t.velocity=0;t.falling=false;this.signals.push('land');}}
  if(this.statusUntil&&this.time>=this.statusUntil&&!this.solved){this.status='';this.statusUntil=0;}
  if(this.events.live){this.currentCaption=null;this.queue=[];return;}if(this.currentCaption&&this.time>=this.currentCaption.until)this.currentCaption=null;
  if(!this.currentCaption&&canNarrate&&this.queue.length){const next=this.queue.shift();this.currentCaption={text:next.text,until:this.time+next.duration};if(next.text.includes('Apparently'))this.flickerUntil=this.time+.25;}
 }
 get caption(){return this.events.live?'':this.currentCaption?.text||'';}
}
