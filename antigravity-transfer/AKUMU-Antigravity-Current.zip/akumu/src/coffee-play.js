import * as T from 'three';
import {collides,move,PLAYER_RADIUS} from './physics.js';
import {CoffeeState,COFFEE_BREW_SECONDS} from './coffee-state.js';

export function createCoffeePlay(parent,machine,cups,boxes,bounds){
 let floorAt=()=>parent.position.y,carryVisible=true;const model=new CoffeeState(),effects=new T.Group();effects.name='coffee-effects';parent.add(effects);
 const homes=cups.map(c=>c.position.clone()),floorPos=cups.map(c=>c.position.clone()),targets=[];
 const coffeeMaterial=new T.MeshStandardMaterial({color:0x351407,roughness:.28,metalness:0});
 function target(root,kind,object,id){const hit=new T.Mesh(new T.BoxGeometry(...(kind==='coffee-machine'?[.34,.30,.19]:[.14,.105,.14])),new T.MeshBasicMaterial({visible:false}));root.add(hit);hit.position.set(0,kind==='coffee-machine'?.335:.045,kind==='coffee-machine'?-.015:0);hit.userData.noOcclude=true;targets.push({root:hit,object,kind,cupId:id,enabled:()=>kind==='coffee-machine'||model.cups[id].place!=='held'&&!(model.brewing&&model.brewCup===id)});}
 target(machine,'coffee-machine',machine);
 const liquid=cups.map((cup,id)=>{target(cup,'coffee-cup',cup,id);const disk=new T.Mesh(new T.CircleGeometry(.037,24),coffeeMaterial);disk.rotation.x=-Math.PI/2;disk.position.y=.07;disk.visible=false;cup.add(disk);return disk;});
 const stream=new T.Mesh(new T.CylinderGeometry(.003,.0035,1,8),coffeeMaterial);stream.visible=false;machine.add(stream);
 const spout=new T.Mesh(new T.CylinderGeometry(.009,.007,.025,12),new T.MeshStandardMaterial({color:0x55554a,roughness:.6,metalness:.6}));spout.position.set(-.075,.205,.075);machine.add(spout);
 const spillGeometry=new T.CircleGeometry(.17,32),pos=spillGeometry.attributes.position;for(let i=1;i<pos.count;i++){const v=new T.Vector3().fromBufferAttribute(pos,i);v.multiplyScalar(.92+.08*Math.sin(i*2.1));pos.setXYZ(i,v.x,v.y,v.z);}spillGeometry.computeVertexNormals();
 const spillMaterial=new T.MeshStandardMaterial({color:0x301306,roughness:.19,transparent:true,opacity:.82,depthWrite:false});
 const spill=new T.Mesh(spillGeometry,spillMaterial);spill.rotation.x=-Math.PI/2;spill.position.set(machine.position.x,1.018,machine.position.z+.22);spill.visible=false;effects.add(spill);
 const overflow=new T.Mesh(new T.CylinderGeometry(.0025,.002,1,6),coffeeMaterial);overflow.position.set(machine.position.x,1.035,machine.position.z+.13);overflow.scale.y=.04;overflow.visible=false;effects.add(overflow);
 const shadowFlags=new Map();for(const cup of cups)cup.traverse(o=>{if(o.isMesh)shadowFlags.set(o,o.castShadow);});
 const slot=machine.position.clone().add(new T.Vector3(-.075,.04,.075));
 const carry=new T.Vector3(),offset=new T.Vector3(),q=new T.Quaternion();
 function drop(camera){if(model.held===null||model.drinkLeft>0)return false;const id=model.held;
  if(Math.hypot(camera.position.x-machine.position.x,camera.position.z-machine.position.z)<2.1)return model.drop('counter');
  const forward=new T.Vector3();camera.getWorldDirection(forward);forward.y=0;if(forward.lengthSq()<.01)forward.set(0,0,-1);forward.normalize();const p=new T.Vector3(camera.position.x+forward.x*.5,0,camera.position.z+forward.z*.5);
  if(p.x<bounds.minX+PLAYER_RADIUS||p.x>bounds.maxX-PLAYER_RADIUS||p.z<bounds.minZ+PLAYER_RADIUS||p.z>bounds.maxZ-PLAYER_RADIUS||collides(p.x,p.z,boxes,.07))return false;
  const safe=move(camera.position,p.x-camera.position.x,p.z-camera.position.z,boxes,bounds);if(Math.hypot(safe.x-p.x,safe.z-p.z)>.08)return false;floorPos[id].set(p.x,floorAt(p.x,p.z)-parent.position.y,p.z);return model.drop('floor');
 }
 function interact(focused,camera){if(focused?.kind==='coffee-machine')return model.useMachine();if(model.heldFull)return model.drink();if(focused?.kind==='coffee-cup')return model.pick(focused.cupId);if(model.held!==null)return drop(camera);return false;}
 function update(dt,camera){model.update(dt);for(const [id,cup]of cups.entries()){
   const state=model.cups[id];cup.visible=state.place!=='held'||carryVisible;cup.traverse(o=>{if(shadowFlags.has(o))o.castShadow=state.place==='held'?false:shadowFlags.get(o);});if(state.place==='held'){
    const sip=model.drinkLeft>0?Math.sin(Math.PI*(1-model.drinkLeft/.75)):0;offset.set(.18*(1-sip),-.23+.15*sip,-.42+.19*sip).applyQuaternion(camera.quaternion);carry.copy(camera.position).add(offset);const safe=move(camera.position,carry.x-camera.position.x,carry.z-camera.position.z,boxes,bounds);carry.x=safe.x;carry.z=safe.z;parent.worldToLocal(carry);cup.position.copy(carry);cup.quaternion.copy(camera.quaternion);q.setFromAxisAngle(new T.Vector3(1,0,0),sip*.75);cup.quaternion.multiply(q);
   }else{cup.position.copy(state.place==='machine'?slot:state.place==='floor'?floorPos[id]:homes[id]);cup.rotation.set(0,0,0);}
   const filling=model.brewing&&model.brewCup===id;const sipping=state.place==='held'&&model.drinkLeft>0;liquid[id].visible=state.full||filling||sipping;liquid[id].position.y=state.full?.07:sipping?.018+.052*model.drinkLeft/.75:.018+.052*(1-model.brewLeft/COFFEE_BREW_SECONDS);cup.updateMatrixWorld(true);
  }
  stream.visible=model.brewing;const end=model.brewCup===null?.041:.04+liquid[model.brewCup].position.y;stream.scale.y=.193-end;stream.position.set(-.075,(.193+end)/2,.075);
  spill.visible=model.spillLeft>0;spill.scale.setScalar(Math.min(1,(5-model.spillLeft)*1.7+.15));spill.position.z=machine.position.z+.13+.08*spill.scale.x;spill.scale.y*=.65;spillMaterial.opacity=.82*Math.min(1,model.spillLeft/.35);overflow.visible=model.brewing&&model.brewCup===null;
 }
 function prompt(focused,touch){if(model.drinkLeft>0)return 'DRINKING COFFEE...';const action=touch?'TAP INTERACT':'E / LEFT CLICK';if(focused?.kind==='coffee-machine'){if(model.brewing)return 'BREWING COFFEE...';if(model.slot!==null&&model.held!==null)return 'REMOVE THE CUP FROM THE MACHINE FIRST';if(model.held!==null)return action+' — PLACE CUP'+(model.heldFull?'':' & BREW');if(model.slot!==null&&model.cups[model.slot].full)return 'COFFEE READY — PICK UP CUP';return action+' — BREW COFFEE';}if(model.heldFull)return action+' — DRINK COFFEE';if(focused?.kind==='coffee-cup')return model.held===null?action+' — PICK UP CUP':'PUT DOWN YOUR CUP FIRST';if(model.held!==null)return action+' — PUT CUP DOWN';return '';}
 return {setSpace(nextBoxes,nextBounds,nextFloor){boxes=nextBoxes;bounds=nextBounds;floorAt=nextFloor;},setCarryVisible(visible){carryVisible=visible;},model,effects,targets,stream,spill,liquid,interact,drop,update,prompt};
}

export function createCoffeeFoley(audio,machine){
 let ctx=null,gain=null;
 function start(){if(!audio.ctx||ctx===audio.ctx)return;ctx=audio.ctx;const source=ctx.createBufferSource(),filter=ctx.createBiquadFilter();source.buffer=audio.noise;source.loop=true;filter.type='lowpass';filter.frequency.value=650;gain=ctx.createGain();gain.gain.value=0;const pan=ctx.createPanner(),p=machine.getWorldPosition(new T.Vector3());pan.panningModel='HRTF';pan.distanceModel='inverse';pan.refDistance=.8;pan.rolloffFactor=1;pan.positionX.value=p.x;pan.positionY.value=p.y+.25;pan.positionZ.value=p.z;source.connect(filter).connect(gain).connect(pan).connect(audio.sfx);source.start();}
 function clink(drink){if(!audio.ctx)return;const c=audio.ctx,o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.setValueAtTime(drink?360:920,c.currentTime);o.frequency.exponentialRampToValueAtTime(drink?220:710,c.currentTime+.16);g.gain.setValueAtTime(.018,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+.18);o.connect(g).connect(audio.sfx);o.start();o.stop(c.currentTime+.2);o.onended=()=>{o.disconnect();g.disconnect();};}
 return {update(active,brewing,signals){if(active)start();if(gain)gain.gain.setTargetAtTime(active&&brewing?.055:0,ctx.currentTime,.06);for(const s of signals.splice(0))if(active&&['pickup','place','drink','finished'].includes(s))clink(s==='drink');}};
}
