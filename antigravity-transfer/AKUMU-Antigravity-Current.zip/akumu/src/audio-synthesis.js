// Original, deterministic PCM foley. No recordings, downloads or musical loops.
export const EFFECT_DURATION={tapeInsert:.56,tapeEject:.65,tapeSlot:.22,crtPower:.72,archiveError:.34,footstep:.25,door:.38,drawer:.78,wheel:.095,unlock:.30,pickup:.23,impact:.44,fall:.52,key:.57,doorCreak:1.65,ambientCreak:1.05,twigSnap:.48,spiderSting:1.2,clockTick:.085,doorSlam:1.1,doorLock:.42,concreteStep:.27};
export const EFFECT_LEVEL={tapeInsert:.46,tapeEject:.43,tapeSlot:.33,crtPower:.30,archiveError:.29,footstep:.50,door:.58,drawer:.43,wheel:.32,unlock:.46,pickup:.37,impact:.74,fall:.50,key:.48,doorCreak:.49,ambientCreak:.16,twigSnap:.28,spiderSting:.95,clockTick:.2,doorSlam:.76,doorLock:.53,concreteStep:.44};
export function synthesizeEffect(name,sampleRate,seed=207){
 const duration=EFFECT_DURATION[name];if(!duration)throw new Error(`Unknown sound: ${name}`);
 const samples=new Float32Array(Math.ceil(duration*sampleRate));let state=seed>>>0,low=0,phase=0;
 const random=()=>{state=(1664525*state+1013904223)>>>0;return state/4294967296;};
 const variation=.95+random()*.10,noiseScale=1-Math.exp(-2*Math.PI*1250/sampleRate);
 const hit=(t,at,frequencies,decay)=>{const s=t-at;if(s<0)return 0;return frequencies.reduce((sum,f,i)=>sum+Math.sin(2*Math.PI*f*variation*s)*Math.exp(-s*decay*(1+i*.43))/(i+1),0)*Math.min(s/.0015,1);};
 for(let i=0;i<samples.length;i++){
  const t=i/sampleRate,n=random()*2-1;low+=noiseScale*(n-low);const grit=n-low,attack=Math.min(t/.0025,1);let value=0;
  switch(name){
   case 'tapeInsert':case 'tapeEject':{
    const eject=name==='tapeEject',envelope=Math.sin(Math.PI*t/duration)**.7;
    phase+=2*Math.PI*(eject?185-65*t:135+90*t)/sampleRate;
    value=.32*hit(t,.014,[231,487,1021],43)+envelope*(low*.32+grit*.045+.13*Math.sin(phase))+.40*hit(t,duration-.10,[123,379,811],35);break;}
   case 'tapeSlot':value=.40*hit(t,.01,[193,421,917],39)+low*.28*Math.exp(-t*25)+grit*.11*Math.exp(-t*65);break;
   case 'crtPower':value=.32*hit(t,.012,[117,349,853],27)+grit*.15*Math.exp(-t*9)+Math.sin(2*Math.PI*(1550*t-620*t*t))*.10*Math.sin(Math.PI*t/duration)*Math.exp(-t*3);break;
   case 'archiveError':value=Math.sin(2*Math.PI*183*t)*.35*(Math.exp(-t*24)+.8*Math.exp(-Math.abs(t-.17)*36))+low*.1*Math.exp(-t*17);break;
   case 'spiderSting':{
    const envelope=t<.32?1:Math.exp(-(t-.32)*4.4),scream=Math.sin(2*Math.PI*(530*t+260*t*t)+2.2*Math.sin(2*Math.PI*37*t));
    value=(grit*.65+low*.30+scream*.43+Math.sin(2*Math.PI*873*t)*.19)*envelope+.85*hit(t,0,[47,73,121],6)+.35*hit(t,.055,[211,417,839],12);value=Math.tanh(value*3);break;}
   case 'doorSlam':value=1.0*hit(t,0,[43,79,123,191],7)+low*.85*Math.exp(-t*13)+grit*.38*Math.exp(-t*95)+.22*hit(t,.12,[217,439,887],22);break;
   case 'doorLock':value=.38*hit(t,0,[573,1217,2711],35)+.55*hit(t,.105,[837,1789,3487],48)+grit*.28*Math.exp(-Math.abs(t-.11)*75);break;
   case 'concreteStep':value=.38*hit(t,0,[92,174,331],28)+low*.72*Math.exp(-t*26)+grit*.22*Math.exp(-t*34);break;
   case 'clockTick':value=.3*hit(t,0,[1439,2873,4219],145)+grit*.35*Math.exp(-t*155)+.12*hit(t,.009,[943,2213],170);break;
   case 'twigSnap':value=grit*.85*Math.exp(-t*115)+.32*hit(t,0,[719,1433,2279],52)+grit*.24*Math.exp(-Math.abs(t-.057)*110)+low*.13*Math.exp(-t*18)+grit*.07*Math.exp(-Math.abs(t-.16)*42);break;
   case 'footstep':value=.66*hit(t,0,[79,138,247],23)+low*.8*Math.exp(-t*22)+grit*.12*Math.exp(-t*65);break;
   case 'door':value=.46*hit(t,0,[111,193,427],19)+.30*hit(t,.095,[256,723,1499],33)+low*.52*Math.exp(-t*24)+grit*.12*Math.exp(-Math.abs(t-.095)*55);break;
   case 'drawer':{
    const envelope=Math.sin(Math.PI*t/duration)**.7,frequency=146+32*Math.sin(t*6)+7*Math.sin(t*45);phase+=2*Math.PI*frequency/sampleRate;
    value=envelope*(low*.53+grit*.09+(.12*Math.sin(phase)+.055*Math.sin(phase*2.04))*(.55+.45*Math.sin(t*53)**2))+.18*hit(t,.66,[127,319],40);break;}
   case 'wheel':value=.30*hit(t,0,[1231,2389,3467],90)+.18*hit(t,.026,[891,2033],105)+grit*.34*Math.exp(-t*110);break;
   case 'unlock':value=.32*hit(t,0,[326,977,2111],38)+.48*hit(t,.068,[242,718,1637],26)+grit*.18*Math.exp(-Math.abs(t-.07)*65);break;
   case 'pickup':value=low*.6*Math.sin(Math.PI*t/duration)*Math.exp(-t*7)+.24*hit(t,.035,[167,541],33)+grit*.08*Math.exp(-t*26);break;
   case 'impact':value=.75*hit(t,0,[86,157,283,419],12)+low*1.1*Math.exp(-t*19)+grit*.5*Math.exp(-t*125);break;
   case 'fall':value=.5*hit(t,0,[107,201,353],16)+.27*hit(t,.16,[149,281,467],25)+.12*hit(t,.31,[182,391],38)+low*.65*Math.exp(-t*20);break;
   case 'key':value=.36*hit(t,0,[1531,2279,3433],15)+.23*hit(t,.09,[1793,2699,3671],18)+.15*hit(t,.205,[1391,3137],24)+grit*.04*Math.exp(-t*32);break;
   case 'doorCreak':case 'ambientCreak':{
    const envelope=Math.sin(Math.PI*t/duration)**.75,frequency=124+35*Math.sin(t*2.7)+8*Math.sin(t*19);phase+=2*Math.PI*frequency/sampleRate;
    const slip=.35+.65*Math.sin(t*(name==='doorCreak'?37:29)+Math.sin(t*13))**2;
    value=envelope*(slip*(.24*Math.sin(phase)+.11*Math.sin(phase*2.03)+.045*Math.sin(phase*3.61))+low*.2+grit*.035);break;}
  }
  // A short end taper prevents discontinuities, even when resonance tails are cut.
  samples[i]=value*attack*Math.min((duration-t)/.025,1);
 }
 let mean=0;for(const s of samples)mean+=s;mean/=samples.length;let peak=0;
 for(let i=0;i<samples.length;i++){samples[i]-=mean;peak=Math.max(peak,Math.abs(samples[i]));}
 const gain=peak>0?.72/peak:0;for(let i=0;i<samples.length;i++)samples[i]*=gain;
 return samples;
}
