// DEMO-only foley and quiet, spatial equipment tone. Existing narrator bus is untouched.
const DECK={x:2.5,y:1.05,z:6.89},EXIT={x:6.35,y:1.1,z:8.07};
export function createObservationAudio(audio){
 let tone=null,motor=null,context=null,nextCreak=22;
 const position=(node,p)=>{node.panningModel='HRTF';node.distanceModel='inverse';node.refDistance=1.7;node.rolloffFactor=.7;node.maxDistance=12;if(node.positionX){node.positionX.value=p.x;node.positionY.value=p.y;node.positionZ.value=p.z;}else node.setPosition(p.x,p.y,p.z);};
 function effect(name,p=DECK,delay=0){if(!audio.ctx)return;const pan=audio.ctx.createPanner();position(pan,p);pan.connect(audio.sfx);const source=audio.play(name,0,delay,pan);source?.addEventListener('ended',()=>pan.disconnect(),{once:true});}
 function start(){const c=audio.ctx;if(!c||context===c)return;context=c;
  const buffer=c.createBuffer(1,c.sampleRate*2,c.sampleRate),pcm=buffer.getChannelData(0);
  for(let i=0;i<pcm.length;i++){const t=i/c.sampleRate;pcm[i]=.16*Math.sin(2*Math.PI*100*t)+.055*Math.sin(2*Math.PI*150*t)+.025*Math.sin(2*Math.PI*1030*t);}
  const source=c.createBufferSource(),pan=c.createPanner();source.buffer=buffer;source.loop=true;position(pan,DECK);tone=c.createGain();tone.gain.value=0;source.connect(tone).connect(pan).connect(audio.ambience);source.start();
  const transport=c.createBufferSource(),filter=c.createBiquadFilter();transport.buffer=audio.noise;transport.loop=true;filter.type='lowpass';filter.frequency.value=850;motor=c.createGain();motor.gain.value=0;transport.connect(filter).connect(motor).connect(pan);transport.start();
 }
 function update(model,active){if(active)start();if(!context)return;const enabled=active&&!model.events.live,t=context.currentTime;tone.gain.setTargetAtTime(enabled?.12:0,t,.18);motor.gain.setTargetAtTime(enabled&&model.playing?.16:0,t,.12);
  if(enabled&&model.time>=nextCreak){effect('ambientCreak',{x:7.1,y:1.5,z:4.5});nextCreak=model.time+24+Math.random()*18;}
 }
 function signal(name,model){switch(name){
  case 'pickup':effect('pickup',model.held===null?DECK:model.tapes[model.held]);break;
  case 'land':case 'slot':effect('tapeSlot');break;
  case 'insert':effect('tapeInsert');break;
  case 'eject':effect('tapeEject');break;
  case 'startup':effect('crtPower');break;
  case 'recognition':case 'dip':audio.noiseBurst(.04,.16,1700);break;
  case 'invalid':effect('archiveError');break;
  case 'live':audio.setRecognitionSilence(true);effect('unlock',EXIT);break;
  case 'door':effect('door',EXIT);effect('doorCreak',EXIT,.1);break;
 }}
 return {update,signal,get tone(){return tone;},get motor(){return motor;}};
}
