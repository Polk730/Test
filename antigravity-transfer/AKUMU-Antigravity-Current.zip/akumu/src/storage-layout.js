// Six fixed main aisles, with an entry apron and two continuous cross-passages.
export const STORAGE_BOUNDS={minX:.6,maxX:11.6,minZ:2.08,maxZ:11.08,height:3.8};
export const STORAGE_ENTRY={x:1.4,z:2.95,commitZ:2.72};
export const STORAGE_CROSS_PASSAGES=[{minZ:5.15,maxZ:6.25},{minZ:9.4,maxZ:10.95}];
export const STORAGE_VENT={x:10.35,y:3,z:11.08,width:1.1,height:.72};
export function storageLayout(){
 const aisles=[],racks=[];let x=.8;
 for(const [i,width] of [1.15,1,1.3,.95,1.4,1.15].entries()){
  aisles.push({index:i+1,minX:x,maxX:x+width,centerX:x+width/2,width});x+=width;
  if(i<5){for(const [j,[minZ,maxZ]]of [[3.45,5.15],[6.25,i===4?8.45:9.4]].entries())racks.push({index:i,segment:j,minX:x,maxX:x+.7,minZ,maxZ,height:3.2,kind:i<2?'wood':i<4?'metal':j?'wood':'metal'});x+=.7;}
 }
 const b=STORAGE_BOUNDS,walls=[
  {minX:b.minX-.12,maxX:b.minX,minZ:2.08,maxZ:11.2},
  {minX:b.maxX,maxX:b.maxX+.12,minZ:2.08,maxZ:11.2},
  {minX:b.minX,maxX:b.maxX,minZ:11.08,maxZ:11.2},
  {minX:b.minX,maxX:.85,minZ:2,maxZ:2.16},
  {minX:1.95,maxX:b.maxX,minZ:2,maxZ:2.16}
 ];
 return {bounds:b,aisles,racks,walls,boxes:[...walls,...racks.map(({minX,maxX,minZ,maxZ})=>({minX,maxX,minZ,maxZ}))],crossPassages:STORAGE_CROSS_PASSAGES,ventApron:{minX:9.5,maxX:11.4,minZ:8.5,maxZ:10.9}};
}
// Room 1 formerly relied on clamped bounds rather than solid boundary boxes.
export const BEDROOM_PORTAL_WALLS=[
 {minX:-2.66,maxX:-2.5,minZ:-2.16,maxZ:2.16},{minX:2.5,maxX:2.66,minZ:-2.16,maxZ:2.16},
 {minX:-2.5,maxX:2.5,minZ:-2.16,maxZ:-2},{minX:-2.5,maxX:.85,minZ:2,maxZ:2.16},{minX:1.95,maxX:2.5,minZ:2,maxZ:2.16}
];
export const PASSAGE_BOUNDS={minX:-2.5,maxX:11.6,minZ:-2,maxZ:11.08,height:3.8};
