import * as T from 'three';
import {random} from './textures.js';
// Single-stroke handwriting rather than a typeset font; coordinates use a unit cap height.
export const LETTERS={
 A:['0,1 .3,0 .6,1','.12,.62 .49,.62'],B:['0,1 0,0 .38,0 .57,.16 .5,.4 0,.45','.1,.45 .44,.45 .61,.68 .52,.96 0,1'],C:['.6,.1 .43,0 .15,.06 0,.36 .04,.8 .24,1 .59,.88'],D:['0,1 0,0 .3,.02 .57,.22 .61,.64 .43,.94 0,1'],E:['.6,.03 0,0 .02,1 .62,.97','.01,.46 .46,.49'],F:['0,1 0,0 .62,.02','0,.46 .5,.43'],G:['.58,.12 .34,0 .08,.16 0,.63 .17,.96 .49,1 .62,.75 .59,.55 .35,.57'],H:['0,0 .01,1','.58,0 .6,1','0,.49 .6,.45'],I:['.04,0 .55,.02','.3,0 .28,1','.04,1 .55,.98'],J:['.14,0 .61,.02','.48,0 .47,.77 .31,1 .08,.91 0,.72'],K:['0,0 .02,1','.59,.01 .04,.52 .62,1'],L:['0,0 .03,1 .6,.97'],M:['0,1 .03,0 .3,.5 .57,.01 .61,1'],N:['0,1 0,.02 .61,1 .58,0'],O:['.32,0 .08,.11 0,.51 .09,.88 .36,1 .6,.77 .59,.3 .4,.02 .32,0'],P:['0,1 0,.01 .42,0 .6,.19 .52,.47 .02,.5'],Q:['.32,0 .08,.1 0,.5 .09,.89 .36,1 .6,.77 .59,.29 .4,.02 .32,0','.35,.73 .67,1.12'],R:['0,1 .01,.01 .4,0 .59,.18 .51,.44 .03,.5','.25,.49 .65,1'],S:['.6,.11 .35,0 .07,.13 .06,.36 .5,.56 .61,.78 .43,.98 .12,1 0,.87'],T:['0,.03 .65,0','.33,.01 .29,1'],U:['0,0 .02,.78 .16,.99 .42,1 .6,.8 .59,0'],V:['0,0 .28,1 .63,.02'],W:['0,0 .1,1 .32,.48 .5,1 .64,0'],X:['0,0 .63,1','.6,0 0,1'],Y:['0,0 .3,.49 .64,0','.3,.49 .29,1'],Z:['0,.02 .64,0 .02,1 .65,.98'],
 '0':['.3,0 .04,.16 0,.72 .23,1 .53,.91 .61,.34 .47,.02 .3,0'], '1':['.05,.22 .3,0 .29,1'], '2':['0,.15 .25,0 .55,.12 .57,.35 .02,1 .65,.99'], '3':['0,.06 .46,0 .6,.24 .27,.48 .57,.61 .58,.87 .33,1 0,.93'], '4':['.47,1 .49,0 0,.66 .65,.67'], '5':['.6,.01 0,0 .02,.49 .4,.45 .61,.68 .5,.96 .15,1 0,.9'], '6':['.5,0 .15,.15 0,.57 .03,.88 .32,1 .57,.8 .56,.55 .27,.45 0,.61'], '7':['0,.02 .64,0 .17,1'], '8':['.31,0 .04,.13 .06,.34 .5,.61 .61,.83 .36,1 .06,.9 0,.67 .5,.31 .54,.1 .31,0'], '9':['.59,.42 .3,.53 .05,.4 .02,.14 .25,0 .54,.12 .61,.56 .41,.99 .16,1'],
 "'":['.3,0 .22,.2'],',':['.3,.93 .19,1.12'],'.':['.29,.94 .31,.96'],'-':['.03,.5 .55,.51']
};
export function addBloodMessage(scene){
 const canvas=document.createElement('canvas');canvas.width=1536;canvas.height=768;
 const map=new T.CanvasTexture(canvas);map.colorSpace=T.SRGBColorSpace;map.anisotropy=4;
 // A restrained visibility floor on the pigment, without adding lights or a wall-wide glow.
 const material=new T.MeshStandardMaterial({map,emissiveMap:map,emissive:0xffffff,emissiveIntensity:.32,transparent:true,depthWrite:false,roughness:.65,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});
 const mesh=new T.Mesh(new T.PlaneGeometry(1.95,.96),material);mesh.name='personal-blood-message';mesh.position.set(2.495,2.13,.88);mesh.rotation.y=-Math.PI/2;mesh.receiveShadow=true;mesh.visible=false;mesh.userData.noBatch=true;mesh.userData.noOcclude=true;scene.add(mesh);
 function setName(name){
  const c=canvas.getContext('2d'),r=random(731);c.clearRect(0,0,1536,768);c.lineCap='round';c.lineJoin='round';
  const lines=[name+',',"you don't remember me,",'but I remember you..'];
  lines.forEach((text,row)=>{
   const letters=[...text.toUpperCase()],height=Math.min(row===0?126:105,1350/(letters.length*.77)),advance=height*.77;
   let x=(1536-letters.length*advance)/2;const top=43+row*227;
   for(const ch of letters){
    if(ch===' '){x+=advance;continue;}
    const y=top+(r()-.5)*13,paths=LETTERS[ch];c.save();c.translate(x,y);c.rotate((r()-.5)*.11);
    if(paths){for(const path of paths){const points=path.split(' ').map(p=>p.split(',').map(Number));
      c.beginPath();points.forEach(([px,py],i)=>{const xx=px*height+(r()-.5)*3,yy=py*height+(r()-.5)*3;if(i)c.lineTo(xx,yy);else c.moveTo(xx,yy);});
      c.strokeStyle='#9c2622';c.lineWidth=10+r()*5;c.stroke();c.strokeStyle='rgba(207,69,49,.55)';c.lineWidth=3+r()*2;c.stroke();
     }}else{c.font=`italic bold ${height}px cursive`;c.fillStyle='#af3026';c.fillText(ch,0,height);}
    c.restore();
    if(paths&&ch!=='.'&&ch!==','&&ch!=="'"&&r()<.33){
     // A hanging bead follows a stroke that actually reaches the letter's bottom.
     const ends=paths.flatMap(path=>path.split(' ').map(p=>p.split(',').map(Number))).filter(p=>p[1]>.85);
     if(ends.length){const point=ends[Math.floor(r()*ends.length)],dx=x+point[0]*height,dy=y+point[1]*height,length=22+r()*72;
      c.beginPath();c.moveTo(dx,dy-5);c.bezierCurveTo(dx-2,dy+length*.3,dx+3,dy+length*.75,dx+1,dy+length);c.strokeStyle='#a72a22';c.lineWidth=2+r()*4;c.stroke();c.fillStyle='#bd3529';c.beginPath();c.ellipse(dx+1,dy+length,3+r()*2,6+r()*3,0,0,Math.PI*2);c.fill();
     }
    }x+=advance;
   }
  });
  // Slight uneven translucency leaves plaster visible through wet streaks.
  const image=c.getImageData(0,0,1536,768);for(let i=3;i<image.data.length;i+=4)if(image.data[i])image.data[i]*=.9+r()*.1;c.putImageData(image,0,0);
  map.needsUpdate=true;mesh.visible=true;mesh.userData.message=lines.join(' ');
 }
 return {mesh,setName};
}
