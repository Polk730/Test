import * as THREE from 'three';
export function random(seed = 31) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
export {agedSurface as surface} from './aged-surface.js';
import {agedSurface} from './aged-surface.js';
export function texture(kind,seed=31){return agedSurface(kind,seed).color;}
export function photograph(){
 const canvas=document.createElement('canvas');canvas.width=512;canvas.height=640;const c=canvas.getContext('2d'),r=random(9);
 c.fillStyle='#8e8870';c.fillRect(0,0,512,640);c.fillStyle='#5e6355';c.fillRect(28,28,456,530);
 const sky=c.createLinearGradient(0,30,0,560);sky.addColorStop(0,'#a4a08b');sky.addColorStop(1,'#434c41');c.fillStyle=sky;c.fillRect(28,28,456,530);
 for(let i=0;i<16;i++){const x=r()*512;c.fillStyle='#353c3299';c.fillRect(x,28,6+r()*10,530);for(let j=0;j<6;j++){c.beginPath();c.moveTo(x,50+j*65);c.lineTo(x-40,150+j*65);c.lineTo(x+40,150+j*65);c.fill();}}
 c.fillStyle='#6c6a5b';c.fillRect(110,220,280,210);c.fillStyle='#393e35';c.beginPath();c.moveTo(80,225);c.lineTo(250,110);c.lineTo(420,225);c.fill();c.fillStyle='#30382e';c.fillRect(160,270,50,70);c.fillRect(290,270,50,70);c.fillRect(230,320,45,110);
 c.fillStyle='#262c25';for(const [x,y]of [[180,425],[300,435]]){c.beginPath();c.ellipse(x,y-25,12,17,0,0,7);c.fill();c.beginPath();c.moveTo(x-10,y-5);c.lineTo(x-23,y+85);c.lineTo(x+24,y+85);c.lineTo(x+10,y-5);c.fill();}
 for(let i=0;i<14000;i++){c.fillStyle=`rgba(30,24,17,${r()*.12})`;c.fillRect(r()*512,r()*640,1+r()*2,1);}
 c.strokeStyle='#d0c6a03a';c.beginPath();c.moveTo(20,440);c.lineTo(390,80);c.stroke();c.fillStyle='#514e41';c.font='italic 18px Georgia';c.fillText('Summer, 1986',167,602);
 const t=new THREE.CanvasTexture(canvas);t.colorSpace=THREE.SRGBColorSpace;return t;
}
