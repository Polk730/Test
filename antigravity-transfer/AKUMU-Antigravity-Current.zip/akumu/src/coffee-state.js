export const COFFEE_BREW_SECONDS=1.8,COFFEE_SPILL_SECONDS=5,COFFEE_BOOST_SECONDS=5,COFFEE_SPEED_MULTIPLIER=3;
// An optional toy, independent of every puzzle and exit condition.
export class CoffeeState {
 constructor(){this.cups=[0,1].map(id=>({id,place:'counter',full:false}));this.held=null;this.slot=null;this.brewLeft=0;this.brewCup=null;this.spillLeft=0;this.boostLeft=0;this.drinkLeft=0;this.signals=[];}
 get brewing(){return this.brewLeft>0;}
 get multiplier(){return this.boostLeft>0?COFFEE_SPEED_MULTIPLIER:1;}
 get heldFull(){return this.held!==null&&this.cups[this.held].full;}
 pick(id){const cup=this.cups[id];if(!cup||this.held!==null||this.drinkLeft>0||cup.place==='held'||this.brewing&&this.brewCup===id)return false;if(this.slot===id)this.slot=null;cup.place='held';this.held=id;this.signals.push('pickup');return true;}
 useMachine(){if(this.brewing||this.drinkLeft>0)return false;
  if(this.held!==null){if(this.slot!==null)return false;const id=this.held;this.held=null;this.slot=id;this.cups[id].place='machine';this.signals.push('place');}
  if(this.slot!==null&&this.cups[this.slot].full)return true;
  this.brewLeft=COFFEE_BREW_SECONDS;this.brewCup=this.slot;if(this.slot===null)this.spillLeft=COFFEE_SPILL_SECONDS;this.signals.push('brew');return true;
 }
 drink(){if(!this.heldFull||this.drinkLeft>0)return false;this.cups[this.held].full=false;this.boostLeft=COFFEE_BOOST_SECONDS;this.drinkLeft=.75;this.signals.push('drink');return true;}
 drop(place='counter'){if(this.held===null||this.drinkLeft>0||!['counter','floor'].includes(place))return false;this.cups[this.held].place=place;this.held=null;this.signals.push('place');return true;}
 update(dt){if(!Number.isFinite(dt)||dt<=0)return;this.boostLeft=Math.max(0,this.boostLeft-dt);this.drinkLeft=Math.max(0,this.drinkLeft-dt);this.spillLeft=Math.max(0,this.spillLeft-dt);if(this.brewing){this.brewLeft=Math.max(0,this.brewLeft-dt);if(!this.brewing){if(this.brewCup!==null)this.cups[this.brewCup].full=true;this.signals.push('finished');}}}
}
