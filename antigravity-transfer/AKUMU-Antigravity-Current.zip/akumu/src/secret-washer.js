import * as T from 'three';
export function createSecretWasher(root,{w,h,cy,r,enamel,metal,rubber,dark,glass}){
 const shape=new T.Shape();shape.moveTo(-w/2,0);shape.lineTo(w/2,0);shape.lineTo(w/2,h);shape.lineTo(-w/2,h);shape.closePath();const hole=new T.Path();hole.absarc(0,cy,.264,0,Math.PI*2,true);shape.holes.push(hole);
 const front=new T.Mesh(new T.ShapeGeometry(shape),enamel);front.position.z=.415;front.castShadow=front.receiveShadow=true;root.add(front);
 const liner=new T.Mesh(new T.CylinderGeometry(.264,.264,.76,32,1,true),new T.MeshStandardMaterial({color:0x404640,roughness:.72,metalness:.6,side:T.DoubleSide}));liner.rotation.x=Math.PI/2;liner.position.set(0,cy,.04);root.add(liner);
 const door=new T.Group();door.name='washer-hinged-door';door.position.set(-r-.03,cy,.47);root.add(door);
 function part(geometry,material,x,y,z,parent=root){const o=new T.Mesh(geometry,material);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;parent.add(o);return o;}
 function leaf(geometry,material,x,y,z){return part(geometry,material,x+r+.03,y-cy,z-.47,door);}
 part(new T.TorusGeometry(r-.042,.018,8,40),rubber,0,cy,.482);
 leaf(new T.TorusGeometry(r,.031,8,40),metal,0,cy,.47);
 const pane=leaf(new T.CylinderGeometry(r-.065,r-.065,.018,24),glass,0,cy,.482);pane.rotation.x=Math.PI/2;
 for(let k=0;k<3;k++){const a=k*Math.PI*2/3;const o=leaf(new T.BoxGeometry(.025,.14,.012),dark,Math.sin(a)*r*.43,cy+Math.cos(a)*r*.43,.495);o.rotation.z=-a;}
 leaf(new T.BoxGeometry(.028,.18,.05),dark,r-.02,cy,.51);
 for(const z of [.23,.0,-.23])part(new T.TorusGeometry(.257,.006,6,32),metal,0,cy,z);
 const hit=part(new T.CircleGeometry(.255,32),new T.MeshBasicMaterial({visible:false}),0,cy,.52);hit.castShadow=hit.receiveShadow=false;hit.userData.noOcclude=true;
 return {root,door,hit,target:{root:hit,object:root,kind:'basement-washer'}};
}
