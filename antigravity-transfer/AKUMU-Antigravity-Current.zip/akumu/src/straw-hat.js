import * as T from 'three';

// A decorative shelf prop: no inventory ID, interaction target or collider.
export function createStrawHat(parent, position) {
 const root=new T.Group();root.name='straw-hat';root.position.copy(position);root.rotation.y=.15;root.scale.set(.76,1,1);parent.add(root);
 const canvas=document.createElement('canvas');canvas.width=canvas.height=256;
 const c=canvas.getContext('2d');c.fillStyle='#cda75f';c.fillRect(0,0,256,256);
 for(let y=0;y<256;y+=4){c.strokeStyle=y%12?'#ae884b':'#e6c57c';c.lineWidth=1;c.beginPath();c.moveTo(0,y);c.lineTo(256,y+8);c.stroke();}
 for(let x=0;x<256;x+=7){c.strokeStyle='#b48c50';c.beginPath();c.moveTo(x,0);c.lineTo(x+28,256);c.stroke();}
 const map=new T.CanvasTexture(canvas);map.colorSpace=T.SRGBColorSpace;map.wrapS=map.wrapT=T.RepeatWrapping;map.repeat.set(3,1);
 const straw=new T.MeshStandardMaterial({map,bumpMap:map,bumpScale:.0015,roughness:.94,color:0xf5dfae});
 const ribbon=new T.MeshStandardMaterial({color:0x9b2630,roughness:.91});
 const materials=[straw,ribbon];
 function lathe(profile,material){const mesh=new T.Mesh(new T.LatheGeometry(profile.map(([r,y])=>new T.Vector2(r,y)),48),material);mesh.receiveShadow=true;mesh.userData.noOcclude=true;root.add(mesh);return mesh;}
 lathe([[0,.007],[.1,.007],[.17,.009],[.22,.016],[.225,.022],[.22,.027],[.17,.018],[.1,.016],[0,.016]],straw);
 lathe([[.105,.017],[.118,.035],[.12,.085],[.11,.125],[.085,.154],[.045,.172],[0,.178]],straw);
 lathe([[.118,.035],[.121,.04],[.123,.074],[.121,.079]],ribbon);
 const edge=new T.Mesh(new T.TorusGeometry(.221,.0035,6,64),straw);edge.rotation.x=Math.PI/2;edge.position.y=.022;edge.receiveShadow=true;edge.userData.noOcclude=true;root.add(edge);
 let elapsed=0,complete=false;root.visible=false;
 for(const material of materials){material.transparent=true;material.opacity=0;}
 return {root,update(dt){if(complete||dt<=0)return false;elapsed=Math.min(1.4,elapsed+dt);const t=elapsed/1.4,alpha=t*t*(3-2*t);root.visible=true;for(const material of materials)material.opacity=alpha;
 if(elapsed>=1.4){complete=true;for(const material of materials){material.transparent=false;material.needsUpdate=true;}root.traverse(o=>{if(o.isMesh)o.castShadow=true;});return true;}return false;}};
}
