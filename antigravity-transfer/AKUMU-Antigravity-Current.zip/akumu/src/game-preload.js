import * as T from 'three';
import {EFFECT_DURATION,synthesizeEffect} from './audio-synthesis.js';

const depthProbes=new WeakMap();

export const paintLoading=()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));

// Prepare resources without advancing puzzles, audio events, room entry or clocks.
export async function prepareGame({renderer,scene,camera,roots,passes,inspection,extra=[],materialVariants=[],audio,progress}){
 const viewport=renderer.getViewport(new T.Vector4()),scissor=renderer.getScissor(new T.Vector4()),scissorTest=renderer.getScissorTest(),target=renderer.getRenderTarget(),size=renderer.getSize(new T.Vector2());
 const visibility=roots.map(root=>root.visible),culling=new Map(),textures=new Set();
 const lightVisibility=new Map(),proxies=new Map();
 for(const root of roots){const proxy=new T.Group();proxies.set(root,proxy);root.traverse(o=>{
  if(o.isMesh||o.isPoints||o.isLine){culling.set(o,o.frustumCulled);o.frustumCulled=false;proxy.add(o.clone(false));}
  if(o.isLight){lightVisibility.set(o,o.visible);}
  for(const m of Array.isArray(o.material)?o.material:[o.material])if(m){for(const value of Object.values(m))if(value?.isTexture&&!value.isRenderTargetTexture)textures.add(value);for(const uniform of Object.values(m.uniforms||{}))if(uniform.value?.isTexture&&!uniform.value.isRenderTargetTexture)textures.add(uniform.value);}
 });}
 const select=pass=>{roots.forEach(root=>root.visible=pass.roots.includes(root));for(const [light,visible]of lightVisibility)light.visible=visible;for(const light of pass.lights||[])light.visible=true;scene.updateMatrixWorld(true);};
 const draw=view=>{renderer.setRenderTarget(null);renderer.setViewport(0,0,64,64);renderer.setScissor(0,0,64,64);renderer.setScissorTest(true);scene.traverseVisible(o=>{if(o.isLight&&o.castShadow)o.shadow.needsUpdate=true;});renderer.shadowMap.needsUpdate=true;renderer.render(scene,view);};
 const tasks=[];
 tasks.push(['Preparing sound...',async()=>{
  if(!audio.ctx)return;let count=0;
  for(const name of Object.keys(EFFECT_DURATION))for(let variant=0;variant<4;variant++){
   const key=name+':'+variant;if(audio.buffers.has(key))continue;
   const pcm=synthesizeEffect(name,audio.ctx.sampleRate,207+variant*7919),buffer=audio.ctx.createBuffer(1,pcm.length,audio.ctx.sampleRate);buffer.copyToChannel(pcm,0);audio.buffers.set(key,buffer);if(++count%8===0)await paintLoading();
  }
 }]);
 tasks.push(['Preparing surfaces...',async()=>{let count=0;for(const texture of textures){renderer.initTexture(texture);if(++count%8===0)await paintLoading();}}]);
 for(const pass of passes)tasks.push(['Preparing lighting...',async()=>{
  select(pass);
  const view=camera.clone();view.position.set(...pass.eye);view.lookAt(...pass.look);view.updateMatrixWorld(true);scene.updateMatrixWorld(true);
  // Geometry-only proxies avoid counting the room lights twice during compile.
  for(const root of pass.roots)await renderer.compileAsync(proxies.get(root),view,scene);
  if(materialVariants.length){const flags=materialVariants.map(m=>m.transparent);try{materialVariants.forEach(m=>{m.transparent=false;m.needsUpdate=true;});for(const root of pass.roots)await renderer.compileAsync(proxies.get(root),view,scene);}finally{materialVariants.forEach((m,i)=>{m.transparent=flags[i];m.needsUpdate=true;});}}
  draw(view);
  for(const [light,visible]of lightVisibility)light.visible=visible;
 }]);
 if(inspection)tasks.push(['Preparing objects...',async()=>{for(const root of inspection.roots)await renderer.compileAsync(proxies.get(root),inspection.camera,inspection.scene);}]);
 tasks.push(...extra);
 tasks.push(['Preparing shadows...',async()=>{
  let probe=depthProbes.get(renderer);if(!probe){const material=new T.MeshDepthMaterial({depthPacking:T.RGBADepthPacking,side:T.BackSide});material.fog=false;probe=new T.Mesh(new T.BoxGeometry(.001,.001,.001),material);depthProbes.set(renderer,probe);}
  const output=renderer.getRenderTarget(),fog=scene.fog,scratch=new T.WebGLRenderTarget(1,1);
  try{renderer.setRenderTarget(scratch);scene.fog=null;for(const pass of passes){select(pass);await renderer.compileAsync(probe,camera,scene);await paintLoading();}}finally{scene.fog=fog;renderer.setRenderTarget(output);scratch.dispose();}
 }]);
 // Shadow depth programs can use the preceding frame's lighting layout.
 // Replay the actual route changes after the surface programs are prepared.
 tasks.push(['Finishing lighting...',async()=>{for(const pass of passes){select(pass);const view=camera.clone();view.position.set(...pass.eye);view.lookAt(...pass.look);view.updateMatrixWorld(true);draw(view);await paintLoading();}}]);
 let done=0;
 try{
  // Draw behind the opaque loading screen on the real output, so tone-mapping
  // and colour-space shader variants match gameplay. Small scissor saves work.
  renderer.setRenderTarget(null);renderer.setViewport(0,0,64,64);renderer.setScissor(0,0,64,64);renderer.setScissorTest(true);
  for(const [label,run]of tasks){progress(label,done/tasks.length);await paintLoading();await run();done++;progress(label,done/tasks.length);}
  roots.forEach((root,i)=>root.visible=visibility[i]);for(const [light,visible]of lightVisibility)light.visible=visible;scene.updateMatrixWorld(true);draw(camera);
 }finally{
  roots.forEach((root,i)=>root.visible=visibility[i]);for(const [object,flag]of culling)object.frustumCulled=flag;for(const [light,visible]of lightVisibility)light.visible=visible;
  renderer.setRenderTarget(target);const currentSize=renderer.getSize(new T.Vector2());if(currentSize.equals(size)){renderer.setViewport(viewport);renderer.setScissor(scissor);}else{renderer.setViewport(0,0,currentSize.x,currentSize.y);renderer.setScissor(0,0,currentSize.x,currentSize.y);}renderer.setScissorTest(scissorTest);renderer.shadowMap.needsUpdate=true;scene.updateMatrixWorld(true);
 }
}
