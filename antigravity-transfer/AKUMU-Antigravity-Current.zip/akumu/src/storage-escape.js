import {STORAGE_VENT} from './storage-layout.js';
export class StorageEscape {
 constructor(puzzle){this.puzzle=puzzle;this.opened=new Set();}
 canOpen(id){return this.puzzle.stageThreeCompleted&&[1,2,3].includes(id)&&!this.opened.has(id);}
 open(id){if(!this.canOpen(id))return false;this.opened.add(id);return true;}
 collectWrench(inventory){if(!this.puzzle.stageThreeCompleted||!this.opened.has(1)||inventory.wrench==='carried')return false;inventory.wrench='carried';return true;}
 canReachVent(inventory,feet,position,boxes){return this.puzzle.stageThreeCompleted&&inventory.wrench==='carried'&&feet>=1.08&&Math.hypot(position.x-STORAGE_VENT.x,position.z-STORAGE_VENT.z)<1.35&&boxes.length===3&&boxes.every(b=>b.placement==='floor'||b.placement==='stack');}
}
