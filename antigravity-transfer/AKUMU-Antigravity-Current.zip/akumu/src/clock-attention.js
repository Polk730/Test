// Deliberate look/away visits, independent of the escape timer.
export class ClockAttention {
 constructor(){this.looks=0;this.seconds=0;this.looking=false;this.ticking=false;this.dwell=0;this.away=.35;this.armed=true;this.narratorPending=false;this.narrated=false;}
 update(dt,looking,active){
  if(!active){this.ticking=false;return;}
  this.looking=looking;this.ticking=!looking;
  if(looking){this.away=0;this.dwell+=dt;if(this.armed&&this.dwell>=.18){this.looks++;this.armed=false;if(this.looks>=3&&!this.narrated)this.narratorPending=true;}}
  else{this.dwell=0;this.away+=dt;if(this.away>=.35)this.armed=true;this.seconds+=dt;}
 }
 markNarrated(){this.narrated=true;this.narratorPending=false;}
}
