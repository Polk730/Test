import * as T from 'three';
import {random} from './textures.js';
import {LETTERS} from './blood-message.js';
export const STORAGE_LETTER_TEXT="I know this doesent make sense.\n\nIt didnt make sense to me either.\n\nJust promise me one thing.\n\nDont trust the voice.";
export function createStorageEnvelope(root){
 const group=new T.Group();group.name='storage-envelope';group.userData.dynamic=true;group.position.set(5.635,1.085,7.8);group.rotation.y=-Math.PI/2;root.add(group);
 function texture(draw,w=1024,h=640){const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;const c=canvas.getContext('2d'),r=random(923);c.fillStyle='#c6b993';c.fillRect(0,0,w,h);for(let i=0;i<14000;i++){c.fillStyle=`rgba(64,42,23,${r()*.08})`;c.fillRect(r()*w,r()*h,1+r()*3,1);}const edge=c.createRadialGradient(w*.5,h*.5,h*.12,w*.5,h*.5,h*.85);edge.addColorStop(0,'#38250d00');edge.addColorStop(1,'#38250d55');c.fillStyle=edge;c.fillRect(0,0,w,h);draw(c,w,h);const map=new T.CanvasTexture(canvas);map.colorSpace=T.SRGBColorSpace;map.anisotropy=4;return map;}
 const envelopeMaterial=new T.MeshStandardMaterial({roughness:.98});
 const face=new T.Mesh(new T.PlaneGeometry(.32,.20),envelopeMaterial);face.name='envelope-cover';group.add(face);
 const back=new T.Mesh(new T.PlaneGeometry(.32,.20),new T.MeshStandardMaterial({color:0xb6a780,roughness:1,side:T.DoubleSide}));back.position.z=-.003;group.add(back);
 let address='';
 function bloodAddress(c,line,y,seed){
  const r=random(seed),chars=[...line.toUpperCase()],height=Math.min(56,850/(chars.length*.73)),advance=height*.73;let x=80;c.lineCap='round';c.lineJoin='round';
  for(const ch of chars){c.save();c.translate(x,y+(r()-.5)*5);c.rotate((r()-.5)*.07);const paths=LETTERS[ch];
   if(paths){for(const path of paths){c.beginPath();path.split(' ').forEach((p,i)=>{const [u,v]=p.split(',').map(Number);if(i)c.lineTo(u*height,v*height);else c.moveTo(u*height,v*height);});c.strokeStyle='#791b18';c.lineWidth=height*(.06+r()*.025);c.stroke();c.strokeStyle='#ba3528aa';c.lineWidth=height*.025;c.stroke();}
    if(/[A-Z]/.test(ch)&&r()<.22){const ends=paths.flatMap(p=>p.split(' ').map(p=>p.split(',').map(Number))).filter(p=>p[1]>.85);if(ends.length){const [u,v]=ends[0],length=10+r()*22;c.strokeStyle='#8b211a';c.lineWidth=1.8;c.beginPath();c.moveTo(u*height,v*height);c.lineTo(u*height+1,v*height+length);c.stroke();c.fillStyle='#9c271e';c.beginPath();c.ellipse(u*height+1,v*height+length,2,3.5,0,0,Math.PI*2);c.fill();}}
   }else if(ch===':'){c.fillStyle='#8d231d';for(const v of [.3,.75]){c.beginPath();c.ellipse(height*.28,height*v,2.5,3.5,0,0,Math.PI*2);c.fill();}}
   else if(ch!==' '){c.font=`italic ${height}px cursive`;c.fillStyle='#8d231d';c.fillText(ch,0,height);}
   c.restore();x+=advance;
  }
 }
 function setName(name){address=`From: ${name}\nTo: ${name}`;const previous=envelopeMaterial.map;envelopeMaterial.map=texture((c,w,h)=>{c.strokeStyle='#68533a66';c.lineWidth=3;c.beginPath();c.moveTo(0,0);c.lineTo(w*.5,h*.33);c.lineTo(w,0);c.stroke();for(const [i,line] of address.split('\n').entries())bloodAddress(c,line,285+i*155,804+i);},1024,640);envelopeMaterial.needsUpdate=true;previous?.dispose();group.userData.address=address;}
 const letterMap=texture((c)=>{
  const r=random(519),lines=[];
  for(const paragraph of STORAGE_LETTER_TEXT.split('\n\n')){let line='';for(const word of paragraph.split(' ')){if(line&&line.length+word.length+1>25){lines.push(line);line=word;}else line+=(line?' ':'')+word;}lines.push(line,'');}lines.pop();
  c.lineCap='round';c.lineJoin='round';
  lines.forEach((line,row)=>{let x=85;const height=43,y=210+row*103;
   for(const ch of line.toUpperCase()){
    const paths=LETTERS[ch];if(paths){c.save();c.translate(x,y+(r()-.5)*7);c.rotate((r()-.5)*.07);
     for(const path of paths){c.beginPath();path.split(' ').forEach((p,i)=>{const [px,py]=p.split(',').map(Number);if(i)c.lineTo(px*height,py*height);else c.moveTo(px*height,py*height);});c.strokeStyle='#761b19';c.lineWidth=3+r()*1.8;c.stroke();c.strokeStyle='#b33227aa';c.lineWidth=1.1;c.stroke();}
     if(/[A-Z]/.test(ch)&&r()<.17){const endpoints=paths.flatMap(p=>p.split(' ').map(p=>p.split(',').map(Number))).filter(p=>p[1]>.85);if(endpoints.length){const [px,py]=endpoints[0],length=9+r()*25;c.strokeStyle='#8a211c';c.lineWidth=1.5;c.beginPath();c.moveTo(px*height,py*height);c.lineTo(px*height+1,py*height+length);c.stroke();c.fillStyle='#a52a21';c.beginPath();c.ellipse(px*height+1,py*height+length,1.8,3,0,0,Math.PI*2);c.fill();}}
     c.restore();
    }x+=height*.73;
   }
  });
  // A few finger smears away from the words preserve the message's readability.
  c.fillStyle='#79201925';for(let i=0;i<4;i++){c.beginPath();c.ellipse(940-i*9,1030+i*12,9,45,-.35,0,Math.PI*2);c.fill();}
 },1024,1280);
 const letter=new T.Mesh(new T.PlaneGeometry(.40,.50),new T.MeshStandardMaterial({map:letterMap,roughness:1}));letter.name='envelope-letter';letter.visible=false;letter.position.z=.006;group.add(letter);group.userData.message=STORAGE_LETTER_TEXT;
 const reverse=new T.Mesh(new T.PlaneGeometry(.40,.50),new T.MeshStandardMaterial({map:texture(c=>{bloodAddress(c,'HE IS LISTENING',570,818);},1024,1280),roughness:1}));reverse.name='letter-reverse';reverse.rotation.y=Math.PI;reverse.position.z=-.001;letter.add(reverse);group.userData.reverseMessage='HE IS LISTENING';
 const hit=new T.Mesh(new T.BoxGeometry(.33,.22,.025),new T.MeshBasicMaterial({visible:false}));group.add(hit);
 let opened=false;setName('');
 return {object:group,target:{root:hit,object:group,kind:'envelope',enabled:()=>true},setName,get opened(){return opened;},open(view){opened=true;view.getObjectByName('envelope-cover').visible=false;view.getObjectByName('envelope-letter').visible=true;for(const child of view.children)if(child.name!=='envelope-letter')child.visible=false;},flip(view){const paper=view.getObjectByName('envelope-letter');if(!opened||!paper?.visible)return false;view.userData.flipped=!view.userData.flipped;view.rotation.set(0,view.userData.flipped?Math.PI:0,0);return true;},address:()=>address};
}
