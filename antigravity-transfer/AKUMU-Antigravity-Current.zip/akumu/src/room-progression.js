import {STORAGE_BOUNDS,STORAGE_ENTRY} from './storage-layout.js';
const smooth=t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};
export class RoomProgression {
 constructor(){this.phase='bedroom-locked';this.committed=false;this.time=0;this.enteredAt=null;this.slamAt=null;this.angle=0;}
 unlock(){if(this.phase!=='bedroom-locked')return false;this.phase='opening';return true;}
 startInStorage(){this.phase='locked';this.committed=true;this.angle=0;}
 get portalOpen(){return this.phase==='open';}
 update(dt,doorOpen,position){
  this.time+=dt;const events=[];
  if(this.phase==='opening'&&doorOpen){this.phase='open';this.angle=1.22;}
  if(this.phase==='open'&&position.z>=STORAGE_ENTRY.commitZ&&position.x>STORAGE_BOUNDS.minX&&position.x<STORAGE_BOUNDS.maxX){this.phase='closing';this.committed=true;this.enteredAt=this.time;events.push('entered');}
  if(this.phase==='closing'){const age=this.time-this.enteredAt;this.angle=1.22*(1-smooth(age/.26));if(age>=.26){this.angle=0;this.phase='waiting-lock';this.slamAt=this.time;events.push('slam');}}
  if(this.phase==='waiting-lock'&&this.time-this.slamAt>=.5){this.phase='locked';events.push('lock');}
  return events;
 }
}
