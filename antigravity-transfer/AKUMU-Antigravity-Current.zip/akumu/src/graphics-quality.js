import * as T from 'three';
// Quality affects only GPU resolution. No simulation, audio, event or CCTV clocks are sampled here.
export class GraphicsQuality {
 constructor(renderer,touch){this.renderer=renderer;this.touch=touch;this.profile=touch?'MEDIUM':'HIGH';this.frames=0;this.elapsed=0;this.cooldown=0;this.ratio=0;this.resize();}
 resize(){const caps={HIGH:this.touch?1.25:1.5,MEDIUM:1,LOW:.8},native=devicePixelRatio||1;this.ratio=Math.min(native,caps[this.profile]);this.renderer.setPixelRatio(this.ratio);}
 update(dt,active){if(!active||dt<=0||dt>1)return;this.cooldown+=dt;if(this.cooldown<8)return;this.elapsed+=dt;this.frames++;if(this.elapsed<6)return;const mean=this.elapsed/this.frames;this.frames=0;this.elapsed=0;let next=this.profile;if(mean>1/27)next=this.profile==='HIGH'?'MEDIUM':'LOW';else if(mean<1/58&&this.cooldown>25)next=this.profile==='LOW'?'MEDIUM':'HIGH';if(next!==this.profile){this.profile=next;this.resize();this.cooldown=0;}}
}
const polishedMaterials=new WeakSet();
export function polishLighting(root,reflections){
 root.traverse(o=>{if(o.isSpotLight){o.shadow.radius=2.2;o.shadow.normalBias=Math.min(o.shadow.normalBias,.018);o.shadow.camera.updateProjectionMatrix();}if(o.isMesh&&o.material?.isMeshStandardMaterial&&!polishedMaterials.has(o.material)){const m=o.material;polishedMaterials.add(m);if(m.normalMap){m.normalScale?.setScalar(.35);}if(m.metalness>=.5){m.envMap=reflections;m.envMapIntensity=.42;if(!m.map)m.roughness=Math.max(.36,m.roughness*.9);}}});
}
