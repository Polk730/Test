export const DEMO_INVITATION_TEXT='Oh, you thought that was the end? That was only the beginning. Play the full version... if you dare.';
export const DEMO_INVITATION_WAIT=3;
// Caption-only timing is temporary until the supplied recording is available.
export class DemoInvitation {
 constructor(){this.reset();}
 reset(){this.titleAt=null;this.started=false;this.complete=false;this.startedAt=0;this.playback=null;}
 update(time,startAudio){if(this.titleAt===null&&time>=4.2)this.titleAt=time;if(!this.started&&this.titleAt!==null&&time-this.titleAt>=DEMO_INVITATION_WAIT){const playback=startAudio();if(playback?.pending)return;this.playback=playback||null;this.started=true;this.startedAt=time;}if(this.started&&!this.complete)this.complete=this.playback?this.playback.ended():time-this.startedAt>=10;}
 get caption(){return this.started&&!this.complete?'(Narrator) '+DEMO_INVITATION_TEXT:'';}
}
