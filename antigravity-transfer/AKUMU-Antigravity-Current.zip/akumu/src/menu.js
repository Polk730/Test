import * as T from 'three';
import {createReception} from './reception-scene.js';
import {createReceptionAudio} from './reception-audio.js';
import {createCorridorPicker} from './reception-corridor-pick.js';

// Maps a real accessible HTML form onto the 3D page, rather than replacing input with canvas text.
function pageTransform(points,width,height){
 const [p0,p1,p2,p3]=points,dx1=p1.x-p2.x,dx2=p3.x-p2.x,dx3=p0.x-p1.x+p2.x-p3.x,dy1=p1.y-p2.y,dy2=p3.y-p2.y,dy3=p0.y-p1.y+p2.y-p3.y,det=dx1*dy2-dx2*dy1;
 const g=Math.abs(det)<1e-8?0:(dx3*dy2-dx2*dy3)/det,h=Math.abs(det)<1e-8?0:(dx1*dy3-dx3*dy1)/det;
 return `matrix3d(${(p1.x-p0.x+g*p1.x)/width},${(p1.y-p0.y+g*p1.y)/width},0,${g/width},${(p3.x-p0.x+h*p3.x)/height},${(p3.y-p0.y+h*p3.y)/height},0,${h/height},0,0,1,0,${p0.x},${p0.y},0,1)`;
}
// Snapshot the native input's untransformed text metrics before blur can reset its scroll.
function nameInkLayout(input){
 const style=getComputedStyle(input),number=value=>parseFloat(value)||0,context=document.createElement('canvas').getContext('2d');
 const font=`${style.fontStyle} ${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;context.font=font;
 const metrics=context.measureText('Mg'),ascent=metrics.fontBoundingBoxAscent??metrics.actualBoundingBoxAscent,descent=metrics.fontBoundingBoxDescent??metrics.actualBoundingBoxDescent;
 const left=input.offsetLeft+number(style.borderLeftWidth)+number(style.paddingLeft),top=input.offsetTop+number(style.borderTopWidth)+number(style.paddingTop),height=input.clientHeight-number(style.paddingTop)-number(style.paddingBottom),width=input.clientWidth-number(style.paddingLeft)-number(style.paddingRight);
 return {font,color:style.color,direction:style.direction,letterSpacing:style.letterSpacing==='normal'?'0px':style.letterSpacing,x:left-input.scrollLeft,y:top+(height-ascent-descent)/2+ascent,clip:{x:left,y:top,width,height}};
}
export function initTitleMenu({menu,renderer,environment,audio}){
 const reception=createReception(environment),sound=createReceptionAudio(audio),abort=new AbortController(),signal=abort.signal,$=id=>document.getElementById(id),form=$('name-form'),input=$('player-name'),film=$('reception-film'),black=$('reception-black'),motion=matchMedia('(prefers-reduced-motion: reduce)');
 $('world').setAttribute('aria-label','AKUMU hotel reception');
 const secret=$('corridor-secret'),secretBack=$('corridor-secret-back'),canvas=$('world'),pickCorridor=createCorridorPicker(reception.root,reception.camera),pickPoint=new T.Vector2();let corridorTap=null;
 const controls=[...document.querySelectorAll('#menu button,#mode-card button,#name-form button,#corridor-secret button')];let phase='title',stopped=false,transition=null,previous=0,time=0,confirmed=false,bookReady=false,dirty=true;let currentLook=reception.widePose().look.clone(),currentEye=reception.widePose().eye.clone();const pointer=new T.Vector2(),parallax=new T.Vector2();
 document.body.dataset.reception='title';
 try{if(sessionStorage.getItem('akumuReceptionIntroSeen')){time=2;menu.style.animation='none';}sessionStorage.setItem('akumuReceptionIntroSeen','1');}catch{}
 const debug=new URLSearchParams(location.search).has('debug');menu.querySelector('.room-test-buttons').hidden=!debug;
 const noise=document.createElement('canvas');noise.width=noise.height=96;const n=noise.getContext('2d'),pixels=n.createImageData(96,96);let seed=86;for(let i=0;i<pixels.data.length;i+=4){seed=(Math.imul(seed,1664525)+1013904223)>>>0;pixels.data[i]=pixels.data[i+1]=pixels.data[i+2]=seed%256;pixels.data[i+3]=110;}n.putImageData(pixels,0,0);film.style.setProperty('--film-grain',`url(${noise.toDataURL()})`);
 function listen(target,name,fn){target.addEventListener(name,fn,{signal});}
 for(const button of controls){let hover=false,focus=false,selected=false;const refresh=()=>{const next=hover||focus;if(next&&!selected)sound.click();selected=next;};listen(button,'pointerenter',()=>{hover=true;refresh();});listen(button,'pointerleave',()=>{hover=false;refresh();});listen(button,'focus',()=>{focus=true;refresh();});listen(button,'blur',()=>{focus=false;refresh();});}
 listen(document,'visibilitychange',()=>{if(!document.hidden&&sound.ready)void sound.unlock();});listen(document,'pointerdown',()=>{void sound.unlock();});listen(document,'keydown',()=>{void sound.unlock();});listen(document,'pointermove',e=>{if(e.target.closest?.('#name-form'))return;if(e.pointerType==='touch'&&e.buttons===0)return;pointer.set(T.MathUtils.clamp(e.clientX/innerWidth*2-1,-1,1),T.MathUtils.clamp(e.clientY/innerHeight*2-1,-1,1));});
 function openSecret(){
  if(stopped||phase!=='title'||transition)return;
  menu.inert=true;$('play').disabled=true;setPage('secret-fade');
  animateTo('secret',.55,()=>{setPage('secret');menu.hidden=true;secret.hidden=false;secretBack.focus({preventScroll:true});});
 }
 listen(canvas,'pointerdown',e=>{corridorTap=null;if(e.button===0&&e.isPrimary&&phase==='title'&&!transition&&!menu.hidden&&Number(black.style.opacity)<.05)corridorTap={id:e.pointerId,x:e.clientX,y:e.clientY};});
 listen(document,'pointerup',e=>{const start=corridorTap;corridorTap=null;if(!start||e.target!==canvas||e.pointerId!==start.id||phase!=='title'||transition||Math.hypot(e.clientX-start.x,e.clientY-start.y)>12)return;const rect=canvas.getBoundingClientRect();pickPoint.set((e.clientX-rect.left)/rect.width*2-1,1-(e.clientY-rect.top)/rect.height*2);if(pickCorridor(pickPoint))openSecret();});
 listen(document,'pointercancel',()=>{corridorTap=null;});
 listen(secretBack,'click',()=>{if(phase!=='secret')return;secret.hidden=true;menu.style.animation='none';menu.hidden=false;menu.inert=false;$('play').disabled=false;time=Math.max(time,1.35);pointer.set(0,0);parallax.set(0,0);setPage('title');transition=null;black.style.opacity='0';$('play').focus({preventScroll:true});});
 listen(secret,'keydown',e=>{if(e.key==='Tab'){e.preventDefault();secretBack.focus();}else if(e.code==='Space'&&e.target===secretBack){e.stopPropagation();}});
 function resize(){reception.resize();dirty=true;}listen(window,'resize',resize);if(window.visualViewport)listen(window.visualViewport,'resize',resize);
 function setPage(next){phase=next;document.body.dataset.reception=next;bookReady=false;dirty=true;}
 function animateTo(kind,duration,done){transition={kind,time:0,duration:motion.matches?.10:duration,done};}
 function guestbook(){if(stopped||confirmed)return;setPage('guestbook');input.style.visibility='';input.disabled=true;form.querySelectorAll('button').forEach(b=>b.disabled=true);form.classList.remove('page-ready');reception.hinge.rotation.z=0;reception.writeName();animateTo('approach',.9,()=>{bookReady=true;input.disabled=false;form.querySelectorAll('button').forEach(b=>b.disabled=false);form.classList.add('page-ready');input.focus({preventScroll:true});});}
 function projectForm(){const points=reception.pageCorners().map(v=>v.project(reception.camera)).map(p=>({x:(p.x+1)*innerWidth/2,y:(1-p.y)*innerHeight/2}));form.style.transform=pageTransform(points,600,750);}
 function render(now){if(stopped)return;const dt=previous?Math.min((now-previous)/1000,.05):0;previous=now;if(document.hidden){sound.update(0,false);return;}time+=dt;let lighting=1,opacity=0;
 if(transition){const t=transition.time=Math.min(transition.duration,transition.time+dt),p=t/transition.duration;
  if(transition.kind==='play'){lighting=1-T.MathUtils.smoothstep(p,.3,.85);opacity=T.MathUtils.smoothstep(p,.28,.9);reception.bell.scale.y=1-.06*Math.sin(Math.min(1,p*5)*Math.PI);}
  if(transition.kind==='reveal')opacity=1-p;
  if(transition.kind==='secret')opacity=T.MathUtils.smoothstep(p,0,1);
  if(transition.kind==='confirm'){const close=T.MathUtils.smoothstep(p,0,.72);reception.hinge.rotation.z=-Math.PI*close;opacity=T.MathUtils.smoothstep(p,.6,1);}
  if(t>=transition.duration){const done=transition.done;transition=null;done?.();if(stopped)return;}
 }
 if(phase==='secret'){black.style.opacity='1';film.hidden=true;sound.update(dt,false);return;}
 const isBook=phase==='guestbook'||phase==='confirm',pose=isBook?reception.bookPose():reception.widePose();
 if(!motion.matches&&!isBook)parallax.lerp(pointer,1-Math.exp(-dt*4));else parallax.set(0,0);
 const desired=pose.eye.clone().add(new T.Vector3(parallax.x*.075,-parallax.y*.035,0));const rate=motion.matches?1:1-Math.exp(-dt*(isBook?8:4));currentEye.lerp(desired,rate);currentLook.lerp(pose.look,rate);reception.camera.position.copy(currentEye);reception.camera.lookAt(currentLook);reception.camera.updateMatrixWorld(true);
 if(isBook)projectForm();if(phase==='confirm'){input.style.visibility='hidden';form.style.opacity='0';}else form.style.opacity='';
 if(phase==='title'&&time<1.35&&!motion.matches)opacity=Math.max(opacity,1-T.MathUtils.smoothstep(time,.15,1.35));
 black.style.opacity=String(opacity);film.classList.toggle('tracking',time<1.35&&!motion.matches);film.hidden=false;reception.update(motion.matches?0:dt,lighting);sound.update(dt,true);
 // The same renderer and the application's single RAF are reused. Gameplay scene state is untouched.
 if(dirty||transition&&['play','confirm'].includes(transition.kind)){renderer.shadowMap.needsUpdate=true;dirty=false;}
 renderer.render(reception.scene,reception.camera);
 }
 return {render,guestbook,mode(){setPage('mode');animateTo('reveal',.30);},title(){confirmed=false;input.disabled=false;form.querySelectorAll('button').forEach(b=>b.disabled=false);setPage('title');transition=null;black.style.opacity='0';$('play').disabled=false;},play(done){if(stopped||transition||phase!=='title')return;void sound.unlock();$('play').disabled=true;sound.bell();setPage('play');animateTo('play',.82,()=>{done();});},confirm(name,done){if(stopped||confirmed||!bookReady)return false;const ink=nameInkLayout(input);confirmed=true;setPage('confirm');input.blur();input.disabled=true;form.querySelectorAll('button').forEach(b=>b.disabled=true);reception.writeName(name,ink);sound.paper();sound.bell(true);animateTo('confirm',.78,done);return true;},get confirming(){return confirmed;},get phase(){return phase;},get scene(){return reception;},stop(){if(stopped)return;stopped=true;abort.abort();corridorTap=null;secret.hidden=true;sound.stop();film.hidden=true;black.hidden=true;$('world').setAttribute('aria-label','AKUMU first-person game');delete document.body.dataset.reception;reception.dispose();},get audioReady(){return sound.ready;}};
}
