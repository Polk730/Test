import {batchVisualChildren} from './visual-batching.js';
import * as T from 'three';
import {addWallClock} from './wall-clock.js';
import {buildBreakableCloset} from './closet-damage.js';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {texture,surface,photograph,random} from './textures.js';
import {addBloodMessage} from './blood-message.js';
import {addTallyWall} from './tallies.js';
import {contactOcclusion} from './atmosphere.js';
export function createRoom(scene){
 const boxes=[],targets=[];const rand=random(88);
 const mat=(kind,color=0xffffff,roughness=.9)=>{const maps=surface(kind);const m=new T.MeshStandardMaterial({map:maps.color,normalMap:maps.normal,normalScale:new T.Vector2(kind==='wall'?.32:.23,kind==='wall'?.32:.23),roughnessMap:maps.roughness,metalnessMap:kind==='metal'?maps.roughness:null,color,roughness:kind==='wood'?.83:roughness,metalness:kind==='metal'?.72:0});m.userData.kind=kind;return m;};
 const wall=mat('wall'),wood=mat('wood'),darkwood=mat('wood',0x777064),floor=mat('floor'),ceiling=mat('ceiling'),cloth=mat('cloth'),metal=mat('metal',0x7b7161,.65);
 const box=(w,h,d,x,y,z,m=wood,parent=scene)=>{const geometry=m.userData.kind==='wood'&&w>.10&&h>.065&&d>.05?new RoundedBoxGeometry(w,h,d,1,Math.min(.004,d*.1)):new T.BoxGeometry(w,h,d);if(m.userData.kind==='wall'||m.userData.kind==='ceiling'){const uv=geometry.attributes.uv,position=geometry.attributes.position,normal=geometry.attributes.normal;for(let i=0;i<uv.count;i++){const nx=Math.abs(normal.getX(i)),ny=Math.abs(normal.getY(i));uv.setXY(i,(nx>.5?position.getZ(i)+z:position.getX(i)+x)/1.65,(ny>.5?position.getZ(i)+z:position.getY(i)+y)/1.65);}}const o=new T.Mesh(geometry,m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;};
 const cyl=(r1,r2,h,x,y,z,m=metal,parent=scene)=>{const o=new T.Mesh(new T.CylinderGeometry(r1,r2,h,16),m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;};
 const obstacle=(x,z,w,d)=>boxes.push({minX:x-w/2,maxX:x+w/2,minZ:z-d/2,maxZ:z+d/2});
 // Individual planks and dark joints keep the floor readable in grazing light.
 box(5.2,.12,4.2,0,-.075,0,new T.MeshStandardMaterial({color:0x16130f}));
 const floorVariants=[.82,.94,1.06,1.14].map(v=>{const m=floor.clone();m.color.setScalar(v);return m;});
 for(let i=0;i<25;i++){const x=-2.4+i*.2;for(let j=0;j<4;j++){const z=-1.5+j;const plank=box(.194,.045,.991,x,-.01,z,floor);plank.material=floorVariants[Math.floor(rand()*4)];for(const end of [-.45,.45]){const nail=cyl(.004,.004,.002,x-.065,.014,z+end,metal);nail.castShadow=false;}}}
 box(5.2,.15,4.2,0,2.875,0,ceiling);
 box(.16,2.8,4.2,-2.58,1.4,0,wall);box(.16,2.8,4.2,2.58,1.4,0,wall);
 // South wall contains an actual door opening; the locked slab closes it.
 box(3.35,2.8,.16,-.825,1.4,2.08,wall);box(.55,2.8,.16,2.225,1.4,2.08,wall);box(1.1,.55,.16,1.4,2.525,2.08,wall);
 // North wall, real window opening rather than a glowing panel pasted on a wall.
 box(1.45,2.8,.16,-1.775,1.4,-2.08,wall);box(1.45,2.8,.16,1.775,1.4,-2.08,wall);box(2.1,.85,.16,0,.425,-2.08,wall);box(2.1,.6,.16,0,2.5,-2.08,wall);
 for(const z of [-1.985,1.985])box(5,.14,.055,0,.07,z,darkwood);
 for(const x of [-2.485,2.485])box(.055,.14,4,x,.07,0,darkwood);
 for(const z of [-1.98,1.98])box(5,.055,.075,0,2.73,z,darkwood);
 // Damp streaks along the wall base, damaged plaster patches and sparse scraps.
 for(let i=0;i<13;i++){const paper=box(.07+rand()*.15,.001,.05+rand()*.1,-.9+rand()*2.9,.018,-.6+rand()*2.2,mat('paper',0x8b866d));paper.rotation.y=rand()*6;}
 const wallClock=addWallClock(scene,darkwood,metal);
 const tallyWall=addTallyWall(scene);
 const bloodMessage=addBloodMessage(scene);
 // Window casing, narrow glass strips, moonlit forest beyond. Background is inaccessible.
 const windowFrame=mat('wood',0x999686);
 for(const x of [-1.06,1.06])box(.09,1.48,.19,x,1.53,-2,windowFrame);
 for(const y of [.82,2.24])box(2.2,.09,.22,0,y,-1.98,windowFrame);
 box(.055,1.4,.09,0,1.53,-2.06,darkwood);box(2.1,.05,.09,0,1.53,-2.06,darkwood);box(2.3,.06,.35,0,.79,-1.94,windowFrame);
 const night=new T.MeshBasicMaterial({color:0x070d12});box(14,8,.1,0,2,-7.5,night);
 const treeMat=new T.MeshBasicMaterial({color:0x070e12});
 for(let i=0;i<25;i++){const x=(rand()-.5)*13,z=-3-rand()*4,h=2+rand()*4;const trunk=cyl(.035,.10,h,x,h/2-1,z,treeMat);trunk.castShadow=false;for(let j=0;j<3;j++){const crown=new T.Mesh(new T.ConeGeometry(.5+j*.16,h*.55,7),treeMat);crown.position.set(x,h*.6-j*.45,z);scene.add(crown);}}
 const moon=new T.Mesh(new T.SphereGeometry(.28,24,16),new T.MeshBasicMaterial({color:0x3b4c5d}));moon.position.set(.6,3.2,-7);scene.add(moon);
 const windowObstacle={minX:-1.19,maxX:1.19,minZ:-1.90,maxZ:-1.71};boxes.push(windowObstacle);
 const boards=[];const windowBarricade=new T.Group();windowBarricade.userData.dynamic=true;scene.add(windowBarricade);
 const reinforcedWood=wood.clone();reinforcedWood.color.multiplyScalar(.82);reinforcedWood.normalScale.multiplyScalar(.65);
 // Solid, aligned timber and broad fixings contrast with the fragile closet front.
 for(let i=0;i<5;i++){const b=box(2.24,.205+rand()*.01,.075,0,1.01+i*.245,-1.84,reinforcedWood,windowBarricade);b.rotation.z=(rand()-.5)*.018;boards.push(b);for(const x of [-.91,.92]){const washer=cyl(.025,.025,.006,x,0,.0405,metal,b);washer.rotation.x=Math.PI/2;const bolt=cyl(.012,.012,.016,x,0,.049,metal,b);bolt.rotation.x=Math.PI/2;}}
 const diagonal=box(2.4,.18,.085,0,1.5,-1.76,darkwood,windowBarricade);boards.push(diagonal);diagonal.rotation.z=.38;
 // Old bed: shaped turned posts, narrow rails, sagging mattress, seams, pillow and rumpled cover.
 const bed=new T.Group();bed.position.set(-1.66,0,-.27);scene.add(bed);obstacle(-1.66,-.27,1.36,2.3);
 for(const x of [-.64,.64])for(const z of [-1.06,1.06]){cyl(.035,.045,.68,x,.34,z,darkwood,bed);cyl(.055,.045,.06,x,.72,z,wood,bed);const finial=new T.Mesh(new T.SphereGeometry(.055,12,10),wood);finial.position.set(x,.79,z);bed.add(finial);}
 for(const x of [-.63,.63])box(.075,.22,2.12,x,.3,0,darkwood,bed);
 for(const z of [-1.04,1.04]){box(1.3,.1,.08,0,.55,z,wood,bed);box(1.3,.08,.08,0,.15,z,darkwood,bed);for(let x=-.48;x<.6;x+=.16)cyl(.012,.012,.31,x,.35,z,wood,bed);}
 box(1.2,.15,2.02,0,.40,0,cloth,bed);
 const mattress=box(1.18,.13,1.98,0,.51,0,cloth,bed);
 const blanketGeo=new T.PlaneGeometry(1.25,1.47,30,38);const pos=blanketGeo.attributes.position;
 for(let i=0;i<pos.count;i++){const x=pos.getX(i),y=pos.getY(i);pos.setZ(i,.009*Math.sin(x*19+y*4)+.006*Math.sin(y*22)+.012*Math.cos(x*10));}blanketGeo.computeVertexNormals();
 const blanket=new T.Mesh(blanketGeo,mat('cloth',0x656d5c));blanket.rotation.x=-Math.PI/2;blanket.position.set(.025,.616,.29);blanket.castShadow=false;blanket.receiveShadow=true;bed.add(blanket);
 for(const x of [-.61,.61])box(.025,.24,1.5,x,.495,.29,blanket.material,bed);
 const pillow=new T.Mesh(new T.SphereGeometry(1,28,18),mat('cloth',0xb3ad91));pillow.scale.set(.42,.075,.24);pillow.rotation.y=.05;pillow.position.set(-.04,.62,-.67);pillow.castShadow=true;bed.add(pillow);
 // Bedside cabinet: one working drawer. Collision includes the open drawer extension.
 const cabinet=new T.Group();cabinet.position.set(-.57,0,-1.52);scene.add(cabinet);obstacle(-.57,-1.52,.6,.58);
 for(const x of [-.24,.24])for(const z of [-.22,.22])box(.055,.24,.055,x,.12,z,darkwood,cabinet);
 box(.62,.055,.60,0,.72,0,wood,cabinet);box(.58,.06,.54,0,.23,0,darkwood,cabinet);
 for(const x of [-.27,.27])box(.05,.46,.54,x,.47,0,wood,cabinet);
 box(.54,.45,.04,0,.47,-.25,wood,cabinet);
 const drawer=new T.Group();drawer.userData.dynamic=true;drawer.position.set(0,.56,0);cabinet.add(drawer);
 box(.50,.035,.46,0,-.12,0,darkwood,drawer);box(.52,.24,.055,0,0,.27,wood,drawer);
 for(const x of [-.245,.245])box(.025,.2,.46,x,-.01,0,wood,drawer);
 const handle=cyl(.014,.014,.13,0,0,.315,metal,drawer);handle.rotation.z=Math.PI/2;
 const drawerHit=box(.52,.24,.055,0,0,.27,new T.MeshBasicMaterial({visible:false}),drawer); // raycast uses invisible material, actual geometry stays visible
 targets.push({root:drawerHit,label:'Open drawer',kind:'drawer',drawer,open:false});
 // Photograph, framed in moulded timber with a slightly reflective, scratched glass surface.
 const photo=new T.Group();
 box(.27,.35,.026,0,0,0,darkwood,photo);
 for(const x of [-.142,.142])box(.025,.38,.042,x,0,.018,wood,photo);
 for(const y of [-.18,.18])box(.31,.025,.042,0,y,.018,wood,photo);
 const picture=new T.Mesh(new T.PlaneGeometry(.252,.326),new T.MeshStandardMaterial({map:photograph(),roughness:.65}));picture.position.z=.016;photo.add(picture);
 const glass=new T.Mesh(new T.PlaneGeometry(.251,.325),new T.MeshPhysicalMaterial({color:0xd4c7a4,transparent:true,opacity:.06,roughness:.22,metalness:.1}));glass.position.z=.019;photo.add(glass);
 photo.position.set(-.57,.95,-1.56);photo.rotation.x=-.15;photo.rotation.y=.23;scene.add(photo);
 const photoHit=box(.33,.40,.07,0,0,0,new T.MeshBasicMaterial({visible:false}),photo);
 targets.push({root:photoHit,label:'Examine photograph',kind:'photo',object:photo});
 // Locked panel door, inset panels, jamb and worn brass lock.
 const door=new T.Group();door.userData.dynamic=true;door.position.set(1.4,0,1.99);scene.add(door);const doorFrame=new T.Group();doorFrame.userData.dynamic=true;doorFrame.position.copy(door.position);scene.add(doorFrame);
 const doorwood=mat('wood',0x817b66);
 box(1.0,2.20,.065,0,1.115,0,doorwood,door);
 for(const x of [-.31,.31])for(const y of [.59,1.57]){box(.27,.67,.014,x,y,-.042,darkwood,door);for(const dx of [-.15,.15])box(.025,.73,.02,x+dx,y,-.055,wood,door);for(const dy of [-.36,.36])box(.32,.025,.02,x,y+dy,-.055,wood,door);}
 for(const x of [-.56,.56])box(.11,2.28,.13,x,1.14,0,darkwood,doorFrame);box(1.23,.12,.13,0,2.28,0,darkwood,doorFrame);
 const brass=new T.MeshStandardMaterial({color:0x85734c,metalness:.65,roughness:.62});box(.055,.2,.016,.35,1.03,-.058,brass,door);
 const knob=new T.Mesh(new T.SphereGeometry(.033,16,12),brass);knob.scale.z=.7;knob.position.set(.35,1.08,-.09);door.add(knob);box(.009,.025,.003,.35,.985,-.069,new T.MeshStandardMaterial({color:0x0a0b08}),door);
 const doorHit=box(1.0,2.20,.08,0,1.115,0,new T.MeshBasicMaterial({visible:false}),door);targets.push({root:doorHit,label:'Try door',kind:'door',object:door});for(const child of door.children)child.position.x+=.5;door.position.x-=.5;
 // A restrained second barricade closes an old cupboard, rather than adding another room.
 const cupboard=new T.Group();cupboard.position.set(2.2,0,-.65);scene.add(cupboard);obstacle(2.2,-.65,.55,1.0);
 const closetDamage=buildBreakableCloset(scene,cupboard,{wood,darkwood,metal});
 const cupHit=box(.08,1.9,1,-.32,1,0,new T.MeshBasicMaterial({visible:false}),cupboard);targets.push({root:cupHit,label:'Examine barricade',kind:'barricade',object:cupboard,enabled:()=>!closetDamage.broken});
 // A shaded tungsten lamp: one downward soft-shadow source and very weak local spill.
 cyl(.10,.11,.026,.15,2.77,.05,metal);const lampStem=cyl(.009,.009,.20,.15,2.66,.05,metal);const lampSocket=cyl(.025,.023,.05,.15,2.54,.05,metal);
 const profile=[new T.Vector2(.031,.16),new T.Vector2(.039,.12),new T.Vector2(.075,.07),new T.Vector2(.15,.015),new T.Vector2(.235,-.015)];
 const shade=new T.Mesh(new T.LatheGeometry(profile,36),new T.MeshStandardMaterial({color:0x45473c,metalness:.24,roughness:.72,side:T.DoubleSide}));shade.position.set(.15,2.52,.05);shade.castShadow=false;scene.add(shade);
 const inner=new T.Mesh(new T.LatheGeometry(profile.map(p=>new T.Vector2(p.x*.985,p.y-.002)),36),new T.MeshStandardMaterial({color:0xb2a78a,roughness:.78,side:T.BackSide}));inner.position.copy(shade.position);scene.add(inner);
 const rim=new T.Mesh(new T.TorusGeometry(.235,.005,6,40),metal);rim.rotation.x=Math.PI/2;rim.position.set(.15,2.505,.05);scene.add(rim);
 const bulbMaterial=new T.MeshStandardMaterial({color:0xc9b58a,emissive:0xffd6a0,emissiveIntensity:1.35});const bulb=new T.Mesh(new T.SphereGeometry(.034,16,12),bulbMaterial);bulb.position.set(.15,2.49,.05);scene.add(bulb);
 const lamp=new T.SpotLight(0xffdfac,27,7,1.28,.42,2);lamp.position.set(.15,2.44,.05);lamp.target.position.set(.15,0,.05);lamp.castShadow=true;lamp.shadow.mapSize.set(1024,1024);lamp.shadow.bias=-.00012;lamp.shadow.normalBias=.008;lamp.shadow.radius=2.5;lamp.shadow.camera.near=.08;scene.add(lamp,lamp.target);
 const spill=new T.PointLight(0xffd7a0,1.6,4,2);spill.position.set(.15,2.46,.05);scene.add(spill);
 const ambient=new T.HemisphereLight(0x87939c,0x3b3426,.35);scene.add(ambient);
 const bounce=new T.PointLight(0xc5b491,.8,4,2);bounce.position.set(.15,.6,.05);scene.add(bounce);
 const moonlight=new T.SpotLight(0x8faed0,19,12,.55,.35,2);moonlight.position.set(-.85,3.15,-4.3);moonlight.target.position.set(.65,.15,1.3);moonlight.castShadow=true;moonlight.shadow.mapSize.set(1024,1024);moonlight.shadow.normalBias=.006;moonlight.shadow.bias=-.0001;moonlight.shadow.radius=1.5;moonlight.shadow.camera.near=.2;scene.add(moonlight,moonlight.target);
 const glassPane=box(2.02,1.33,.008,0,1.53,-2.075,new T.MeshPhysicalMaterial({color:0x6c7b7b,transparent:true,opacity:.065,roughness:.65}));glassPane.castShadow=false;
 contactOcclusion(scene);
 // Fine motes, sparsely lit and almost stationary, no noisy fullscreen effects.
 const dustGeo=new T.BufferGeometry(),points=[];for(let i=0;i<90;i++)points.push((rand()-.5)*4.8,.3+rand()*2.3,(rand()-.5)*3.8);dustGeo.setAttribute('position',new T.Float32BufferAttribute(points,3));const moteCanvas=document.createElement('canvas');moteCanvas.width=moteCanvas.height=32;const mc=moteCanvas.getContext('2d');const mg=mc.createRadialGradient(16,16,0,16,16,16);mg.addColorStop(0,'#ffffff');mg.addColorStop(.25,'#ffffffaa');mg.addColorStop(1,'#ffffff00');mc.fillStyle=mg;mc.fillRect(0,0,32,32);const dust=new T.Points(dustGeo,new T.PointsMaterial({map:new T.CanvasTexture(moteCanvas),color:0xc2b58c,size:.009,transparent:true,opacity:.12,depthWrite:false}));scene.add(dust);
 batchVisualChildren(bed);
 // Batch static geometry by material; keep photograph and drawer independently movable.
 scene.updateMatrixWorld(true);
 const batches=new Map(),staticMeshes=[];
 scene.traverse(o=>{
  if(!o.isMesh||o.material.visible===false||o.userData.noBatch)return;
  for(let parent=o;parent;parent=parent.parent)if(parent===photo||parent===bed||parent.userData.dynamic)return;
  const key=o.material.uuid+':'+o.castShadow;
  if(!batches.has(key))batches.set(key,{material:o.material,shadow:o.castShadow,geometries:[]});
  const geometry=(o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone()).applyMatrix4(o.matrixWorld);
  batches.get(key).geometries.push(geometry);staticMeshes.push(o);
 });
 for(const o of staticMeshes)o.removeFromParent();
 for(const b of batches.values()){
  const geometry=mergeGeometries(b.geometries);const mesh=new T.Mesh(geometry,b.material);mesh.castShadow=b.shadow;mesh.receiveShadow=true;scene.add(mesh);
  for(const g of b.geometries)g.dispose();
 }
 // Raycast occluders use actual structure and visible furniture, including moving drawer.
 const occluders=[];scene.traverse(o=>{if(o.isMesh && o.material.visible!==false&&!o.userData.noOcclude)occluders.push(o);});
 return {lampFixture:{stem:lampStem,socket:lampSocket,bulb},wallClock,closetDamage,cupboard,bloodMessage,tallyWall,bed,boxes,targets,door,doorFrame,drawer,cabinet,boards,windowObstacle,windowBarricade,lamp,spill,bounce,ambient,moonlight,bulbMaterial,dust,photo,occluders,drawerObstacle:{minX:-.83,maxX:-.31,minZ:-1.22,maxZ:-.86}};
}
