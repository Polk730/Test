import {StageTwoAssistance} from './stage-two-assistance.js';
export const PASSWORD_LETTERS=Object.freeze('N S E I L H E T S G I I N'.split(' '));
export class PasswordRecovery {
 constructor(){this.selected=[];this.completed=false;}
 get answer(){return this.selected.map(i=>PASSWORD_LETTERS[i]).join('');}
 get full(){return this.selected.length===PASSWORD_LETTERS.length;}
 select(index){if(this.completed||this.full||!Number.isInteger(index)||index<0||index>=PASSWORD_LETTERS.length||this.selected.includes(index))return false;this.selected.push(index);return true;}
 backspace(){if(this.completed||!this.selected.length)return false;this.selected.pop();return true;}
 clear(){if(this.completed)return false;this.selected=[];return true;}
 submit(){if(this.completed||!this.full||this.answer!=='HEISLISTENING')return false;this.completed=true;return true;}
}
export const LETTER_NUMBER_KEY=Object.freeze({A:'1',B:'2',C:'3',D:'4',E:'5',F:'6',G:'7',H:'8',I:'9'});
export class ComputerStageOne {
 constructor(random=()=>globalThis.crypto?.getRandomValues?globalThis.crypto.getRandomValues(new Uint32Array(1))[0]/4294967296:Math.random()){
  const letters=Object.keys(LETTER_NUMBER_KEY);this.sequence=Array.from({length:4},()=>letters[Math.min(8,Math.floor(random()*9))]).join('');this.powered=false;this.completed=false;this.stageTwoCompleted=false;this.passwordRecovery=new PasswordRecovery();this.assistance=new StageTwoAssistance();
 }
 powerOn(){this.powered=true;}
 get answer(){return [...this.sequence].map(c=>LETTER_NUMBER_KEY[c]).join('');}
 get stages(){return [this.completed?'COMPLETED':'AVAILABLE',this.stageTwoCompleted?'COMPLETED':this.completed?'AVAILABLE':'LOCKED',this.stageThreeCompleted?'COMPLETED':this.stageTwoCompleted?'AVAILABLE':'LOCKED',this.stageThreeCompleted?'AVAILABLE':'LOCKED'];}
 get stageThreeCompleted(){return this.passwordRecovery.completed;}
 isBoxUnlocked(id){return id===1?this.completed:id===2?this.stageTwoCompleted:id===3?this.stageThreeCompleted:false;}
 submitStageThree(){if(!this.powered||!this.stageTwoCompleted)return false;return this.passwordRecovery.submit();}
 submitStageTwo(value){if(!this.powered||!this.completed||this.stageTwoCompleted||String(value).trim().toUpperCase()!=='38C')return false;this.stageTwoCompleted=true;this.assistance.complete();return true;}
 submit(value){if(!this.powered||this.completed||!/^[1-9]{4}$/.test(String(value).trim())||String(value).trim()!==this.answer)return false;this.completed=true;this.assistance.start();return true;}
}
