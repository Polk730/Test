import * as T from 'three';

// World-space bounds of the existing corrected entrance and three fixed door frames.
// Actual rendered meshes provide the visibility test, including the desk and other occluders.
export function createCorridorPicker(root,camera){
 const entrance=new T.Box3(new T.Vector3(1.52,.02,-3.42),new T.Vector3(2.98,3.18,-3.37)),ray=new T.Raycaster(),point=new T.Vector3(),solids=[];
 root.traverse(o=>{if(o.isMesh)solids.push(o);});
 return ndc=>{
  camera.updateMatrixWorld(true);root.updateWorldMatrix(true,true);ray.setFromCamera(ndc,camera);
  const visible=ray.intersectObjects(solids,false).find(h=>{for(let p=h.object;p;p=p.parent)if(!p.visible)return false;const m=Array.isArray(h.object.material)?h.object.material[h.face?.materialIndex||0]:h.object.material;return m&&m.visible!==false&&(!m.transparent||m.opacity>.05);});
  if(!visible)return false;
  const p=visible.point,door=p.x>=2.93&&p.x<=3.08&&p.y>=0&&p.y<=2.40&&[-5.1,-8.1,-10.9].some(z=>Math.abs(p.z-z)<=.48);
  if(door)return true;
  if(!ray.ray.intersectBox(entrance,point))return false;
  return visible.distance>=ray.ray.origin.distanceTo(point)-.001;
 };
}
