import {equipmentPlastic} from './equipment-detail.js';
import {createWrenchVisual} from './wrench-visual.js';
import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {StorageEscape} from './storage-escape.js';
import {createBoxFloorMarkings} from './box-floor-markings.js';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {ComputerStageOne,LETTER_NUMBER_KEY} from './computer-stage.js';
import {StableBoxStack,STACK_BOX_SIZE} from './box-stacking.js';
import {random,surface} from './textures.js';
export function createStorageComputer(root){
 const floorMarkings=createBoxFloorMarkings(root);
 const puzzle=new ComputerStageOne(),escape=new StorageEscape(puzzle),stack=new StableBoxStack(id=>puzzle.isBoxUnlocked(id));
 function map(w,h,draw){const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;return t;}
 const worn=map(256,256,(c,w,h)=>{const r=random(541);c.fillStyle='#b4aa8d';c.fillRect(0,0,w,h);for(let i=0;i<6000;i++){c.fillStyle=`rgba(55,42,25,${r()*.1})`;c.fillRect(r()*w,r()*h,1+r()*3,1);}c.fillStyle='#665b4433';c.fillRect(0,244,w,12);});
 const beige=new T.MeshStandardMaterial({map:worn,roughness:.92}),dark=new T.MeshStandardMaterial({color:0x24251e,roughness:.93}),metal=new T.MeshStandardMaterial({color:0x514d42,metalness:.45,roughness:.8});
 const unit=new T.BoxGeometry(1,1,1);
 function box(parent,w,h,d,x,y,z,mat=beige,rounded=false){const m=new T.Mesh(rounded?new RoundedBoxGeometry(w,h,d,2,.014):unit,mat);if(!rounded)m.scale.set(w,h,d);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;parent.add(m);return m;}
 equipmentPlastic(beige);
 const computer=new T.Group();computer.position.set(3.81,.96,4.72);computer.rotation.y=-Math.PI/2;root.add(computer);
 box(computer,.54,.10,.38,0,.05,-.13,beige,true);box(computer,.52,.41,.35,0,.32,-.145,beige,true);
 box(computer,.424,.305,.012,0,.34,.036,dark,true);
 const display=new T.MeshStandardMaterial({roughness:.55,color:0xffffff,emissive:0x668e65,emissiveIntensity:.32});
 const screen=new T.Mesh(new T.PlaneGeometry(.382,.26,12,10),display);const verts=screen.geometry.attributes.position;for(let i=0;i<verts.count;i++)verts.setZ(i,.007*(1-Math.pow(verts.getX(i)/.20,2))*(1-Math.pow(verts.getY(i)/.14,2)));screen.geometry.computeVertexNormals();screen.position.set(0,.34,.045);computer.add(screen);
 for(let i=0;i<8;i++)box(computer,.003,.052,.002,-.18+i*.019,.115,.064,dark);
 box(computer,.018,.014,.005,.205,.115,.065,metal);
 box(computer,.54,.035,.19,0,.018,.055,beige,true);
 const keyGeo=new T.BoxGeometry(.034,.014,.029),keys=new T.InstancedMesh(keyGeo,beige,36),matrix=new T.Matrix4();for(let i=0;i<36;i++){matrix.makeTranslation(-.225+(i%12)*.041,.044,.014+Math.floor(i/12)*.041);keys.setMatrixAt(i,matrix);}keys.castShadow=true;computer.add(keys);
 const hit=box(computer,.56,.57,.55,0,.25,-.075,new T.MeshBasicMaterial({visible:false}));
 function refreshScreen(){const previous=display.map;const t=map(512,384,(c,w,h)=>{c.fillStyle='#07120b';c.fillRect(0,0,w,h);c.fillStyle=puzzle.powered?'#8bb68a':'#253a28';c.font='24px monospace';c.fillText(puzzle.powered?'HOTEL TERMINAL':'POWER OFF',30,49);if(puzzle.powered){puzzle.stages.forEach((status,i)=>c.fillText(`${i+1}  ${status}`,30,110+i*58));}for(let y=0;y<h;y+=4){c.fillStyle='#00000022';c.fillRect(0,y,w,1);}});display.map=t;display.emissiveMap=t;display.needsUpdate=true;previous?.dispose();}
 refreshScreen();
 const clueMaterial=new T.MeshStandardMaterial({map:map(768,960,(c,w,h)=>{const r=random(371);c.fillStyle='#baad89';c.fillRect(0,0,w,h);for(let i=0;i<5000;i++){c.fillStyle='#503d2310';c.fillRect(r()*w,r()*h,2,1);}c.fillStyle='#252b22';c.textAlign='center';c.font='bold 38px monospace';c.fillText('LETTER / NUMBER',w/2,100);c.font='43px monospace';Object.entries(LETTER_NUMBER_KEY).forEach(([a,n],i)=>c.fillText(`${a} = ${n}`,w/2,190+i*70));}),roughness:1,side:T.DoubleSide});
 const clue=new T.Mesh(new T.PlaneGeometry(.32,.40),clueMaterial);clue.position.set(7.285,1.4,8.75);clue.rotation.y=-Math.PI/2;root.add(clue);
 const wood=new T.MeshStandardMaterial({map:surface('wood',72).color,roughness:.95,color:0x8d795d}),band=new T.MeshStandardMaterial({color:0x59594b,roughness:.85,metalness:.35});
 const openParts=[[.55,.035,.55,0,-.2575,0],[.035,.55,.55,-.2575,0,0],[.035,.55,.55,.2575,0,0],[.48,.55,.035,0,0,-.2575],[.48,.55,.035,0,0,.2575]].map(([w,h,d,x,y,z])=>new T.BoxGeometry(w,h,d).translate(x,y,z));
 const openGeometry=mergeGeometries(openParts);for(const g of openParts)g.dispose();
 const crates=stack.boxes.map(b=>{const g=new T.Group();g.name=`puzzle-box-${b.id}`;root.add(g);const size=STACK_BOX_SIZE;
  const body=box(g,size,size,size,0,0,0,wood,true);body.userData.closed=true;const carryHit=box(g,size,size,size,0,0,0,new T.MeshBasicMaterial({visible:false}));
  const lid=new T.Group();lid.position.set(0,size/2,-size/2-.025);lid.visible=false;g.add(lid);box(lid,size,.035,size,0,0,size/2,wood);
  for(const x of [-.20,.20]){box(g,.025,size+.005,size+.005,x,0,0,band);}
  const label=map(256,256,(c,w,h)=>{c.fillStyle='#c1b38b';c.fillRect(0,0,w,h);c.fillStyle='#302c23';c.textAlign='center';c.font='bold 35px monospace';c.fillText('BOX',128,72);c.font='bold 110px monospace';c.fillText(String(b.id),128,185);});
  const tagMaterial=new T.MeshStandardMaterial({map:label,roughness:.95});for(const axis of ['z','x'])for(const side of [-1,1]){const tag=new T.Mesh(new T.PlaneGeometry(.20,.20),tagMaterial);if(axis==='z'){tag.position.z=side*(size/2+.002);tag.rotation.y=side<0?Math.PI:0;}else{tag.position.x=side*(size/2+.002);tag.rotation.y=side*Math.PI/2;}g.add(tag);}
  if(b.id===1){const wrench=new T.Group();wrench.name='reserved-wrench';wrench.position.y=.20;wrench.add(createWrenchVisual());wrench.visible=false;g.add(wrench);const toolHit=box(g,.34,.18,.42,0,.28,0,new T.MeshBasicMaterial({visible:false}));toolHit.name='wrench-target';}
  const glow=new T.Mesh(new T.BoxGeometry(size+.009,size+.009,size+.009),new T.MeshBasicMaterial({color:0xb2c6a1,transparent:true,opacity:.08,side:T.BackSide,depthWrite:false}));glow.visible=false;g.add(glow);
  const throughWall=new T.LineSegments(new T.EdgesGeometry(new T.BoxGeometry(size+.024,size+.024,size+.024)),new T.LineBasicMaterial({color:0x8cfa92,transparent:true,opacity:.9,depthTest:false,depthWrite:false,fog:false,toneMapped:false}));throughWall.name='glowing-box-outline';throughWall.renderOrder=10000;throughWall.visible=false;g.add(throughWall);
  return {id:b.id,root:g,body,lid,glow,throughWall,target:{root:carryHit,object:g,kind:'stack-box',boxId:b.id,enabled:()=>stack.canPickup(b.id)}};
 });
 function refreshBoxes(){for(const c of crates){const opened=escape.opened.has(c.id);c.body.userData.closed=!opened;if(opened){c.body.geometry=openGeometry;c.body.scale.set(1,1,1);}c.lid.visible=opened;c.lid.rotation.x=-Math.PI*1.5;const p=stack.position(c.id),unlocked=puzzle.isBoxUnlocked(c.id);if(stack.heldId!==c.id){c.root.position.set(p.x,p.y,p.z);c.root.rotation.set(0,0,0);}c.glow.visible=unlocked;c.throughWall.visible=unlocked&&stack.heldId!==c.id;if(!c.body.material.userData.boxMaterial){c.body.material=c.body.material.clone();c.body.material.userData.boxMaterial=true;}c.body.material.emissive.set(unlocked?0x647857:0x000000);c.body.material.emissiveIntensity=unlocked?.36:0;}}
 function updateCarried(camera,obstacles,bounds){if(stack.heldId===null)return false;const c=crates.find(c=>c.id===stack.heldId),p=new T.Vector3(.25,-.32,-.8).applyMatrix4(camera.matrixWorld),margin=.29;
  for(let round=0;round<4;round++){p.x=T.MathUtils.clamp(p.x,bounds.minX+margin,bounds.maxX-margin);p.z=T.MathUtils.clamp(p.z,bounds.minZ+margin,bounds.maxZ-margin);for(const o of obstacles){const minX=o.minX-margin,maxX=o.maxX+margin,minZ=o.minZ-margin,maxZ=o.maxZ+margin;if(p.x>minX&&p.x<maxX&&p.z>minZ&&p.z<maxZ){const choices=[[p.x-minX,'x',minX],[maxX-p.x,'x',maxX],[p.z-minZ,'z',minZ],[maxZ-p.z,'z',maxZ]].sort((a,b)=>a[0]-b[0]);p[choices[0][1]]=choices[0][2];}}}
  c.root.position.copy(p);c.root.rotation.set(0,camera.rotation.y,0);return true;
 }
 function openBox(id){if(!stack.canPickup(id)||!escape.open(id))return false;refreshBoxes();if(id===1)crates[0].root.getObjectByName('reserved-wrench').visible=true;return true;}
 function collectWrench(inventory){if(stack.heldId!==null||!escape.collectWrench(inventory))return false;crates[0].root.getObjectByName('reserved-wrench').visible=false;return true;}
 const wrenchTarget={root:crates[0].root.getObjectByName('wrench-target'),object:crates[0].root,kind:'wrench',enabled:()=>escape.opened.has(1)&&crates[0].root.getObjectByName('reserved-wrench').visible&&stack.heldId===null&&stack.isTop(1)};
 refreshBoxes();
 return {puzzle,stack,escape,openBox,collectWrench,computer,clue,crates,floorMarkings,targets:[{root:hit,object:computer,kind:'computer',enabled:()=>true},{root:clue,object:clue,kind:'cipher-clue',enabled:()=>true},...crates.map(c=>c.target),wrenchTarget],refreshScreen,refreshBoxes,updateCarried,get colliders(){return stack.colliders;}};
}
