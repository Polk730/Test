import * as T from 'three';
// A tiny, original soft-light reflection probe for metal only; no scene-wide ambient wash.
export function createMetalReflections(renderer){
 const faces=Array.from({length:6},(_,i)=>{const c=document.createElement('canvas');c.width=c.height=64;const ctx=c.getContext('2d'),g=ctx.createLinearGradient(0,0,0,64);g.addColorStop(0,i===2?'#9b927c':'#484c4b');g.addColorStop(.45,'#323a3c');g.addColorStop(1,'#171a18');ctx.fillStyle=g;ctx.fillRect(0,0,64,64);if(i!==3){const light=ctx.createLinearGradient(12,0,35,0);light.addColorStop(0,'#b7c3bf00');light.addColorStop(.5,i===0?'#e5cf9c88':'#c3d7e088');light.addColorStop(1,'#b7c3bf00');ctx.fillStyle=light;ctx.fillRect(12,6,23,35);}return c;});
 const cube=new T.CubeTexture(faces);cube.colorSpace=T.SRGBColorSpace;cube.needsUpdate=true;const pmrem=new T.PMREMGenerator(renderer),target=pmrem.fromCubemap(cube);cube.dispose();pmrem.dispose();return target;
}
