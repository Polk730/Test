import {createBasement} from './basement-room.js';
import {createBasementAudio} from './basement-audio.js';
import {BasementJourney} from './basement-journey.js';
import {BASEMENT_ROOM,BASEMENT_FLOOR,STAIRS,basementWet,walkBasement} from './basement-layout.js';
import {createCoffeeFoley} from './coffee-play.js';
import {prepareGame,paintLoading} from './game-preload.js';
import {createLaundryContinuation} from './laundry-room.js';
import {createLaundryAudio} from './laundry-audio.js';
import {LaundryJourney,DUCT_ROOM,LAUNDRY_ROOM,DUCT_EYE,DUCT_ENTRY,LAUNDRY_FLOOR} from './laundry-layout.js';
import {surfaceBuildStats} from './aged-surface.js';
import {GraphicsQuality,polishLighting} from './graphics-quality.js';
import {createMetalReflections} from './metal-reflections.js';
import {DemoInvitation} from './demo-invitation.js';
import {createObservationAudio} from './observation-audio.js';
import {createObservationRoom} from './observation-room.js';
import {captureBedroomRecordings} from './bedroom-recordings.js';
import * as T from 'three';
import photoVoice from './assets/photo-voice.mp3?inline';
import letterVoice from './assets/letter-voice.mp3?inline';
import assistanceVoice from './assets/attention-assistance.mp3?inline';
import pcStartup from './assets/pc-startup.mp3?inline';
import {ClockAttention} from './clock-attention.js';
import clockVoice from './assets/clock-voice.mp3?inline';
import uploadedScareSfx from './assets/uploaded-scare-sfx.mp3?inline';
import {validatePlayerName} from './name-filter.js';
import {createSpiderScare} from './spider-scare.js';
import closetScareVoice from './assets/closet-scare-voice.mp3?inline';
import './style.css';
import './reception.css';
import {createRoom} from './room.js';
import {walkOnCrates} from './crate-walking.js';
import {createComputerInterface} from './computer-interface.js';
import {createStorageRoom} from './storage-room.js';
import {RoomProgression} from './room-progression.js';
import {ROOM} from './physics.js';
import {STORAGE_BOUNDS,PASSAGE_BOUNDS,BEDROOM_PORTAL_WALLS} from './storage-layout.js';
import {move} from './physics.js';
import {Ambience} from './audio.js';
import {createTouchInput} from './touch.js';
import {createPuzzle} from './puzzle.js';
import {LampFaults,KeyBlackout} from './atmosphere.js';
import {initTitleMenu} from './menu.js';
import wakeupVoice from './assets/wakeup-voice.mp3?inline';
import wrongCodeVoice from './assets/wrong-code-voice.mp3?inline';
import drawerRepeatVoice from './assets/drawer-repeat-voice.mp3?inline';
import escapeVoice from './assets/escape-voice.mp3?inline';
import cabinetVoice from './assets/cabinet-voice.mp3?inline';
import bedVoice from './assets/bed-voice.mp3?inline';
import doorVoice from './assets/locked-door-voice.mp3?inline';
import hammerDoorVoice from './assets/hammer-door-voice.mp3?inline';
import {OPENING,openingFrame} from './opening.js';
const $=id=>document.getElementById(id);
let touchMode=navigator.maxTouchPoints>0&&matchMedia('(pointer: coarse)').matches;
const canvas=$('world'),menu=$('menu'),veil=$('veil'),hud=$('hud'),pause=$('pause'),prompt=$('prompt'),inspection=$('inspection');
let menuEffects;const spiderScare=createSpiderScare();let finishClosetScare=null;

let renderer;
try{renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});}
catch{$('error').hidden=false;$('error').textContent='AKUMU needs WebGL 2. Please open it in a current browser with hardware acceleration enabled.';throw new Error('WebGL 2 unavailable');}
renderer.setPixelRatio(Math.min(devicePixelRatio,touchMode?1.25:1.5));
renderer.setSize(innerWidth,innerHeight);
renderer.shadowMap.enabled=true;
renderer.shadowMap.autoUpdate=false;
renderer.shadowMap.needsUpdate=true;
renderer.shadowMap.type=T.PCFSoftShadowMap;
renderer.outputColorSpace=T.SRGBColorSpace;
renderer.toneMapping=T.ACESFilmicToneMapping;
renderer.toneMappingExposure=1.20;
const scene=new T.Scene();scene.background=new T.Color(0x060b10);scene.fog=new T.FogExp2(0x141a1c,.038);
const graphicsQuality=new GraphicsQuality(renderer,touchMode);
const environmentTarget=createMetalReflections(renderer);
const camera=new T.PerspectiveCamera(65,innerWidth/innerHeight,.04,30);camera.rotation.order='YXZ';
const bedroomRoot=new T.Group(),storageRoot=new T.Group(),sharedRoot=new T.Group();scene.add(bedroomRoot,storageRoot,sharedRoot);storageRoot.visible=false;
const room=createRoom(bedroomRoot),audio=new Ambience(),ray=new T.Raycaster(),faults=new LampFaults(),blackout=new KeyBlackout(),clockAttention=new ClockAttention(),clockRay=new T.Raycaster();clockRay.far=8;ray.far=1.8;
menuEffects=initTitleMenu({menu,renderer,environment:environmentTarget.texture,audio});
sharedRoot.attach(room.door);sharedRoot.attach(room.doorFrame);
const storage=createStorageRoom(storageRoot,room.door,room.targets.find(t=>t.kind==='door')),progression=new RoomProgression();let gameMode='normal',observation=null;let currentRoom=1,playerName='',testStartRoomTwo=false,testStartRoomThree=false,roomTwoMotion={feet:0,fallSpeed:0};
function ensureObservation(){if(!observation){const frames=captureBedroomRecordings(renderer,scene,{room,puzzle,bedroomRoot,storageRoot,sharedRoot}),root=new T.Group();root.visible=false;scene.add(root);observation=createObservationRoom(root,frames);observation.sound=createObservationAudio(audio);polishLighting(root,environmentTarget.texture);room.door.traverse(o=>{if(o.isMesh)observation.occluders.push(o);});room.doorFrame.traverse(o=>{if(o.isMesh)observation.occluders.push(o);});}return observation;}
function activateObservation(){const o=ensureObservation();if(puzzle.state.hammer==='carried')puzzle.dropHammer();puzzle.hammer.visible=false;currentRoom=3;o.root.visible=true;storageRoot.visible=false;o.activate();focused=null;scene.fog.color.set(0x18201e);scene.fog.density=.032;$('room-label').innerHTML='<span>02</span> THE OBSERVATION ROOM';renderer.shadowMap.needsUpdate=true;}
let laundryContinuation=null;const laundryJourney=new LaundryJourney(),basementJourney=new BasementJourney();let laundrySound=null;
function ensureLaundry(){if(!laundryContinuation){laundryContinuation=createLaundryContinuation(scene);laundrySound=createLaundryAudio(audio);laundryContinuation.coffeeSound=createCoffeeFoley(audio,laundryContinuation.coffee);laundryContinuation.basement=createBasement(scene,laundryContinuation);laundryContinuation.basement.sound=createBasementAudio(audio);laundryContinuation.coffeePlay.setSpace(laundryContinuation.basement.walking.boxes,laundryContinuation.basement.walking.bounds,laundryContinuation.basement.floorAt);polishLighting(laundryContinuation.duct.root,environmentTarget.texture);polishLighting(laundryContinuation.laundry.root,environmentTarget.texture);polishLighting(laundryContinuation.basement.root,environmentTarget.texture);}return laundryContinuation;}
function enterLaundryDuct(){
 if(gameMode!=='normal'||currentRoom!==2||!storage.vent.isOpen||!laundryJourney.enter(camera.position))return;
 const next=ensureLaundry();if(puzzle.state.hammer==='carried')puzzle.dropHammer();puzzle.hammer.visible=false;
 audio.stopPCBeacon();storageRoot.visible=false;bedroomRoot.visible=false;sharedRoot.visible=false;next.duct.root.visible=next.laundry.root.visible=next.basement.root.visible=true;
 currentRoom=DUCT_ROOM;focused=null;velocity.set(0,0);setBusy(true);yaw=Math.PI;pitch=0;scene.fog.color.set(0x101918);scene.fog.density=.035;$('room-label').innerHTML='<span>—</span> VENTILATION';renderer.shadowMap.needsUpdate=true;
}
function useSecretWasher(){
 const l=laundryContinuation;if(basementJourney.open()){l.basement.sound.door({x:22.29,y:1.37,z:13.2});renderer.shadowMap.needsUpdate=true;return;}
 if(!basementJourney.enter(camera.position,yaw,pitch))return;l.coffeePlay.setCarryVisible(false);focused=null;velocity.set(0,0);setBusy(true);
}
function updateBasement(dt){
 if(!laundryContinuation||![LAUNDRY_ROOM,BASEMENT_ROOM].includes(currentRoom))return;const l=laundryContinuation,b=l.basement,active=state==='playing'&&!paused&&!document.hidden;
 const target=basementJourney.doorOpen?-1.5:0;if(Math.abs(l.secretWasher.door.rotation.y-target)>.001){l.secretWasher.door.rotation.y=T.MathUtils.damp(l.secretWasher.door.rotation.y,target,9,active?Math.min(dt,.05):0);renderer.shadowMap.needsUpdate=true;}
 if(active&&basementJourney.sliding){const pose=basementJourney.update(dt);if(pose){camera.position.copy(pose.position);yaw=pose.yaw;pitch=pose.pitch;if(pose.done){currentRoom=BASEMENT_ROOM;l.coffeePlay.setCarryVisible(true);velocity.set(0,0);setBusy(false);b.sound.land(camera.position);renderer.shadowMap.needsUpdate=true;}}}
 if(!basementJourney.sliding){const next=camera.position.z>STAIRS.minZ+.02?BASEMENT_ROOM:LAUNDRY_ROOM;if(currentRoom!==next){currentRoom=next;renderer.shadowMap.needsUpdate=true;}}
 if(b.updateExit(camera.position,active?Math.min(dt,.05):0))renderer.shadowMap.needsUpdate=true;
 const floor=b.floorAt(camera.position.x,camera.position.z),above=b.update(elapsed,floor);
 l.laundry.root.traverse(o=>{if(o.isHemisphereLight)o.intensity=.58*above;});
 scene.fog.color.set(currentRoom===BASEMENT_ROOM?0x171c18:0x202925);scene.fog.density=currentRoom===BASEMENT_ROOM?.045:.017;
 $('room-label').innerHTML=currentRoom===BASEMENT_ROOM?'<span>—</span> THE BASEMENT — ABANDONED STORAGE':'<span>03</span> THE LAUNDRY ROOM';
 b.sound.update(dt,active,basementJourney.sliding,currentRoom===BASEMENT_ROOM&&!basementJourney.sliding);
}
function updateLaundry(dt,realDt=dt){
 if(!laundryContinuation)return;const active=state==='playing'&&!paused&&!document.hidden;
 if(currentRoom===DUCT_ROOM&&active){
  const p=laundryJourney.update(dt);if(p)camera.position.set(p.x,p.y,p.z);
  if(busy&&laundryJourney.phase==='crawling')setBusy(false);
  if(laundryJourney.phase==='laundry'){currentRoom=LAUNDRY_ROOM;laundryContinuation.duct.root.visible=false;velocity.set(0,0);pitch=0;yaw=-Math.PI/2;setBusy(false);scene.fog.color.set(0x202925);scene.fog.density=.017;$('room-label').innerHTML='<span>03</span> THE LAUNDRY ROOM';audio.footstep('storage');renderer.shadowMap.needsUpdate=true;}
  if(laundryJourney.phase==='crawling'&&!laundryJourney.behindPlayed&&camera.position.z>16.15){laundryJourney.behindPlayed=true;laundrySound.metal({x:camera.position.x+Math.sin(yaw)*1.6,y:3.1,z:camera.position.z+Math.cos(yaw)*1.6},.065,.7);}
 }
 if(currentRoom===DUCT_ROOM||currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM){if(active)laundryContinuation.update(elapsed,laundryJourney.phase==='exiting'||laundryJourney.phase==='laundry');laundrySound.update(dt,active&&currentRoom!==BASEMENT_ROOM,currentRoom===DUCT_ROOM,camera.position);}
}
function getSpace(includeDrawer=false){
 if(currentRoom===DUCT_ROOM)return laundryContinuation.duct;
 if(currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM)return laundryContinuation.basement.walking;
 if(currentRoom===3)return {root:observation.root,boxes:observation.boxes,bounds:observation.bounds,bedroom:false};
 if(currentRoom===2)return {root:storageRoot,boxes:[...storage.boxes,...storage.terminal.colliders],bounds:STORAGE_BOUNDS,bedroom:false};
 let boxes=progression.portalOpen?[...room.boxes,...BEDROOM_PORTAL_WALLS,...(gameMode==='demo'?ensureObservation().boxes:[...storage.boxes,...storage.terminal.colliders])]:room.boxes;
 if(includeDrawer&&drawerAmount>.04)boxes=[...boxes,room.drawerObstacle];
 return {root:bedroomRoot,boxes,bounds:progression.portalOpen?(gameMode==='demo'?{...PASSAGE_BOUNDS,maxX:7.6,maxZ:8.08}:PASSAGE_BOUNDS):ROOM,bedroom:true};
}
function refreshStorageDoorOccluders(){for(const parent of [room.door,room.doorFrame])parent.traverse(o=>{if(o.isMesh&&o.material?.visible!==false&&!storage.occluders.includes(o))storage.occluders.push(o);});}
function beginRoomTwoPassage(){
 if(!progression.unlock())return;if(gameMode==='demo')ensureObservation().root.visible=true;else storageRoot.visible=true;storage.installDoorReverse();refreshStorageDoorOccluders();audio.startPassageVoice();renderer.shadowMap.needsUpdate=true;
}
function activateStorage(){if(storageEnteredAt===null)storageEnteredAt=performance.now()/1000;currentRoom=2;roomTwoMotion={feet:0,fallSpeed:0};storage.activate();if(puzzle.state.hammer==='carried')storageRoot.attach(puzzle.hammer);focused=null;scene.fog.color.set(0x151619);scene.fog.density=.021;$('room-label').innerHTML='<span>02</span> THE STORAGE ROOM';}
function updateRoomProgression(dt){
 for(const event of progression.update(dt,puzzle.state.door==='open',camera.position)){
  if(event==='entered'){if(gameMode==='demo')activateObservation();else activateStorage();}
  if(event==='slam'){audio.play('doorSlam',-.1);audio.play('doorLock',-.1,.5);bedroomRoot.visible=false;renderer.shadowMap.needsUpdate=true;}
  if(event==='lock'){puzzle.state.door='locked-behind';}
 }
 if(progression.committed&&room.door.rotation.y!==progression.angle){room.door.rotation.y=progression.angle;renderer.shadowMap.needsUpdate=true;}
}
storage.entryTarget.enabled=()=>progression.phase==='locked';
storage.vent.setExitHandler(()=>{if(currentRoom===2)enterLaundryDuct();});
const voiceReady=Promise.all([audio.prepareVoice(wakeupVoice),audio.prepareVoice(doorVoice,'doorVoiceBuffer'),audio.prepareVoice(hammerDoorVoice,'hammerDoorVoiceBuffer'),audio.prepareVoice(bedVoice,'bedVoiceBuffer'),audio.prepareVoice(wrongCodeVoice,'wrongCodeVoiceBuffer'),audio.prepareVoice(cabinetVoice,'cabinetVoiceBuffer'),audio.prepareVoice(escapeVoice,'escapeVoiceBuffer'),audio.prepareVoice(drawerRepeatVoice,'drawerRepeatVoiceBuffer'),audio.prepareVoice(closetScareVoice,'closetScareVoiceBuffer'),audio.prepareVoice(uploadedScareSfx,'uploadedScareBuffer'),audio.prepareVoice(clockVoice,'clockVoiceBuffer'),audio.prepareVoice(photoVoice,'photoVoiceBuffer'),audio.prepareVoice(letterVoice,'letterVoiceBuffer'),audio.prepareVoice(assistanceVoice,'assistanceVoiceBuffer'),audio.prepareVoice(pcStartup,'pcStartupBuffer')]).catch(()=>false);
let openingReady=false,openingUsesAudio=false,runStartedAt=null,runSeconds=0,escapeSeconds=null,endingUsesAudio=false,endingRealStart=0;
const demoInvitation=new DemoInvitation();
const formatTime=seconds=>{const total=Math.max(0,Math.floor(seconds));return String(Math.floor(total/60)).padStart(2,'0')+':'+String(total%60).padStart(2,'0');};
let state='menu',paused=false,busy=false,dragLook=false,mouseLooking=false,lookPointer=null,captureWanted=false,captureBlocked=false,captureTimer=0,wasLocked=false,openingInterrupted=false,touchInput=null,puzzle;
let yaw=0,pitch=0,openingStart=0,last=performance.now(),elapsed=0,focused=null,stepsDistance=0,drawerAmount=0,endingAt=0,keyFoundAt=0,keyFoundModel=null;
let storageEnteredAt=null,pcStartupPlayed=false;
let photoInspectStartedAt=null,photoVoicePlayed=false,letterVoicePending=false,letterVoicePlayed=false,boxNoticeUntil=0;
let inspectDistance=.62,drag=false,lastPointer=null,inspectPress=null,inspected=null,inspectionKind=null,sourceObject=null,sourceVisible=true;
const velocity=new T.Vector2(),keys=new Set(),pcBeaconPosition=new T.Vector3();
const playable=()=>state==='playing'&&!paused&&!busy&&!document.hidden;
const inspectScene=new T.Scene(),inspectCamera=new T.PerspectiveCamera(42,innerWidth/innerHeight,.01,10);
inspectCamera.position.z=inspectDistance;
inspectScene.add(new T.HemisphereLight(0xe4dec5,0x343d3c,1.8));
const inspectLight=new T.DirectionalLight(0xffe8cc,2.8);inspectLight.position.set(-1,2,3);inspectScene.add(inspectLight);
const smooth=t=>{t=T.MathUtils.clamp(t,0,1);return t*t*(3-2*t);};
function clearInput(){keys.clear();velocity.set(0,0);stepsDistance=0;mouseLooking=false;lookPointer=null;touchInput?.reset();}
function syncUI(){
 document.body.classList.toggle('using-storage-panel',state==='computer');
 document.body.classList.toggle('reading-storage-letter',state==='inspecting'&&inspectionKind==='envelope'&&storage.envelope.opened);
 pause.hidden=state!=='playing'||!paused;hud.hidden=!playable();inspection.hidden=state!=='inspecting';
 $('touch-zoom').hidden=!touchMode||state!=='inspecting';
 $('key-found').hidden=state!=='key-found';
 touchInput?.update(playable(),(currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM)&&laundryContinuation.coffeePlay.model.heldFull&&focused?.kind!=='coffee-machine'&&focused?.kind!=='basement-washer'?'DRINK':'INTERACT');
 $('touch-drop').hidden=!touchMode||!playable()||!carryingItem();
 document.body.classList.toggle('touch-mode',touchMode);
 $('input-notice').hidden=touchMode||!playable()||document.pointerLockElement===canvas||!captureBlocked;
}
function setPaused(value){last=performance.now();paused=value;if(value){captureWanted=false;if(document.pointerLockElement===canvas)document.exitPointerLock();}clearInput();syncUI();if(value)void audio.pause();else void audio.resume();}
function setBusy(value){busy=value;clearInput();syncUI();}
function focusGame(){canvas.focus({preventScroll:true});}
function captureFailed(){
 if(document.pointerLockElement===canvas)return;
 clearTimeout(captureTimer);captureBlocked=true;captureWanted=false;dragLook=true;syncUI();
}
function requestCapture(retry=false){
 if(touchMode)return;
 focusGame();dragLook=document.pointerLockElement!==canvas;
 if(captureBlocked&&!retry){syncUI();return;}
 captureWanted=true;
 if(typeof canvas.requestPointerLock!=='function'){captureFailed();return;}
 try{
  const result=canvas.requestPointerLock();result?.catch(captureFailed);
  clearTimeout(captureTimer);captureTimer=setTimeout(()=>{if(captureWanted&&document.pointerLockElement!==canvas){dragLook=true;captureBlocked=true;syncUI();}},1000);
 }catch{captureFailed();}
}
document.addEventListener('pointerlockerror',captureFailed);
document.addEventListener('pointerlockchange',()=>{
 const locked=document.pointerLockElement===canvas,previous=wasLocked;wasLocked=locked;clearInput();
 if(locked){clearTimeout(captureTimer);if(!captureWanted){document.exitPointerLock();return;}captureBlocked=false;dragLook=false;focusGame();syncUI();}
 else if(previous){captureWanted=false;if(state==='key-found')finishKeyFound(true);else if(state==='playing'&&!touchMode)setPaused(true);else if((state==='opening'||state==='loading')&&!touchMode)openingInterrupted=true;}
});
let startupReady=false;
function loadingProgress(label,value){const labels={'Preparing the room...':'Preparing accommodation...','Preparing surfaces...':'Recording accommodation details...','Preparing sound...':'Checking room arrangements...','Preparing lighting...':'Completing arrival record...','Preparing shadows...':'Checking the arrival record...','Finishing lighting...':'Final checks...','Ready.':'Your room is ready.'};$('loading-status').textContent=labels[label]||label;$('loading-progress').value=value;}
async function start(){
 if(state!=='menu'&&state!=='loading-error')return;
 state='loading';menuEffects.stop();menu.hidden=true;veil.style.opacity=1;$('game-loading').hidden=false;$('loading-retry').hidden=true;$('game-loading').setAttribute('aria-busy','true');loadingProgress('Preparing the room...',0);
 requestCapture();syncUI();
 const audioReady=audio.start().catch(()=>{}),sfx=audio.sfx?.gain.value,ambience=audio.ambience?.gain.value;
 if(audio.sfx)audio.sfx.gain.value=0;if(audio.ambience)audio.ambience.gain.value=0;
 try{
  await paintLoading();
  await Promise.race([audioReady,new Promise(resolve=>setTimeout(resolve,2500))]);await voiceReady;
  storage.installDoorReverse();
  const roots=[bedroomRoot,storageRoot,sharedRoot],passes=[{roots:[bedroomRoot,sharedRoot],eye:[0,1.65,0],look:[0,1.5,-2]}],extra=[];
  if(gameMode==='demo'){
   loadingProgress('Preparing the room...',.02);await paintLoading();const o=ensureObservation();roots.push(o.root);
   passes.push({roots:[bedroomRoot,sharedRoot,o.root],eye:[1.4,1.65,2.4],look:[3,1.5,6]},{roots:[sharedRoot,o.root],eye:[3.5,1.65,5],look:[3,1.4,7]});
   extra.push(['Preparing the room...',()=>o.prepare(renderer,scene)]);
  }else{
   loadingProgress('Preparing the room...',.02);await paintLoading();const l=ensureLaundry();await l.portraits.ready;roots.push(l.duct.root,l.laundry.root,l.basement.root);extra.push(['Preparing sound...',()=>l.basement.sound.prepare()]);
   passes.push({roots:[bedroomRoot,sharedRoot,storageRoot],eye:[1.4,1.65,2.4],look:[3,1.5,6]},{roots:[bedroomRoot,sharedRoot,storageRoot],lights:[storage.ambient],eye:[1.4,1.65,2.9],look:[3,1.5,6]},{roots:[storageRoot,sharedRoot],lights:[storage.ambient],eye:[6,1.65,6],look:[6,1.5,10]},{roots:[l.duct.root,l.laundry.root,l.basement.root],eye:[10.35,3.05,16.9],look:[16.85,3.05,17.08]},{roots:[l.laundry.root,l.basement.root],eye:[21,2.49,17],look:[25,2.3,17]},{roots:[l.laundry.root,l.basement.root],eye:[25.6,-.11,25.5],look:[24.5,-.2,24]});
  }
  extra.push(['Preparing the room...',()=>spiderScare.prepare(renderer)]);
  const materialVariants=[];if(gameMode==='normal')storage.strawHat.root.traverse(o=>{if(o.isMesh&&!materialVariants.includes(o.material))materialVariants.push(o.material);});
  await prepareGame({renderer,scene,camera,roots,passes,audio,materialVariants,inspection:{roots:[bedroomRoot,...(gameMode==='normal'?[storageRoot]:[])],scene:inspectScene,camera:inspectCamera},extra,progress:(label,value)=>loadingProgress(label,.04+.95*value)});
  startupReady=true;loadingProgress('Ready.',1);await paintLoading();
 }catch(error){
  console.error('AKUMU loading interrupted',error);state='loading-error';loadingProgress('Loading interrupted. Please try again.',0);$('loading-retry').hidden=false;$('loading-retry').focus();$('game-loading').setAttribute('aria-busy','false');captureWanted=false;if(document.pointerLockElement===canvas)document.exitPointerLock();syncUI();return;
 }finally{if(audio.sfx&&sfx!==undefined)audio.sfx.gain.value=sfx;if(audio.ambience&&ambience!==undefined)audio.ambience.gain.value=ambience;}
 $('game-loading').hidden=true;$('game-loading').setAttribute('aria-busy','false');state='opening';openingStart=performance.now();last=openingStart;camera.position.set(-1.65,.69,-.24);pitch=1.24;yaw=.08;syncUI();
 if(testStartRoomThree){
  progression.startInStorage();currentRoom=2;puzzle.state.key='collected';puzzle.state.door='locked-behind';camera.position.set(DUCT_ENTRY.x,DUCT_ENTRY.y,DUCT_ENTRY.z);runStartedAt=elapsed;runSeconds=0;state='playing';veil.style.opacity=0;$('opening-caption').textContent='';clearInput();setPaused(openingInterrupted);storage.vent.openWithTool({kind:'wrench'});enterLaundryDuct();return;
 }
 if(testStartRoomTwo){
  storageRoot.visible=true;storage.installDoorReverse();refreshStorageDoorOccluders();progression.startInStorage();activateStorage();bedroomRoot.visible=false;puzzle.state.key='collected';puzzle.state.door='locked-behind';camera.position.set(1.4,1.65,3);yaw=Math.PI;pitch=0;camera.rotation.set(pitch,yaw,0);renderer.shadowMap.needsUpdate=true;runStartedAt=elapsed;runSeconds=0;state='playing';veil.style.opacity=0;$('opening-caption').textContent='';clearInput();setPaused(openingInterrupted);return;
 }
 if(gameMode==='demo')ensureObservation();
 openingUsesAudio=audio.scheduleOpeningVoice(OPENING.voiceStart);openingStart=performance.now();openingReady=true;

}
function beginInspection({object,kind='photo',title='An old photograph',description='Someone used to call this place home.',scale=1}){
 if(state!=='playing'||busy)return;
 state='inspecting';captureWanted=false;clearInput();inspectionKind=kind;photoInspectStartedAt=kind==='photo'?runSeconds+Math.max(0,(performance.now()-last)/1000):null;sourceObject=object;sourceVisible=object.visible;
 inspected=object.clone(true);inspected.visible=true;inspected.position.set(0,0,0);inspected.rotation.set(0,0,0);inspected.scale.multiplyScalar(scale);inspected.userData.inspectKind=kind;
 sourceObject.visible=false;inspectScene.add(inspected);inspectDistance=kind==='lock'?.47:kind==='bed'?.85:.64;
 if(kind==='inventory-sheet')inspectDistance=.85;
 if(kind==='inventory-stock'){inspectDistance=.95;inspected.position.y=-.12;}
 if(kind==='envelope'){inspectDistance=.82;$('flip-letter').hidden=!storage.envelope.opened;$('open-envelope').hidden=storage.envelope.opened;if(storage.envelope.opened)storage.envelope.open(inspected);}
 if(kind==='bed'){inspected.position.y=-.07;inspected.rotation.set(.35,-.5,0);}
 inspection.dataset.kind=kind;inspection.querySelector('h2').textContent=kind==='envelope'&&storage.envelope.opened?'The letter':title;
 inspection.querySelector('.inspect-heading>p:last-child').textContent=description;
 inspection.querySelector('.eyebrow').textContent=kind==='lock'?'FOUR-WHEEL MECHANISM':'EXAMINING';
 $('inspect-instructions').textContent=kind==='lock'?(touchMode?'Tap a wheel · Pinch or + / − to zoom':'CLICK a wheel · SCROLL to zoom'):(touchMode?'Drag to rotate · Pinch or + / − to zoom':'DRAG to rotate · SCROLL to zoom');
 syncUI();if(document.pointerLockElement)document.exitPointerLock();
}
function exitInspection(resumeWithCapture=false){
 if(state!=='inspecting')return;
 $('open-envelope').hidden=true;$('flip-letter').hidden=true;photoInspectStartedAt=null;inspectScene.remove(inspected);inspected=null;sourceObject.visible=sourceVisible;sourceObject=null;inspectionKind=null;drag=false;state='playing';setPaused(!touchMode&&!resumeWithCapture);renderer.shadowMap.needsUpdate=true;if(resumeWithCapture)requestCapture();
}
function carryingItem(){if(currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM)return laundryContinuation.coffeePlay.model.held!==null;if(currentRoom>=DUCT_ROOM)return false;if(currentRoom===3)return observation.model.held!==null;return puzzle?.state.hammer==='carried'||storage.terminal.stack.heldId!==null;}
function boxNotice(text){$('box-notice').textContent=text;boxNoticeUntil=performance.now()+2800;$('box-notice').hidden=false;}
function pickUpBox(id){if(puzzle.state.hammer==='carried'){boxNotice('Drop the hammer first (G / DROP).');return;}if(storage.terminal.stack.pickup(id)){storage.terminal.refreshBoxes();renderer.shadowMap.needsUpdate=true;audio.pickup();syncUI();}}
function dropCarriedItem(){if(currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM){if(laundryContinuation.coffeePlay.drop(camera)){renderer.shadowMap.needsUpdate=true;syncUI();}return;}if(currentRoom>=DUCT_ROOM)return;if(currentRoom===3){if(observation.drop(camera.position,yaw))renderer.shadowMap.needsUpdate=true;syncUI();return;}const t=storage.terminal;if(t.stack.heldId!==null){if(t.stack.dropNear(camera.position,yaw,storage.boxes,STORAGE_BOUNDS)){t.refreshBoxes();renderer.shadowMap.needsUpdate=true;audio.fall();}else boxNotice('No clear space here. Step away from the shelf and try again.');}else puzzle.dropHammer();syncUI();}
function openStoragePanel(){if(!playable())return;audio.stopPCBeacon();state='computer';captureWanted=false;clearInput();syncUI();if(document.pointerLockElement)document.exitPointerLock();computerUI.openComputer();}
function closeStoragePanel(){computerUI.close();state='playing';setPaused(false);requestCapture();}
function interact(){if(!playable())return;if(currentRoom===LAUNDRY_ROOM&&focused?.kind==='basement-washer'){useSecretWasher();return;}if(currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM){const coffee=laundryContinuation.coffeePlay;if(coffee.interact(focused,camera)){renderer.shadowMap.needsUpdate=true;if(coffee.model.signals.includes('drink'))boxNotice('Coffee — 3× speed for 5 seconds.');syncUI();}return;}if(currentRoom>=DUCT_ROOM){if(currentRoom===DUCT_ROOM&&focused?.kind==='laundry-grille'&&laundryJourney.open(camera.position)){laundrySound.metal(camera.position,.12,.8);setBusy(true);renderer.shadowMap.needsUpdate=true;}return;}if(currentRoom===3){if(focused){if(observation.interact(focused)!==false){renderer.shadowMap.needsUpdate=true;}if(observation.model.events.live){audio.setRecognitionSilence(true);$('opening-caption').textContent='';}}else if(observation.model.held!==null)dropCarriedItem();syncUI();return;}if(!focused){if(storage.terminal.stack.heldId!==null)dropCarriedItem();else puzzle.swingHammer();return;}if(currentRoom===2){if(focused.kind==='inventory-sheet'){beginInspection({object:storage.inventoryLabels.sheet,kind:'inventory-sheet',title:'Inventory',description:'Hotel storage item IDs.'});}else if(focused.kind==='inventory-shelf'){beginInspection({object:focused.object,kind:'inventory-stock',title:`Aisle 3 / Shelf ${focused.shelf}`,description:'Examine the stored items.',scale:.65});}else if(focused.kind==='computer'){openStoragePanel();}else if(focused.kind==='stack-box'){const id=focused.boxId;if(storage.terminal.escape.canOpen(id)){if(storage.terminal.openBox(id)){renderer.shadowMap.needsUpdate=true;audio.fall();}}else pickUpBox(id);}else if(focused.kind==='wrench'){if(storage.terminal.collectWrench(puzzle.state)){audio.pickup();renderer.shadowMap.needsUpdate=true;boxNotice('Found wrench.');}}else if(focused.kind==='vent'){if(storage.terminal.escape.canReachVent(puzzle.state,roomTwoMotion.feet,camera.position,storage.terminal.stack.boxes)){if(!storage.vent.isOpen){storage.vent.openWithTool({kind:'wrench'});audio.door();renderer.shadowMap.needsUpdate=true;}else storage.vent.confirmEscape();}}else if(focused.kind==='cipher-clue'){beginInspection({object:storage.terminal.clue,kind:'cipher-clue',title:'Cipher key',description:'Letter → number.'});}else if(focused.kind==='envelope'){beginInspection({object:storage.envelope.object,kind:'envelope',title:'An envelope',description:storage.envelope.address()});}else if(focused.kind==='hammer'){if(storage.terminal.stack.heldId!==null)boxNotice('Set down the box first (G / DROP).');else puzzle.interact(focused);}else if(focused.kind==='storage-door'){if(puzzle.state.hammer==='carried')puzzle.swingHammer(()=>{});else audio.door();}syncUI();return;}if(focused.kind==='photo')beginInspection({object:room.photo});else puzzle.interact(focused);syncUI();}
function showKeyFound(object){
 state='key-found';keyFoundAt=runSeconds;clearInput();keyFoundModel=object.clone(true);keyFoundModel.visible=true;keyFoundModel.position.set(0,-.025,0);keyFoundModel.rotation.set(0,-.22,-.12);keyFoundModel.scale.multiplyScalar(2.4);inspectScene.add(keyFoundModel);inspectCamera.position.z=.64;syncUI();
}
function finishKeyFound(pauseAfter=false){
 if(state!=='key-found')return;inspectScene.remove(keyFoundModel);keyFoundModel=null;state='playing';blackout.trigger(runSeconds);setPaused(pauseAfter);renderer.shadowMap.needsUpdate=true;
}
function beginEnding(withNarrator=false){
 if(gameMode==='demo'&&state==='ending')return;if(gameMode==='demo')demoInvitation.reset();
 escapeSeconds=runSeconds;state='ending';captureWanted=false;endingAt=elapsed;clearInput();syncUI();endingRealStart=performance.now();endingUsesAudio=withNarrator&&audio.startEscapeVoice();if(!endingUsesAudio)audio.fadeOut(4);document.body.classList.add('ending');if(document.pointerLockElement)document.exitPointerLock();
}
function inspectTap(x,y){
 if(state!=='inspecting'||inspectionKind!=='lock')return;
 const b=canvas.getBoundingClientRect(),cursor=new T.Vector2((x-b.left)/b.width*2-1,-(y-b.top)/b.height*2+1),r=new T.Raycaster();
 inspectCamera.updateMatrixWorld();inspected.updateMatrixWorld(true);r.setFromCamera(cursor,inspectCamera);
 for(const hit of r.intersectObject(inspected,true)){
  let object=hit.object;
  while(object&&object!==inspected){if(Number.isInteger(object.userData.wheelIndex)){puzzle.turnWheel(object.userData.wheelIndex);return;}object=object.parent;}
 }
}
// Keep native Chrome menus from interrupting the game's mouse buttons.
document.addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('auxclick',e=>{if(e.button===2)e.preventDefault();});
// Hybrid laptops must not lose mouse input simply because a touchscreen exists.
document.addEventListener('pointerdown',e=>{
 const next=e.pointerType==='touch'?true:e.pointerType==='mouse'?false:touchMode;
 if(next!==touchMode){touchMode=next;if(next){captureWanted=false;if(document.pointerLockElement===canvas)document.exitPointerLock();}clearInput();syncUI();}
},true);
function showModeChoice(){$('mode-entry').hidden=false;menu.inert=true;menuEffects.mode();$('mode-normal').focus();}
function askPlayerName(testRoomTwo=false,testRoomThree=false){testStartRoomThree=testRoomThree;$('mode-entry').hidden=true;testStartRoomTwo=testRoomTwo;$('name-entry').hidden=false;menu.inert=true;menuEffects.guestbook();}
$('play').addEventListener('click',()=>menuEffects.play(showModeChoice));
$('mode-normal').addEventListener('click',()=>{gameMode='normal';askPlayerName(false);});
$('mode-demo').addEventListener('click',()=>{gameMode='demo';askPlayerName(false);});
$('mode-back').addEventListener('click',()=>{$('mode-entry').hidden=true;menu.inert=false;menuEffects.title();$('play').focus();});
for(const id of ['return-title','demo-return-title'])$(id).addEventListener('click',e=>{e.stopPropagation();const url=new URL(location.href);if(url.searchParams.has('akumuStart')){url.searchParams.delete('akumuStart');location.assign(url.href);}else location.reload();});
$('play-full-version').addEventListener('click',()=>{if(gameMode!=='demo'||state!=='ending'||!demoInvitation.complete)return;const url=new URL(location.href);url.searchParams.set('akumuStart','normal');location.assign(url.href);});
$('test-room-two').addEventListener('click',()=>{gameMode='normal';askPlayerName(true);});
$('loading-retry').addEventListener('click',()=>{void start();});
$('test-room-three').addEventListener('click',()=>{gameMode='normal';askPlayerName(false,true);});
$('player-name').addEventListener('input',()=>{$('name-error').textContent='';$('player-name').removeAttribute('aria-invalid');});
$('name-back').addEventListener('click',()=>{$('name-entry').hidden=true;menu.inert=false;menuEffects.title();$('play').focus();});
function submitPlayerName(e){e?.preventDefault();if(state!=='menu'||menuEffects.confirming)return;const result=validatePlayerName($('player-name').value);if(!result.ok){$('name-error').textContent=result.error;$('player-name').setAttribute('aria-invalid','true');$('player-name').focus();return;}$('name-error').textContent='';$('player-name').removeAttribute('aria-invalid');playerName=result.name;room.bloodMessage.setName(result.name);storage.envelope.setName(result.name);menuEffects.confirm(result.name,()=>{$('name-entry').hidden=true;menu.inert=false;void start();});}
// Embedded viewers may omit allow-forms: handle activation before native submission.
$('name-form').querySelector('button[type=submit]').addEventListener('click',submitPlayerName);
$('player-name').addEventListener('keydown',e=>{if(e.key==='Enter')submitPlayerName(e);});
$('name-form').addEventListener('submit',submitPlayerName);
$('open-envelope').addEventListener('click',()=>{if(state!=='inspecting'||inspectionKind!=='envelope')return;storage.envelope.open(inspected);if(!letterVoicePlayed)letterVoicePending=true;inspected.rotation.set(0,0,0);$('open-envelope').hidden=true;$('flip-letter').hidden=false;inspection.querySelector('h2').textContent='The letter';syncUI();});
$('flip-letter').addEventListener('click',()=>{if(state==='inspecting'&&inspectionKind==='envelope')storage.envelope.flip(inspected);});
pause.addEventListener('click',()=>{if(state==='playing'){setPaused(false);requestCapture();}});
$('close-inspect').addEventListener('click',()=>exitInspection(true));
$('touch-drop').addEventListener('click',()=>{if(playable())dropCarriedItem();});
document.addEventListener('keydown',e=>{
 if(!$('mode-entry').hidden){if(e.code==='Escape')$('mode-back').click();return;}
 if(!$('name-entry').hidden){if(e.code==='Escape')$('name-back').click();return;}
 if(state==='computer'){if(e.code==='Escape'){e.preventDefault();closeStoragePanel();}return;}
 if(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code))e.preventDefault();
 if(e.repeat&&!['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))return;
 if(e.code==='Escape'){if(state==='inspecting'){e.preventDefault();exitInspection(true);return;}captureWanted=false;if(state==='key-found')finishKeyFound(true);else if(state==='playing')setPaused(true);else if(state==='opening'){openingInterrupted=true;if(document.pointerLockElement===canvas)document.exitPointerLock();}return;}
 if(e.code==='KeyE'&&playable()){interact();return;}
 if(e.code==='KeyG'&&playable()){dropCarriedItem();return;}
 if(playable())keys.add(e.code);
});
document.addEventListener('keyup',e=>keys.delete(e.code));
window.addEventListener('blur',()=>{clearInput();if(state==='key-found')finishKeyFound(true);else if(state==='playing')setPaused(true);});
document.addEventListener('visibilitychange',()=>{last=performance.now();clearInput();if(document.hidden){if(state==='key-found')finishKeyFound(true);else if(state==='playing')setPaused(true);if(document.pointerLockElement===canvas)document.exitPointerLock();void audio.pause();}else if(['loading','opening','ending','computer'].includes(state)){void audio.resume();}});
document.addEventListener('mousemove',e=>{
 if(playable()&&!touchMode&&document.pointerLockElement===canvas){yaw-=e.movementX*.00165;pitch=T.MathUtils.clamp(pitch-e.movementY*.00165,-1.40,1.40);}
 else if(playable()&&!touchMode&&mouseLooking&&lookPointer){yaw-=(e.clientX-lookPointer.x)*.00165;pitch=T.MathUtils.clamp(pitch-(e.clientY-lookPointer.y)*.00165,-1.40,1.40);lookPointer={x:e.clientX,y:e.clientY};}
 if(state==='inspecting'&&inspectionKind!=='lock'&&drag&&inspected&&lastPointer){inspected.rotation.y+=(e.clientX-lastPointer.x)*.009;inspected.rotation.x+=(e.clientY-lastPointer.y)*.009;lastPointer={x:e.clientX,y:e.clientY};}
});
let gameplayClick=null;
canvas.addEventListener('mousedown',e=>{
 if(playable()&&!touchMode&&e.button===0){
  if(document.pointerLockElement===canvas){e.preventDefault();interact();return;}
  gameplayClick={x:e.clientX,y:e.clientY};
 }

 if(playable()&&!touchMode&&(e.button===0||e.button===2)){e.preventDefault();focusGame();if(document.pointerLockElement!==canvas){dragLook=true;mouseLooking=true;lookPointer={x:e.clientX,y:e.clientY};if(e.button===0)requestCapture(true);}}
 if(state==='inspecting'&&e.button===0){inspectPress={x:e.clientX,y:e.clientY};if(inspectionKind!=='lock'){drag=true;lastPointer=inspectPress;}}
});
canvas.addEventListener('click',e=>{
 if(gameplayClick){const press=gameplayClick;gameplayClick=null;if(playable()&&!touchMode&&Math.hypot(e.clientX-press.x,e.clientY-press.y)<7)interact();return;}
 if(!touchMode&&inspectPress&&Math.hypot(e.clientX-inspectPress.x,e.clientY-inspectPress.y)<7)inspectTap(e.clientX,e.clientY);inspectPress=null;});
window.addEventListener('mouseup',()=>{drag=false;mouseLooking=false;lookPointer=null;lastPointer=null;});
window.addEventListener('wheel',e=>{if(state==='inspecting'){e.preventDefault();inspectDistance=T.MathUtils.clamp(inspectDistance+e.deltaY*.0006,.36,1.05);}}, {passive:false});
function actuallyVisible(object){for(let p=object;p;p=p.parent)if(!p.visible)return false;return true;}
const clockFrustum=new T.Frustum(),clockViewMatrix=new T.Matrix4(),clockSphere=new T.Sphere(new T.Vector3(),.238),clockScreen=new T.Vector3(),clockSight=new T.Vector2();
const clockSightSamples=[[0,0],...Array.from({length:16},(_,i)=>[Math.cos(i*Math.PI/8)*.226,Math.sin(i*Math.PI/8)*.226])];
function clockInView(){
 clockViewMatrix.multiplyMatrices(camera.projectionMatrix,camera.matrixWorldInverse);clockFrustum.setFromProjectionMatrix(clockViewMatrix);room.wallClock.face.getWorldPosition(clockSphere.center);if(!clockFrustum.intersectsSphere(clockSphere))return false;
 const blockers=room.occluders.filter(o=>actuallyVisible(o)&&!room.wallClock.meshes.has(o)),clockMeshes=[...room.wallClock.meshes];
 for(let i=0;i<clockSightSamples.length;i++){
  const [x,y]=clockSightSamples[i];clockScreen.set(x,y,0).applyMatrix4(room.wallClock.face.matrixWorld).project(camera);
  if(clockScreen.z< -1||clockScreen.z>1)continue;
  if(i===0){clockSight.set(T.MathUtils.clamp(clockScreen.x,-.9999,.9999),T.MathUtils.clamp(clockScreen.y,-.9999,.9999));}
  else{if(Math.abs(clockScreen.x)>1||Math.abs(clockScreen.y)>1)continue;clockSight.set(clockScreen.x,clockScreen.y);}
  clockRay.setFromCamera(clockSight,camera);const hit=clockRay.intersectObjects(clockMeshes,false)[0];if(!hit)continue;
  const obstruction=clockRay.intersectObjects(blockers,false)[0];if(!obstruction||obstruction.distance>=hit.distance-.008)return true;
 }return false;
}
function isHeldBoxPart(object){const id=storage.terminal.stack.heldId;if(id===null)return false;const root=storage.terminal.crates.find(c=>c.id===id).root;for(let p=object;p;p=p.parent)if(p===root)return true;return false;}
function updateTarget(){
 ray.setFromCamera(new T.Vector2(),camera);focused=null;
 const targetRoom=currentRoom===DUCT_ROOM?laundryContinuation.duct:(currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM)?{targets:currentRoom===LAUNDRY_ROOM?laundryContinuation.laundry.targets:laundryContinuation.coffeePlay.targets.filter(t=>t.kind==='coffee-cup'),occluders:[...laundryContinuation.laundry.occluders,...laundryContinuation.basement.walking.occluders]}:currentRoom===3?observation:currentRoom===1?room:storage;
 const eligible=targetRoom.targets.filter(t=>(t.kind!=='vent'||storage.terminal.escape.canReachVent(puzzle.state,roomTwoMotion.feet,camera.position,storage.terminal.stack.boxes))&&(!t.enabled||t.enabled())&&actuallyVisible(t.root));
 const hits=ray.intersectObjects(eligible.map(t=>t.root),false);
 if(hits.length){const hit=hits[0],candidate=eligible.find(t=>t.root===hit.object),owner=candidate.object||candidate.drawer;const belongsToOwner=object=>{for(let p=object;p;p=p.parent)if(p===owner)return true;return false;};const blocked=ray.intersectObjects(targetRoom.occluders.filter(o=>actuallyVisible(o)&&!belongsToOwner(o)&&!isHeldBoxPart(o)&&!(currentRoom===3&&observation.isHeldPart(o))),false).find(h=>h.distance<hit.distance-.025);if(!blocked)focused=candidate;}
 prompt.hidden=true;prompt.classList.toggle('observation-exit-prompt',currentRoom===3);
 if(currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM){const text=focused?.kind==='basement-washer'?'':laundryContinuation.coffeePlay.prompt(focused,touchMode);prompt.textContent=text;prompt.hidden=!text;}
 if(currentRoom===3&&focused?.kind==='observation-exit'){prompt.textContent=observation.model.solved?(observation.model.doorOpen?'EXIT OPEN — WALK THROUGH':(touchMode?'TAP INTERACT TO OPEN EXIT':'E / LEFT CLICK — OPEN EXIT')):'EXIT LOCKED — RESTORE THE ARCHIVE';prompt.hidden=false;}
}
function opening(now){
 if(!openingReady)return;
 const t=openingUsesAudio?audio.openingTime():(now-openingStart)/1000,f=openingFrame(t);
 veil.style.opacity=String(f.veil);camera.position.set(...f.position);pitch=f.pitch;yaw=f.yaw;$('opening-caption').textContent=f.caption;
 if(f.done){runStartedAt=elapsed;state='playing';clearInput();veil.style.opacity=0;$('opening-caption').textContent='';setPaused(openingInterrupted);syncUI();}
}
function movement(dt){
 const forward=(keys.has('KeyW')||keys.has('ArrowUp')?1:0)-(keys.has('KeyS')||keys.has('ArrowDown')?1:0),side=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0);
 const desired=new T.Vector2(side+(touchInput?.axis.x||0),-forward+(touchInput?.axis.y||0));if(desired.length()>1)desired.normalize();const speed=currentRoom===DUCT_ROOM?.64:currentRoom===2?1.35:(currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM)?1.05*laundryContinuation.coffeePlay.model.multiplier:1.05;desired.multiplyScalar(speed);if((currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM)&&speed===1.05&&velocity.length()>speed)velocity.setLength(speed);velocity.lerp(desired,1-Math.exp(-dt*13));
 const dx=(velocity.x*Math.cos(yaw)+velocity.y*Math.sin(yaw))*dt,dz=(-velocity.x*Math.sin(yaw)+velocity.y*Math.cos(yaw))*dt;
 const space=getSpace(true),p=currentRoom===2?walkOnCrates(camera.position,dx,dz,storage.boxes,storage.terminal.stack.boxes,space.bounds,roomTwoMotion,dt):(currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM)?walkBasement(camera.position,dx,dz,space.boxes,space.bounds):move(camera.position,dx,dz,space.boxes,space.bounds),distance=Math.hypot(p.x-camera.position.x,p.z-camera.position.z);
 if(currentRoom===2)roomTwoMotion={feet:p.feet,fallSpeed:p.fallSpeed};
 camera.position.set(p.x,currentRoom===DUCT_ROOM?DUCT_EYE:(currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM)?T.MathUtils.damp(camera.position.y,laundryContinuation.basement.floorAt(p.x,p.z)+1.65,14,dt):currentRoom===2?T.MathUtils.damp(camera.position.y,1.65+p.feet,14,dt):1.65,p.z);if(currentRoom!==2||p.grounded)stepsDistance+=distance;else stepsDistance=0;if(stepsDistance>.62){if(currentRoom===DUCT_ROOM)laundrySound.step(camera.position);else if(currentRoom===BASEMENT_ROOM)laundryContinuation.basement.sound.step(camera.position,basementWet(p.x,p.z),p.z<STAIRS.maxZ);else audio.footstep(currentRoom>=3||currentRoom===2&&p.feet<.1?'storage':'bedroom');stepsDistance=0;}
}
function animate(now){
 requestAnimationFrame(animate);const realDt=Math.max(0,(now-last)/1000),dt=Math.min(realDt,.05);last=now;
 if(state==='loading'||state==='loading-error')return;
 if(state==='menu'){menuEffects.render(now);return;}
 if(runStartedAt!==null&&escapeSeconds===null&&!document.hidden&&(state==='playing'&&!paused||state==='inspecting'||state==='computer'||state==='key-found'))runSeconds+=realDt;
 const active=!document.hidden&&(state==='opening'||state==='playing'&&!paused||state==='inspecting'||state==='computer'||state==='ending'||state==='key-found');if(active)elapsed+=dt;graphicsQuality.update(realDt,state==='playing'&&!paused&&!busy&&!document.hidden);
 if(state==='menu'){camera.position.set(1.3,1.6,1.25);yaw=.85+Math.sin(now*.00008)*.035;pitch=-.04;}
 if(state==='opening')opening(now);if(playable())movement(dt);updateLaundry(dt,realDt);updateBasement(realDt);
 camera.rotation.set(pitch,yaw,0);camera.updateMatrixWorld();
 if(currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM){const coffee=laundryContinuation.coffeePlay,coffeeActive=state==='playing'&&!paused&&!document.hidden;coffee.update(coffeeActive?realDt:0,camera);laundryContinuation.coffeeSound.update(coffeeActive,coffee.model.brewing,coffee.model.signals);}
 if(playable())updateTarget();else focused=null;
 const clockActive=currentRoom===1&&runStartedAt!==null&&!document.hidden&&!paused&&!busy&&['playing','inspecting','key-found'].includes(state);
 clockAttention.update(realDt,(state==='playing'||state==='key-found')&&clockActive&&clockInView(),clockActive);room.wallClock.update(clockAttention.seconds);
 audio.setClockTicking(clockAttention.ticking&&clockActive&&!audio.scareBusy,room.wallClock.position);
 if(clockActive&&state!=='key-found'&&clockAttention.narratorPending&&audio.clockVoice())clockAttention.markNarrated();
 if(currentRoom===1&&state==='inspecting'&&inspectionKind==='photo'&&!paused&&!document.hidden&&!photoVoicePlayed&&photoInspectStartedAt!==null&&runSeconds-photoInspectStartedAt>=5&&audio.photoVoice())photoVoicePlayed=true;
 if(currentRoom===2&&!document.hidden&&!paused&&storage.strawHat.update(realDt))renderer.shadowMap.needsUpdate=true;
 if(currentRoom===2&&letterVoicePending&&state==='inspecting'&&inspectionKind==='envelope'&&storage.envelope.opened&&!paused&&!document.hidden&&audio.letterVoice()){letterVoicePending=false;letterVoicePlayed=true;}
 if(currentRoom===2&&!pcStartupPlayed&&storageEnteredAt!==null&&now/1000-storageEnteredAt>=2&&!document.hidden&&!paused&&!busy&&['playing','inspecting','computer'].includes(state)&&audio.startPCStartup())pcStartupPlayed=true;
 const assistance=storage.terminal.puzzle.assistance;if(assistance.update())computerUI.refreshAssistance();
 if(currentRoom===2&&!document.hidden&&!paused&&!busy&&['playing','inspecting','computer'].includes(state)&&assistance.pending&&audio.assistanceVoice())assistance.markAnnounced();
 const drawer=room.targets.find(t=>t.kind==='drawer');
 if(currentRoom===1&&Math.abs(drawerAmount-(drawer.open?.32:0))>.001)renderer.shadowMap.needsUpdate=true;
 drawerAmount=T.MathUtils.damp(drawerAmount,drawer.open?.32:0,7,active&&currentRoom===1?dt:0);drawer.drawer.position.z=drawerAmount;
 if(puzzle.update(dt,elapsed,active,state==='inspecting'&&inspectionKind==='lock',currentRoom===1))renderer.shadowMap.needsUpdate=true;
 if(currentRoom===2&&playable()&&storage.terminal.updateCarried(camera,getSpace().boxes,STORAGE_BOUNDS))renderer.shadowMap.needsUpdate=true;
 $('box-notice').hidden=!playable()||now>=boxNoticeUntil;
 updateRoomProgression(active?realDt:0);
 if(currentRoom===3){observation.update(active&&state!=='ending'?realDt:0,active&&state!=='ending'?dt:0,camera,!audio.recognitionSilenced&&(!audio.doorVoice||audio.ctx?.currentTime>=audio.doorVoice.cooldownUntil));
  if(observation.model.held!==null||observation.model.tapes.some(t=>t.falling)||Math.abs(observation.exit.rotation.y-(observation.model.doorOpen?-1.4:0))>.002)renderer.shadowMap.needsUpdate=true;
  observation.sound.update(observation.model,active&&state!=='ending');
  for(const signal of observation.model.signals.splice(0))observation.sound.signal(signal,observation.model);
  if(observation.model.exit(camera.position))beginEnding(false);
 }
 const power=blackout.sample(runSeconds),light=faults.sample(elapsed)*power;room.ambient.intensity=.35*(.08+.92*power);room.moonlight.intensity=19*(.28+.72*power);room.lamp.intensity=27*light;room.spill.intensity=1.6*light;room.bounce.intensity=.8*light;room.bulbMaterial.emissiveIntensity=1.35*light;room.dust.rotation.y=Math.sin(now*.00004)*.025;
 if(active&&spiderScare.active){spiderScare.update(realDt);if(!spiderScare.active){finishClosetScare?.();finishClosetScare=null;audio.finishSpiderScare();setBusy(false);}}
 if(active)audio.update(elapsed,light,camera.position,yaw,pitch,currentRoom===1&&playable(),currentRoom!==1?'storage':'bedroom');
 if(currentRoom===2){storage.terminal.computer.getWorldPosition(pcBeaconPosition);pcBeaconPosition.y+=.34;audio.updatePCBeacon(!document.hidden&&!paused&&['playing','inspecting'].includes(state)&&!!audio.pcStartupVoice?.ended,pcBeaconPosition);}
 touchInput?.update(playable(),(currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM)&&laundryContinuation.coffeePlay.model.heldFull&&focused?.kind!=='coffee-machine'&&focused?.kind!=='basement-washer'?'DRINK':'INTERACT');$('touch-drop').hidden=!touchMode||!playable()||!carryingItem();
 if(state!=='opening'&&state!=='ending')$('opening-caption').textContent=currentRoom>=DUCT_ROOM?'':currentRoom===3?(!paused?(observation.model.caption||(!observation.model.events.live?audio.narratorCaption():'')):''):(['playing','inspecting','computer'].includes(state))&&!paused?audio.narratorCaption():'';
 $('pc-startup-caption').textContent=currentRoom===2&&!paused&&!document.hidden&&['playing','inspecting','computer'].includes(state)?audio.pcStartupCaption():'';
 const timerVisible=runStartedAt!==null&&['playing','inspecting','computer','key-found'].includes(state);$('run-timer').hidden=!timerVisible;if(timerVisible)$('run-timer').textContent=formatTime(runSeconds);
 if(state==='ending'){
  const t=endingUsesAudio?audio.escapeTime():(now-endingRealStart)/1000,voiceTime=t-.75;
  const finalAt=endingUsesAudio?Math.max(4.2,.75+audio.escapeVoice.duration+.3):4.2;
  veil.style.opacity=String(smooth((t-1.95)/2.2));
  $('ending-caption').textContent=endingUsesAudio&&voiceTime>=0&&voiceTime<2.34?'(Narrator) One door down.':endingUsesAudio&&voiceTime>=2.50&&voiceTime<5.05?'(Narrator) How many more until you remember?':'';
  if(gameMode==='demo'&&currentRoom===3){if(!document.hidden)demoInvitation.update(t,()=>audio.startDemoInvitation());$('ending-caption').textContent=demoInvitation.caption;$('play-full-version').hidden=!demoInvitation.complete;}
  $('escape-time').hidden=currentRoom!==1||t<finalAt;$('demo-return-title').hidden=gameMode!=='demo'||t<finalAt;$('escape-time').textContent='Escaped in '+formatTime(escapeSeconds);$('opening-caption').textContent=t>=finalAt?'TO BE CONTINUED...':'';
 }

 if(state==='key-found'){
  const t=runSeconds-keyFoundAt;keyFoundModel.rotation.y=-.22+Math.sin(t*1.3)*.18;renderer.render(scene,camera);const autoClear=renderer.autoClear;renderer.autoClear=false;renderer.clearDepth();renderer.render(inspectScene,inspectCamera);renderer.autoClear=autoClear;if(t>=2.3)finishKeyFound();
 }else if(state==='inspecting'){
  puzzle.updateInspection(inspected,dt);
  if(inspectionKind==='lock'&&puzzle.state.drawer!=='locked')inspection.querySelector('.inspect-heading>p:last-child').textContent='The latch is open. Close this view, then pull the drawer.';
  renderer.setClearColor(0x0a100f,1);inspectCamera.position.z=T.MathUtils.damp(inspectCamera.position.z,inspectDistance,10,dt);renderer.render(inspectScene,inspectCamera);
 }else{if(currentRoom===3&&state!=='ending')observation.renderLive(renderer,scene,now/1000);renderer.render(scene,camera);}
 spiderScare.render(renderer,camera.aspect);
}
window.addEventListener('resize',()=>{clearInput();camera.aspect=inspectCamera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();inspectCamera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);graphicsQuality.resize();});
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();clearInput();$('error').hidden=false;$('error').textContent='The graphics connection was interrupted. Reload the page to return to AKUMU.';});
puzzle=createPuzzle({scene:bedroomRoot,camera,room,getSpace:()=>getSpace(false),audio,inspect:beginInspection,setBusy,foundKey:showKeyFound,finish:beginRoomTwoPassage,scareCloset(done){finishClosetScare=done;setBusy(true);audio.startSpiderScare();spiderScare.start();}});
polishLighting(bedroomRoot,environmentTarget.texture);polishLighting(storageRoot,environmentTarget.texture);polishLighting(sharedRoot,environmentTarget.texture);
const computerUI=createComputerInterface(storage.terminal,{onClose:closeStoragePanel,getPlayerName:()=>playerName,onRecognition:active=>{audio.setRecognitionSilence(active);if(active){$('opening-caption').textContent='';audio.noiseBurst(.035,.11,1600);}},onChange:()=>{renderer.shadowMap.needsUpdate=true;storageRoot.updateMatrixWorld(true);}});
storage.targets.push(room.targets.find(t=>t.kind==='hammer'));refreshStorageDoorOccluders();
touchInput=createTouchInput({enabled:()=>touchMode,canvas,getState:()=>state,canMove:playable,
 onLook(dx,dy){yaw-=dx*.003;pitch=T.MathUtils.clamp(pitch-dy*.003,-1.4,1.4);},
 onRotate(dx,dy){if(inspected&&inspectionKind!=='lock'){inspected.rotation.y+=dx*.009;inspected.rotation.x+=dy*.009;}},
 onZoom(factor){if(state==='inspecting')inspectDistance=T.MathUtils.clamp(inspectDistance*factor,.36,1.05);},
 onTap:inspectTap,onInteract:interact,onPause:()=>setPaused(true)});
if(touchMode){$('pause').querySelector('p:not(.eyebrow)').textContent='Tap to return to the room.';$('pause').querySelector('small').textContent='Left stick to move · Swipe to look · Tap to interact';$('close-inspect').textContent='CLOSE';}
syncUI();
if(new URLSearchParams(location.search).get('akumuStart')==='normal'){const url=new URL(location.href);url.searchParams.delete('akumuStart');try{history.replaceState(null,'',url.href);}catch{}gameMode='normal';askPlayerName(false);}
if(new URLSearchParams(location.search).has('debug'))window.__AKUMU__={
 get laundryContinuation(){return laundryContinuation;},laundryJourney,basementJourney,
 get reception(){return menuEffects;},get startupReady(){return startupReady;},
 surfaceBuildStats,graphicsQuality,demoInvitation,get gameMode(){return gameMode;},get observation(){return observation;},beginRoomTwoPassage,get storageEnteredAt(){return storageEnteredAt;},get pcStartupPlayed(){return pcStartupPlayed;},get crateFeet(){return roomTwoMotion.feet;},get currentRoom(){return currentRoom;},get playerName(){return playerName;},storage,progression,getSpace,finishGame:beginEnding,
 get state(){return state;},get elapsed(){return elapsed;},get paused(){return paused;},get busy(){return busy;},touchMode,touchInput,get dragLook(){return dragLook;},
 get letterVoicePlayed(){return letterVoicePlayed;},get letterVoicePending(){return letterVoicePending;},get photoVoicePlayed(){return photoVoicePlayed;},get photoInspectSeconds(){return photoInspectStartedAt===null?0:Math.max(0,runSeconds-photoInspectStartedAt);},clockAttention,blackout,get runSeconds(){return runSeconds;},spiderScare,camera,room,puzzle,renderer,faults,audio,get openingTime(){return openingReady?(openingUsesAudio?audio.openingTime():(performance.now()-openingStart)/1000):0;},get openingUsesAudio(){return openingUsesAudio;},get keyFoundModel(){return keyFoundModel;},get focused(){return focused;},get inspected(){return inspected;},get inspectionKind(){return inspectionKind;},get inspectDistance(){return inspectDistance;},
 setView(x,z,newYaw=0,newPitch=0){if(currentRoom===2)roomTwoMotion={feet:0,fallSpeed:0};camera.position.set(x,currentRoom===DUCT_ROOM?DUCT_EYE:(currentRoom===LAUNDRY_ROOM||currentRoom===BASEMENT_ROOM)?laundryContinuation.basement.floorAt(x,z)+1.65:1.65,z);yaw=newYaw;pitch=newPitch;camera.rotation.set(pitch,yaw,0);camera.updateMatrixWorld();},interact,exitInspection,keys,
 wheelScreen(index){const o=inspected?.getObjectByName('wheel-'+index);if(!o)return null;o.updateWorldMatrix(true,false);const p=o.getWorldPosition(new T.Vector3()).add(new T.Vector3(0,0,.04)).project(inspectCamera);return {x:(p.x+1)*innerWidth/2,y:(1-p.y)*innerHeight/2};}
};
requestAnimationFrame(animate);
