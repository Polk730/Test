import * as T from 'three';
import {random} from './textures.js';
export function addWallClock(scene,wood,metal){
 const root=new T.Group();root.name='unusual-wall-clock';root.position.set(-1.15,2.13,1.98);root.rotation.y=Math.PI;root.userData.dynamic=true;scene.add(root);
 const caseMesh=new T.Mesh(new T.CylinderGeometry(.235,.235,.055,40),wood);caseMesh.rotation.x=Math.PI/2;caseMesh.castShadow=caseMesh.receiveShadow=true;root.add(caseMesh);
 const canvas=document.createElement('canvas');canvas.width=canvas.height=768;const c=canvas.getContext('2d'),r=random(801);
 c.fillStyle='#c0b48b';c.fillRect(0,0,768,768);for(let i=0;i<12000;i++){c.fillStyle=`rgba(62,45,18,${r()*.15})`;c.fillRect(r()*768,r()*768,1+r()*3,1+r()*3);}
 const stain=c.createRadialGradient(384,384,160,384,384,385);stain.addColorStop(0,'#39250b00');stain.addColorStop(1,'#39250b99');c.fillStyle=stain;c.fillRect(0,0,768,768);
 c.strokeStyle='#29271c';c.fillStyle='#29271c';for(let i=0;i<60;i++){const a=i*Math.PI/30,x=Math.sin(a),y=-Math.cos(a);c.lineWidth=i%5?2:5;c.beginPath();c.moveTo(384+x*340,384+y*340);c.lineTo(384+x*(i%5?326:314),384+y*(i%5?326:314));c.stroke();}
 c.font='bold 62px Georgia';c.textAlign='center';c.textBaseline='middle';for(let i=1;i<=12;i++){const a=i*Math.PI/6;c.fillText(String(i),384+Math.sin(a)*266,386-Math.cos(a)*266);}c.font='18px Georgia';c.fillText('AKUMU',384,490);
 const map=new T.CanvasTexture(canvas);map.colorSpace=T.SRGBColorSpace;
 const face=new T.Mesh(new T.CircleGeometry(.203,48),new T.MeshStandardMaterial({map,roughness:.94}));face.position.z=.031;face.receiveShadow=true;root.add(face);
 const rim=new T.Mesh(new T.TorusGeometry(.218,.015,8,48),metal);rim.position.z=.029;rim.castShadow=true;root.add(rim);
 const handMaterial=new T.MeshStandardMaterial({color:0x202018,roughness:.85});
 function hand(length,width,z,material){const geometry=new T.BoxGeometry(width,length,.004);geometry.translate(0,length/2,0);const mesh=new T.Mesh(geometry,material);mesh.position.z=z;root.add(mesh);return mesh;}
 const hour=hand(.105,.012,.040,handMaterial),minute=hand(.152,.007,.046,handMaterial),second=hand(.17,.003,.052,new T.MeshStandardMaterial({color:0x6d2924,roughness:.75}));
 const hub=new T.Mesh(new T.SphereGeometry(.009,10,8),metal);hub.position.z=.058;root.add(hub);
 const glass=new T.Mesh(new T.CircleGeometry(.201,40),new T.MeshPhysicalMaterial({color:0xb8ae99,transparent:true,opacity:.035,roughness:.42}));glass.position.z=.066;root.add(glass);
 const meshes=new Set();root.traverse(o=>{if(o.isMesh)meshes.add(o);});
 function update(seconds){hour.rotation.z=-(2+17/60+seconds/3600)*Math.PI/6;minute.rotation.z=-(17+seconds/60)*Math.PI/30;second.rotation.z=-(9+Math.floor(seconds))*Math.PI/30;}
 update(0);return {root,face,meshes,position:root.position,update};
}
