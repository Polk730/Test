// NORMAL-only continuation. DEMO keeps its existing numeric room id (3).
export const DUCT_ROOM=4,LAUNDRY_ROOM=5;
export const DUCT_FLOOR=2.64,DUCT_EYE=3.05,LAUNDRY_FLOOR=.84;
export const DUCT_BOUNDS={minX:9.83,maxX:16.85,minZ:11.08,maxZ:17.60};
export const DUCT_BOXES=[{minX:10.87,maxX:16.85,minZ:11.08,maxZ:16.56}];
export const DUCT_ENTRY={x:10.35,y:DUCT_EYE,z:11.46};
export const LAUNDRY_BOUNDS={minX:16.85,maxX:28.85,minZ:12.08,maxZ:22.08,height:3.2};
export const LAUNDRY_LANDING={x:18.05,y:LAUNDRY_FLOOR+1.65,z:17.08};
export const EXIT_GRILLE={x:16.85,y:LAUNDRY_FLOOR+2.2,z:17.08};
// Time-driven camera paths pause with the game and cannot double-trigger.
export class LaundryJourney {
 constructor(){this.phase='idle';this.time=0;this.from=null;this.behindPlayed=false;}
 enter(position){if(this.phase!=='idle')return false;this.phase='entering';this.time=0;this.from={...position};return true;}
 open(position){if(this.phase!=='crawling')return false;this.phase='exiting';this.time=0;this.from={...position};return true;}
 update(dt){if(!['entering','exiting'].includes(this.phase))return null;this.time+=Math.min(dt,.05);const exiting=this.phase==='exiting',duration=exiting?1.65:.65,t=Math.min(1,this.time/duration),s=t*t*(3-2*t);let point;
 if(exiting){const first={x:17.35,y:DUCT_EYE,z:17.08};if(t<.45){const a=t/.45;point={x:this.from.x+(first.x-this.from.x)*a,y:DUCT_EYE,z:this.from.z+(first.z-this.from.z)*a};}else{const a=(t-.45)/.55,e=a*a*(3-2*a);point={x:first.x+(LAUNDRY_LANDING.x-first.x)*e,y:first.y+(LAUNDRY_LANDING.y-first.y)*e,z:17.08};}}
 else point=Object.fromEntries(['x','y','z'].map(k=>[k,this.from[k]+(DUCT_ENTRY[k]-this.from[k])*s]));
 if(t===1)this.phase=exiting?'laundry':'crawling';return point;
 }
}
