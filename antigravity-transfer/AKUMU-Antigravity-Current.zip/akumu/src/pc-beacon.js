// One quiet monitor beep every 3.2 seconds, positioned in world space.
export function createPCBeacon(context,bus,position){
 const buffer=context.createBuffer(1,Math.ceil(context.sampleRate*3.2),context.sampleRate),pcm=buffer.getChannelData(0);
 for(let i=0;i<Math.ceil(context.sampleRate*.11);i++){const t=i/context.sampleRate,envelope=Math.min(1,t/.006)*Math.min(1,(.11-t)/.025);pcm[i]=.22*envelope*(Math.sin(t*2*Math.PI*1040)+.12*Math.sin(t*2*Math.PI*2080))/1.12;}
 const source=context.createBufferSource(),gain=context.createGain(),panner=context.createPanner();source.buffer=buffer;source.loop=true;gain.gain.value=.6;
 panner.panningModel='HRTF';panner.distanceModel='inverse';panner.refDistance=1.5;panner.rolloffFactor=.65;panner.maxDistance=18;panner.setPosition(position.x,position.y,position.z);
 source.connect(gain).connect(panner).connect(bus);source.start();let stopped=false;
 return {source,gain,panner,setEnabled(enabled){gain.gain.setTargetAtTime(enabled?.6:0,context.currentTime,.025);},stop(){if(stopped)return;stopped=true;source.stop();source.disconnect();gain.disconnect();panner.disconnect();}};
}
