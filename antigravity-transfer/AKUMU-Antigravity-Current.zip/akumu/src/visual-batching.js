import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
// Bake only explicitly chosen, rigid visual children. Invisible hit targets stay identical.
export function batchVisualChildren(root,exclude=new Set()){
 root.updateMatrixWorld(true);const inverse=root.matrixWorld.clone().invert(),groups=new Map(),remove=[];
 root.traverse(o=>{if(o===root||!o.isMesh||o.isInstancedMesh||exclude.has(o)||o.material.visible===false||o.material.transparent||Array.isArray(o.material))return;const key=o.material.uuid+':'+o.castShadow;const matrix=inverse.clone().multiply(o.matrixWorld),geometry=(o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone()).applyMatrix4(matrix);if(!groups.has(key))groups.set(key,{material:o.material,shadow:o.castShadow,geometries:[]});groups.get(key).geometries.push(geometry);remove.push(o);});
 for(const o of remove)o.removeFromParent();for(const {material,shadow,geometries}of groups.values()){const mesh=new T.Mesh(mergeGeometries(geometries),material);mesh.castShadow=shadow;mesh.receiveShadow=true;root.add(mesh);geometries.forEach(g=>g.dispose());}
}
