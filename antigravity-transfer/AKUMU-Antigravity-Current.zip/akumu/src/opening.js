// Times inside the supplied, unmodified MP3: yawn ~0.20–0.58; speech ~1.01–2.58.
export const OPENING={duration:8,voiceStart:1.5,speechStart:1.01,speechEnd:2.58,captionTail:.18,fadeStart:1.2,fadeDuration:3,liftStart:2.45,liftDuration:5.15,travelStart:2.7,travelDuration:5,lookStart:2.45,lookDuration:5.25};
const smooth=t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};
const mix=(a,b,t)=>a+(b-a)*t;
export function openingFrame(time){
 const caption=time>=OPENING.voiceStart+OPENING.speechStart&&time<OPENING.voiceStart+OPENING.speechEnd+OPENING.captionTail?'Where am I?':'';
 return {position:[mix(-1.65,-.35,smooth((time-OPENING.travelStart)/OPENING.travelDuration)),mix(.69,1.65,smooth((time-OPENING.liftStart)/OPENING.liftDuration)),mix(-.24,.6,smooth((time-OPENING.travelStart)/OPENING.travelDuration))],pitch:mix(1.24,-.03,smooth((time-OPENING.lookStart)/OPENING.lookDuration)),yaw:mix(.08,.03,smooth(time/OPENING.duration)),veil:1-smooth((time-OPENING.fadeStart)/OPENING.fadeDuration),caption,done:time>=OPENING.duration};
}
