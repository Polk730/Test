export const STACK_BOX_SIZE=.55;
// The numbered crates occupy ordinary shelf bays, rather than floor pads by the vent.
export const BOX_HOMES=Object.freeze([
 {x:2.3,y:1.2325,z:7.825,rackIndex:0,segment:1,bay:1},
 {x:6,y:1.2325,z:4.725,rackIndex:2,segment:0,bay:1},
 {x:9.75,y:1.2325,z:7.9,rackIndex:4,segment:1,bay:1}
]);
export class StableBoxStack {
 constructor(canMove=()=>false){this.canMove=canMove;this.heldId=null;this.boxes=BOX_HOMES.map((p,i)=>({id:i+1,x:p.x,y:p.y,z:p.z,placement:'shelf',support:null}));}
 get(id){return this.boxes.find(b=>b.id===id);}
 position(id){const {x,y,z}=this.get(id);return {x,y,z};}
 isTop(id){return !this.boxes.some(b=>b.placement!=='carried'&&b.support===id);}
 canPickup(id){return !!this.get(id)&&this.heldId===null&&this.canMove(id)&&this.isTop(id);}
 pickup(id){if(!this.canPickup(id))return false;this.heldId=id;Object.assign(this.get(id),{placement:'carried',support:null});return true;}
 footprint(id){const p=this.position(id),h=STACK_BOX_SIZE/2;return {minX:p.x-h,maxX:p.x+h,minZ:p.z-h,maxZ:p.z+h};}
 get colliders(){return this.boxes.filter(b=>b.placement==='floor'||b.placement==='stack').map(b=>this.footprint(b.id));}
 dropAt(x,z,obstacles,bounds,player){
  const b=this.get(this.heldId);if(!b||!this.canMove(b.id)||!Number.isFinite(x)||!Number.isFinite(z))return false;const h=STACK_BOX_SIZE/2,pad=.015;
  const others=this.boxes.filter(o=>o!==b&&o.placement!=='carried'&&o.placement!=='shelf');
  const target=others.filter(o=>this.isTop(o.id)&&Math.abs(o.x-x)<h&&Math.abs(o.z-z)<h).sort((a,b)=>b.y-a.y)[0];
  if(target){x=target.x;z=target.z;}
  if(x-h<bounds.minX+pad||x+h>bounds.maxX-pad||z-h<bounds.minZ+pad||z+h>bounds.maxZ-pad)return false;
  if(obstacles.some(o=>x+h>o.minX-pad&&x-h<o.maxX+pad&&z+h>o.minZ-pad&&z-h<o.maxZ+pad))return false;
  if(player){const dx=player.x-Math.max(x-h,Math.min(player.x,x+h)),dz=player.z-Math.max(z-h,Math.min(player.z,z+h));if(dx*dx+dz*dz<.205*.205)return false;}
  const y=target?target.y+STACK_BOX_SIZE:.015+h;if(y+h>bounds.height-.1)return false;
  if(others.some(o=>Math.abs(o.x-x)<STACK_BOX_SIZE-.001&&Math.abs(o.z-z)<STACK_BOX_SIZE-.001&&Math.abs(o.y-y)<STACK_BOX_SIZE-.001))return false;
  Object.assign(b,{x,y,z,placement:target?'stack':'floor',support:target?.id??null});this.heldId=null;return true;
 }
 dropNear(player,yaw,obstacles,bounds){
  if(this.heldId===null)return false;
  for(const distance of [.75,1.0,1.25])for(const angle of [0,.6,-.6,1.2,-1.2,Math.PI/2,-Math.PI/2,Math.PI]){
   const x=player.x-Math.sin(yaw+angle)*distance,z=player.z-Math.cos(yaw+angle)*distance;
   // Do not place through a shelf, wall or another static obstacle into an adjacent aisle.
   let clear=true;for(let t=.12;t<=distance;t+=.06){const px=player.x+(x-player.x)*t/distance,pz=player.z+(z-player.z)*t/distance;if(obstacles.some(o=>px>o.minX-.285&&px<o.maxX+.285&&pz>o.minZ-.285&&pz<o.maxZ+.285)){clear=false;break;}}
   if(clear&&this.dropAt(x,z,obstacles,bounds,player))return true;
  }return false;
 }
}
