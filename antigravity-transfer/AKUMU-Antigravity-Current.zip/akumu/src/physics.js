// Horizontal circle versus axis-aligned boxes, resolved on each movement axis.
export const PLAYER_RADIUS = .19;
export const ROOM = { minX:-2.5, maxX:2.5, minZ:-2, maxZ:2, height:2.8 };
export function collides(x,z,boxes,radius=PLAYER_RADIUS){
 return boxes.some(b=>{
  const dx=x-Math.max(b.minX,Math.min(x,b.maxX));
  const dz=z-Math.max(b.minZ,Math.min(z,b.maxZ));
  return dx*dx+dz*dz < radius*radius-1e-10;
 });
}
export function move(position,dx,dz,boxes,bounds=ROOM){
 // Substeps prevent tunnelling after a slow frame or against thin furniture.
 const steps=Math.max(1,Math.ceil(Math.hypot(dx,dz)/.07));
 let x=position.x,z=position.z;
 for(let i=0;i<steps;i++){
  const nx=Math.max(bounds.minX+PLAYER_RADIUS,Math.min(bounds.maxX-PLAYER_RADIUS,x+dx/steps));
  if(!collides(nx,z,boxes))x=nx;
  const nz=Math.max(bounds.minZ+PLAYER_RADIUS,Math.min(bounds.maxZ-PLAYER_RADIUS,z+dz/steps));
  if(!collides(x,nz,boxes))z=nz;
 }
 return {x,z};
}
