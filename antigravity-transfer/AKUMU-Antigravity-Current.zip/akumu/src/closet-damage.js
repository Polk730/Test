import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {random} from './textures.js';

export function buildBreakableCloset(scene,cupboard,{wood,darkwood,metal}){
 cupboard.userData.dynamic=true;
 const intact=new T.Group();cupboard.add(intact);
 function box(parent,w,h,d,x,y,z,material){const m=new T.Mesh(new T.BoxGeometry(w,h,d),material);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;parent.add(m);return m;}
 // A hollow carcass stays standing after the front splinters away.
 box(cupboard,.035,1.95,1,.245,.975,0,darkwood);
 for(const z of [-.48,.48])box(cupboard,.52,1.95,.04,0,.975,z,darkwood);
 for(const y of [.04,1.92])box(cupboard,.52,.06,1,0,y,0,darkwood);
 box(cupboard,.48,.035,.93,0,.70,0,darkwood);
 // Thin, separated boards with chipped ends replace the smooth, solid-looking front.
 const exposed=wood.clone();exposed.color.multiplyScalar(1.34);exposed.roughness=1;
 const crackMaterial=new T.MeshStandardMaterial({color:0x17100c,roughness:1});
 function timber(parent,points,x,y,z,thickness,material){const shape=new T.Shape();points.forEach(([u,v],i)=>i?shape.lineTo(u,v):shape.moveTo(u,v));shape.closePath();const geometry=new T.ExtrudeGeometry(shape,{depth:thickness,bevelEnabled:false});geometry.rotateY(Math.PI/2);const mesh=new T.Mesh(geometry,material);mesh.position.set(x,y,z);mesh.castShadow=mesh.receiveShadow=true;parent.add(mesh);return mesh;}
 for(let i=0;i<4;i++){
  const left=-.435+i*.2175+.006,right=left+.2055;
  timber(intact,[[left,.15],[left+.018,.127],[left+.04,.16],[right-.035,.127],[right,.14],[right,1.87],[right-.02,1.845],[right-.045,1.875],[left+.025,1.855],[left,1.875]],-.295,0,0,.025,wood);
  // Pale exposed fibres along splits catch the existing lamp without glowing.
  timber(intact,[[left,.29],[left+.009,.36],[left+.006,1.51],[left,1.64]],-.297,0,0,.002,exposed);
 }
 // Branching stress cracks and narrow splinters are attached to the breakaway front.
 for(const [u,y,length] of [[-.23,.54,.39],[.08,1.12,.49],[.31,.32,.46],[-.34,1.39,.32]]){
  timber(intact,[[u,y],[u+.015,y+length*.35],[u+.004,y+length*.65],[u+.012,y+length],[u+.021,y+length*.67],[u+.025,y+length*.34],[u+.009,y]],-.299,0,0,.001,crackMaterial);
  timber(intact,[[u+.01,y+length*.4],[u+.07,y+length*.58],[u+.058,y+length*.6]],-.300,0,0,.001,crackMaterial);
 }
 for(let i=0;i<3;i++){
  const plank=new T.Group();plank.position.set(-.335,.60+i*.42,0);plank.rotation.x=i%2?.17:-.12;intact.add(plank);
  timber(plank,[[-.51,-.055],[-.47,-.07],[-.08,-.07],[-.045,-.045],[.015,-.067],[.46,-.07],[.51,-.048],[.49,.068],[.18,.07],[.15,.045],[.12,.068],[-.48,.07],[-.505,.035]],0,0,0,.04,exposed);
  timber(plank,[[-.14,-.004],[-.025,.012],[.035,-.003],[.17,.018],[.07,.008],[.01,-.012],[-.03,.004]],-.002,0,0,.001,crackMaterial);
  for(const z of [-.39,.39]){const nail=new T.Mesh(new T.CylinderGeometry(.011,.011,.019,8),metal);nail.rotation.z=Math.PI/2;nail.position.set(-.008,0,z);plank.add(nail);}
 }
 // Keep the extra wear detail inexpensive: all front pieces break as one group.
 intact.updateWorldMatrix(true,true);const inverse=new T.Matrix4().copy(intact.matrixWorld).invert(),batches=new Map(),frontPieces=[];
 intact.traverse(mesh=>{if(!mesh.isMesh)return;const key=mesh.material.uuid+mesh.castShadow;const geometry=(mesh.geometry.index?mesh.geometry.toNonIndexed():mesh.geometry.clone()).applyMatrix4(new T.Matrix4().multiplyMatrices(inverse,mesh.matrixWorld));if(!batches.has(key))batches.set(key,{material:mesh.material,cast:mesh.castShadow,receive:mesh.receiveShadow,parts:[]});batches.get(key).parts.push(geometry);frontPieces.push(mesh);});
 for(const mesh of frontPieces)mesh.removeFromParent();for(const batch of batches.values()){const mesh=new T.Mesh(mergeGeometries(batch.parts),batch.material);mesh.castShadow=batch.cast;mesh.receiveShadow=batch.receive;intact.add(mesh);for(const geometry of batch.parts)geometry.dispose();}
 const rubble=new T.Group();rubble.name='broken-closet-debris';rubble.userData.dynamic=true;rubble.visible=false;scene.add(rubble);
 const r=random(273);const shards=[];
 function shard(points,origin,material,thickness=.025){
  const center=new T.Vector2();for(const p of points)center.add(new T.Vector2(...p));center.multiplyScalar(1/points.length);
  const shape=new T.Shape();points.forEach(([z,y],i)=>{if(i)shape.lineTo(z-center.x,y-center.y);else shape.moveTo(z-center.x,y-center.y);});shape.closePath();
  const geometry=new T.ExtrudeGeometry(shape,{depth:thickness,bevelEnabled:false});geometry.rotateY(Math.PI/2);
  const mesh=new T.Mesh(geometry,material);mesh.castShadow=mesh.receiveShadow=true;rubble.add(mesh);
  const start=new T.Vector3(origin.x,origin.y+center.y,origin.z-center.x);
  shards.push({mesh,start,velocity:new T.Vector3(-.55-r()*.8,.4+r()*.9,(r()-.5)*1.3),spin:new T.Vector3((r()-.5)*4,(r()-.5)*6,(r()-.5)*5),yaw:r()*Math.PI*2,landed:false});
 }
 const grid=[];
 for(let row=0;row<=4;row++){grid[row]=[];for(let col=0;col<=3;col++)grid[row][col]=[-.435+col*.29+(col&&col<3?(r()-.5)*.10:0),.125+row*.4375+(row&&row<4?(r()-.5)*.12:0)];}
 const origin=new T.Vector3(cupboard.position.x-.295,0,cupboard.position.z);
 for(let row=0;row<4;row++)for(let col=0;col<3;col++){
  const a=grid[row][col],b=grid[row][col+1],c=grid[row+1][col+1],d=grid[row+1][col];shard([a,b,c],origin,wood);shard([a,c,d],origin,wood);
 }
 for(let i=0;i<3;i++)for(const side of [-1,1]){
  const y=.60+i*.42,z=side*.255;shard([[z-.255,y-.07],[z+.255,y-.07],[z+.24,y+.07],[z-.24,y+.05]],new T.Vector3(cupboard.position.x-.335,0,cupboard.position.z),wood,.04);
 }
 let broken=false,age=0;
 function breakApart(){if(broken)return false;broken=true;age=0;intact.visible=false;rubble.visible=true;for(const s of shards){s.mesh.position.copy(s.start);s.mesh.rotation.set(0,0,0);}return true;}
 function update(dt){
  if(!broken||age>=2.6)return false;age+=dt;
  for(const s of shards){if(s.landed)continue;s.velocity.y-=9.8*dt;s.mesh.position.addScaledVector(s.velocity,dt);s.mesh.rotation.x+=s.spin.x*dt;s.mesh.rotation.y+=s.spin.y*dt;s.mesh.rotation.z+=s.spin.z*dt;
   s.mesh.position.x=T.MathUtils.clamp(s.mesh.position.x,1.15,2.3);s.mesh.position.z=T.MathUtils.clamp(s.mesh.position.z,-1.40,.15);
   if(s.mesh.position.y<.045||age>2.4){s.mesh.position.y=.033+shards.indexOf(s)%3*.006;s.mesh.rotation.set(0,s.yaw,Math.PI/2);s.landed=true;}
  }return true;
 }
 return {intact,rubble,shards,get broken(){return broken;},breakApart,update};
}
