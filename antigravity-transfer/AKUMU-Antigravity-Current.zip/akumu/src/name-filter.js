// Local/offline screening. Exact words avoid rejecting names like Scunthorpe or Hancock.
const words=new Set(['fuck','fucker','fucking','motherfucker','shit','shithead','bullshit','bitch','bastard','cunt','dickhead','asshole','arsehole','piss','wanker','twat','slut','whore','nigger','nigga','faggot','fag','chink','gook','spic','kike','paki','retard','retarded','tranny','nazi','hitler','heilhitler','siegheil','whitepower','kkk','scheisse','arsch','arschloch','hurensohn','fotze','wichser','hure','fuk','fukk','fuc','fuker','fukin','phuck','phuk','fvck','shyt','bich','biatch','asshat','cocksucker','motherfuker','neger','negger','negro','schlampe','spasti','spast','missgeburt','drecksau']);
const fragments=['fuck','nigger','nigga','faggot','heilhitler','siegheil','hurensohn','arschloch'];
// Targeted spelling families: missing/doubled letters and phonetic substitutions.
const abusiveSpellings=[/n+[iel]+g+(?:e+r+|a+(?:r+|h+)?)/,/f+[uv]+(?:c+k+|k{2,})/,/ph+[u]+c?k+/,/sh+[il]+t+/];
const lookalikes={'а':'a','е':'e','о':'o','р':'p','с':'c','х':'x','у':'y','і':'i','ј':'j','к':'k','м':'m','т':'t','ѕ':'s','α':'a','ο':'o','ι':'i','0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','8':'b','9':'g','@':'a','$':'s','!':'i','+':'t'};
function folded(text){return [...text.normalize('NFKD').toLowerCase().replace(/\p{M}|\p{Cf}/gu,'').replace(/ß/g,'ss')].map(ch=>lookalikes[ch]||ch).join('');}
export function validatePlayerName(value){
 const name=value.normalize('NFKC').trim().replace(/\s+/gu,' ');
 if(!name)return {ok:false,error:'Please enter your name.'};
 const normalized=folded(name),tokens=normalized.split(/[^a-z]+/).filter(Boolean),compact=normalized.replace(/[^a-z]/g,'');
 const versions=s=>[s,s.replace(/(.)\1{2,}/g,'$1'),s.replace(/(.)\1{2,}/g,'$1$1')];
 const rejected=[...tokens,compact].some(s=>versions(s).some(v=>words.has(v)||fragments.some(w=>v.includes(w))||abusiveSpellings.some(pattern=>pattern.test(v))));
 if(rejected)return {ok:false,error:'Please choose a different name.'};
 if([...name].length>24||!/^\p{L}[\p{L}\p{M}\p{N} .’'\-]*$/u.test(name))return {ok:false,error:'Use up to 24 letters, numbers, spaces or name punctuation.'};
 return {ok:true,name};
}
