import * as T from 'three';
export function createSpiderScare(){
 const scene=new T.Scene(),camera=new T.PerspectiveCamera(60,1,.02,8),root=new T.Group();scene.add(root);
 const shell=new T.MeshStandardMaterial({color:0x211b17,roughness:.72}),joint=new T.MeshStandardMaterial({color:0x100d0c,roughness:.8}),fang=new T.MeshStandardMaterial({color:0x92785a,roughness:.48});
 function ball(x,y,z,sx,sy,sz,material=shell){const o=new T.Mesh(new T.SphereGeometry(1,22,16),material);o.position.set(x,y,z);o.scale.set(sx,sy,sz);root.add(o);return o;}
 ball(0,.22,-.10,.25,.34,.20);ball(0,-.08,.025,.21,.23,.17);ball(0,-.23,.11,.17,.13,.12,joint);
 const eyes=new T.MeshStandardMaterial({color:0x210a08,roughness:.13,emissive:0x9f240c,emissiveIntensity:.18});
 for(const side of [-1,1])for(let i=0;i<4;i++)ball(side*(.035+i*.035),-.16+(i>1?.045:0),.24-i*.011,i<2?.025:.017,.025,.019,eyes);
 for(const side of [-1,1]){const curve=new T.CatmullRomCurve3([new T.Vector3(side*.07,-.27,.18),new T.Vector3(side*.11,-.36,.24),new T.Vector3(side*.055,-.42,.27)]);const geo=new T.TubeGeometry(curve,12,.019,7,false),pos=geo.attributes.position;for(let ring=0;ring<=12;ring++){const center=curve.getPointAt(ring/12),taper=1-.98*ring/12;for(let j=0;j<=7;j++){const i=ring*8+j,v=new T.Vector3().fromBufferAttribute(pos,i).sub(center).multiplyScalar(taper).add(center);pos.setXYZ(i,v.x,v.y,v.z);}}geo.computeVertexNormals();root.add(new T.Mesh(geo,fang));}
 const legs=[];
 function segment(a,b,r1,r2,parent){const d=new T.Vector3().subVectors(b,a),mesh=new T.Mesh(new T.CylinderGeometry(r2,r1,d.length(),7),shell);mesh.position.copy(a).add(b).multiplyScalar(.5);mesh.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),d.normalize());parent.add(mesh);}
 for(const side of [-1,1])for(let i=0;i<4;i++){
  const leg=new T.Group(),y=.12-i*.13;leg.position.set(side*.15,y,0);root.add(leg);
  const a=new T.Vector3(),b=new T.Vector3(side*(.36+i*.025),.35-i*.19,.03),c=new T.Vector3(side*(.66-i*.045),.20-i*.25,.17),d=new T.Vector3(side*(.73-i*.08),-.02-i*.26,.23);
  segment(a,b,.035,.023,leg);segment(b,c,.024,.014,leg);segment(c,d,.015,.002,leg);legs.push({leg,side,index:i});
 }
 // Fine silhouette bristles catch the rim light without a texture download.
 const hair=[];let seed=37;const rand=()=>{seed=seed*16807%2147483647;return seed/2147483647;};
 for(let i=0;i<250;i++){const angle=rand()*Math.PI*2,z=(rand()-.5)*.25,x=Math.cos(angle)*.25,y=.22+Math.sin(angle)*.33;hair.push(x,y,z,x+Math.cos(angle)*.035,y+Math.sin(angle)*.035,z+.015);}
 const hairs=new T.BufferGeometry();hairs.setAttribute('position',new T.Float32BufferAttribute(hair,3));root.add(new T.LineSegments(hairs,new T.LineBasicMaterial({color:0x6c5841,transparent:true,opacity:.65})));
 scene.add(new T.HemisphereLight(0xb4b8ce,0x211008,2));const light=new T.PointLight(0xffd8b0,8,6);light.position.set(-.6,.8,1);scene.add(light);const rim=new T.PointLight(0x899bc7,5,5);rim.position.set(.8,.2,-.5);scene.add(rim);
 let age=0,active=false;
 function update(dt){if(!active)return;age+=dt;const lunge=Math.min(1,age/.035),retreat=Math.max(0,(age-.92)/.34);root.position.set(Math.sin(age*39)*.016, .15+Math.sin(age*31)*.012,-2.4+(2.4-.82)*lunge-retreat*2.8);root.rotation.set(-.05+Math.sin(age*26)*.04,Math.sin(age*23)*.045,Math.sin(age*35)*.035);for(const {leg,side,index}of legs){leg.rotation.z=side*Math.sin(age*24+index*1.3)*.13;leg.rotation.x=Math.sin(age*19+index)*.13;}if(age>=1.26)active=false;}
 return {async prepare(renderer){await renderer.compileAsync(scene,camera);renderer.render(scene,camera);},get active(){return active;},get age(){return age;},start(){age=0;active=true;update(0);},update,render(renderer,aspect){if(!active)return;camera.aspect=aspect;camera.updateProjectionMatrix();const old=renderer.autoClear;renderer.autoClear=false;renderer.clearDepth();renderer.render(scene,camera);renderer.autoClear=old;}};
}
