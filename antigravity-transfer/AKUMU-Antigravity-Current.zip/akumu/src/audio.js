import {DEMO_INVITATION_TEXT} from './demo-invitation.js';
import {createPCBeacon} from './pc-beacon.js';
import {ASSISTANCE_CAPTION} from './stage-two-assistance.js';
import {synthesizeEffect,EFFECT_LEVEL} from './audio-synthesis.js';
// Separate foley/ambience buses, a small room tail, and controlled output headroom.
export class Ambience {
 async start(){
  if(this.ctx)return this.ctx.resume();
  const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;
  this.setup(new Audio());await this.ctx.resume();
 }
 async prepareVoice(url,name='voiceBuffer'){
  // Decode before PLAY without opening a live audio output or requiring a download.
  const encoded=url.slice(url.indexOf(',')+1),raw=atob(encoded),bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
  const Offline=window.OfflineAudioContext||window.webkitOfflineAudioContext;
  if(!Offline)return false;
  const decoder=new Offline(1,1,44100);this[name]=await decoder.decodeAudioData(bytes.buffer);return true;
 }
 scheduleOpeningVoice(offset){
  if(!this.ctx||this.ctx.state!=='running'||!this.voiceBuffer)return false;
  const c=this.ctx,epoch=c.currentTime+.06,at=epoch+offset,source=c.createBufferSource();source.buffer=this.voiceBuffer;source.connect(this.voice);source.start(at);
  this.openingEpoch=epoch;this.openingVoice={source,startAt:at,duration:this.voiceBuffer.duration,ended:false};
  this.ambience.gain.cancelScheduledValues(c.currentTime);this.ambience.gain.setValueAtTime(.44,c.currentTime);this.ambience.gain.setValueAtTime(.44,Math.max(c.currentTime,at-.12));this.ambience.gain.linearRampToValueAtTime(.18,at);this.ambience.gain.setValueAtTime(.18,at+this.voiceBuffer.duration);this.ambience.gain.linearRampToValueAtTime(.44,at+this.voiceBuffer.duration+.35);
  source.onended=()=>{this.openingVoice.ended=true;source.disconnect();};return true;
 }
 lockedDoorVoice(hammer=false){
  return this.playNarrator(hammer?this.hammerDoorVoiceBuffer:this.doorVoiceBuffer,hammer?'(Narrator) Creative. Unfortunately, the door disagrees.':'(Narrator) Did you think escaping would be that easy?',0,hammer?3.94:3.10);
 }
 wrongCodeVoice(){return this.playNarrator(this.wrongCodeVoiceBuffer,"(Narrator) Four numbers. Apparently, that's asking a lot.",0,3.51);}
 cabinetVoice(){return this.playNarrator(this.cabinetVoiceBuffer,"(▓▒░▓▒) Can't a guy have his peace?",.12,1.83);}
 drawerRepeatVoice(){return this.playNarrator(this.drawerRepeatVoiceBuffer,"(Narrator) Maybe it'll magically refill. Keep trying.",0,4.25);}
 letterVoice(){
  if(!this.playNarrator(this.letterVoiceBuffer,'',0,6.64))return false;
  this.doorVoice.cues=[{start:.02,end:1.65,text:'(Narrator) Found something interesting?'},{start:1.76,end:6.64,text:'(Narrator) How about we forget about that and concentrate on escaping, shall we?'}];return true;
 }
 updatePCBeacon(enabled,position){
  if(this.pcBeaconStopped||!this.ctx||this.ctx.state!=='running')return;
  if(enabled&&!this.pcBeacon)this.pcBeacon=createPCBeacon(this.ctx,this.sfx,position);
  this.pcBeacon?.setEnabled(enabled);
 }
 stopPCBeacon(){this.pcBeaconStopped=true;this.pcBeacon?.stop();this.pcBeacon=null;}
 startDemoInvitation(){
  if(!this.demoInvitationBuffer)return null;
  if(!this.ctx||this.ctx.state!=='running')return {pending:true};
  if(this.demoInvitationPlayback)return this.demoInvitationPlayback;
  if(this.scareBusy||this.escapeVoice||this.doorVoice&&this.ctx.currentTime<this.doorVoice.cooldownUntil)return {pending:true};
  const t=this.ctx.currentTime;this.setRecognitionSilence(false);
  this.master.gain.cancelScheduledValues(t);this.master.gain.setValueAtTime(.88,t);
  if(!this.playNarrator(this.demoInvitationBuffer,'(Narrator) '+DEMO_INVITATION_TEXT,0,this.demoInvitationBuffer.duration))return {pending:true};
  for(const bus of [this.sfx,this.ambience]){bus.gain.cancelScheduledValues(t);bus.gain.value=0;bus.gain.setValueAtTime(0,t);}
  const voice=this.doorVoice;this.demoInvitationPlayback={ended:()=>voice.ended||this.ctx.currentTime>=voice.endAt};return this.demoInvitationPlayback;
 }
 startPCStartup(){
  if(this.pcStartupVoice||!this.pcStartupBuffer||!this.ctx||this.ctx.state!=='running')return false;
  const source=this.ctx.createBufferSource(),at=this.ctx.currentTime+.06;source.buffer=this.pcStartupBuffer;source.connect(this.sfx);
  const cue=this.pcStartupVoice={source,startAt:at,endAt:at+source.buffer.duration,ended:false};source.start(at);source.onended=()=>{cue.ended=true;source.disconnect();};return true;
 }
 pcStartupCaption(){const v=this.pcStartupVoice,t=this.ctx?.currentTime;return v&&!v.ended&&t>=v.startAt&&t<v.endAt?'(PC Startup)':'';}
 assistanceVoice(){return this.playNarrator(this.assistanceVoiceBuffer,ASSISTANCE_CAPTION,0,this.assistanceVoiceBuffer?.duration??0);}
 photoVoice(){return this.playNarrator(this.photoVoiceBuffer,'(Narrator) Funny. Last time you recognized everyone.',.14,4.02);}
 clockVoice(){return this.playNarrator(this.clockVoiceBuffer,"(Narrator) Watching it won't give you more time.",.15,2.62);}
 setClockTicking(enabled,position){
  if(!this.ctx)return;const c=this.ctx;
  if(!this.clockTickSource){
   const buffer=c.createBuffer(1,c.sampleRate*2,c.sampleRate);
   for(let i=0;i<2;i++){const pcm=synthesizeEffect('clockTick',c.sampleRate,807+i*7919);buffer.copyToChannel(pcm,0,i*c.sampleRate);}
   const source=c.createBufferSource(),panner=c.createPanner();source.buffer=buffer;source.loop=true;this.clockTickGain=c.createGain();this.clockTickGain.gain.value=0;
   panner.panningModel='HRTF';panner.refDistance=1.2;panner.rolloffFactor=.7;panner.maxDistance=10;panner.setPosition(position.x,position.y,position.z);
   source.connect(this.clockTickGain).connect(panner).connect(this.ambience);source.start();this.clockTickSource=source;this.clockTickEnabled=false;
  }
  if(this.clockTickEnabled!==enabled){this.clockTickEnabled=enabled;this.clockTickGain.gain.cancelScheduledValues(c.currentTime);this.clockTickGain.gain.setValueAtTime(enabled?.26:0,c.currentTime);}
 }
 bedVoice(){return this.playNarrator(this.bedVoiceBuffer,'(Narrator) You just woke up. Already tired?',.18,3.23);}
 setRecognitionSilence(active){
  if(this.recognitionSilenced===active)return;this.recognitionSilenced=active;
  if(!this.ctx||!this.voice)return;
  const gain=this.voice.gain;if(active)this.recognitionVoiceLevel=gain.value;
  gain.cancelScheduledValues(this.ctx.currentTime);const value=active?0:(this.recognitionVoiceLevel??1.55);gain.value=value;gain.setValueAtTime(value,this.ctx.currentTime);
 }
 playNarrator(buffer,caption,captionStart,captionEnd){
  if(this.recognitionSilenced||this.scareBusy||this.escapeVoice||!this.ctx||this.ctx.state!=='running'||!buffer)return false;
  const c=this.ctx,t=c.currentTime;
  // Repeated handle presses cannot layer or restart the narrator.
  if(this.doorVoice&&t<this.doorVoice.cooldownUntil)return false;
  const source=c.createBufferSource();source.buffer=buffer;source.connect(this.voice);
  const at=t+.06,duration=source.buffer.duration;
  this.doorVoice={source,startAt:at,endAt:at+duration,captionStart:at+captionStart,captionEnd:at+Math.min(duration,captionEnd),caption,cooldownUntil:at+duration+2,ended:false};
  this.ambience.gain.cancelScheduledValues(t);this.ambience.gain.setValueAtTime(.44,t);this.ambience.gain.linearRampToValueAtTime(.18,at);this.ambience.gain.setValueAtTime(.18,at+duration);this.ambience.gain.linearRampToValueAtTime(.44,at+duration+.35);
  source.start(at);source.onended=()=>{this.doorVoice.ended=true;source.disconnect();};return true;
 }
 narratorCaption(){
  if(this.recognitionSilenced||this.scareBusy)return '';
  if(!this.ctx||!this.doorVoice)return '';
  const t=this.ctx.currentTime,v=this.doorVoice;
  if(v.cues){const cue=v.cues.find(c=>t>=v.startAt+c.start&&t<v.startAt+c.end);return cue?.text||'';}
  return t>=v.captionStart&&t<v.captionEnd?v.caption:'';
 }
 startSpiderScare(){
  this.scareBusy=true;if(this.doorVoice&&!this.doorVoice.ended){try{this.doorVoice.source.stop();}catch{}}
  this.scareVisualDone=false;this.scareAftermathStarted=false;
  if(this.ctx&&this.uploadedScareBuffer){
   const source=this.ctx.createBufferSource(),gain=this.ctx.createGain();source.buffer=this.uploadedScareBuffer;gain.gain.value=.85;source.connect(gain).connect(this.scare);
   const at=this.ctx.currentTime,duration=Math.min(4,source.buffer.duration);gain.gain.setValueAtTime(.85,at);gain.gain.setValueAtTime(.85,at+Math.max(0,duration-.08));gain.gain.linearRampToValueAtTime(0,at+duration);
   this.scarePlayback={source,startAt:at,duration,ended:false};source.start(at,0,duration);
   source.onended=()=>{this.scarePlayback.ended=true;source.disconnect();gain.disconnect();if(this.scareVisualDone)this.finishSpiderScare();};
  }else{this.scarePlayback=null;this.play('spiderSting',0,0,this.scare);}

 }
 finishSpiderScare(){
  this.scareVisualDone=true;if(this.scarePlayback&&!this.scarePlayback.ended||this.scareAftermathStarted)return false;this.scareAftermathStarted=true;
  this.scareBusy=false;if(this.doorVoice)this.doorVoice.cooldownUntil=0;
  const played=this.playNarrator(this.closetScareVoiceBuffer,"(Narrator) Imagine getting jumpscared by a closet.",0,8.48);
  if(played)this.doorVoice.cues=[{start:0,end:3.55,text:'(Narrator) Imagine getting jumpscared by a closet.'},{start:3.67,end:8.48,text:"(Narrator) That's property damage. You owe me about 200 francs."}];return played;
 }
 startPassageVoice(){
  if(!this.ctx||!this.escapeVoiceBuffer)return false;
  if(this.doorVoice&&!this.doorVoice.ended){const old=this.doorVoice;old.source.onended=()=>{old.ended=true;old.source.disconnect();};try{old.source.stop();}catch{}}
  this.scareAftermathStarted=true;this.scareBusy=false;if(this.scarePlayback&&!this.scarePlayback.ended){try{this.scarePlayback.source.stop();}catch{}}
  const c=this.ctx,source=c.createBufferSource(),at=c.currentTime+.75;source.buffer=this.escapeVoiceBuffer;source.connect(this.voice);source.start(at);
  const v={source,startAt:at,endAt:at+source.buffer.duration,captionStart:at,captionEnd:at+source.buffer.duration,cooldownUntil:at+source.buffer.duration+2,ended:false,cues:[{start:0,end:2.34,text:'(Narrator) One door down.'},{start:2.5,end:5.05,text:'(Narrator) How many more until you remember?'}]};this.doorVoice=v;source.onended=()=>{v.ended=true;source.disconnect();};return true;
 }
 startEscapeVoice(){
  if(!this.ctx||this.ctx.state!=='running'||!this.escapeVoiceBuffer)return false;
  this.scareAftermathStarted=true;this.scareBusy=false;if(this.scarePlayback&&!this.scarePlayback.ended){try{this.scarePlayback.source.stop();}catch{}}
  const c=this.ctx,epoch=c.currentTime,at=epoch+.75,source=c.createBufferSource();
  if(this.doorVoice&&!this.doorVoice.ended){try{this.doorVoice.source.stop();}catch{}}
  for(const [bus,duration] of [[this.sfx,2],[this.ambience,3]]){bus.gain.cancelScheduledValues(epoch);bus.gain.setValueAtTime(bus.gain.value,epoch);bus.gain.linearRampToValueAtTime(0,epoch+duration);}
  source.buffer=this.escapeVoiceBuffer;source.connect(this.voice);source.start(at);
  this.escapeVoice={source,epoch,startAt:at,duration:source.buffer.duration,ended:false};
  source.onended=()=>{this.escapeVoice.ended=true;source.disconnect();this.fadeOut(1.5);};return true;
 }
 escapeTime(){return Math.max(0,this.ctx.currentTime-this.escapeVoice.epoch);}
 openingTime(){return Math.max(0,this.ctx.currentTime-this.openingEpoch);}
 setup(c){
  this.ctx=c;this.buffers=new Map();this.steps=0;this.lastLight=1;this.nextRearSnap=18+Math.random()*12;
  this.master=c.createGain();this.master.gain.value=.88;
  this.compressor=c.createDynamicsCompressor();this.compressor.threshold.value=-10;this.compressor.knee.value=10;this.compressor.ratio.value=5;this.compressor.attack.value=.003;this.compressor.release.value=.16;
  this.compressor.connect(this.master).connect(c.destination);
  const scareLimiter=c.createDynamicsCompressor();scareLimiter.threshold.value=-1.5;scareLimiter.knee.value=2;scareLimiter.ratio.value=16;scareLimiter.attack.value=.001;scareLimiter.release.value=.12;
  this.scare=c.createGain();this.scare.gain.value=1.45;this.scare.connect(scareLimiter).connect(this.master);
  this.voice=c.createGain();this.voice.gain.value=1.55;this.voice.connect(this.compressor);
  this.sfx=c.createGain();this.sfx.gain.value=.94;this.sfx.connect(this.compressor);
  this.ambience=c.createGain();this.ambience.gain.value=.44;this.ambience.connect(this.compressor);
  const room=c.createConvolver(),impulse=c.createBuffer(2,Math.ceil(c.sampleRate*.38),c.sampleRate);
  for(let ch=0;ch<2;ch++){const data=impulse.getChannelData(ch);for(let i=0;i<data.length;i++){const t=i/c.sampleRate;data[i]=(Math.random()*2-1)*Math.exp(-t*23)*.13;}for(const [seconds,level]of [[.019,.22],[.037,.13],[.064,.07]])data[Math.floor((seconds+ch*.002)*c.sampleRate)]+=level;}
  room.buffer=impulse;const wet=c.createGain();wet.gain.value=.10;this.sfx.connect(room);room.connect(wet).connect(this.compressor);
  this.noise=c.createBuffer(1,c.sampleRate*5,c.sampleRate);const data=this.noise.getChannelData(0);let n=0;for(let i=0;i<data.length;i++){n=(n+(Math.random()*2-1)*.018)/1.018;data[i]=n*3.3;}
  const wind=c.createBufferSource();wind.buffer=this.noise;wind.loop=true;const filter=c.createBiquadFilter();filter.type='lowpass';filter.frequency.value=460;this.wind=c.createGain();this.wind.gain.value=.10;wind.connect(filter).connect(this.wind).connect(this.ambience);wind.start();
  const buzz=c.createOscillator();buzz.frequency.value=100;buzz.setPeriodicWave(c.createPeriodicWave(new Float32Array(5),new Float32Array([0,1,.24,0,.08])));this.buzz=c.createGain();this.buzz.gain.value=.012;buzz.connect(this.buzz).connect(this.ambience);buzz.start();this.nextCreak=12+Math.random()*12;
 }
 play(name,pan=0,delay=0,bus=this.sfx){
  if(!this.ctx)return;const c=this.ctx,variant=Math.floor(Math.random()*4),key=name+':'+variant;
  if(!this.buffers.has(key)){const pcm=synthesizeEffect(name,c.sampleRate,207+variant*7919);const buffer=c.createBuffer(1,pcm.length,c.sampleRate);buffer.copyToChannel(pcm,0);this.buffers.set(key,buffer);}
  const source=c.createBufferSource(),gain=c.createGain(),panner=c.createStereoPanner();source.buffer=this.buffers.get(key);source.playbackRate.value=.98+Math.random()*.04;gain.gain.value=EFFECT_LEVEL[name];panner.pan.value=pan;source.connect(gain).connect(panner).connect(bus);source.start(c.currentTime+delay);source.onended=()=>[source,gain,panner].forEach(n=>n.disconnect());return source;
 }
 noiseBurst(volume,duration,frequency,pan=0){
  if(!this.ctx)return;const c=this.ctx,t=c.currentTime,source=c.createBufferSource(),filter=c.createBiquadFilter(),gain=c.createGain(),panner=c.createStereoPanner();source.buffer=this.noise;filter.type='lowpass';filter.frequency.value=frequency;panner.pan.value=pan;gain.gain.setValueAtTime(.001,t);gain.gain.linearRampToValueAtTime(volume,t+.008);gain.gain.exponentialRampToValueAtTime(.001,t+duration);source.connect(filter).connect(gain).connect(panner).connect(this.sfx);source.start(t,Math.random()*2);source.stop(t+duration+.02);source.onended=()=>[source,filter,gain,panner].forEach(n=>n.disconnect());
 }
 footstep(environment='bedroom'){this.steps++;return this.play(environment==='storage'?'concreteStep':'footstep',this.steps%2?.12:-.12);}
 door(){return this.play('door',.22);}
 drawer(){return this.play('drawer',-.18);}
 wheel(){return this.play('wheel');}
 unlock(){return this.play('unlock',.1);}
 pickup(){return this.play('pickup');}
 impact(){return this.play('impact',.05);}
 fall(){return this.play('fall',Math.random()*.5-.25);}
 key(){return this.play('key',.08);}
 doorCreak(){return this.play('doorCreak',.3);}
 fadeOut(seconds){if(!this.ctx)return;const t=this.ctx.currentTime;this.master.gain.cancelScheduledValues(t);this.master.gain.setValueAtTime(this.master.gain.value,t);this.master.gain.linearRampToValueAtTime(0,t+seconds);}
 rearSnap(time,position,yaw){
  const c=this.ctx,source=c.createBufferSource(),buffer=c.createBuffer(1,Math.ceil(c.sampleRate*.48),c.sampleRate),gain=c.createGain(),panner=c.createPanner(),filter=c.createBiquadFilter();
  buffer.copyToChannel(synthesizeEffect('twigSnap',c.sampleRate,Math.floor(Math.random()*100000)),0);source.buffer=buffer;
  const side=(Math.random()-.5)*.7,distance=1.25+Math.random()*.65;
  const x=position.x+Math.sin(yaw)*distance+Math.cos(yaw)*side,y=position.y-.35,z=position.z+Math.cos(yaw)*distance-Math.sin(yaw)*side;
  panner.panningModel='HRTF';panner.distanceModel='inverse';panner.refDistance=1.4;panner.rolloffFactor=.55;panner.maxDistance=8;panner.setPosition(x,y,z);
  filter.type='lowpass';filter.frequency.value=3600;gain.gain.value=.28;
  source.connect(filter).connect(gain).connect(panner).connect(this.ambience);source.start();source.onended=()=>[source,filter,gain,panner].forEach(n=>n.disconnect());
  this.lastRearSnap={time,position:[x,y,z],listener:[position.x,position.y,position.z],forward:[-Math.sin(yaw),0,-Math.cos(yaw)]};this.nextRearSnap=time+16+Math.random()*18;
 }
 update(time,light,position,yaw=0,pitch=0,canScare=false,environment='bedroom'){
  if(!this.ctx)return;const distance=position?Math.hypot(position.x-.15,position.y-2.44,position.z-.05):2;
  if(position){const l=this.ctx.listener,fx=-Math.sin(yaw)*Math.cos(pitch),fy=Math.sin(pitch),fz=-Math.cos(yaw)*Math.cos(pitch),t=this.ctx.currentTime;
   if(l.positionX){for(const [param,value]of [[l.positionX,position.x],[l.positionY,position.y],[l.positionZ,position.z],[l.forwardX,fx],[l.forwardY,fy],[l.forwardZ,fz],[l.upX,Math.sin(yaw)*Math.sin(pitch)],[l.upY,Math.cos(pitch)],[l.upZ,Math.cos(yaw)*Math.sin(pitch)]])param.setValueAtTime(value,t);}
   else{l.setPosition(position.x,position.y,position.z);l.setOrientation(fx,fy,fz,0,1,0);}
  }
  if(environment==='storage'){this.wind.gain.setTargetAtTime(.009,this.ctx.currentTime,1);this.buzz.gain.setTargetAtTime(.002,this.ctx.currentTime,1);return;}
  const narratorBusy=this.doorVoice&&this.ctx.currentTime<this.doorVoice.cooldownUntil;
  if(canScare&&position&&!this.scareBusy&&!narratorBusy&&!this.escapeVoice&&time>=this.nextRearSnap)this.rearSnap(time,position,yaw);
  this.wind.gain.setTargetAtTime(.07+Math.max(0,Math.sin(time*.067))*.075,this.ctx.currentTime,2);
  this.buzz.gain.setTargetAtTime(.012*light/Math.max(1,distance),this.ctx.currentTime,.07);
  if(light<.78&&this.lastLight>=.78)this.noiseBurst(.018,.08,2400,.05);this.lastLight=light;
  if(time>this.nextCreak){this.play('ambientCreak',Math.random()*1.4-.7);this.nextCreak=time+23+Math.random()*40;}
 }
 pause(){return this.ctx?.suspend();}resume(){return this.ctx?.resume();}
}
