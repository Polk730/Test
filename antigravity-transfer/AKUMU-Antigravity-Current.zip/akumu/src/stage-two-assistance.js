export const ASSISTANCE_DELAY=300;
export const ASSISTANCE_CAPTION='(PC) Attention. Assistance is now available. Please check the computer.';
// Monotonic wall time: closing the terminal, pausing or backgrounding never restarts the wait.
export class StageTwoAssistance {
 constructor(clock=()=>performance.now()/1000){this.clock=clock;this.startedAt=null;this.available=false;this.announced=false;this.finished=false;}
 start(){if(this.startedAt===null&&!this.finished)this.startedAt=this.clock();}
 update(){if(this.finished||this.available||this.startedAt===null||this.clock()-this.startedAt<ASSISTANCE_DELAY)return false;this.available=true;return true;}
 complete(){this.update();this.finished=true;}
 get pending(){return this.available&&!this.announced&&!this.finished;}
 markAnnounced(){if(!this.pending)return false;this.announced=true;return true;}
}
