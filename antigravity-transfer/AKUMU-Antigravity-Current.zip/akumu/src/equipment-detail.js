import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {agedSurface} from './aged-surface.js';
// Decorative meshes use existing materials and stay inside the equipment footprint.
export function addDeckDetails(player,metal,black){
 const parts=[];for(let i=0;i<5;i++)parts.push(new T.BoxGeometry(.026,.017,.006).translate(.18+i*.027,-.022,-.184));for(let i=0;i<9;i++)parts.push(new T.BoxGeometry(.004,.022,.004).translate(-.26+i*.012,.022,-.184));const mesh=new T.Mesh(mergeGeometries(parts),black);parts.forEach(g=>g.dispose());player.add(mesh);
 const rim=new T.Mesh(new T.BoxGeometry(.37,.004,.004),metal);rim.position.set(0,.037,-.184);player.add(rim);
 const led=new T.Mesh(new T.SphereGeometry(.0035,8,4),new T.MeshStandardMaterial({color:0xa8b896,emissive:0x5e8353,emissiveIntensity:.5,roughness:.6}));led.position.set(.27,.023,-.184);player.add(led);
}
let labelMaterial;
export function addCassetteDetails(g,black){
 if(!labelMaterial){const c=document.createElement('canvas');c.width=256;c.height=128;const ctx=c.getContext('2d');ctx.fillStyle='#a6a18c';ctx.fillRect(0,0,256,128);ctx.fillStyle='#3c443b';ctx.font='bold 19px monospace';ctx.fillText('HOTEL ARCHIVE',14,29);ctx.font='13px monospace';ctx.fillText('VHS  /  E-180',14,54);ctx.strokeStyle='#56594a66';for(const y of [76,94,111]){ctx.beginPath();ctx.moveTo(14,y);ctx.lineTo(240,y);ctx.stroke();}const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;labelMaterial=new T.MeshStandardMaterial({map:t,roughness:.96});}
 const label=new T.Mesh(new T.PlaneGeometry(.118,.055),labelMaterial);label.rotation.x=-Math.PI/2;label.position.set(0,.036,-.055);g.add(label);
 const screw=new T.CylinderGeometry(.003,.003,.002,8),parts=[];for(const x of [-.131,.131])for(const z of [-.071,.071])parts.push(screw.clone().translate(x,.036,z));const mesh=new T.Mesh(mergeGeometries(parts),black);parts.forEach(p=>p.dispose());screw.dispose();g.add(mesh);
}
export function equipmentPlastic(material){const s=agedSurface('plastic',851);material.map=s.color;material.normalMap=s.normal;material.normalScale=new T.Vector2(.18,.18);material.roughnessMap=s.roughness;material.roughness=.88;material.needsUpdate=true;}
