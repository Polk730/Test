import {collides,PLAYER_RADIUS} from './physics.js';
import {STACK_BOX_SIZE} from './box-stacking.js';
export const CRATE_STEP_HEIGHT=.58;
// Room 2 only: supported step-up surfaces, with a controlled fall when stepping off.
export function walkOnCrates(position,dx,dz,obstacles,crates,bounds,motion,dt){
 const h=STACK_BOX_SIZE/2,surfaces=crates.filter(b=>b.placement==='floor'||b.placement==='stack').map(b=>({minX:b.x-h,maxX:b.x+h,minZ:b.z-h,maxZ:b.z+h,top:b.y+h}));
 let x=position.x,z=position.z,feet=Math.max(0,motion.feet||0),fallSpeed=motion.fallSpeed||0;
 const steps=Math.max(1,Math.ceil(Math.hypot(dx,dz)/.055));
 function stepUp(){const reachable=surfaces.filter(b=>b.top>feet&&b.top<=feet+CRATE_STEP_HEIGHT+1e-7&&collides(x,z,[b]));if(reachable.length){feet=Math.max(...reachable.map(b=>b.top));fallSpeed=0;}}
 for(let i=0;i<steps;i++){
  const nx=Math.max(bounds.minX+PLAYER_RADIUS,Math.min(bounds.maxX-PLAYER_RADIUS,x+dx/steps));
  if(!collides(nx,z,obstacles)&&!collides(nx,z,surfaces.filter(b=>b.top>feet+CRATE_STEP_HEIGHT+1e-7))){x=nx;stepUp();}
  const nz=Math.max(bounds.minZ+PLAYER_RADIUS,Math.min(bounds.maxZ-PLAYER_RADIUS,z+dz/steps));
  if(!collides(x,nz,obstacles)&&!collides(x,nz,surfaces.filter(b=>b.top>feet+CRATE_STEP_HEIGHT+1e-7))){z=nz;stepUp();}
 }
 const touching=surfaces.filter(b=>b.top<=feet+1e-7&&collides(x,z,[b])),support=touching.length?Math.max(...touching.map(b=>b.top)):0;
 if(feet>support+1e-7){fallSpeed-=9.8*dt;feet=Math.max(support,feet+fallSpeed*dt);if(feet===support)fallSpeed=0;}else{feet=support;fallSpeed=0;}
 return {x,z,feet,fallSpeed,grounded:feet===support};
}
