// Pointer Events support multiple fingers independently (left stick + right look).
export function createTouchInput({enabled,canvas,getState,canMove,onLook,onRotate,onZoom,onTap,onInteract,onPause}){
 const root=document.getElementById('touch-controls'),stick=document.getElementById('joystick'),knob=document.getElementById('joystick-knob'),action=document.getElementById('touch-interact');
 const isEnabled=()=>typeof enabled==='function'?enabled():enabled;
 const axis={x:0,y:0},fingers=new Map();let stickId=null,lookId=null,pinchDistance=0;
 function resetStick(){stickId=null;axis.x=axis.y=0;knob.style.transform='translate(-50%,-50%)';}
 function reset(){resetStick();lookId=null;fingers.clear();pinchDistance=0;}
 function stickMove(e){const b=stick.getBoundingClientRect(),radius=b.width*.32;let x=(e.clientX-b.left-b.width/2)/radius,y=(e.clientY-b.top-b.height/2)/radius;const length=Math.hypot(x,y);if(length>1){x/=length;y/=length;}axis.x=Math.abs(x)<.09?0:x;axis.y=Math.abs(y)<.09?0:y;knob.style.transform=`translate(calc(-50% + ${x*radius}px),calc(-50% + ${y*radius}px))`;}
 stick.addEventListener('pointerdown',e=>{if(!isEnabled()||!canMove()||stickId!==null)return;e.preventDefault();stickId=e.pointerId;stick.setPointerCapture(e.pointerId);stickMove(e);});
 stick.addEventListener('pointermove',e=>{if(e.pointerId===stickId){e.preventDefault();stickMove(e);}});
 for(const event of ['pointerup','pointercancel','lostpointercapture'])stick.addEventListener(event,e=>{if(e.pointerId===stickId)resetStick();});
 const distance=()=>{const [a,b]=[...fingers.values()];return a&&b?Math.hypot(a.x-b.x,a.y-b.y):0;};
 canvas.addEventListener('pointerdown',e=>{if(!isEnabled()||e.pointerType!=='touch')return;if(getState()!=='inspecting'&&!canMove())return;e.preventDefault();canvas.setPointerCapture(e.pointerId);fingers.set(e.pointerId,{x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY});if(fingers.size>1)for(const finger of fingers.values())finger.multi=true;if(getState()==='inspecting'){pinchDistance=distance();}else if(lookId===null)lookId=e.pointerId;});
 canvas.addEventListener('pointermove',e=>{const previous=fingers.get(e.pointerId);if(!previous)return;e.preventDefault();const dx=e.clientX-previous.x,dy=e.clientY-previous.y;fingers.set(e.pointerId,{...previous,x:e.clientX,y:e.clientY});if(getState()==='inspecting'){if(fingers.size>=2){const d=distance();if(pinchDistance&&d)onZoom(pinchDistance/d);pinchDistance=d;}else onRotate(dx,dy);}else if(canMove()&&lookId===e.pointerId)onLook(dx,dy);});
 for(const event of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(event,e=>{const p=fingers.get(e.pointerId);if(event==='pointerup'&&p&&!p.multi&&fingers.size===1&&getState()==='inspecting'&&Math.hypot(e.clientX-p.startX,e.clientY-p.startY)<8)onTap?.(e.clientX,e.clientY);fingers.delete(e.pointerId);if(lookId===e.pointerId)lookId=null;pinchDistance=distance();});
 action.addEventListener('click',()=>{if(isEnabled()&&canMove())onInteract();});document.getElementById('touch-pause').addEventListener('click',onPause);
 document.getElementById('zoom-in').addEventListener('click',()=>onZoom(.88));document.getElementById('zoom-out').addEventListener('click',()=>onZoom(1.12));
 return {axis,reset,update(visible,label){root.hidden=!isEnabled()||!visible;action.disabled=!label;action.textContent=label||'INTERACT';}};
}
