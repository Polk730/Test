import * as T from 'three';
import {createStrawHat} from './straw-hat.js';
import {shelfUnits,INVENTORY_IDS} from './storage-inventory.js';
import {createInventoryLabels} from './inventory-labels.js';
import {createInventoryShelf} from './inventory-props.js';
import {BOX_HOMES} from './box-stacking.js';
import {createStorageComputer} from './storage-computer.js';
import {createStorageEnvelope} from './storage-envelope.js';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {surface,random} from './textures.js';
import {storageSurface} from './storage-materials.js';
import {storageLayout,STORAGE_BOUNDS,STORAGE_VENT} from './storage-layout.js';
export const STORAGE_LIGHTING={ambient:.98,primaryPower:58,fillPower:6,shadowSize:1024};
export function createStorageRoom(root,door,doorTarget){
 const layout=storageLayout(),r=random(6207),b=STORAGE_BOUNDS,units=shelfUnits(layout),inventory=[];let stockUnit=null;
 function register(type,object,unit=stockUnit){const parts=Array.isArray(object)?object:[object];for(const p of parts)p.traverse(o=>{o.userData.inventoryId=INVENTORY_IDS[type];o.userData.inventoryType=type;});inventory.push({type,inventoryId:INVENTORY_IDS[type],unit:unit?.key??null,shelf:unit?.label??null,parts});}
 function registerNew(type,start){register(type,root.children.slice(start));}
 const material=(kind,color=0xffffff)=>new T.MeshStandardMaterial({...storageSurface(kind),color,roughness:.96,metalness:kind==='rust'?.32:0,normalScale:new T.Vector2(.2,.2)});
 const plaster=material('plaster'),concrete=material('concrete'),ceiling=material('ceiling'),brick=material('brick'),rust=material('rust'),cardboard=material('cardboard');
 const wood=new T.MeshStandardMaterial({map:surface('wood',72).color,normalMap:surface('wood',72).normal,roughnessMap:surface('wood',72).roughness,color:0x9a9180,roughness:.93});
 const woodDark=wood.clone();woodDark.color.set(0x5d5346);
 const cloth=new T.MeshStandardMaterial({map:surface('cloth',52).color,normalMap:surface('cloth',52).normal,roughness:.98,color:0x8e8981});
 const caseMaterials=[0x5a4e42,0x777066,0x4d4d47].map(color=>new T.MeshStandardMaterial({map:surface('cloth',52).color,color,roughness:.9}));
 const dark=new T.MeshStandardMaterial({color:0x171612,roughness:1}),label=new T.MeshStandardMaterial({color:0xa99f85,roughness:1}),metal=new T.MeshStandardMaterial({color:0x827d71,roughness:.78,metalness:.5});
 const unitBox=new T.BoxGeometry(1,1,1),unitCylinder=new T.CylinderGeometry(1,1,1,10),unitSphere=new T.SphereGeometry(1,12,8);
 function box(w,h,d,x,y,z,m=wood,parent=root){const o=new T.Mesh(unitBox,m);o.scale.set(w,h,d);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;parent.add(o);return o;}
 function cylinder(radius,height,x,y,z,m=metal,parent=root){const o=new T.Mesh(unitCylinder,m);o.scale.set(radius,height,radius);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;parent.add(o);return o;}
 function mappedBox(w,h,d,x,y,z,m,scale=1.5){const geometry=new T.BoxGeometry(w,h,d),uv=geometry.attributes.uv,p=geometry.attributes.position,n=geometry.attributes.normal;for(let i=0;i<uv.count;i++){const nx=Math.abs(n.getX(i)),ny=Math.abs(n.getY(i));uv.setXY(i,(nx>.5?p.getZ(i)+z:p.getX(i)+x)/scale,(ny>.5?p.getZ(i)+z:p.getY(i)+y)/scale);}const o=new T.Mesh(geometry,m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;root.add(o);return o;}
 mappedBox(11.2,.12,9.2,6.1,-.05,6.58,concrete,2.4);
 mappedBox(11.2,.14,9.2,6.1,3.87,6.58,ceiling,2.1);
 mappedBox(.16,3.8,9.2,.52,1.9,6.58,plaster);mappedBox(.16,3.8,9.2,11.68,1.9,6.58,plaster);
 mappedBox(.25,3.8,.16,.725,1.9,2.08,plaster);mappedBox(9.65,3.8,.16,6.775,1.9,2.08,plaster);mappedBox(1.1,1.55,.16,1.4,3.025,2.08,plaster);
 // Far masonry wall has a real high ventilation opening; no windows.
 mappedBox(9.2,3.8,.16,5.2,1.9,11.16,plaster);mappedBox(.7,3.8,.16,11.25,1.9,11.16,plaster);
 mappedBox(1.1,2.64,.16,10.35,1.32,11.16,plaster);mappedBox(1.1,.44,.16,10.35,3.58,11.16,plaster);
 for(const x of [.625,11.575])box(.055,.14,8.94,x,.07,6.61,woodDark);
 for(const z of [2.17,11.055])box(10.9,.14,.035,6.1,.07,z,woodDark);
 // Localized masonry loss, not identical damage on every wall.
 function brickPatch(x,y,z,w,h,angle,seed){const rand=random(seed),shape=new T.Shape();for(let i=0;i<18;i++){const a=i/18*Math.PI*2,rad=.76+rand()*.24;const px=Math.cos(a)*w*.5*rad,py=Math.sin(a)*h*.5*rad;if(i)shape.lineTo(px,py);else shape.moveTo(px,py);}shape.closePath();const geometry=new T.ShapeGeometry(shape),uv=geometry.attributes.uv,p=geometry.attributes.position;for(let i=0;i<uv.count;i++)uv.setXY(i,p.getX(i)/1.3,p.getY(i)/1.3);const o=new T.Mesh(geometry,brick);o.position.set(x,y,z);o.rotation.y=angle;o.receiveShadow=true;root.add(o);}
 brickPatch(.607,1.1,7.8,2.8,1.35,Math.PI/2,12);brickPatch(.607,2.7,4.0,1.2,.65,Math.PI/2,33);brickPatch(11.593,.8,5.0,1.7,1.3,-Math.PI/2,52);brickPatch(7.9,1.2,11.071,2.2,1.5,Math.PI,71);brickPatch(5.4,2.8,2.167,1.5,.9,0,83);
 // Sparse old paintwork and skirting damage make intersections visually distinct.
 function sign(text,x,y,z,angle){const canvas=document.createElement('canvas');canvas.width=512;canvas.height=128;const c=canvas.getContext('2d');c.fillStyle='#6f6b5d';c.fillRect(0,0,512,128);c.strokeStyle='#3d3a32';c.strokeRect(5,5,502,118);c.fillStyle='#22221d';c.font='bold 34px Georgia';c.textAlign='center';c.fillText(text,256,78);const t=new T.CanvasTexture(canvas);t.colorSpace=T.SRGBColorSpace;const o=new T.Mesh(new T.PlaneGeometry(.74,.185),new T.MeshStandardMaterial({map:t,roughness:1}));o.position.set(x,y,z);o.rotation.y=angle;root.add(o);}
 sign('LINEN & FURNISHINGS',4.6,2.6,2.168,0);sign('HOTEL STORES',7.1,2.75,11.071,Math.PI);
 const rackMaterials={wood,metal:rust};
 function suitcase(x,y,z,w,h,d){const start=root.children.length;const m=caseMaterials[Math.floor(r()*caseMaterials.length)];box(w,h,d,x,y+h/2,z,m);for(const end of [-1,1])box(w+.012,.017,.025,x,y+h*.48,z+end*d*.48,woodDark);box(w*.36,.018,d+.014,x,y+h*.48,z,woodDark);box(.09,.022,.045,x,y+h+.02,z,metal);box(.035,.035,.008,x+w*.28,y+h*.48,z+d*.51,metal);registerNew('suitcase',start);}
 function blankets(x,y,z,w,d){const start=root.children.length;const layers=2+Math.floor(r()*3);for(let i=0;i<layers;i++)box(w,.055,d,x+(r()-.5)*.02,y+.03+i*.057,z,cloth);registerNew('folded-linen',start);}
 function carton(x,y,z,w,h,d){const start=root.children.length;const o=box(w,h,d,x,y+h/2,z,cardboard);o.rotation.y=(r()-.5)*.08;box(w*.16,.006,d+.005,x,y+h+.004,z,label);registerNew('carton',start);}
 function oldLamp(x,y,z){const start=root.children.length;cylinder(.10,.025,x,y+.013,z,woodDark);cylinder(.009,.24,x,y+.145,z);const shade=new T.Mesh(new T.ConeGeometry(.14,.18,12,1,true),cloth);shade.position.set(x,y+.32,z);root.add(shade);registerNew('table-lamp',start);}
 for(const rack of layout.racks){
  const cx=(rack.minX+rack.maxX)/2,length=rack.maxZ-rack.minZ,bays=Math.max(2,Math.round(length/1.04)),bay=length/bays,m=rackMaterials[rack.kind];
  for(let k=0;k<=bays;k++)for(const x of [rack.minX+.035,rack.maxX-.035])box(.055,3.2,.055,x,1.6,rack.minZ+k*bay,m);
  for(const y of [.20,.93,1.66,2.39,3.12])box(.69,.055,length,cx,y,(rack.minZ+rack.maxZ)/2,m);
  for(let k=0;k<bays;k++){
   const unit=units.find(u=>u.rackIndex===rack.index&&u.segment===rack.segment&&u.bay===k);stockUnit=unit;
   const z=rack.minZ+(k+.5)*bay,computerBay=rack.index===1&&rack.segment===0&&k===1,boxBay=BOX_HOMES.some(h=>h.rackIndex===rack.index&&h.segment===rack.segment&&h.bay===k),reservedBay=computerBay||boxBay;
   // Partial backing breaks horizontal sightlines, with open sections between bays.
   const backing=rack.kind==='wood'||r()<.63;
   if(backing&&!reservedBay)box(.025,2.78,bay*.88,cx,.2+1.39,z,woodDark);
   else if(!backing&&!reservedBay){const brace=box(.035,3,bay*.028,cx,1.6,z,m);brace.rotation.x=.23;}
   for(let level=0;level<4;level++){
    if(r()<.34)continue;const contentStart=root.children.length,recordStart=inventory.length;const y=.23+level*.73,kind=Math.floor(r()*6),itemZ=z+(r()-.5)*bay*.10;
    if(kind<2){carton(cx,y,itemZ,.46+r()*.12,.22+r()*.26,bay*.55);if(r()<.3)carton(cx,y+.43,itemZ,.4,.20,bay*.44);}
    else if(kind===2)suitcase(cx,y,itemZ,.50,.27+r()*.12,bay*.65);
    else if(kind===3)blankets(cx,y,itemZ,.53,bay*.7);
    else if(kind===4)oldLamp(cx,y,itemZ);
    else{box(.49,.32,bay*.54,cx,y+.16,itemZ,woodDark);const cover=new T.Mesh(unitSphere,cloth);cover.scale.set(.28,.09,bay*.31);cover.position.set(cx,y+.34,itemZ);root.add(cover);registerNew('covered-item',contentStart);}
    if(unit.puzzle||(reservedBay&&level===1)){for(const o of root.children.slice(contentStart))o.removeFromParent();inventory.splice(recordStart);}
   }
  }
 }
 // Forgotten framed pictures stay inside the shelf footprints.
 for(const rack of layout.racks.filter((_,i)=>i%3===0)){const unit=units.find(u=>u.rackIndex===rack.index&&u.segment===rack.segment&&u.bay===0);if(unit.puzzle)continue;stockUnit=unit;const start=root.children.length,x=(rack.minX+rack.maxX)/2,z=rack.minZ+.30;box(.48,.36,.035,x,.43,z,woodDark);box(.42,.29,.04,x,.43,z-.005,label);registerNew('picture-frame',start);}
 const inventoryLabels=createInventoryLabels(root,layout,units);
 const inventoryShelves=units.filter(u=>u.puzzle).map(u=>createInventoryShelf(root,u,register));
 // Existing two shadow casters plus restrained shelf/cross-passage bounce fills.
 const lights=new T.Group(),ambient=new T.HemisphereLight(0xc5c6ca,0x8a857b,STORAGE_LIGHTING.ambient);root.add(lights);lights.add(ambient);ambient.visible=false;
 for(const [x,z]of [[3.25,4.5],[8.3,8.15]]){
  box(.35,.06,.16,x,3.63,z,rust);cylinder(.014,.16,x,3.72,z,metal);
  const glow=new T.Mesh(new T.CylinderGeometry(.042,.042,.24,10),new T.MeshStandardMaterial({color:0xc8c4b4,emissive:0xfff1d8,emissiveIntensity:.5}));glow.rotation.z=Math.PI/2;glow.position.set(x,3.57,z);root.add(glow);
  const spot=new T.SpotLight(0xfff1df,STORAGE_LIGHTING.primaryPower,14,1.25,.65,2);spot.position.set(x,3.49,z);spot.target.position.set(x+.4,0,z+.35);spot.castShadow=true;spot.shadow.autoUpdate=false;spot.shadow.needsUpdate=true;spot.shadow.mapSize.set(STORAGE_LIGHTING.shadowSize,STORAGE_LIGHTING.shadowSize);spot.shadow.camera.near=.12;spot.shadow.camera.far=14;spot.shadow.normalBias=.018;spot.shadow.bias=-.00015;spot.shadow.radius=3;lights.add(spot,spot.target);
 }
 for(const [i,[x,z]]of [[1.4,3.0],[10.2,10],[8.6,4.4],[2.9,7.8]].entries()){const fill=new T.PointLight(0xd5d2ca,i<2?3.2:0,7,2);fill.position.set(x,i<2?2.6:1.9,z);fill.userData.storageBounce=true;fill.userData.shelfFill=i>=2;lights.add(fill);}
 // High ventilation shaft: physical metal duct and hinged grille, no acquisition puzzle.
 const ventRoot=new T.Group();ventRoot.position.set(STORAGE_VENT.x,STORAGE_VENT.y,11.075);ventRoot.rotation.y=Math.PI;root.add(ventRoot);
 box(1.1,.72,.035,0,0,-.70,dark,ventRoot);for(const x of [-.56,.56])box(.045,.78,.74,x,0,-.34,rust,ventRoot);for(const y of [-.38,.38])box(1.14,.045,.74,0,y,-.34,rust,ventRoot);
 const grille=new T.Group();grille.userData.dynamic=true;grille.position.x=-.55;ventRoot.add(grille);
 for(const x of [0,1.1])box(.035,.74,.03,x,0,0,rust,grille);for(const y of [-.36,.36])box(1.14,.035,.03,.55,y,0,rust,grille);
 for(let i=0;i<9;i++){const louver=box(1.05,.035,.04,.55,-.29+i*.073,.012,metal,grille);louver.rotation.x=-.35;}
 const ventHit=box(1.05,.68,.05,0,0,.04,new T.MeshBasicMaterial({visible:false}),ventRoot);
 let ventOpen=false,onExit=null;const vent={root:ventRoot,grille,requiredTool:'wrench',get isOpen(){return ventOpen;},openWithTool(tool){if(tool?.kind!=='wrench')return false;ventOpen=true;grille.rotation.y=-1.35;return true;},setExitHandler(fn){onExit=fn;},confirmEscape(){if(!ventOpen||!onExit)return false;onExit();return true;}};
 // Merge static meshes by material, keeping the shared entrance and future vent hinge movable.
 root.updateMatrixWorld(true);const batches=new Map(),remove=[];
 root.traverse(o=>{if(!o.isMesh||o.material.visible===false)return;for(let p=o;p&&p!==root;p=p.parent)if(p.userData.dynamic)return;const key=o.material.uuid+':'+o.castShadow;const g=(o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone()).applyMatrix4(o.matrixWorld);if(!batches.has(key))batches.set(key,{material:o.material,shadow:o.castShadow,parts:[]});batches.get(key).parts.push(g);remove.push(o);});
 for(const o of remove)o.removeFromParent();for(const batch of batches.values()){const geometry=mergeGeometries(batch.parts),mesh=new T.Mesh(geometry,batch.material);mesh.castShadow=batch.shadow;mesh.receiveShadow=true;root.add(mesh);for(const g of batch.parts)g.dispose();}
 // Use an existing empty shelf compartment; never replace stock or puzzle props.
 let hatPosition=null;
 for(const rack of layout.racks){
  if(hatPosition)break;
  const bays=Math.max(2,Math.round((rack.maxZ-rack.minZ)/1.04)),bay=(rack.maxZ-rack.minZ)/bays;
  for(let k=0;k<bays&&!hatPosition;k++){
   const unit=units.find(u=>u.rackIndex===rack.index&&u.segment===rack.segment&&u.bay===k);
   if(unit.puzzle||rack.index===1&&rack.segment===0&&k===1||BOX_HOMES.some(h=>h.rackIndex===rack.index&&h.segment===rack.segment&&h.bay===k))continue;
   for(const shelfY of [.93]){
    const z=rack.minZ+(k+.5)*bay,x=rack.minX+.175;
    const clearance=new T.Box3(new T.Vector3(rack.minX,shelfY+.028,z-.25),new T.Vector3((rack.minX+rack.maxX)/2-.02,shelfY+.24,z+.25));
    const occupied=inventory.filter(item=>item.unit===unit.key).some(item=>item.parts.some(part=>clearance.intersectsBox(new T.Box3().setFromObject(part))));
    if(!occupied){hatPosition=new T.Vector3(x,shelfY+.028,z);break;}
   }
  }
 }
 const strawHat=createStrawHat(root,hatPosition??new T.Vector3(2.3,3.148,3.875));
 const envelope=createStorageEnvelope(root),terminal=createStorageComputer(root);
 register('computer',terminal.computer,null);for(const crate of terminal.crates)register('sealed-crate',crate.root,null);
 const occluders=[];root.traverse(o=>{if(o.isMesh&&o.material.visible!==false&&!o.userData.noOcclude)occluders.push(o);});
 const entryTarget={root:doorTarget.root,object:door,kind:'storage-door',enabled:()=>false};
 return {installDoorReverse(){if(door.userData.storageReverse)return;door.userData.storageReverse=true;for(const child of [...door.children]){if(child.position.z>=-.035||child.material?.visible===false)continue;const back=child.clone(true);back.position.z*=-1;if(Array.isArray(child.material))back.rotation.y+=Math.PI;door.add(back);}},root,layout,bounds:b,boxes:layout.boxes,targets:[entryTarget,envelope.target,{root:ventHit,object:ventRoot,kind:'vent',enabled:()=>true},...terminal.targets,inventoryLabels.target,...inventoryShelves.map(s=>s.target)],terminal,envelope,strawHat,inventory,units,inventoryLabels,inventoryShelves,entryTarget,occluders,ambient,lights,vent,staticDrawCalls:batches.size,activate(){ambient.visible=true;lights.traverse(o=>{if(o.userData.storageBounce)o.intensity=STORAGE_LIGHTING.fillPower*(o.userData.shelfFill?.65:1);if(o.isSpotLight){o.shadow.autoUpdate=true;o.shadow.needsUpdate=true;}});}};
}
