import * as T from 'three';
import {hammerPose,SWING_DURATION,SWING_CONTACT} from './hammer-swing.js';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {surface,random} from './textures.js';
import {PROTOTYPE_CODE,HOTEL_ROOM} from './config.js';
import {LOGBOOK_TEXTS,CODE_NOTE_INDEX} from './logbooks.js';
import {collides,ROOM} from './physics.js';
const TAU=Math.PI*2;
export function createPuzzle({scene,camera,room,audio,inspect,setBusy,foundKey,finish,scareCloset,getSpace=()=>({root:scene,boxes:room.boxes,bounds:ROOM,bedroom:true})}){
 const state={notes:[false,false,false],drawer:'locked',digits:[0,0,0,0],hammer:'available',barricade:'intact',key:'hidden',door:'locked',sequence:'idle',bedInspections:0,bedNarratorPlayed:false,wrongCodeNarratorPlayed:false,cabinetScarePlayed:false,cabinetHits:0,cabinetTouches:0,cabinetVoicePlayed:false,drawerOpens:0,drawerVoicePlayed:false};
 const materials={};
 for(const kind of ['wood','metal','paper']){const maps=surface(kind);materials[kind]=new T.MeshStandardMaterial({map:maps.color,normalMap:maps.normal,normalScale:new T.Vector2(.2,.2),roughnessMap:maps.roughness,roughness:kind==='metal'?.78:.95,metalness:kind==='metal'?.68:0,color:kind==='metal'?0x8c8b78:0xffffff});}
 const dark=new T.MeshStandardMaterial({color:0x1d211e,roughness:.9,metalness:.3});
 const addBox=(parent,w,h,d,x,y,z,material=materials.metal)=>{const mesh=new T.Mesh((material.visible===false?new T.BoxGeometry(w,h,d):new RoundedBoxGeometry(w,h,d,1,Math.min(w,h,d)*.12)),material);mesh.position.set(x,y,z);mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh;};
 const hit=(parent,w,h,d)=>addBox(parent,w,h,d,0,0,0,new T.MeshBasicMaterial({visible:false}));
 const dirty=()=>{scene.updateMatrixWorld(true);};
 const target=(root,kind,object,enabled=()=>true,extra={})=>{const t={root,kind,object,enabled,...extra};room.targets.push(t);return t;};
 function canvasMap(draw,w=512,h=640){const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);const map=new T.CanvasTexture(c);map.colorSpace=T.SRGBColorSpace;return map;}

 function paperMap(lines,back=false){return canvasMap((c,w,h)=>{const r=random(back?81:17);c.fillStyle=back?'#b6a36b':'#c5b77d';c.fillRect(0,0,w,h);for(let i=0;i<9500;i++){c.fillStyle=`rgba(50,39,16,${r()*.10})`;c.fillRect(r()*w,r()*h,r()*2+1,1);}const g=c.createLinearGradient(0,0,w,h);g.addColorStop(0,'#fff0b718');g.addColorStop(.48,'#00000000');g.addColorStop(.5,'#392e1324');g.addColorStop(.53,'#fff5c016');g.addColorStop(1,'#33200933');c.fillStyle=g;c.fillRect(0,0,w,h);c.fillStyle='#333022';c.textAlign=back?'center':'left';if(back){c.font='italic 24px Georgia';c.fillText('I wrote it here so I wouldn’t forget.',w/2,190);c.font='bold 87px Georgia';c.fillText(PROTOTYPE_CODE,w/2,338);c.font='italic 24px Georgia';c.fillText('Don’t let them hear you.',w/2,430);}else{lines.forEach((line,i)=>{c.font=i===0?'bold 29px Georgia':'italic 24px Georgia';c.fillText(line,35,56+i*35);});}});}
 const notePositions=[{p:[-.63,1.43,1.978],r:Math.PI},{p:[-2.478,1.48,1.24],r:Math.PI/2},{p:[2.478,1.43,.68],r:-Math.PI/2}];
 const bedHit=hit(room.bed,1.32,.78,2.18);bedHit.position.y=.39;target(bedHit,'bed',room.bed,()=>state.sequence==='idle');
 let drawerVoicePending=false;
 let cabinetVoicePending=false,lastCabinetHit=-Infinity,lastCabinetTouch=-Infinity;
 let bedVoicePending=false,lastWheelTurn=-Infinity,codeChanged=false;
 const notes=LOGBOOK_TEXTS.map((lines,index)=>{
  const group=new T.Group(),geo=new T.PlaneGeometry(.25,.32,10,14),pos=geo.attributes.position;
  for(let i=0;i<pos.count;i++)pos.setZ(i,Math.sin(pos.getY(i)*21)*.0015+Math.sin(pos.getX(i)*44)*.0008);geo.computeVertexNormals();
  const front=new T.Mesh(geo,new T.MeshStandardMaterial({map:paperMap(lines),roughness:1,normalMap:surface('paper').normal,normalScale:new T.Vector2(.18,.18)}));front.castShadow=true;group.add(front);
  const back=new T.Mesh(geo.clone(),new T.MeshStandardMaterial({map:index===CODE_NOTE_INDEX?paperMap([],true):surface('paper').color,roughness:1}));back.rotation.y=Math.PI;back.position.z=-.002;group.add(back);
  group.position.set(...notePositions[index].p);group.rotation.y=notePositions[index].r;scene.add(group);const root=hit(group,.26,.33,.02);target(root,'note',group,()=>state.sequence==='idle',{index});return group;
 });
 // Physical brass hotel number, part of the door rather than an interaction label.
 const numberMap=canvasMap((c,w,h)=>{c.fillStyle='#76674c';c.fillRect(0,0,w,h);c.fillStyle='#211f19';c.textAlign='center';c.font='bold 76px Georgia';c.fillText(HOTEL_ROOM,w/2,100);},256,128);
 const plaque=new T.Mesh(new T.BoxGeometry(.18,.09,.008),[materials.metal,materials.metal,materials.metal,materials.metal,materials.metal,new T.MeshStandardMaterial({map:numberMap,roughness:.73,metalness:.45})]);plaque.position.set(.5,1.90,-.049);room.door.add(plaque);
 // A mechanical four-wheel lock. Digits are real meshes arranged around each drum.
 const lock=new T.Group();lock.position.set(0,0,.323);room.drawer.add(lock);addBox(lock,.30,.118,.035,0,0,0);addBox(lock,.263,.087,.01,0,0,.023,dark);
 const digitAtlas=canvasMap((c,w,h)=>{c.fillStyle='#aaa181';c.fillRect(0,0,w,h);c.fillStyle='#20231d';c.textAlign='center';c.font='bold 78px monospace';for(let n=0;n<10;n++)c.fillText(String(n),(n+.5)*100,85);},1000,112);
 const digitMaterial=new T.MeshStandardMaterial({map:digitAtlas,roughness:.84,metalness:.08});
 const wheels=[],turns=[0,0,0,0];
 for(let i=0;i<4;i++){
  const group=new T.Group();group.name='wheel-'+i;group.userData.wheelIndex=i;group.position.set(-.096+i*.064,0,.026);lock.add(group);
  const cylinder=new T.Mesh(new T.CylinderGeometry(.035,.035,.045,24),materials.metal);cylinder.rotation.z=Math.PI/2;group.add(cylinder);
  const faces=[];
  for(let n=0;n<10;n++){const angle=n*TAU/10,geometry=new T.PlaneGeometry(.038,.019),uv=geometry.attributes.uv;for(let j=0;j<uv.count;j++)uv.setX(j,(uv.getX(j)+n)/10);geometry.rotateX(angle);geometry.translate(0,-Math.sin(angle)*.0355,Math.cos(angle)*.0355);faces.push(geometry);}
  group.add(new T.Mesh(mergeGeometries(faces),digitMaterial));for(const face of faces)face.dispose();wheels.push(group);
 }
 const latch=addBox(lock,.034,.022,.026,.17,0,0);latch.name='lock-latch';
 const drawerControl=room.targets.find(t=>t.kind==='drawer');
 const lockTarget=target(hit(lock,.32,.13,.10),'lock',lock);
 // The same physical lock remains a drawer handle after it is solved.
 Object.defineProperty(lockTarget,'kind',{get:()=>state.drawer==='locked'?'lock':'drawer'});lockTarget.drawer=room.drawer;
 // Actual hammer model: stained ash handle, steel head and two split claw prongs.
 const hammer=new T.Group();hammer.name='physical-hammer';
 const handle=new T.Mesh(new T.CylinderGeometry(.014,.019,.33,12),materials.wood);handle.position.y=-.055;hammer.add(handle);
 addBox(hammer,.15,.057,.052,0,.125,0);const face=new T.Mesh(new T.CylinderGeometry(.033,.029,.045,16),materials.metal);face.rotation.z=Math.PI/2;face.position.set(-.09,.125,0);hammer.add(face);
 for(const z of [-.018,.018]){const claw=addBox(hammer,.074,.017,.012,.09,.142,z);claw.rotation.z=.35;}
 hammer.position.set(0,-.07,-.015);hammer.rotation.x=Math.PI/2;room.drawer.add(hammer);hammer.visible=false;
 const hammerHit=hit(hammer,.25,.43,.12);const hammerTarget=target(hammerHit,'hammer',hammer,()=>hammer.visible&&state.hammer!=='carried'&&state.sequence==='idle'&&(state.drawer==='open'||state.hammer==='dropped'));
 const windowRoot=new T.Group();windowRoot.position.set(0,1.5,-1.72);scene.add(windowRoot);target(hit(windowRoot,2.30,1.5,.05),'window',windowRoot,()=>state.barricade==='intact'&&state.sequence==='idle');
 // The key hangs centrally between the boarded front and the closed window glass.
 const keyGroup=new T.Group();keyGroup.position.set(0,1.50,-1.96);keyGroup.visible=false;scene.add(keyGroup);
 const keyMaterial=new T.MeshStandardMaterial({color:0xb79857,metalness:.55,roughness:.48,roughnessMap:surface('metal').roughness,normalMap:surface('metal').normal,normalScale:new T.Vector2(.12,.12)});
 const mount=new T.Mesh(new T.CylinderGeometry(.003,.003,.09,10),materials.metal);mount.rotation.x=Math.PI/2;mount.position.set(0,.095,-.025);keyGroup.add(mount);
 const hook=new T.Mesh(new T.TorusGeometry(.008,.0025,8,16,Math.PI*1.6),materials.metal);hook.position.set(0,.089,.023);keyGroup.add(hook);
 const key=new T.Group();key.position.z=.018;key.rotation.z=.08;key.scale.setScalar(1.6);keyGroup.add(key);
 const bow=new T.Mesh(new T.TorusGeometry(.017,.0045,8,20),keyMaterial);bow.position.y=.039;key.add(bow);addBox(key,.007,.064,.008,0,-.006,0,keyMaterial);addBox(key,.022,.009,.008,.007,-.036,0,keyMaterial);addBox(key,.013,.008,.008,.005,-.022,0,keyMaterial);
 const keyHit=hit(keyGroup,.18,.25,.10);target(keyHit,'key',key,()=>state.key==='available');
 let hammerSwing=null;
 let flight=null,removalStart=0,doorStart=0,lastActiveTime=0,shadowDirty=true;
 const boardStarts=room.boards.map(b=>({p:b.position.clone(),r:b.rotation.clone(),restY:.014+(b.geometry.parameters.depth||.055)/2+(b===room.boards.at(-1)?.055:0)}));
 function inspectTarget(object,kind,title,description='',scale=1){inspect({object,kind,title,description,scale});}
 function turnWheel(index){if(state.drawer!=='locked')return;state.digits[index]=(state.digits[index]+1)%10;turns[index]++;lastWheelTurn=lastActiveTime;codeChanged=true;audio.wheel();shadowDirty=true;
  /* The latch releases only once the physical drums have settled on the code. */ }
 function safeFloor(){const space=getSpace(),bounds=space.bounds,obstacles=space.bedroom&&state.drawer==='open'?[...space.boxes,room.drawerObstacle]:space.boxes;const direction=camera.getWorldDirection(new T.Vector3());for(const angle of [0,.8,-.8,1.7,-1.7,Math.PI]){const v=new T.Vector3(direction.x,0,direction.z).normalize().applyAxisAngle(new T.Vector3(0,1,0),angle);const x=T.MathUtils.clamp(camera.position.x+v.x*.4,bounds.minX+.16,bounds.maxX-.16),z=T.MathUtils.clamp(camera.position.z+v.z*.4,bounds.minZ+.16,bounds.maxZ-.16);if(!collides(x,z,obstacles,.12))return {x,z};}return {x:camera.position.x,z:camera.position.z};}
 function swingHammer(onHit=null){if(state.hammer!=='carried'||hammerSwing)return false;hammerSwing={start:lastActiveTime,hit:false,onHit};audio.noiseBurst(.012,.18,1800,.15);return true;}
 function dropHammer(){if(hammerSwing)return;if(state.hammer!=='carried')return;const p=safeFloor();getSpace().root.attach(hammer);hammer.position.set(p.x,Math.min(1.2,camera.position.y-.3),p.z);state.hammer='dropped';hammer.userData.resting=false;flight={v:0,rotation:hammer.rotation.clone()};shadowDirty=true;}
 function interact(t){
  if(!t||state.sequence!=='idle'||hammerSwing)return;
  if(t.kind==='bed'){state.bedInspections++;inspectTarget(room.bed,'bed','The old bed','The sheets are cold. You are not going back to sleep.',.16);if(state.bedInspections>=2&&!state.bedNarratorPlayed)bedVoicePending=true;}
  if(t.kind==='note'){state.notes[t.index]=true;inspectTarget(t.object,'note','LOGBOOK '+(t.index+1),'',1.35);}
  if(t.kind==='lock')inspectTarget(lock,'lock','Mechanical combination lock','Turn each wheel. Listen for the latch.',1.3);
  if(t.kind==='drawer'){
   if(state.drawer==='locked'){audio.door();return;}
   if(state.drawer==='open'){state.drawer='unlocked';drawerControl.open=false;audio.drawer();hammer.visible=state.hammer!=='available';}
   else{if(collides(camera.position.x,camera.position.z,[room.drawerObstacle])){audio.door();return;}state.drawer='open';state.drawerOpens++;if(state.drawerOpens>=3&&!state.drawerVoicePlayed)drawerVoicePending=true;drawerControl.open=true;hammer.visible=true;audio.drawer();}shadowDirty=true;
  }
  if(t.kind==='hammer'&&t.enabled()){
   getSpace().root.attach(hammer);state.hammer='carried';hammer.userData.resting=false;flight=null;audio.pickup();shadowDirty=true;
  }
  if(t.kind==='window'){
   if(state.hammer!=='carried'){audio.noiseBurst(.025,.12,500);return;}
   setBusy(true);swingHammer(()=>{state.sequence='removing';state.barricade='removing';removalStart=lastActiveTime;});
  }
  if(t.kind==='key'&&state.key==='available'){state.key='collected';key.visible=false;audio.key();foundKey(key);shadowDirty=true;}
  if(t.kind==='door'){
   if(state.key!=='collected'){
    const hammerAttempt=state.hammer==='carried';
    if(hammerAttempt)swingHammer(()=>audio.lockedDoorVoice(true));else{audio.door();audio.lockedDoorVoice(false);}return;
   }
   state.door='opening';state.sequence='door-opening';doorStart=lastActiveTime;audio.unlock();audio.doorCreak();finish();
  }
  if(t.kind==='barricade'){
   if(room.closetDamage.broken)return;
   if(state.hammer!=='carried'){
    if(lastActiveTime-lastCabinetTouch<.5)return;
    lastCabinetTouch=lastActiveTime;state.cabinetTouches++;audio.noiseBurst(.025,.12,650);
    if(state.cabinetTouches>=7&&!state.cabinetVoicePlayed)cabinetVoicePending=true;
    return;
   }
   swingHammer(()=>{lastCabinetHit=lastActiveTime;state.cabinetHits++;if(state.cabinetHits>=1&&!state.cabinetScarePlayed){state.cabinetScarePlayed=true;room.closetDamage.breakApart();cabinetVoicePending=false;state.sequence='scaring';scareCloset(()=>{state.sequence='idle';});}});
  }
 }
 function updateInspection(clone,dt){if(!clone||clone.userData.inspectKind!=='lock')return;for(let i=0;i<4;i++){const wheel=clone.getObjectByName('wheel-'+i);if(wheel)wheel.rotation.x=T.MathUtils.damp(wheel.rotation.x,-turns[i]*TAU/10,18,dt);}const pin=clone.getObjectByName('lock-latch');if(pin)pin.position.x=T.MathUtils.damp(pin.position.x,state.drawer==='locked'?.17:.19,10,dt);}
 function update(dt,time,active,examiningLock=false,roomOneActive=true){
  if(!active)return false;lastActiveTime=time;
  if(hammerSwing){const age=time-hammerSwing.start;if(!hammerSwing.hit&&age>=SWING_CONTACT){hammerSwing.hit=true;if(hammerSwing.onHit){audio.impact();hammerSwing.onHit();}}if(age>=SWING_DURATION)hammerSwing=null;}
  if(roomOneActive&&room.closetDamage.update(dt))shadowDirty=true;
  if(roomOneActive&&drawerVoicePending&&audio.drawerRepeatVoice()){drawerVoicePending=false;state.drawerVoicePlayed=true;}
  if(roomOneActive&&cabinetVoicePending&&!room.closetDamage.broken&&state.hammer!=='carried'&&audio.cabinetVoice()){cabinetVoicePending=false;state.cabinetVoicePlayed=true;}
  if(roomOneActive&&bedVoicePending&&audio.bedVoice()){bedVoicePending=false;state.bedNarratorPlayed=true;}
  for(let i=0;i<4;i++)wheels[i].rotation.x=T.MathUtils.damp(wheels[i].rotation.x,-turns[i]*TAU/10,18,dt);
  if(roomOneActive&&state.drawer==='locked'&&state.digits.join('')===PROTOTYPE_CODE&&wheels.every((w,i)=>Math.abs(w.rotation.x+turns[i]*TAU/10)<.025)){state.drawer='unlocked';audio.unlock();shadowDirty=true;}
  // Treat a settled combination as an attempt, not each intermediate wheel click.
  if(roomOneActive&&examiningLock&&codeChanged&&!state.wrongCodeNarratorPlayed&&state.drawer==='locked'&&state.digits.join('')!==PROTOTYPE_CODE&&time-lastWheelTurn>=2&&wheels.every((w,i)=>Math.abs(w.rotation.x+turns[i]*TAU/10)<.025)&&audio.wrongCodeVoice())state.wrongCodeNarratorPlayed=true;
  latch.position.x=T.MathUtils.damp(latch.position.x,state.drawer==='locked'?.17:.19,10,dt);
  if(state.hammer==='carried'){
   const space=getSpace(),bounds=space.bounds,pose=hammerPose(hammerSwing?time-hammerSwing.start:-1),offset=new T.Vector3(...pose.offset);
   const position=offset.applyMatrix4(camera.matrixWorld);for(let i=0;i<5&&collides(position.x,position.z,space.boxes,.09);i++)position.lerp(camera.position,.35);position.x=T.MathUtils.clamp(position.x,bounds.minX+.15,bounds.maxX-.15);position.z=T.MathUtils.clamp(position.z,bounds.minZ+.15,bounds.maxZ-.15);hammer.position.lerp(position,1-Math.exp(-dt*15));hammer.quaternion.copy(camera.quaternion).multiply(new T.Quaternion().setFromEuler(new T.Euler(...pose.rotation)));shadowDirty=true;
  }
  if(flight){
   flight.v-=9.8*dt;hammer.position.y+=flight.v*dt;hammer.rotation.z+=dt*1.3;shadowDirty=true;
   let support=.014;
   if(roomOneActive&&state.barricade==='removed')for(const board of room.boards){const bounds=new T.Box3().setFromObject(board);if(hammer.position.x>=bounds.min.x-.06&&hammer.position.x<=bounds.max.x+.06&&hammer.position.z>=bounds.min.z-.06&&hammer.position.z<=bounds.max.z+.06)support=Math.max(support,bounds.max.y);}
   if(hammer.position.y<=support+.033){hammer.position.y=support+.033;hammer.rotation.set(Math.PI/2,Math.PI*.23,0);hammer.userData.resting=true;flight=null;audio.fall();}
  }
  if(state.sequence==='removing'){
   const timeSince=time-removalStart;
   room.boards.forEach((board,i)=>{const t=T.MathUtils.clamp((timeSince-.45-i*.095)/1.15,0,1),f=t*t*(3-2*t);board.position.copy(boardStarts[i].p).lerp(new T.Vector3(.35+i*.045,boardStarts[i].restY,-.84+i*.17),f);board.rotation.x=T.MathUtils.lerp(boardStarts[i].r.x,Math.PI/2,f);board.rotation.z=boardStarts[i].r.z+Math.sin(t*Math.PI)*.08;if(t>.95&&!board.userData.landed){board.userData.landed=true;audio.fall();}});shadowDirty=true;
   if(timeSince>2.45){state.barricade='removed';const obstacleIndex=room.boxes.indexOf(room.windowObstacle);if(obstacleIndex>=0)room.boxes.splice(obstacleIndex,1);state.sequence='idle';state.key='available';keyGroup.visible=true;dropHammer();setBusy(false);}
  }
  if(roomOneActive&&state.door==='opening'){const t=T.MathUtils.clamp((time-doorStart)/1.9,0,1);room.door.rotation.y=t*t*(3-2*t)*1.22;shadowDirty=true;if(t===1){state.door='open';state.sequence='idle';}}
  const changed=shadowDirty;shadowDirty=false;return changed;
 }
 // Add physical puzzle meshes to occlusion checks. Held hammer never blocks the view ray.
 for(const group of [...notes,lock,keyGroup])group.traverse(o=>{if(o.isMesh&&o.material.visible!==false)room.occluders.push(o);});
 dirty();
 return {swingHammer,get swinging(){return !!hammerSwing;},state,notes,lock,wheels,hammer,key,keyGroup,interact,turnWheel,dropHammer,update,updateInspection};
}
