// TEMPORARY story value. Change only here: both the note and physical lock use it.
export const PROTOTYPE_CODE = '1986';
export const HOTEL_ROOM = '207';
