export const INVENTORY_TYPES=Object.freeze([
 {type:'radio',label:'RADIO',id:14},{type:'table-lamp',label:'TABLE LAMP',id:27},{type:'suitcase',label:'SUITCASE',id:38},
 {type:'carton',label:'CARTON',id:42},{type:'folded-linen',label:'FOLDED LINEN',id:51},{type:'covered-item',label:'COVERED ITEM',id:63},
 {type:'picture-frame',label:'PICTURE FRAME',id:72},{type:'sealed-crate',label:'SEALED CRATE',id:84},{type:'computer',label:'COMPUTER',id:91}
]);
export const INVENTORY_IDS=Object.freeze(Object.fromEntries(INVENTORY_TYPES.map(t=>[t.type,t.id])));
export const STAGE_TWO_MANIFEST=Object.freeze([{shelf:'A',type:'radio',expected:2,actual:2},{shelf:'B',type:'table-lamp',expected:1,actual:1},{shelf:'C',type:'suitcase',expected:3,actual:2}]);
export function shelfUnits(layout){
 const units=[];let next=3;
 for(const rack of layout.racks){const length=rack.maxZ-rack.minZ,bays=Math.max(2,Math.round(length/1.04));for(let bay=0;bay<bays;bay++){
  const puzzle=rack.index===1&&rack.segment===1;
  units.push({key:`${rack.index}/${rack.segment}/${bay}`,rackIndex:rack.index,segment:rack.segment,bay,label:puzzle?'ABC'[bay]:String.fromCharCode(65+next++),aisles:[rack.index+1,rack.index+2],minX:rack.minX,maxX:rack.maxX,minZ:rack.minZ+bay*length/bays,maxZ:rack.minZ+(bay+1)*length/bays,puzzle});
 }}return units;
}
