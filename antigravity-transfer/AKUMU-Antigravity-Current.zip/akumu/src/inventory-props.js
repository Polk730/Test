import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {INVENTORY_IDS} from './storage-inventory.js';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
// Recognizable props for the three counted units; all use the existing shelf supports.
export function createInventoryShelf(root,unit,register){
 const g=new T.Group();g.userData.dynamic=true;g.position.set(unit.maxX-.20,.9575,(unit.minZ+unit.maxZ)/2);g.rotation.y=Math.PI/2;root.add(g);
 const caseMat=new T.MeshStandardMaterial({color:0x665741,roughness:.94}),dark=new T.MeshStandardMaterial({color:0x191b16,roughness:.9}),metal=new T.MeshStandardMaterial({color:0x93866b,metalness:.35,roughness:.8}),cloth=new T.MeshStandardMaterial({color:0xa39b82,roughness:.98});
 function box(parent,w,h,d,x,y,z,mat=caseMat){const m=new T.Mesh(new RoundedBoxGeometry(w,h,d,1,Math.min(w,h,d)*.12),mat);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;parent.add(m);return m;}
 function cylinder(parent,r,h,x,y,z,mat=metal){const m=new T.Mesh(new T.CylinderGeometry(r,r,h,12),mat);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;parent.add(m);return m;}
 function radio(x){const item=new T.Group();item.position.x=x;g.add(item);box(item,.31,.19,.16,0,.095,0);box(item,.19,.13,.009,-.041,.10,.084,dark);for(let i=0;i<9;i++)box(item,.003,.115,.006,-.122+i*.019,.10,.092,metal);for(const y of [.065,.135]){const knob=cylinder(item,.019,.018,.105,y,.093);knob.rotation.x=Math.PI/2;}box(item,.10,.014,.014,0,.214,0,dark);for(const side of [-1,1])box(item,.012,.03,.014,side*.05,.20,0,dark);const antenna=cylinder(item,.003,.16,-.12,.26,-.035);antenna.rotation.z=.18;register('radio',item,unit);}
 function lamp(){const item=new T.Group();g.add(item);cylinder(item,.09,.025,0,.013,0,caseMat);cylinder(item,.008,.22,0,.135,0);const shade=new T.Mesh(new T.ConeGeometry(.135,.17,16,1,true),cloth);shade.position.y=.30;shade.castShadow=shade.receiveShadow=true;item.add(shade);register('table-lamp',item,unit);}
 function suitcase(x){const item=new T.Group();item.position.x=x;g.add(item);box(item,.35,.26,.20,0,.13,0);for(const side of [-1,1]){box(item,.025,.265,.206,side*.105,.13,0,dark);box(item,.022,.03,.013,side*.105,.13,.108,metal);box(item,.014,.038,.025,side*.047,.278,0,dark);}box(item,.11,.018,.025,0,.30,0,dark);box(item,.35,.007,.204,0,.128,0,dark);register('suitcase',item,unit);}
 if(unit.label==='A'){radio(-.205);radio(.205);}else if(unit.label==='B')lamp();else{suitcase(-.215);suitcase(.215);}
 // Preserve the countable arrangement while rendering each material in one batch.
 g.updateWorldMatrix(true,true);const inverse=new T.Matrix4().copy(g.matrixWorld).invert(),batches=new Map(),remove=[];g.traverse(o=>{if(!o.isMesh)return;const part=(o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone()).applyMatrix4(new T.Matrix4().multiplyMatrices(inverse,o.matrixWorld));if(!batches.has(o.material))batches.set(o.material,[]);batches.get(o.material).push(part);remove.push(o);});for(const o of remove)o.removeFromParent();const type=unit.label==='A'?'radio':unit.label==='B'?'table-lamp':'suitcase';for(const [material,parts]of batches){const m=new T.Mesh(mergeGeometries(parts),material);m.castShadow=m.receiveShadow=true;m.userData.inventoryId=INVENTORY_IDS[type];m.userData.inventoryType=type;g.add(m);for(const part of parts)part.dispose();}
 const hit=new T.Mesh(new T.BoxGeometry(.94,.76,.018),new T.MeshBasicMaterial({visible:false}));hit.position.set(0,.36,.25);g.add(hit);
 return {root:g,unit,target:{root:hit,object:g,kind:'inventory-shelf',shelf:unit.label,enabled:()=>true}};
}
