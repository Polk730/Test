import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {agedSurface} from './aged-surface.js';
import {BASEMENT_FLOOR as F,BASEMENT_CEILING as C,BASEMENT_BOUNDS as B,BASEMENT_BOUNDARIES,BASEMENT_WALK_BOUNDS,STAIRS,STAIR_EXIT_Z,BASEMENT_DAMP,basementFloorAt} from './basement-layout.js';
import {CHUTE_CURVE} from './basement-journey.js';

export function createBasement(scene,laundry){
 const root=new T.Group();root.name='basement-abandoned-storage';root.visible=false;scene.add(root);
 const boxes=[...laundry.laundry.boxes,...BASEMENT_BOUNDARIES],unit=new T.BoxGeometry(1,1,1);
 function mat(kind,color,roughness=.92,metalness=0){const t=agedSurface(kind);return new T.MeshStandardMaterial({color,map:t.color,normalMap:t.normal,normalScale:new T.Vector2(.3,.3),roughnessMap:t.roughness,roughness,metalness});}
 const concrete=mat('concrete',0x89857a),plaster=mat('plaster',0xa6a18c),brick=mat('brick',0x84705a),wood=mat('wood',0x8b7151),darkWood=mat('wood',0x514536),rust=mat('rust',0x8e7960,.88,.4),metal=mat('metal',0x879087,.7,.6),black=mat('plastic',0x252b29),cloth=mat('cloth',0x8b8979),card=mat('cardboard',0xb4a582),paper=mat('paper',0xd0c6a2),glass=new T.MeshStandardMaterial({color:0x26312e,roughness:.48,metalness:.55});
 cloth.side=T.DoubleSide;
 function mesh(g,m,parent=root){const o=new T.Mesh(g,m);o.castShadow=o.receiveShadow=true;parent.add(o);return o;}
 function box(w,h,d,x,y,z,m=wood,parent=root){const o=mesh(unit,m,parent);o.scale.set(w,h,d);o.position.set(x,y,z);return o;}
 function cyl(r,h,x,y,z,m=metal,parent=root){const o=mesh(new T.CylinderGeometry(r,r,h,12),m,parent);o.position.set(x,y,z);return o;}
 function beam(a,b,r,m=rust){const d=new T.Vector3().subVectors(b,a),o=mesh(new T.CylinderGeometry(r,r,d.length(),10),m);o.position.copy(a).add(b).multiplyScalar(.5);o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),d.normalize());return o;}
 function solid(x,z,w,d){boxes.push({minX:x-w/2,maxX:x+w/2,minZ:z-d/2,maxZ:z+d/2});}
 box(6.2,.16,6.2,26,F-.08,25.08,concrete);
 box(.16,2.2,6.2,22.92,F+1.1,25.08,brick);box(.16,2.2,6.2,29.08,F+1.1,25.08,plaster);box(6.2,2.2,.16,26,F+1.1,28.16,brick);
 // A real low aperture surrounds the chute mouth; no solid wall crosses the camera path.
 box(.29,2.2,.16,23.145,F+1.1,22,plaster);box(3.07,2.2,.16,25.545,F+1.1,22,plaster);
 box(.72,.44,.16,23.65,F+.22,22,plaster);box(.72,1.04,.16,23.65,-.08,22,plaster);
 box(.68,2.2,.16,28.66,F+1.1,22,plaster);
 // Ceiling leaves a real stairwell opening, not a camera portal.
 for(const [w,d,x,z]of [[4.08,6,25.04,25.08],[.68,6,28.66,25.08],[1.24,2.10,27.7,27.03]])box(w,.12,d,x,C+.06,z,concrete);
 const length=STAIRS.maxZ-STAIRS.minZ,rise=.84-F,angle=Math.atan2(rise,length);
 const roofStart=22.24,roofRise=rise*(STAIRS.maxZ-roofStart)/length;
 box(1.24,.12,Math.hypot(STAIRS.maxZ-roofStart,roofRise),27.7,C+roofRise/2,(roofStart+STAIRS.maxZ)/2,concrete).rotation.x=angle;
 // Solid stairwell cheek walls follow the sloping ceiling.
 const sideShape=new T.Shape();sideShape.moveTo(roofStart,F);sideShape.lineTo(24.98,F);sideShape.lineTo(24.98,C+rise*(25.98-24.98)/length);sideShape.lineTo(roofStart,C+roofRise);sideShape.closePath();
 for(const x of [27.08,28.32]){const g=new T.ExtrudeGeometry(sideShape,{depth:.08,bevelEnabled:false,curveSegments:1});const o=mesh(g,concrete);o.rotation.y=-Math.PI/2;o.position.x=x+.04;}
 const stairMetal=mat('rust',0xb4a38a,.83,.35),edgePaint=mat('metal',0xc4bba1,.94,.08);
 // Low indirect spill keeps metal and worn nosings readable without adding a lamp.
 stairMetal.emissive.copy(stairMetal.color);stairMetal.emissiveIntensity=.035;edgePaint.emissive.copy(edgePaint.color);edgePaint.emissiveIntensity=.10;
 for(let i=0;i<STAIRS.steps;i++){
  const z=STAIRS.minZ+(i+.5)*length/STAIRS.steps,y=.84-(i+1)*rise/STAIRS.steps;
  box(1.12,.035,length/STAIRS.steps,27.7,y-.0175,z,stairMetal);box(1.12,rise/STAIRS.steps,.025,27.7,y+rise/STAIRS.steps/2,z-length/STAIRS.steps/2,stairMetal);
  box(1.06,.007,.035,27.7,y+.0035,z+length/STAIRS.steps/2-.02,edgePaint);
  for(const x of [27.2,28.2]){box(.055,.12,length/STAIRS.steps,x,y-.07,z,metal);if(i%3===0)box(.025,.88,.025,x,y+.44,z,rust);}
 }
 for(const x of [27.2,28.2])beam(new T.Vector3(x,.84+.88-rise*(22.20-STAIRS.minZ)/length,22.20),new T.Vector3(x,F+.88,25.98),.026,stairMetal);
 // A spring return gate swings toward Laundry automatically when approached from below.
 const exitGate=new T.Group();exitGate.name='basement-return-gate';exitGate.position.set(27.15,.84,22.08);root.add(exitGate);
 const laundryFace=laundry.wallMaterial.clone();laundryFace.side=T.BackSide;
 const gatePanel=mesh(new T.PlaneGeometry(1.08,1.94),laundryFace,exitGate);gatePanel.position.set(.54,.99,.04);
 // One-way visibility at the upper opening: opaque from Laundry, culled from below.
 const privacyFace=mesh(new T.PlaneGeometry(1.24,2.05),laundryFace);privacyFace.name='laundry-stair-screen';privacyFace.position.set(27.7,.84+1.025,22.0798);privacyFace.castShadow=false;
 // Continue the surrounding south wall's tile grid instead of outlining a hidden opening.
 const wallUV=privacyFace.geometry.attributes.uv,wallPosition=privacyFace.geometry.attributes.position;
 for(let i=0;i<wallUV.count;i++)wallUV.setXY(i,(28.95-(27.7+wallPosition.getX(i)))/2,(1.025+wallPosition.getY(i))/2);
 box(.74,.04,.065,.54,.98,.06,stairMetal,exitGate);
 for(const y of [.20,1.75])box(.04,.12,.075,0,y,.07,rust,exitGate);
 for(const x of [27.1,28.3])box(.055,2.05,.07,x,.84+1.025,22.13,metal);
 box(1.25,.06,.07,27.7,.84+2.04,22.13,metal);
 let exitOpen=false;
 function updateExit(position,dt){
  if(position.x>STAIRS.minX&&position.x<STAIRS.maxX&&position.z>STAIRS.minZ&&position.z<23.65)exitOpen=true;
  if(position.z<=STAIR_EXIT_Z)exitOpen=false;
  const angle=T.MathUtils.damp(exitGate.rotation.y,exitOpen?1.54:0,10,dt);
  const changed=Math.abs(angle-exitGate.rotation.y)>.0001;exitGate.rotation.y=angle;return changed;
 }
 // Inaccessible narrow strip beside the stairwell is filled, not a trap.
 box(.60,.75,3.75,28.69,F+.375,24.04,darkWood);solid(28.69,24.04,.62,3.85);
 function carton(x,y,z,w=.45,h=.28,d=.42){box(w,h,d,x,F+y+h/2,z,card);box(w*.16,.008,d+.004,x,F+y+h+.004,z,paper);}
 function crate(x,y,z,w=.5){box(w,w,w,x,F+y+w/2,z,darkWood);for(const zz of [-1,1])for(let i=0;i<4;i++)box(w-.025,w*.19,.025,x,F+y+(i+.5)*w/4,z+zz*w/2,wood);for(const xx of [-1,1])box(.045,w+.015,w+.02,x+xx*w*.43,F+y+w/2,z,wood);}
 // Wooden storage shelves, with an off CRT partially obscured by cartons.
 for(const z of [24.75,26.25]){for(const x of [23.05,23.72])for(const zz of [z-.62,z+.62])box(.045,2.03,.045,x,F+1.015,zz,wood);for(const y of [.18,.65,1.35,1.98])box(.72,.035,1.30,23.38,F+y,z,wood);solid(23.38,z,.76,1.34);}
 for(const [x,y,z]of [[23.38,.2,24.4],[23.38,.2,25.05],[23.38,1.37,24.3],[23.38,1.37,25.1],[23.38,.67,25.8],[23.38,1.37,26.5]])carton(x,y,z,.44,.24,.34);
 const tv=new T.Group();tv.name='off-vintage-crt';tv.position.set(23.38,F+.6675,24.75);tv.rotation.y=Math.PI/2;root.add(tv);
 box(.50,.42,.38,0,.21,0,black,tv);box(.40,.31,.025,-.035,.22,.202,glass,tv);for(const x of [-.247,.177])box(.025,.37,.025,x,.22,.215,wood,tv);for(const y of [.045,.395])box(.43,.025,.03,-.035,y,.218,wood,tv);for(const y of [.14,.24,.33]){const dial=cyl(.018,.018,.22,y,.21,metal,tv);dial.rotation.x=Math.PI/2;}for(let i=0;i<7;i++)box(.09,.007,.012,.19,.055+i*.012,.21,metal,tv);carton(23.70,.67,24.40,.23,.32,.35);carton(23.38,.67,25.25,.42,.36,.28);
 const wardrobe=new T.Group();wardrobe.name='closed-damaged-wardrobe';wardrobe.position.set(24.9,F,22.48);root.add(wardrobe);box(1.1,1.82,.56,0,.91,0,darkWood,wardrobe);
 for(const x of [-.268,.268]){const panel=box(.515,1.63,.045,x,.91,.305,wood,wardrobe);panel.rotation.z=x>0?.025:0;box(.025,.11,.03,x+(x<0?.15:-.15),.90,.345,rust,wardrobe);for(const y of [.28,1.35,1.65])cyl(.014,.09,x<0?-.51:.51,y,.33,rust,wardrobe);for(let i=0;i<3;i++){const scratch=box(.14,.005,.002,x-.05+i*.03,.45+i*.25,.332,black,wardrobe);scratch.rotation.z=.4;}}
 solid(24.9,22.48,1.15,.68);
 function chair(x,z,broken=false){box(.45,.045,.44,x,F+.44,z,wood);box(.45,.50,.045,x,F+.70,z-.20,wood).rotation.z=broken?.12:0;for(const dx of [-.18,.18])for(const dz of [-.17,.17])box(.035,broken&&dx>0?.35:.43,.035,x+dx,F+.215,z+dz,darkWood);solid(x,z,.52,.52);}
 chair(25.9,22.77);chair(26.25,27.35,true);
 // The neglected corner: draped furniture, suitcases and closed wooden crates.
 box(1.10,.70,.68,24.10,F+.35,27.35,darkWood);const sheet=new T.PlaneGeometry(1.3,.95,10,8);const p=sheet.attributes.position;for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getY(i),edge=Math.max(0,(Math.abs(x)-.43)/.22,(Math.abs(z)-.30)/.175);p.setXYZ(i,x,.77-.36*Math.min(1,edge)+.008*Math.sin(x*42+z*17),z);}sheet.computeVertexNormals();mesh(sheet,cloth).position.set(24.10,F,27.35);solid(24.10,27.35,1.32,1.0);
 crate(25.12,0,27.65);crate(25.12,.5,27.65,.40);solid(25.12,27.65,.55,.55);
 for(const [x,z,w]of [[24.04,26.0,.66],[24.12,25.8,.54]]){box(w,.23,.37,x,F+.115,z,darkWood);for(const xx of [-1,1])box(.025,.245,.38,x+xx*w*.33,F+.12,z,metal);box(.11,.02,.03,x,F+.25,z,wood);solid(x,z,w+.03,.4);}
 for(const [x,z,rot]of [[23.08,27.1,Math.PI/2],[26.45,22.15,0]]){const g=new T.Group();g.position.set(x,F+.44,z);g.rotation.y=rot;root.add(g);box(.48,.86,.035,0,0,0,darkWood,g);box(.425,.80,.012,0,0,.026,glass,g);}
 const news=document.createElement('canvas');news.width=news.height=256;const nc=news.getContext('2d');nc.fillStyle='#b4a783';nc.fillRect(0,0,256,256);nc.fillStyle='#655c49';for(let y=25;y<240;y+=8)for(let col=0;col<3;col++)nc.fillRect(12+col*80,y,48+(y%3)*7,2);const nt=new T.CanvasTexture(news);nt.colorSpace=T.SRGBColorSpace;const newspaper=new T.MeshStandardMaterial({map:nt,roughness:1});for(let i=0;i<4;i++){const o=mesh(new T.PlaneGeometry(.30,.23),newspaper);o.rotation.x=-Math.PI/2;o.rotation.z=i*.4;o.position.set(24.8+i*.13,F+.001+i*.0004,26.7);}
 // A split, worn table stays beside the clear central route.
 for(const x of [25.16,25.84])for(const z of [23.59,24.01])box(.045,.59,.045,x,F+.295,z,darkWood);
 for(let i=0;i<4;i++){const top=box(.85,.035,.125,25.5,F+.61,23.6+i*.135,wood);if(i===3)top.rotation.z=.035;}
 box(.72,.08,.035,25.5,F+.43,23.57,darkWood);solid(25.5,23.8,.90,.62);
 const tablePaper=mesh(new T.PlaneGeometry(.28,.22),newspaper);tablePaper.rotation.x=-Math.PI/2;tablePaper.rotation.z=.18;tablePaper.position.set(25.4,F+.63,23.75);
 for(let i=0;i<5;i++){const plank=box(.07,.025,.5,24.3+i*.17,F+.015,27.9-i*.07,wood);plank.rotation.y=i*.45;const can=cyl(.04,.13,26.65+i*.08,F+.065,27.7-i*.12,rust);if(i%2){can.rotation.z=Math.PI/2;can.position.y=F+.04;}box(.05,.012,.12,26.8,F+.008,26.6+i*.1,metal).rotation.y=i*.8;}
 // Pipes and cabling stay tight to the low ceiling, with visible mounts.
 for(const x of [23.22,26.7]){beam(new T.Vector3(x,C-.10,22.18),new T.Vector3(x,C-.10,27.95),.032,rust);for(const z of [22.8,25,27.5])box(.11,.12,.035,x,C-.04,z,metal);}
 beam(new T.Vector3(23.2,C-.055,26.5),new T.Vector3(26.8,C-.055,26.5),.012,black);for(const x of [23.4,24.8,26.5])box(.025,.07,.03,x,C-.025,26.5,metal);
 const wetMaterial=new T.MeshStandardMaterial({color:0x28332e,roughness:.19,metalness:.15,transparent:true,opacity:.43});for(const q of BASEMENT_DAMP){const o=mesh(new T.CircleGeometry(q.r,24),wetMaterial);o.rotation.x=-Math.PI/2;o.scale.y=.6;o.position.set(q.x,F+.004,q.z);o.castShadow=false;}
 // Exactly one primary lamp, plus a very low indirect fill (no extra fixture).
 cyl(.006,.12,25.6,C-.06,25.2,black);cyl(.026,.065,25.6,C-.15,25.2,rust);const bulbMaterial=new T.MeshStandardMaterial({color:0xf4d9a1,emissive:0xffc679,emissiveIntensity:.9,roughness:.55});const bulb=mesh(new T.SphereGeometry(.047,14,10),bulbMaterial);bulb.scale.y=1.28;bulb.position.set(25.6,C-.23,25.2);bulb.castShadow=false;
 const light=new T.PointLight(0xffd39a,13,6.5,2);light.position.copy(bulb.position);light.castShadow=true;light.shadow.mapSize.set(512,512);light.shadow.camera.near=.08;light.shadow.camera.far=7;light.shadow.normalBias=.014;light.shadow.bias=-.0004;root.add(light);
 const ambient=new T.HemisphereLight(0x9c947b,0x252720,0);root.add(ambient);
 // Rectangular sheet-metal chute, following the same spline as the camera.
 const count=90,centres=CHUTE_CURVE.getSpacedPoints(count),frames=CHUTE_CURVE.computeFrenetFrames(count,false),vertices=[],uvs=[],indices=[];
 for(let i=0;i<=count;i++)for(const [j,[a,b]]of [[-.36,-.36],[.36,-.36],[.36,.36],[-.36,.36]].entries()){const v=centres[i].clone().addScaledVector(frames.normals[i],a).addScaledVector(frames.binormals[i],b);vertices.push(v.x,v.y,v.z);uvs.push(j/4,i/9);if(i<count){const n=i*4+j,k=i*4+(j+1)%4;indices.push(n,k,n+4,k,k+4,n+4);}}
 const chuteGeometry=new T.BufferGeometry();chuteGeometry.setAttribute('position',new T.Float32BufferAttribute(vertices,3));chuteGeometry.setAttribute('uv',new T.Float32BufferAttribute(uvs,2));chuteGeometry.setIndex(indices);chuteGeometry.computeVertexNormals();const chuteMaterial=mat('metal',0x858f83,.75,.55);chuteMaterial.side=T.DoubleSide;chuteMaterial.emissive=new T.Color(0x26352d);chuteMaterial.emissiveIntensity=.055;mesh(chuteGeometry,chuteMaterial);
 for(let i=5;i<count;i+=10){const c=centres[i],n=frames.normals[i],b=frames.binormals[i];for(const sign of [-1,1]){beam(c.clone().addScaledVector(n,-.355).addScaledVector(b,sign*.355),c.clone().addScaledVector(n,.355).addScaledVector(b,sign*.355),.007,rust);beam(c.clone().addScaledVector(n,sign*.355).addScaledVector(b,-.355),c.clone().addScaledVector(n,sign*.355).addScaledVector(b,.355),.007,rust);}}
 // Batch static meshes while respecting shadow flags and transparent puddles.
 root.updateMatrixWorld(true);const batches=new Map(),remove=[];root.traverse(o=>{if(!o.isMesh||o.material.transparent||o.parent===exitGate||o===privacyFace)return;const key=o.material.uuid+':'+o.castShadow;const g=(o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone()).applyMatrix4(o.matrixWorld);if(!batches.has(key))batches.set(key,{material:o.material,shadow:o.castShadow,parts:[]});batches.get(key).parts.push(g);remove.push(o);});for(const o of remove)o.removeFromParent();for(const b of batches.values()){const o=mesh(mergeGeometries(b.parts),b.material);o.castShadow=b.shadow;b.parts.forEach(g=>g.dispose());}
 const occluders=[];root.traverse(o=>{if(o.isMesh&&!o.material.transparent)occluders.push(o);});
 return {root,exitGate,updateExit,bounds:B,walking:{root,bounds:BASEMENT_WALK_BOUNDS,boxes,targets:[],occluders},floorAt:basementFloorAt,light,ambient,bulbMaterial,tv,wardrobe,update(time,floor){const above=T.MathUtils.clamp((floor-F)/(.84-F),0,1);const phase=time%19.3,power=phase>17.6&&phase<17.83?.73+.17*Math.sin(time*73):1;light.intensity=13*power;bulbMaterial.emissiveIntensity=.9*power;ambient.intensity=.18*(1-above);return above;}};
}
