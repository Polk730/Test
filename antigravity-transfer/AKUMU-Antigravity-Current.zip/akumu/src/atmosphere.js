import * as T from 'three';
import {random} from './textures.js';
// Rare, seeded fault envelopes; interpolated dips avoid repeated on/off strobing.
export class LampFaults {
 constructor(seed=207){this.random=random(seed);this.next=3.6;this.start=-100;this.duration=0;this.depth=0;}
 sample(time){
  if(time>=this.next){this.start=time;this.duration=.16+this.random()*.32;this.depth=this.random()<.16?.69:.12+this.random()*.20;this.next=time+5+this.random()*11;}
  const phase=(time-this.start)/this.duration;
  const dip=phase>=0&&phase<=1?Math.sin(Math.PI*phase)**2*this.depth:0;
  return 1-dip+Math.sin(time*1.73)*.006+Math.sin(time*4.19)*.003;
 }
}
// One deliberate outage on the real active-play clock; paused/background time does not advance it.
export class KeyBlackout {
 constructor(){this.startedAt=null;}
 trigger(time){if(this.startedAt!==null)return false;this.startedAt=time;return true;}
 sample(time){
  if(this.startedAt===null)return 1;const age=Math.max(0,time-this.startedAt);
  if(age<.5){const points=[[0,1],[.055,.28],[.13,.72],[.22,.18],[.31,.5],[.40,.12],[.5,0]];for(let i=1;i<points.length;i++){const [end,b]=points[i],[start,a]=points[i-1];if(age<=end){const t=(age-start)/(end-start),s=t*t*(3-2*t);return a+(b-a)*s;}}}
  if(age<2.5)return 0;const t=Math.min(1,(age-2.5)/.18);return t*t*(3-2*t);
 }
}
export function contactOcclusion(scene){
 const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const c=canvas.getContext('2d');
 const g=c.createRadialGradient(64,64,8,64,64,64);g.addColorStop(0,'#000000aa');g.addColorStop(.48,'#00000066');g.addColorStop(1,'#00000000');c.fillStyle=g;c.fillRect(0,0,128,128);
 const map=new T.CanvasTexture(canvas);
 const material=new T.MeshBasicMaterial({map,transparent:true,opacity:.48,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1});
 function patch(x,z,w,d,opacity=.48){const m=material.clone();m.opacity=opacity;const mesh=new T.Mesh(new T.PlaneGeometry(w,d),m);mesh.rotation.x=-Math.PI/2;mesh.position.set(x,.018,z);mesh.renderOrder=1;mesh.userData.noBatch=true;mesh.userData.noOcclude=true;scene.add(mesh);}
 patch(-1.66,-.27,1.7,2.65,.63);patch(-.57,-1.52,.85,.83,.55);patch(2.2,-.65,.9,1.35,.62);
 for(const x of [-2.35,2.35])for(const z of [-1.85,1.85])patch(x,z,1.1,1.1,.38);
 const edgeCanvas=document.createElement('canvas');edgeCanvas.width=8;edgeCanvas.height=128;const ec=edgeCanvas.getContext('2d');const eg=ec.createLinearGradient(0,0,0,128);eg.addColorStop(0,'#00000000');eg.addColorStop(.65,'#00000014');eg.addColorStop(1,'#00000088');ec.fillStyle=eg;ec.fillRect(0,0,8,128);const edgeMap=new T.CanvasTexture(edgeCanvas);
 const edgeMat=new T.MeshBasicMaterial({map:edgeMap,transparent:true,opacity:.45,depthWrite:false});
 for(const [x,z,w,angle]of [[0,-1.989,5,0],[0,1.989,5,Math.PI],[-2.489,0,4,Math.PI/2],[2.489,0,4,-Math.PI/2]]){const o=new T.Mesh(new T.PlaneGeometry(w,.55),edgeMat);o.position.set(x,.29,z);o.rotation.y=angle;o.userData.noBatch=true;o.userData.noOcclude=true;scene.add(o);}
}
