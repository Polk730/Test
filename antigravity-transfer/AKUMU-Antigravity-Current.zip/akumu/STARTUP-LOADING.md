# Startup loading

Flow: Play → NORMAL/DEMO → name entry → loading screen → existing wake-up sequence. The ROOM 2/ROOM 3 test buttons use the same loading step after name entry.

The selected route is constructed ahead of play: NORMAL prepares Storage, the duct and Laundry; DEMO prepares its Observation Room/recordings without entering it or starting its events. The loader uploads textures, decodes narration and prepares the existing generated sound variants, GPU geometry, room/transition lighting profiles, inspection materials and future display/scare rendering resources. Preparation draws are hidden behind an opaque pixel-styled loading screen. No puzzle, dialogue, room layout or control scheme is changed.

The wake-up audio/animation is scheduled afterward. Loading does not count toward the escape timer or advance environmental events. Progress reflects completed preparation work. An interrupted preparation step shows a retry button. Viewport/culling/visibility/light state is restored before play, including screen rotation during loading.

Changed runtime files: `index.html`, `src/style.css`, `src/main.js`, new `src/game-preload.js`, and non-playing GPU preparation methods in `src/observation-room.js` / `src/spider-scare.js`. `package.json` adds `npm run test:loading`; the preservation test allows these explicit preparation hooks.

All assets remain embedded in the standalone HTML. No API keys, external services or new dependencies are needed. This moves initial construction and GPU preparation upfront; actual frame rate and driver/resource eviction costs still depend on the device. Physical iPad performance is not benchmarked.

## Verification

- Standalone and web builds passed (Vite's existing large-chunk advisory remains).
- 60 existing unit tests and 2 Laundry state/collision tests passed.
- Preservation audit: 78 protected original source/assets files and 29 unrelated main functions remain byte-identical. The explicit startup UI and non-playing rendering preparation hooks are allowed changes.
- Desktop NORMAL and emulated-touch DEMO browser tests passed for the exact menu/name/loading/wake-up order, completed progress, zero escape-clock advancement during loading, untouched room/event states, restored viewport and controls.
- One injected preparation failure verified the retry path. A landscape-to-portrait resize during touch loading verified viewport restoration.
- Route fixtures crossed the actual Room 1 doorway into the selected Room 2 and reused the prebuilt instances. NORMAL then entered the duct; a separate test used ROOM 3 / TEST and opened the grille into Laundry. These fixtures bypass previously tested puzzle prerequisites; they are not new full puzzle playthroughs.
- In these software-Chromium checks, compiled program counts stayed 144→144 for NORMAL/duct and duct→Laundry, and 77→77 for DEMO entry. This demonstrates cache reuse for the tested transitions, not a universal FPS guarantee.
- Loading-screen screenshots were visually inspected. Physical iPad testing and a hardware frame-rate benchmark were not performed.
