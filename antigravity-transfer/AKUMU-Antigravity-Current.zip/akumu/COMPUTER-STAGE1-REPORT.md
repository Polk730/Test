# AKUMU — Room 2 computer and Stage 1

Later update: Stage 2 is now implemented. See `STAGE2-REPORT.md` for the current inventory puzzle and permanent access to both Boxes 1 and 2; Stage 1-only descriptions below record the earlier implementation.

## Files changed

New runtime modules:
- `src/computer-stage.js`: one persistent random four-letter sequence, full A–I translation, strict numeric answer validation and Stage 1 completion.
- `src/box-stacking.js`: exactly three designated boxes, shelf homes, glowing-only pickup, carried state and safe supported placement.
- `src/storage-computer.js`: aged CRT/keyboard, physical clue, numbered sealed crates, inaccessible reserved wrench and Box 1 glow.
- `src/computer-interface.js`: power, four-stage menu, Stage 1 answer form and exit controls; the earlier box placement menu is removed.

Modified runtime/UI files:
- `src/storage-room.js`: reserve one shelf bay for the computer, install the required objects, add targets/occluders, and name the wrench as the future vent tool.
- `src/main.js`: route computer/clue/box interactions, modal input handling, dynamic box collision footprints and timer continuity.
- `index.html`, `src/style.css`: scoped terminal/box interfaces. Existing Room 1 interfaces retain their behavior.

Verification/docs:
- New `tests/computer-stage.test.js`, `tests/computer-stage.mjs`; updated `tests/storage-room.mjs` for the newly specified future wrench metadata. Existing prototype/envelope tests use lower test pixel density for software WebGL.
- `package.json`, `README.md`, `VALIDATION.md`, this report, regenerated HTML/build/download packages.

## Placement

The CRT and physical keyboard occupy a front shelf bay beside aisle 2, at x=3.81, z=4.72. Only that bay's backing and stored contents at the computer's level were cleared; shelf supports, floor plan, lighting and surrounding storage remain in place.

The physical LETTER / NUMBER sheet is on the left-facing side of a rear shelf beside aisle 4, at x=7.285, z=8.75. It uses the existing inspect/rotate/zoom controls.

The three numbered crates sit on ordinary shelf levels at y=1.2325: Box 1 at x=2.3, z=7.825; Box 2 at x=6, z=4.725; Box 3 at x=9.75, z=7.9. Their selected bays are cleared at that level. Shelf supports/layout remain unchanged. They no longer start beside the vent.

## Stage 1

Interact with the computer using E/left-click or touch INTERACT. POWER ON opens a menu containing exactly four stages. Stage 1 is selectable; Stages 2–4 are disabled and remain locked permanently in this update.

The sequence contains four random letters from A–I. The physical clue supplies the complete one-digit mapping A=1 through I=9, so concatenating the translations in order yields one unambiguous four-digit answer. Inputs containing letters, signs, scientific notation, wrong length, zero or an incorrect answer are rejected. The sequence is created once per game run and persists through closing/reopening and repeated power-on calls. Completion persists for that run; reloading starts a new run, consistent with the existing game.

Correct entry marks Stage 1 completed and gives Box 1 a restrained emissive glow. No narration, sound event, jumpscare, later stage, box opening, tool pickup or ending is triggered. EXIT COMPUTER or Esc returns to first-person controls. Time spent at the terminal is included in the existing escape timer.

## Box behavior

Only the currently glowing reward can move. Stage 1 enables Box 1; Boxes 2 and 3 remain fixed. E/left-click or touch INTERACT picks up the glowing crate, which follows the camera like the hammer. G/touch DROP sets it onto nearby clear floor; empty-target interaction also sets it down. Hammer and crate carrying are mutually exclusive. The old movement/reset panel is removed.

Drops check bounds, static obstacles, the route out of the player's aisle, player overlap and supported placement. If no clear location is available, the crate stays held with feedback. Floor crates remain stable and recoverable; no throwing or free rigid-body solver is used. Generic supported placement remains covered for future rewards, but production does not grant movement to Boxes 2 or 3. No automatic teleport to vent pads occurs.

Box 1 stays sealed, including while glowing and while moved. Its reserved wrench model is inside, hidden and untargetable. There is no opening, collecting or using action. Stages 2–4 have no puzzle code or automatic unlock path.

## Validation and limits

Executed checks:
- All 30 unit checks passed (the existing 27 plus three new computer/stacking checks).
- Standalone HTML and production builds passed.
- Desktop and touch-emulated Chromium passed physical computer/clue interaction, power/menu, wrong-answer rejection, correct answer acceptance, persistent sequence/completion and locked Stages 2–4 before/after completion.
- Box 1 was not glowing before completion and glowed afterward while its body remained closed and the wrench hidden. No box-opening action exists in the UI. No new ending was triggered.
- The earlier three-box placement-menu checks are historical. The current carry/drop interaction supersedes that UI; see the latest validation entry for executed checks.
- The full existing Room 1 puzzle regression passed through physical entry into Room 2, including the original drawer combination, hammer, barricade and hidden key. No early ending or page/console errors.
- Existing envelope inspection/open/reopen passed on desktop and touch. Visual review covered the physical CRT, clue, completed four-stage menu and restrained Box 1 glow in a three-box stack.

See the latest computer section of `VALIDATION.md` for details. Unit coverage includes 200 generated puzzles with full-key validation, incorrect-input rejection, Stage 1-only completion, repeated stable placement/reset and player overlap rejection. Browser coverage distinguishes real E/touch interaction from debug camera positioning used to repeatably approach objects.

The current build remains a browser prototype. No physical iPad/Safari or school-computer GPU benchmark is implied by Chromium touch emulation and software WebGL. Vite retains its existing nonblocking bundle-size advisory. No new shadow-casting light, post-processing pass or large external asset is introduced; screen/box emission uses materials under the existing lighting.

## Intentionally unfinished

Stages 2, 3 and 4 remain locked and have no implemented puzzles. Box 1 cannot open. Its wrench cannot be obtained or used. Box step-up is now implemented at the user’s request. The complete staircase still needs the locked Boxes 2 and 3; no vent-opening or new escape interaction is added. The existing future-only vent/ending integration remains separate; its reserved tool metadata follows the new wrench specification, and the new computer/box system never invokes that hook. Existing ending code and text are unchanged.


## Embedded startup compatibility and lighting follow-up
The user's in-app startup issue was reproduced in an iframe allowing scripts but omitting `allow-forms` and pointer-lock permission: native submission blocked WAKE UP. `src/main.js` now handles WAKE UP click/Enter directly and prevents native submission, retaining the name filter. `src/computer-interface.js` uses the same pattern for terminal answers. `tests/embedded-start.mjs` verified click/touch/Enter, rejected invalid names, normal waking, Room 2 direct entry, keyboard movement without capture, and terminal submissions in that restricted iframe. This is browser emulation, not a live test inside the ChatGPT app.

At the user's request, Room 2 now has stronger neutral indirect/ground bounce and two additional unshadowed fills aimed into the formerly dark shelf areas. Existing ceiling-light powers and two shadow casters remain; Room 1 lighting settings are unchanged. `tests/storage-lighting.mjs` captures front and rear rows of all six aisles for visual review.


## Glowing shelf-box carry revision
At the user’s request, the crates are stored in shelf bays and carried through the existing interaction/drop controls. Only glowing Box 1 moves after Stage 1; later stages and unlit crate movement stay locked. The selected bay contents/backing are cleared only where necessary for the crate placements. No box opening or wrench use is added.


Latest carry-revision validation: all 30 unit checks and both builds passed. Desktop/touch browser checks passed glowing-only shelf pickup, camera-relative carrying, G/DROP, stable floor placement and re-pickup while preserving the other two crate positions. Full Room 1 puzzle/hammer-drop and doorway progression also passed. These current carry controls replace the earlier placement-menu behavior described in historical validation entries.


## Through-wall reward outline and floor markings
`src/storage-computer.js` adds a green depth-independent outline only to the currently glowing reward. It hides while carried and follows the crate after dropping; physical interaction range and obstruction checks are unchanged. New `src/box-floor-markings.js` paints three worn numbered BOX guides beneath the high shaft. The guides are visual only: they do not teleport crates, unlock later stages, open Box 1 or enable escape. `tests/box-guides.mjs` checks the after-Stage-1-only outline and guide placement, with screenshots for visual review.


Latest locator/guide validation: actual Stage 1 completion enabled only Box 1's through-wall outline; reviewed its visibility through shelving and all three readable floor markings beneath the shaft. The crate stays closed and normal interaction rules remain. Both builds and the focused browser check passed.


## Staircase guide/climbing revision
The guides are now aligned toward the shaft: Box 1 is the first step at (10.35, 9.8); Box 2 goes at (10.35, 10.45), with Box 3 on top of it. The shared second footprint reads “2 + 3 / 3 ON TOP OF 2.” `src/crate-walking.js` adds Room 2-only supported step-up and safe step-down/falling, integrated in `src/main.js`. Walking onto a placed crate raises the player view; no new jump control is required. Existing static wall/rack collision and Room 1 movement are retained.

All 33 unit checks passed, including the full two-level arrangement as an isolated future-box geometry fixture, rejection of a high column without the first step, and safe return to floor/removal of support. Desktop and touch browser tests passed actual Box 1 pickup, placement at its guide, walking/joystick step-up and step-down. Later-box pickup, vent opening and ending remain locked/untriggered. The full three-box climb is not currently player-completable because Stages 2–4 are still locked, as required.
