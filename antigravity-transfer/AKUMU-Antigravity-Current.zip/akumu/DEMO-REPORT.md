# AKUMU — NORMAL / DEMO and The Observation Room

## Launch and reset
Open the standalone HTML in a browser. PLAY now offers NORMAL and DEMO, followed by the same existing name entry.

- NORMAL: original Room 1 → original storage Room 2, including the PC stages, assistance, recognition event, boxes/wrench/vent and ending.
- DEMO: original Room 1 → the new Observation Room → its metal exit → TO BE CONTINUED...

The existing ROOM 2 / TEST shortcut still starts the normal storage room. RETURN TO TITLE on the pause screen reloads the standalone page for a completely fresh run; the DEMO ending also offers this button. No save-state or cross-mode puzzle state is retained.

## Observation Room
A separate seven-by-six-metre 1980s surveillance office includes three aged CRTs, one functional VHS deck, numbered archive bays, a wooden desk, tape archive shelves, a metal cabinet, a large dark one-way mirror and a hinged metal exit. Walls and furniture have collision. The mirror is decorative only, with no figure, special reflection camera or scare. Existing surface textures/materials, renderer, first-person movement and audio buses are reused. No player model, hands, feet, inventory panel, sprint or gameplay music was added.

Exactly three important VHS tapes remain at fixed desk/shelf/cabinet locations. They have visible reels and non-chronological repair patches; no solution labels. E/left-click/touch INTERACT picks up one cassette, inserts/ejects it at the deck or places/removes it from a bay. G/touch DROP (or empty-target interaction) uses the existing carry/drop convention. Gravity settles dropped tapes on the floor; placement rejects walls/furniture, out-of-bounds and coincident tapes, and an impossible drop keeps the tape in hand. No tape is destroyed or consumed.

Recordings are stills rendered from the actual existing Room 1 scene before the wake-up sequence. The capture temporarily changes visual drawer/hammer/board poses and restores them in a finally block. They show the boarded window/closed drawer, open drawer/visible hammer and unboarded window. Each plays for seven seconds with animated scanlines, noise/static and light distortion. Any tape can be replayed. Its final still remains visible after playback until another state replaces it.

The only main puzzle is chronological ordering in 01/02/03. VERIFY works only with all bays filled. Wrong orders display SEQUENCE INVALID and a soft error noise without resetting tapes or imposing a penalty. Tapes can be removed/rearranged. Correct ordering permanently restores the archive and unlocks the exit. Viewing all tapes is not a forced verification prerequisite; fast completion remains possible.

## Four one-shot events
1. Shortly after entry, a CRT powers on and the existing caption element presents the first new narrator line.
2. Picking up the second distinct cassette briefly displays YOU'VE BEEN HERE BEFORE. on the middle CRT, with no new narrator comment.
3. Viewing all three recordings causes the one-second light dip/crackle and the two specified narrator captions, without blocking play.
4. Correct verification darkens the other CRTs and switches the middle screen to the actual live view, initially overlaid with the requested archive/connection message and then CAM 04 / occupancy / visual-confirmation status.

**The three new narrator lines are captions only until the user supplies their recordings.** No generated/replacement voice was used. Existing Room 1/NORMAL recordings remain in place. During the live feed and exit fade, the voice bus is muted, new narration is refused and narrator captions are suppressed. The invitation described below is allowed only after the black ending title plus three seconds.

## Live camera and ending
One fixed upper-corner PerspectiveCamera renders the current shared 3D scene to a 512×320 GPU render target, capped at 10 updates/second. This is not a still-image substitute. World tapes, lighting and door changes appear in the view. No player/avatar/silhouette is created. The first-person held prop is excluded only from the CCTV pass; the monitor's own sampling surface is also hidden during capture to prevent recursive framebuffer feedback. Objects on the floor/slots remain visible.

After unlocking, normal interaction opens the metal door. Walking through its doorway triggers the existing fade-to-black flow and TO BE CONTINUED... rather than the storage room. The exit event is guarded against duplicates, and gameplay stops. There is no final narrator line or observer explanation.

## Files changed
New runtime modules:
- `src/observation-state.js`: physical tape locations/ownership, replay/order rules, safe drops, one-shot story/caption state and exit/reset guards.
- `src/observation-room.js`: geometry/collision/targets, cassette/VCR/bay visuals, CRT/VHS rendering and the live GPU camera.
- `src/bedroom-recordings.js`: actual Room 1 still captures with restoration.

Integration:
- `src/main.js`: mode selection, conditional room routing, existing interaction/drop/movement integration, DEMO caption/audio signals and live-pass dispatch.
- `src/audio.js`: recognition/final silence also sets the intrinsic voice gain to zero, so an idle voice bus is muted as well as its automation; existing mute/restore tests pass.
- `index.html`, `src/style.css`: matching pixel-style mode picker and return-to-title controls.

Tests/build/docs: new observation state, preview and desktop/touch flow scripts; existing PLAY fixtures now explicitly select NORMAL; package scripts, README/validation/report and regenerated downloads.

`src/room.js`, `src/puzzle.js`, `src/storage-room.js` and `src/computer-stage.js` remain byte-identical to the saved pre-DEMO baseline.

## Verification and limitations
Final HTML/production builds and all 55 unit checks passed. Desktop and touch DEMO flows passed tape carrying/drop/recovery, all recordings/replay, wrong/correct order/rearrangement, all four one-shot events, actual changing live render, final silence, physical exit and ending. Desktop restart/switching passed. The complete original NORMAL bedroom route and normal storage/wrench/vent escape regression also passed. Screenshots were reviewed. An offline packaged-document smoke passed without external assets, including actual VHS drawing. Direct file:// testing was blocked by this managed browser’s administrator policy; the fallback used an intercepted offline document. See the latest DEMO entry in VALIDATION.md for details and honest limits. Physical iPad/Safari and hardware FPS are not implied by Chromium touch emulation or software WebGL.

The suggested five-minute office / ten-minute total duration is a pacing target, not a measured human-playtest result. No artificial completion gate or unrelated puzzle was added to enforce it. New narrator audio remains pending; every new caption and final silence is implemented now.


## Final DEMO invitation
Only the DEMO Observation Room ending changes. After the black fade and TO BE CONTINUED... first appear, a one-shot controller waits three seconds, displays the requested invitation with (Narrator), and reveals PLAY FULL VERSION afterward. The button reloads a fresh NORMAL session directly into its standard name entry; no DEMO puzzle state carries over. The existing return-to-title remains available.

The final invitation recording has not been supplied. The current playable build uses a ten-second caption-only placeholder. `audio.startDemoInvitation()` is ready for `demoInvitationBuffer`; when supplied, its actual playback completion gates the button. It uses the existing narrator voice bus at normal speed, with world SFX/ambience muted, and never starts during the live feed. No synthesized replacement voice or external dependency was added.

Changed runtime files: index.html, src/main.js, src/audio.js, src/style.css and the isolated src/demo-invitation.js timing controller. Added timing and browser-flow tests; original bedroom, storage and Observation geometry/puzzle modules were not edited for this update.

Validation for this update: 58 unit checks and both builds passed. Desktop/caption and Chromium touch/silent-audio-buffer checks passed live narration suppression, black/title delay, single trigger, completion gating, PLAY FULL VERSION → empty NORMAL name entry → original Room 1, and no invitation in the NORMAL ending. No page errors. The actual final narrator MP3 and physical iPad/Safari remain untested. The black ending/CTA screenshot was reviewed.

## Observation Room SFX and exit clarity
Added src/observation-audio.js, using the existing Web Audio SFX/ambience buses and HRTF positioning for the deck and exit. Quiet CRT hum and transport noise stop during the final live feed and ending; no new narration or music was added. Five short deterministic foley sounds were added in audio-synthesis.js without changing existing sounds. main.js routes only Observation Room signals through this module and shows a scoped contextual exit prompt. observation-room.js adds a persistent locked/unlocked sign above the existing exit and a small green indicator/spill after archive restoration. No door geometry, collision, puzzle conditions or room layout was changed. The final DEMO invitation remains caption-only pending the user's recording.

A scoped style exception makes the DEMO exit prompt visible despite the existing global hidden-HUD styling; other room prompts remain unchanged. Spatial parameters use modern AudioParam values with a legacy fallback.

SFX/exit validation: 58 unit checks, both builds, and final desktop/touch browser checks passed, including visible prompts, actual door opening, positional cues, motor/tone gating and narrator silence. The final desktop exit screenshot was reviewed. No page/WebGL console errors were recorded. Physical iPad/Safari and speaker listening remain untested.
