# Clarification before coding

Apply `.agents/skills/clarify-before-coding/SKILL.md` to every coding request without requiring a special trigger.

For every coding request, silently assess whether the intended outcome and constraints are sufficiently clear.

1. If clear, act immediately. Do not ask ritual confirmation questions.
2. If a missing detail could materially change the result, cause destructive changes, or conflict with existing requirements, ask the smallest number of precise questions before proceeding.
3. If a missing detail is minor, choose a reasonable, reversible default and continue. State the assumption briefly when it matters.
4. Reuse answers and decisions from the current conversation and repository instructions; do not re-ask resolved questions.
5. Honor explicit scope restrictions such as 'inspect only' and 'do not change code'.
6. Never require the user to append 'Questions?' or any special trigger phrase.
7. Once the necessary information is provided, continue with the task without another approval loop unless a new consequential ambiguity arises.
8. When instructions conflict, identify the specific conflict rather than guessing.
