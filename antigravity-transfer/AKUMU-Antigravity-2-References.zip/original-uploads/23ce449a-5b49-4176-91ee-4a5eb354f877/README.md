# Clarify Before Coding — Codex

This package includes:
- `SKILL.md`: reusable Codex skill
- `AGENTS.md`: always-on instruction snippet

## Install the skill locally

Copy the `clarify-before-coding` folder into `~/.agents/skills/` (Windows: `%USERPROFILE%\.agents\skills\`).

## Enable always-on behavior

For each repository (including cloud Codex projects), merge the contents of this package's `AGENTS.md` into the repository root `AGENTS.md`, then commit the change. Do not overwrite existing instructions.

For personal Codex environments, you can also merge the guidance into your Codex home `AGENTS.md` where supported.

**Why both?** Skills may be selected only when relevant. `AGENTS.md` makes the clarification policy part of the repository instructions, so you do not need to write 'Questions?' in every request.
